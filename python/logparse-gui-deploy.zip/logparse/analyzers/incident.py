#!/usr/bin/env python3
"""Incident timeline analyzer — reconstruct attack narrative with MITRE mapping."""

from __future__ import annotations

from collections import defaultdict
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import SEVERITY_LEVELS, LogEvent, get_field
from logparse.util import format_number

_IP_FIELDS = {"srcip", "dstip", "src", "dst", "ipaddr", "ip", "clientip",
              "remip", "local_ip", "remote_ip"}
_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser", "account", "samaccountname"}


def analyze_incident(events: list[LogEvent], console: Console) -> None:
    """Build chronological incident timeline around the highest-risk entity."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    console.rule("Incident Timeline Reconstruction", style="bold red")

    # Find pivot entity — the entity with most high-severity events
    entity_severity: defaultdict[str, int] = defaultdict(int)
    entity_events: defaultdict[str, list[LogEvent]] = defaultdict(list)

    severity_weights = {"Critical": 10, "High": 5, "Medium": 2, "Low": 1, "Info": 0}

    for e in events:
        weight = severity_weights.get(e.severity, 0)
        if weight == 0:
            continue

        # Collect all entities from this event
        entities: set[str] = set()
        for field in _IP_FIELDS:
            val = get_field(e, field)
            if val:
                entities.add(f"ip:{val}")
        for field in _USER_FIELDS:
            val = get_field(e, field)
            if val and len(val) > 1:
                entities.add(f"user:{val.lower()}")

        for entity in entities:
            entity_severity[entity] += weight
            entity_events[entity].append(e)

    if not entity_severity:
        console.print("[dim]No high-severity events to build incident timeline.[/dim]")
        return

    # Pick top entity as pivot
    pivot = max(entity_severity, key=entity_severity.get)
    pivot_type, pivot_value = pivot.split(":", 1)
    pivot_evts = entity_events[pivot]

    console.print(f"  Pivot entity: [bold]{pivot_value}[/bold] ({pivot_type})")
    console.print(f"  Related events: {format_number(len(pivot_evts))}")
    console.print(f"  Risk score: {entity_severity[pivot]}")

    # Sort by timestamp
    pivot_evts.sort(key=lambda e: e.timestamp if e.timestamp else datetime.max)

    # Try MITRE mapping
    tactic_map = _get_tactic_map()

    # Build timeline table
    console.print()
    table = Table(title="Event Timeline", border_style="dim", show_lines=True)
    table.add_column("Time", style="dim", width=19)
    table.add_column("Sev", width=8)
    table.add_column("Tactic", style="cyan", width=16)
    table.add_column("Source", width=15)
    table.add_column("Event", ratio=1)

    displayed = 0
    max_display = 50
    for e in pivot_evts:
        if displayed >= max_display:
            break

        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else ""
        sev_colors = {"Critical": "red", "High": "bright_red", "Medium": "yellow", "Low": "green", "Info": "cyan"}
        sev_color = sev_colors.get(e.severity, "dim")
        sev = f"[{sev_color}]{e.severity}[/{sev_color}]"

        # Map to tactic
        tactic = _map_tactic(e, tactic_map)

        msg = e.message[:80] + "..." if len(e.message) > 80 else e.message
        source = e.source[:15] if e.source else ""

        table.add_row(ts, sev, tactic, source, msg)
        displayed += 1

    console.print(table)

    remaining = len(pivot_evts) - displayed
    if remaining > 0:
        console.print(f"  [dim]... and {format_number(remaining)} more events[/dim]")

    # Summary
    severities = defaultdict(int)
    for e in pivot_evts:
        severities[e.severity] += 1
    console.print("\n[bold]Severity Breakdown:[/bold]")
    for sev in SEVERITY_LEVELS:
        if severities[sev]:
            console.print(f"  {sev}: {severities[sev]}")

    # Time range
    timestamps = [e.timestamp for e in pivot_evts if e.timestamp]
    if len(timestamps) >= 2:
        span = timestamps[-1] - timestamps[0]
        console.print(f"\n  Time span: {span}")


def _get_tactic_map() -> dict[str, str]:
    """Try to load MITRE technique mapping."""
    try:
        from logparse.mitre import TECHNIQUES
        return {t.technique_id: t.tactic for t in TECHNIQUES.values()}
    except ImportError:
        return {}


def _map_tactic(event: LogEvent, tactic_map: dict[str, str]) -> str:
    """Attempt to map an event to a MITRE tactic."""
    try:
        from logparse.mitre import TECHNIQUES, _matches_technique
        for sig in TECHNIQUES.values():
            if _matches_technique(event, sig):
                return sig.tactic
    except ImportError:
        pass

    # Heuristic fallback based on event patterns
    msg = event.message.lower()
    action = (get_field(event, "action") or "").lower()

    if any(k in msg for k in ("login", "auth", "credential", "password")):
        if any(k in msg for k in ("fail", "deny", "reject")):
            return "Credential Access"
        return "Initial Access"
    if any(k in msg for k in ("execute", "process", "command", "script")):
        return "Execution"
    if any(k in msg for k in ("privilege", "escalat", "admin", "root")):
        return "Priv Escalation"
    if action in ("deny", "blocked", "drop"):
        return "Defense Evasion"
    if any(k in msg for k in ("lateral", "remote", "psexec", "wmi")):
        return "Lateral Movement"
    if any(k in msg for k in ("exfil", "upload", "transfer")):
        return "Exfiltration"

    return ""
