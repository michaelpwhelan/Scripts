#!/usr/bin/env python3
"""SLA/performance analyzer — availability, latency, and failure metrics."""

from __future__ import annotations

import statistics
from collections import Counter
from datetime import timedelta

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


# Actions indicating failure
_FAIL_ACTIONS = {"deny", "denied", "blocked", "drop", "dropped", "fail", "failed",
                 "error", "timeout", "rejected", "forbidden", "unavailable"}


def analyze_sla(events: list[LogEvent], console: Console) -> None:
    """Calculate SLA metrics: availability, failure rates, latency stats."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    console.rule("SLA / Performance Metrics", style="bold cyan")

    # Time range
    timestamps = sorted(e.timestamp for e in events if e.timestamp)
    if len(timestamps) < 2:
        console.print("[dim]Need timestamped events for SLA analysis.[/dim]")
        return

    total_span = timestamps[-1] - timestamps[0]
    total_minutes = total_span.total_seconds() / 60

    # Failure rate
    total_events = len(events)
    fail_events = 0
    for e in events:
        action = (get_field(e, "action") or "").lower()
        if action in _FAIL_ACTIONS:
            fail_events += 1
        elif e.severity in ("Critical", "High") and any(
            k in e.message.lower() for k in ("error", "fail", "timeout", "unreachable")
        ):
            fail_events += 1

    failure_rate = fail_events / max(total_events, 1) * 100

    # Gap analysis — find periods with no events (potential downtime)
    gap_threshold = timedelta(minutes=max(total_minutes / 100, 5))  # dynamic threshold
    gaps: list[tuple[int, int, timedelta]] = []  # (start_idx, end_idx, duration)

    for i in range(len(timestamps) - 1):
        gap = timestamps[i + 1] - timestamps[i]
        if gap > gap_threshold:
            gaps.append((i, i + 1, gap))

    total_gap_minutes = sum(g[2].total_seconds() / 60 for g in gaps)
    availability = (1 - total_gap_minutes / max(total_minutes, 1)) * 100
    availability = max(0, min(100, availability))

    # Availability color
    avail_color = "green" if availability >= 99 else "yellow" if availability >= 95 else "red"

    # Latency stats (if duration field exists)
    latency_values: list[float] = []
    for e in events:
        for field in ("duration", "latency", "rtt", "senttime", "rcvdtime"):
            val = get_field(e, field)
            if val:
                try:
                    latency_values.append(float(val))
                    break
                except (ValueError, TypeError):
                    continue

    # Build summary panel
    lines = [
        f"  [bold]Time Range:[/bold]    {timestamps[0].strftime('%Y-%m-%d %H:%M')} — {timestamps[-1].strftime('%Y-%m-%d %H:%M')}",
        f"  [bold]Duration:[/bold]      {_fmt_duration(total_span)}",
        f"  [bold]Total Events:[/bold]  {format_number(total_events)}",
        "",
        f"  [bold]Availability:[/bold]  [{avail_color}]{availability:.2f}%[/{avail_color}]",
        f"  [bold]Failure Rate:[/bold]  {'[red]' if failure_rate > 10 else ''}{failure_rate:.1f}% ({format_number(fail_events)} events){'[/red]' if failure_rate > 10 else ''}",
        f"  [bold]Event Gaps:[/bold]    {len(gaps)} gaps > {_fmt_duration(gap_threshold)}",
    ]

    if latency_values and len(latency_values) >= 2:
        sorted_lat = sorted(latency_values)
        n = len(sorted_lat)
        lines.extend([
            "",
            "  [bold]Latency (ms):[/bold]",
            f"    Min:    {sorted_lat[0]:,.1f}",
            f"    Mean:   {statistics.mean(latency_values):,.1f}",
            f"    Median: {statistics.median(latency_values):,.1f}",
            f"    P95:    {sorted_lat[min(int(n * 0.95), n - 1)]:,.1f}",
            f"    P99:    {sorted_lat[min(int(n * 0.99), n - 1)]:,.1f}",
            f"    Max:    {sorted_lat[-1]:,.1f}",
        ])

    console.print(Panel("\n".join(lines), title="SLA Summary", border_style="cyan"))

    # Significant gaps table
    if gaps:
        gaps.sort(key=lambda g: g[2], reverse=True)
        table = Table(title="Significant Event Gaps", border_style="dim")
        table.add_column("Start", style="dim")
        table.add_column("End", style="dim")
        table.add_column("Duration", justify="right", style="yellow")

        for start_idx, end_idx, gap_dur in gaps[:10]:
            start_ts = timestamps[start_idx]
            end_ts = timestamps[end_idx]
            table.add_row(
                start_ts.strftime("%Y-%m-%d %H:%M"),
                end_ts.strftime("%Y-%m-%d %H:%M"),
                _fmt_duration(gap_dur),
            )

        console.print(table)

    # Failure sources
    fail_sources: Counter[str] = Counter()
    for e in events:
        action = (get_field(e, "action") or "").lower()
        if action in _FAIL_ACTIONS:
            fail_sources[e.source or "(unknown)"] += 1

    if fail_sources:
        console.print("\n[bold]Top Failure Sources:[/bold]")
        for source, count in fail_sources.most_common(5):
            console.print(f"  {source}: {format_number(count)}")


def _fmt_duration(td: timedelta) -> str:
    """Format a timedelta for display."""
    total_secs = int(td.total_seconds())
    if total_secs < 60:
        return f"{total_secs}s"
    if total_secs < 3600:
        return f"{total_secs // 60}m {total_secs % 60}s"
    hours = total_secs // 3600
    mins = (total_secs % 3600) // 60
    if hours < 24:
        return f"{hours}h {mins}m"
    days = hours // 24
    hours = hours % 24
    return f"{days}d {hours}h"
