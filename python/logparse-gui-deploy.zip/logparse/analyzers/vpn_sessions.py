#!/usr/bin/env python3
"""VPN session analysis — lifecycle tracking and impossible travel detection."""

from __future__ import annotations

import ipaddress
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_IMPOSSIBLE_TRAVEL_MINUTES = 30


@dataclass
class VpnSession:
    """Tracks VPN session lifecycle and traffic counters."""

    user: str
    remote_ip: str = ""
    tunnel_ip: str = ""
    start: datetime | None = None
    end: datetime | None = None
    bytes_sent: int = 0
    bytes_recv: int = 0
    duration_sec: float = 0
    action: str = ""


def _is_vpn_event(event: LogEvent) -> bool:
    """Check if event is VPN-related."""
    subtype = event.extra.get("subtype", "").lower()
    if subtype in ("vpn", "sslvpn"):
        return True
    msg = event.message.lower()
    return any(k in msg for k in (
        "tunnel", "vpn", "ssl-vpn", "ipsec", "dial-up",
        "tunnel-up", "tunnel-down", "vpn-connection",
    ))


def _same_slash16(ip1: str, ip2: str) -> bool:
    """Check if two IPs are in the same /16 subnet."""
    try:
        a = ipaddress.ip_address(ip1)
        b = ipaddress.ip_address(ip2)
        net = ipaddress.ip_network(f"{a}/16", strict=False)
        return b in net
    except (ValueError, TypeError):
        return False  # can't compare — flag as different subnet


def analyze_vpn_sessions(events: list[LogEvent], console: Console) -> None:
    """Track VPN tunnel lifecycle and detect anomalies."""
    sessions: list[VpnSession] = []
    user_events: dict[str, list[tuple[datetime, str]]] = defaultdict(list)

    for e in events:
        if not _is_vpn_event(e):
            continue

        user = (
            get_field(e, "user")
            or get_field(e, "srcuser")
            or get_field(e, "xauthuser")
            or "(unknown)"
        )
        remote_ip = get_field(e, "remip") or get_field(e, "srcip") or ""
        tunnel_ip = get_field(e, "tunnelip") or ""
        action = get_field(e, "action") or ""
        msg = e.message.lower()

        sess = VpnSession(user=user, remote_ip=remote_ip, tunnel_ip=tunnel_ip)

        if "tunnel-up" in msg or action == "tunnel-up" or "connected" in msg:
            sess.start = e.timestamp
            sess.action = "up"
        elif "tunnel-down" in msg or action == "tunnel-down" or "disconnected" in msg:
            sess.end = e.timestamp
            sess.action = "down"
            # try to get bytes
            sent = get_field(e, "sentbyte") or "0"
            recv = get_field(e, "rcvdbyte") or "0"
            try:
                sess.bytes_sent = int(sent)
                sess.bytes_recv = int(recv)
            except ValueError:
                pass
            dur = get_field(e, "duration") or "0"
            try:
                sess.duration_sec = float(dur)
            except ValueError:
                pass

        sessions.append(sess)

        if e.timestamp and remote_ip:
            user_events[user].append((e.timestamp, remote_ip))

    if not sessions:
        console.print("[dim]No VPN events found.[/dim]")
        return

    console.rule("VPN Session Analysis", style="bold cyan")

    # session table
    up_count = sum(1 for s in sessions if s.action == "up")
    down_count = sum(1 for s in sessions if s.action == "down")
    console.print(f"  Tunnel-up events: {format_number(up_count)}")
    console.print(f"  Tunnel-down events: {format_number(down_count)}")
    console.print(f"  Unique users: {len(set(s.user for s in sessions))}")
    console.print()

    # recent sessions
    table = Table(show_header=True, expand=True)
    table.add_column("USER", style="bold")
    table.add_column("ACTION")
    table.add_column("REMOTE IP")
    table.add_column("TIMESTAMP")
    table.add_column("DURATION")
    table.add_column("BYTES")

    for s in sessions[-25:]:
        ts = ""
        if s.action == "up" and s.start:
            ts = s.start.strftime("%Y-%m-%d %H:%M:%S")
        elif s.action == "down" and s.end:
            ts = s.end.strftime("%Y-%m-%d %H:%M:%S")

        dur = f"{s.duration_sec:.0f}s" if s.duration_sec else ""
        total_bytes = s.bytes_sent + s.bytes_recv
        bytes_str = _human_bytes(total_bytes) if total_bytes else ""

        action_style = "green" if s.action == "up" else "red"
        table.add_row(
            s.user,
            f"[{action_style}]{s.action}[/{action_style}]",
            s.remote_ip,
            ts,
            dur,
            bytes_str,
        )

    console.print(table)

    # impossible travel detection
    alerts: list[str] = []
    for user, evt_list in user_events.items():
        evt_list.sort()
        for i in range(1, len(evt_list)):
            prev_time, prev_ip = evt_list[i - 1]
            curr_time, curr_ip = evt_list[i]
            if not prev_ip or not curr_ip:
                continue
            delta = (curr_time - prev_time).total_seconds() / 60
            if delta <= _IMPOSSIBLE_TRAVEL_MINUTES and not _same_slash16(prev_ip, curr_ip):
                alerts.append(
                    f"  {user}: {prev_ip} → {curr_ip} "
                    f"within {delta:.0f}min"
                )

    if alerts:
        console.print()
        console.print(
            f"[bold yellow]⚠ Impossible travel detected "
            f"({_IMPOSSIBLE_TRAVEL_MINUTES}min threshold):[/bold yellow]"
        )
        for a in alerts[:10]:
            console.print(a)


def analyze_vpn_health(events: list[LogEvent], console: Console) -> None:
    """VPN health scoring — concurrent sessions, failure rate, health score."""
    vpn_events = [e for e in events if _is_vpn_event(e)]
    if not vpn_events:
        console.print("[dim]No VPN events found.[/dim]")
        return

    console.rule("VPN Health Analysis", style="bold cyan")

    # Track sessions and failures
    attempts = 0
    failures = 0
    users: set[str] = set()
    open_sessions: dict[str, datetime] = {}
    concurrent_peak = 0
    current_concurrent = 0
    impossible_travel_count = 0

    user_events: dict[str, list[tuple[datetime, str]]] = defaultdict(list)

    for e in vpn_events:
        user = (
            get_field(e, "user")
            or get_field(e, "srcuser")
            or get_field(e, "xauthuser")
            or ""
        )
        remote_ip = get_field(e, "remip") or get_field(e, "srcip") or ""
        action = get_field(e, "action") or ""
        msg = e.message.lower()

        if user:
            users.add(user)

        is_attempt = (
            "login" in msg or "tunnel-up" in msg or "connected" in msg
            or action in ("ssl-login", "tunnel-up")
        )
        is_failure = (
            "fail" in msg or "denied" in msg or "error" in msg
            or action in ("ssl-login-fail",)
        )

        if is_attempt:
            attempts += 1
        if is_failure:
            failures += 1

        # Track concurrent sessions
        if "tunnel-up" in msg or action == "tunnel-up" or "connected" in msg:
            if e.timestamp is None:
                continue
            session_key = f"{user}:{remote_ip}"
            open_sessions[session_key] = e.timestamp
            current_concurrent = len(open_sessions)
            concurrent_peak = max(concurrent_peak, current_concurrent)
        elif "tunnel-down" in msg or action == "tunnel-down" or "disconnected" in msg:
            session_key = f"{user}:{remote_ip}"
            open_sessions.pop(session_key, None)
            current_concurrent = len(open_sessions)

        if e.timestamp and remote_ip and user:
            user_events[user].append((e.timestamp, remote_ip))

    # Impossible travel detection
    for user, evt_list in user_events.items():
        evt_list.sort()
        for i in range(1, len(evt_list)):
            prev_time, prev_ip = evt_list[i - 1]
            curr_time, curr_ip = evt_list[i]
            if not prev_ip or not curr_ip:
                continue
            delta = (curr_time - prev_time).total_seconds() / 60
            if delta <= _IMPOSSIBLE_TRAVEL_MINUTES and not _same_slash16(prev_ip, curr_ip):
                impossible_travel_count += 1

    # Calculate health score
    failure_rate = failures / max(attempts, 1)
    health_score = max(0, 100 - failure_rate * 50 - impossible_travel_count * 10)

    # Render health gauge
    score_color = "green" if health_score >= 80 else "yellow" if health_score >= 60 else "red"
    gauge_filled = int(health_score / 5)
    gauge = f"[{score_color}]{'█' * gauge_filled}{'░' * (20 - gauge_filled)}[/{score_color}]"

    console.print()
    console.print(f"  Health Score: {gauge} [{score_color}]{health_score:.0f}/100[/{score_color}]")
    console.print()
    console.print(f"  Unique users: {len(users)}")
    console.print(f"  Total attempts: {format_number(attempts)}")
    console.print(f"  Failures: {format_number(failures)} ({failure_rate * 100:.1f}%)")
    console.print(f"  Peak concurrent: {concurrent_peak}")
    if impossible_travel_count:
        console.print(f"  [yellow]Impossible travel alerts: {impossible_travel_count}[/yellow]")
    console.print()

    # User summary table
    if users:
        user_counts: dict[str, dict[str, int]] = defaultdict(lambda: {"events": 0, "fails": 0})
        for e in vpn_events:
            user = (
                get_field(e, "user")
                or get_field(e, "srcuser")
                or get_field(e, "xauthuser")
                or ""
            )
            if not user:
                continue
            user_counts[user]["events"] += 1
            action = get_field(e, "action") or ""
            msg = e.message.lower()
            if "fail" in msg or "fail" in action:
                user_counts[user]["fails"] += 1

        table = Table(show_header=True, expand=True)
        table.add_column("USER", style="bold")
        table.add_column("EVENTS", justify="right")
        table.add_column("FAILURES", justify="right")
        table.add_column("FAIL RATE")

        for user in sorted(user_counts, key=lambda u: -user_counts[u]["events"])[:15]:
            data = user_counts[user]
            rate = data["fails"] / max(data["events"], 1) * 100
            rate_style = "green" if rate < 10 else "yellow" if rate < 30 else "red"
            table.add_row(
                user,
                str(data["events"]),
                str(data["fails"]),
                f"[{rate_style}]{rate:.0f}%[/{rate_style}]",
            )
        console.print(table)


def _human_bytes(n: int) -> str:
    value = float(n)
    for unit in ("B", "KB", "MB", "GB"):
        if abs(value) < 1024:
            return f"{value:.0f}{unit}" if value == int(value) else f"{value:.1f}{unit}"
        value /= 1024
    return f"{value:.1f}TB"
