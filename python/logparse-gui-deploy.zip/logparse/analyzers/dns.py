#!/usr/bin/env python3
"""DNS traffic analyzer — query patterns, tunneling, and beaconing detection."""

from __future__ import annotations

import math
from collections import Counter, defaultdict
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


def analyze_dns(events: list[LogEvent], console: Console) -> None:
    """Analyze DNS traffic for anomalies and patterns."""
    dns_events = [e for e in events if _is_dns(e)]

    if not dns_events:
        console.print("[dim]No DNS events found.[/dim]")
        return

    console.rule("DNS Traffic Analysis", style="bold cyan")
    console.print(f"  DNS events: {format_number(len(dns_events))}\n")

    domains: Counter[str] = Counter()
    qtypes: Counter[str] = Counter()
    nxdomain = 0
    queriers: Counter[str] = Counter()
    domain_times: defaultdict[str, list[datetime]] = defaultdict(list)

    for e in dns_events:
        domain = _get_domain(e)
        if domain:
            domains[domain] += 1
            if e.timestamp:
                domain_times[domain].append(e.timestamp)

        qtype = get_field(e, "qtype") or ""
        if qtype:
            qtypes[qtype] += 1

        rcode = get_field(e, "rcode") or ""
        if rcode == "3" or "nxdomain" in e.message.lower():
            nxdomain += 1

        srcip = get_field(e, "srcip") or get_field(e, "clientip") or ""
        if srcip:
            queriers[srcip] += 1

    # Top domains
    table = Table(title="Top Queried Domains", border_style="dim")
    table.add_column("Domain", style="bold")
    table.add_column("Queries", justify="right", style="cyan")
    for d, c in domains.most_common(15):
        table.add_row(d, format_number(c))
    console.print(table)

    # NXDOMAIN ratio
    total = len(dns_events)
    nx_pct = nxdomain / max(total, 1) * 100
    nx_color = "red" if nx_pct > 30 else "yellow" if nx_pct > 10 else "green"
    console.print(f"\n  NXDOMAIN: [{nx_color}]{format_number(nxdomain)} ({nx_pct:.1f}%)[/{nx_color}]")

    # Query types
    if qtypes:
        console.print("\n[bold]Query Type Breakdown:[/bold]")
        for qtype, count in qtypes.most_common(10):
            unusual = " [yellow]![/yellow]" if qtype.upper() in ("TXT", "NULL", "CNAME", "MX") else ""
            console.print(f"  {qtype:>6}  {format_number(count)}{unusual}")

    # Tunneling detection
    tunneling: list[tuple[str, float, int]] = []
    for domain in domains:
        labels = [label for label in domain.split(".") if label]
        if labels:
            longest_label = max(labels, key=len)
            entropy = _entropy(longest_label)
            if entropy > 3.5 and len(longest_label) > 30:
                tunneling.append((domain, entropy, len(longest_label)))

    if tunneling:
        console.print(f"\n[bold red]Potential DNS Tunneling ({len(tunneling)}):[/bold red]")
        t_table = Table(border_style="red")
        t_table.add_column("Domain", style="bold")
        t_table.add_column("Entropy", justify="right")
        t_table.add_column("Label Len", justify="right")
        for domain, ent, length in tunneling[:10]:
            display = domain if len(domain) <= 60 else domain[:57] + "..."
            t_table.add_row(display, f"{ent:.2f}", str(length))
        console.print(t_table)

    # Beaconing detection — regular intervals to same domain
    beaconing: list[tuple[str, float, int]] = []
    for domain, times in domain_times.items():
        if len(times) < 10:
            continue
        sorted_times = sorted(times)
        intervals = [
            (sorted_times[i + 1] - sorted_times[i]).total_seconds()
            for i in range(len(sorted_times) - 1)
        ]
        if not intervals:
            continue
        mean_interval = sum(intervals) / len(intervals)
        if mean_interval < 1:
            continue
        variance = sum((x - mean_interval) ** 2 for x in intervals) / max(len(intervals) - 1, 1)
        stddev = math.sqrt(variance)
        cv = stddev / mean_interval if mean_interval > 0 else float("inf")
        # Low coefficient of variation = regular timing = beaconing
        if cv < 0.3 and len(times) >= 10:
            beaconing.append((domain, mean_interval, len(times)))

    if beaconing:
        console.print(f"\n[bold yellow]Potential Beaconing ({len(beaconing)}):[/bold yellow]")
        b_table = Table(border_style="yellow")
        b_table.add_column("Domain", style="bold")
        b_table.add_column("Avg Interval", justify="right")
        b_table.add_column("Queries", justify="right")
        for domain, interval, count in beaconing[:10]:
            if interval >= 3600:
                interval_str = f"{interval / 3600:.1f}h"
            elif interval >= 60:
                interval_str = f"{interval / 60:.1f}m"
            else:
                interval_str = f"{interval:.0f}s"
            b_table.add_row(domain, interval_str, str(count))
        console.print(b_table)


def _is_dns(event: LogEvent) -> bool:
    subtype = (event.extra.get("subtype", "") or "").lower()
    if subtype == "dns":
        return True
    if event.extra.get("qname"):
        return True
    msg = event.message.lower()
    return "dns" in msg and ("query" in msg or "response" in msg)


def _get_domain(event: LogEvent) -> str:
    return get_field(event, "qname") or get_field(event, "domain") or get_field(event, "hostname") or ""


def _entropy(text: str) -> float:
    if not text:
        return 0.0
    counter = Counter(text.lower())
    length = len(text)
    return -sum(
        (c / length) * math.log2(c / length) for c in counter.values() if c > 0
    )
