#!/usr/bin/env python3
"""SD-WAN health analysis — link status, latency, jitter, failovers."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field


@dataclass
class HealthCheck:
    """Single SD-WAN health check measurement."""

    timestamp: datetime
    latency_ms: float = 0.0
    jitter_ms: float = 0.0
    packet_loss_pct: float = 0.0
    status: str = ""


@dataclass
class SdwanLink:
    """An SD-WAN link aggregated from events."""

    name: str
    site: str = ""
    checks: list[HealthCheck] = field(default_factory=list)
    state_changes: list[tuple[datetime, str]] = field(default_factory=list)


def _is_sdwan_event(event: LogEvent) -> bool:
    """Check if event is SD-WAN related."""
    subtype = (get_field(event, "subtype") or "").lower()
    if subtype == "sdwan":
        return True
    msg = event.message.lower()
    return any(k in msg for k in ("sdwan", "sd-wan", "health-check", "health_check"))


def analyze_sdwan(events: list[LogEvent], console: Console) -> None:
    """Analyze SD-WAN link health and failovers."""
    links: dict[str, SdwanLink] = defaultdict(lambda: SdwanLink(name=""))

    for e in events:
        if not _is_sdwan_event(e):
            continue
        if not e.timestamp:
            continue

        iface = (
            get_field(e, "interface")
            or get_field(e, "srcintf")
            or get_field(e, "name")
            or "unknown"
        )
        site = get_field(e, "devname") or ""

        if iface not in links:
            links[iface] = SdwanLink(name=iface, site=site)
        link = links[iface]
        if not link.site and site:
            link.site = site

        # Extract health metrics
        latency = _float_field(e, "latency")
        jitter = _float_field(e, "jitter")
        loss = _float_field(e, "packetloss")
        status = (get_field(e, "status") or get_field(e, "action") or "").lower()

        link.checks.append(HealthCheck(
            timestamp=e.timestamp,
            latency_ms=latency,
            jitter_ms=jitter,
            packet_loss_pct=loss,
            status=status,
        ))

        # Track state changes
        if status in ("up", "down", "alive", "dead"):
            normalized = "up" if status in ("up", "alive") else "down"
            if not link.state_changes or link.state_changes[-1][1] != normalized:
                link.state_changes.append((e.timestamp, normalized))

    if not links:
        console.print("[dim]No SD-WAN events found.[/dim]")
        return

    console.rule("SD-WAN Health Dashboard", style="bold cyan")
    console.print()

    table = Table(show_header=True, expand=True)
    table.add_column("LINK", style="bold")
    table.add_column("SITE")
    table.add_column("STATUS")
    table.add_column("AVG LATENCY")
    table.add_column("AVG JITTER")
    table.add_column("AVG LOSS")
    table.add_column("UPTIME%")
    table.add_column("FAILOVERS")

    for name, link in sorted(links.items()):
        if not link.checks:
            continue

        latencies = [c.latency_ms for c in link.checks if c.latency_ms > 0]
        jitters = [c.jitter_ms for c in link.checks if c.jitter_ms > 0]
        losses = [c.packet_loss_pct for c in link.checks if c.packet_loss_pct > 0]

        avg_lat = f"{sum(latencies) / len(latencies):.1f}ms" if latencies else "—"
        avg_jit = f"{sum(jitters) / len(jitters):.1f}ms" if jitters else "—"
        avg_loss = f"{sum(losses) / len(losses):.1f}%" if losses else "—"

        # Calculate uptime
        up_checks = sum(1 for c in link.checks if c.status in ("up", "alive"))
        uptime = up_checks / len(link.checks) * 100 if link.checks else 100
        uptime_str = f"{uptime:.0f}%"
        uptime_style = "green" if uptime >= 99 else "yellow" if uptime >= 95 else "red"

        # Current status
        last_status = link.state_changes[-1][1] if link.state_changes else "up"
        status_style = "green" if last_status == "up" else "red"

        failovers = max(0, len(link.state_changes) - 1)

        table.add_row(
            name,
            link.site,
            f"[{status_style}]{last_status}[/{status_style}]",
            avg_lat,
            avg_jit,
            avg_loss,
            f"[{uptime_style}]{uptime_str}[/{uptime_style}]",
            str(failovers) if failovers else "0",
        )

    console.print(table)

    # Failover timeline
    all_changes = []
    for name, link in links.items():
        for ts, status in link.state_changes:
            all_changes.append((ts, name, status))

    all_changes.sort()
    if len(all_changes) > 1:
        console.print()
        console.print("[bold]Failover Timeline:[/bold]")
        for ts, name, status in all_changes[-15:]:
            style = "green" if status == "up" else "red"
            console.print(
                f"  {ts:%Y-%m-%d %H:%M:%S}  {name}  "
                f"[{style}]{status}[/{style}]"
            )
    console.print()


def analyze_sdwan_failovers(events: list[LogEvent], console: Console) -> None:
    """Show only SD-WAN failover state changes."""
    changes = []
    for e in events:
        if not _is_sdwan_event(e) or not e.timestamp:
            continue
        status = (get_field(e, "status") or get_field(e, "action") or "").lower()
        if status in ("up", "down", "alive", "dead"):
            iface = get_field(e, "interface") or get_field(e, "srcintf") or "unknown"
            site = get_field(e, "devname") or ""
            normalized = "up" if status in ("up", "alive") else "down"
            changes.append((e.timestamp, iface, site, normalized))

    if not changes:
        console.print("[dim]No SD-WAN state changes found.[/dim]")
        return

    changes.sort()
    console.rule("SD-WAN Failovers", style="bold cyan")
    table = Table(show_header=True)
    table.add_column("TIMESTAMP")
    table.add_column("LINK", style="bold")
    table.add_column("SITE")
    table.add_column("STATUS")

    for ts, iface, site, status in changes[-25:]:
        style = "green" if status == "up" else "red"
        table.add_row(
            ts.strftime("%Y-%m-%d %H:%M:%S"),
            iface,
            site,
            f"[{style}]{status}[/{style}]",
        )
    console.print(table)


def _float_field(event: LogEvent, field_name: str) -> float:
    """Extract a float from an event field, returning 0.0 on failure."""
    val = get_field(event, field_name)
    if val is None:
        return 0.0
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0
