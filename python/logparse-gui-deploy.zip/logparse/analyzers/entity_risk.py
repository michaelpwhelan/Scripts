#!/usr/bin/env python3
"""Entity risk analyzer — wraps entity_scoring for the analyzer interface."""

from __future__ import annotations

from logparse.entity_scoring import EntityProfile, score_entities
from logparse.models import LogEvent


def analyze_entity_risk(events: list[LogEvent]) -> list[EntityProfile]:
    """Score all entities and return profiles sorted by risk."""
    return score_entities(events)
