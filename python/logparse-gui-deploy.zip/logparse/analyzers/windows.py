#!/usr/bin/env python3
"""Windows Event Log analyzer — logon types, account mgmt, services, audit."""

from __future__ import annotations

from collections import Counter

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


_LOGON_TYPES = {
    "2": "Interactive",
    "3": "Network",
    "4": "Batch",
    "5": "Service",
    "7": "Unlock",
    "8": "NetworkCleartext",
    "9": "NewCredentials",
    "10": "RemoteInteractive",
    "11": "CachedInteractive",
}

_ACCT_MGMT_IDS = {
    "4720": "Account Created",
    "4722": "Account Enabled",
    "4723": "Password Change Attempt",
    "4724": "Password Reset",
    "4725": "Account Disabled",
    "4726": "Account Deleted",
    "4738": "Account Modified",
}

_GROUP_CHANGE_IDS = {
    "4728": "Added to Global Group",
    "4729": "Removed from Global Group",
    "4732": "Added to Local Group",
    "4733": "Removed from Local Group",
    "4756": "Added to Universal Group",
    "4757": "Removed from Universal Group",
}

_AUDIT_IDS = {
    "1102": "Audit Log Cleared",
    "4719": "Audit Policy Changed",
    "4907": "Auditing Settings Changed",
}

_SERVICE_INSTALL_ID = "7045"

_LOGON_IDS = {"4624", "4625"}


def _is_windows_event(event: LogEvent) -> bool:
    """Detect Windows Event Log events."""
    if event.source_format in ("evtx", "windows_xml"):
        return True
    return bool(get_field(event, "EventID"))


def analyze_windows(events: list[LogEvent], console: Console) -> None:
    """Windows Event Log security analysis."""
    win_events = [e for e in events if _is_windows_event(e)]
    if not win_events:
        console.print("[dim]No Windows Event Log events found.[/dim]")
        return

    console.rule("Windows Event Log Analysis", style="bold cyan")

    # Overview
    computers: set[str] = set()
    event_ids: Counter[str] = Counter()
    ts_events = [e for e in win_events if e.timestamp]

    for e in win_events:
        comp = get_field(e, "Computer") or get_field(e, "devname") or ""
        if comp:
            computers.add(comp)
        eid = get_field(e, "EventID") or ""
        if eid:
            event_ids[eid] += 1

    console.print(
        f"  {format_number(len(win_events))} events  |  "
        f"{len(computers)} computers  |  "
        f"{len(event_ids)} unique EventIDs"
    )
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        console.print(f"  Time range: {first:%Y-%m-%d %H:%M} — {last:%Y-%m-%d %H:%M}")
    console.print()

    # Logon type breakdown
    _logon_types(win_events, console)

    # Account management
    _account_management(win_events, console)

    # Service installations
    _service_installs(win_events, console)

    # Group membership changes
    _group_changes(win_events, console)

    # Audit events (critical)
    _audit_events(win_events, console)

    # Top Event IDs
    _top_event_ids(event_ids, console)


def _logon_types(events: list[LogEvent], console: Console) -> None:
    """Logon type breakdown for EventID 4624/4625."""
    logon_events = [
        e for e in events
        if (get_field(e, "EventID") or "") in _LOGON_IDS
    ]
    if not logon_events:
        return

    # Group by logon type
    type_success: Counter[str] = Counter()
    type_failure: Counter[str] = Counter()

    for e in logon_events:
        lt = get_field(e, "LogonType") or ""
        if not lt:
            lt = "?"
        eid = get_field(e, "EventID") or ""
        if eid == "4624":
            type_success[lt] += 1
        elif eid == "4625":
            type_failure[lt] += 1

    all_types = set(type_success) | set(type_failure)
    if not all_types:
        return

    table = Table(title="Logon Type Breakdown", border_style="dim")
    table.add_column("TYPE", justify="right")
    table.add_column("NAME")
    table.add_column("SUCCESS", justify="right", style="green")
    table.add_column("FAILURES", justify="right", style="red")
    table.add_column("FLAGS")

    for lt in sorted(all_types):
        name = _LOGON_TYPES.get(lt, "Unknown")
        succ = type_success.get(lt, 0)
        fail = type_failure.get(lt, 0)
        flags = []
        if lt == "10":
            flags.append("[yellow]REMOTE[/yellow]")
        if lt == "8":
            flags.append("[red]CLEARTEXT[/red]")
        table.add_row(
            lt, name,
            format_number(succ) if succ else "",
            format_number(fail) if fail else "",
            " ".join(flags),
        )

    console.print(table)
    console.print()


def _account_management(events: list[LogEvent], console: Console) -> None:
    """Account management events (create, modify, delete, etc.)."""
    acct_events = [
        e for e in events
        if (get_field(e, "EventID") or "") in _ACCT_MGMT_IDS
    ]
    if not acct_events:
        return

    # Sort by timestamp
    acct_events.sort(key=lambda e: e.timestamp or _EPOCH)

    table = Table(title="Account Management", border_style="dim")
    table.add_column("TIME")
    table.add_column("EVENT")
    table.add_column("USER", style="bold")
    table.add_column("PERFORMED BY")

    for e in acct_events[:25]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "?"
        eid = get_field(e, "EventID") or ""
        label = _ACCT_MGMT_IDS.get(eid, eid)
        user = (
            get_field(e, "TargetUserName")
            or get_field(e, "user")
            or ""
        )
        performed_by = get_field(e, "SubjectUserName") or ""
        table.add_row(ts, label, user, performed_by)

    console.print(table)
    if len(acct_events) > 25:
        console.print(f"  [dim]... and {len(acct_events) - 25} more[/dim]")
    console.print()


def _service_installs(events: list[LogEvent], console: Console) -> None:
    """Service installation events (EventID 7045)."""
    svc_events = [
        e for e in events
        if (get_field(e, "EventID") or "") == _SERVICE_INSTALL_ID
    ]
    if not svc_events:
        return

    table = Table(title="Service Installations", border_style="dim")
    table.add_column("TIME")
    table.add_column("SERVICE NAME", style="bold")
    table.add_column("IMAGE PATH")
    table.add_column("ACCOUNT")
    table.add_column("FLAGS")

    for e in svc_events[:15]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "?"
        name = (
            get_field(e, "ServiceName")
            or get_field(e, "param1")
            or ""
        )
        path = (
            get_field(e, "ImagePath")
            or get_field(e, "param2")
            or ""
        )
        # Truncate long paths
        if len(path) > 50:
            path = path[:47] + "..."
        account = (
            get_field(e, "ServiceAccount")
            or get_field(e, "param4")
            or ""
        )
        flags = ""
        if account.upper() in ("LOCALSYSTEM", "SYSTEM", "NT AUTHORITY\\SYSTEM"):
            flags = "[red]SYSTEM[/red]"
        table.add_row(ts, name, path, account, flags)

    console.print(table)
    if len(svc_events) > 15:
        console.print(f"  [dim]... and {len(svc_events) - 15} more[/dim]")
    console.print()


def _group_changes(events: list[LogEvent], console: Console) -> None:
    """Group membership changes."""
    group_events = [
        e for e in events
        if (get_field(e, "EventID") or "") in _GROUP_CHANGE_IDS
    ]
    if not group_events:
        return

    group_events.sort(key=lambda e: e.timestamp or _EPOCH)

    table = Table(title="Group Membership Changes", border_style="dim")
    table.add_column("TIME")
    table.add_column("EVENT")
    table.add_column("USER", style="bold")
    table.add_column("GROUP")
    table.add_column("PERFORMED BY")

    for e in group_events[:20]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "?"
        eid = get_field(e, "EventID") or ""
        label = _GROUP_CHANGE_IDS.get(eid, eid)
        user = (
            get_field(e, "MemberName")
            or get_field(e, "TargetUserName")
            or get_field(e, "user")
            or ""
        )
        group = get_field(e, "TargetDomainName") or get_field(e, "GroupName") or ""
        performed_by = get_field(e, "SubjectUserName") or ""
        table.add_row(ts, label, user, group, performed_by)

    console.print(table)
    if len(group_events) > 20:
        console.print(f"  [dim]... and {len(group_events) - 20} more[/dim]")
    console.print()


def _audit_events(events: list[LogEvent], console: Console) -> None:
    """Audit events — log cleared, policy changed (critical)."""
    audit_events = [
        e for e in events
        if (get_field(e, "EventID") or "") in _AUDIT_IDS
    ]
    if not audit_events:
        return

    console.print("[bold red]Audit Events (Critical):[/bold red]")
    for e in audit_events[:10]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "?"
        eid = get_field(e, "EventID") or ""
        label = _AUDIT_IDS.get(eid, eid)
        user = get_field(e, "SubjectUserName") or ""
        comp = get_field(e, "Computer") or ""
        if eid == "1102":
            console.print(f"  [bold red]{ts}  {label}  by {user}  on {comp}[/bold red]")
        else:
            console.print(f"  [red]{ts}  {label}  by {user}  on {comp}[/red]")
    console.print()


def _top_event_ids(event_ids: Counter[str], console: Console) -> None:
    """Top EventIDs for reference."""
    if not event_ids:
        return
    console.print("[bold]Top Event IDs:[/bold]")
    for eid, count in event_ids.most_common(10):
        console.print(f"  {eid:>6}  {format_number(count)}")


# Sentinel for sorting events without timestamps
from datetime import datetime as _dt
_EPOCH = _dt(1970, 1, 1)
