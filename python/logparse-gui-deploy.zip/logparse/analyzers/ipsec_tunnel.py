#!/usr/bin/env python3
"""IPsec tunnel analysis — state tracking, flap detection, uptime."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field

_FLAP_WINDOW_SEC = 300  # 5 minutes


@dataclass
class TunnelState:
    """Tracks IPsec tunnel state transitions and errors."""

    name: str
    transitions: list[tuple[datetime, str]] = field(default_factory=list)
    dpd_timeouts: int = 0
    negotiate_failures: int = 0
    rekeys: int = 0


def _is_ipsec_event(event: LogEvent) -> bool:
    """Check if event is IPsec-related."""
    subtype = event.extra.get("subtype", "").lower()
    if subtype == "ipsec":
        return True
    msg = event.message.lower()
    return any(k in msg for k in (
        "ipsec", "phase1", "phase2", "ike", "dpd",
        "tunnel-up", "tunnel-down", "negotiate",
        "rekey", "sa_", "isakmp",
    ))


def analyze_ipsec_tunnel(events: list[LogEvent], console: Console) -> None:
    """Track IPsec tunnel states and detect issues."""
    tunnels: dict[str, TunnelState] = defaultdict(lambda: TunnelState(name=""))

    for e in events:
        if not _is_ipsec_event(e):
            continue

        # identify tunnel
        name = (
            get_field(e, "tunnelid")
            or get_field(e, "peerip")
            or get_field(e, "gateway")
            or get_field(e, "vpntunnel")
            or "(unknown)"
        )

        tunnel = tunnels[name]
        tunnel.name = name
        msg = e.message.lower()
        action = (get_field(e, "action") or "").lower()

        if e.timestamp:
            if "tunnel-up" in msg or "up" in action or "established" in msg:
                tunnel.transitions.append((e.timestamp, "up"))
            elif "tunnel-down" in msg or "down" in action or "removed" in msg:
                tunnel.transitions.append((e.timestamp, "down"))

        if "dpd" in msg and ("timeout" in msg or "fail" in msg):
            tunnel.dpd_timeouts += 1
        if "negotiat" in msg and ("fail" in msg or "error" in msg):
            tunnel.negotiate_failures += 1
        if "rekey" in msg:
            tunnel.rekeys += 1

    if not tunnels:
        console.print("[dim]No IPsec events found.[/dim]")
        return

    console.rule("IPsec Tunnel Analysis", style="bold cyan")
    console.print(f"  Tracked tunnels: {len(tunnels)}")
    console.print()

    table = Table(show_header=True, expand=True)
    table.add_column("TUNNEL", style="bold")
    table.add_column("STATUS")
    table.add_column("TRANSITIONS", justify="right")
    table.add_column("FLAPS", justify="right", style="red")
    table.add_column("DPD TIMEOUTS", justify="right", style="yellow")
    table.add_column("NEG FAILURES", justify="right", style="red")
    table.add_column("REKEYS", justify="right")
    table.add_column("UPTIME %", justify="right")

    for name, tunnel in sorted(tunnels.items()):
        tunnel.transitions.sort()
        trans_count = len(tunnel.transitions)

        # current status
        status = "unknown"
        if tunnel.transitions:
            status = tunnel.transitions[-1][1]
        status_style = "green" if status == "up" else "red" if status == "down" else "dim"

        # flap detection: up→down within 5min
        flaps = 0
        for i in range(1, len(tunnel.transitions)):
            prev_time, prev_state = tunnel.transitions[i - 1]
            curr_time, curr_state = tunnel.transitions[i]
            if prev_state == "up" and curr_state == "down":
                delta = (curr_time - prev_time).total_seconds()
                if delta <= _FLAP_WINDOW_SEC:
                    flaps += 1

        # uptime calculation
        uptime_pct = _calc_uptime(tunnel.transitions)

        table.add_row(
            name,
            f"[{status_style}]{status.upper()}[/{status_style}]",
            str(trans_count),
            str(flaps) if flaps else "-",
            str(tunnel.dpd_timeouts) if tunnel.dpd_timeouts else "-",
            str(tunnel.negotiate_failures) if tunnel.negotiate_failures else "-",
            str(tunnel.rekeys) if tunnel.rekeys else "-",
            f"{uptime_pct:.1f}%" if uptime_pct >= 0 else "-",
        )

    console.print(table)

    # alert on flapping tunnels
    flapping = [
        (name, t) for name, t in tunnels.items()
        if _count_flaps(t.transitions) >= 3
    ]
    if flapping:
        console.print()
        console.print(f"[bold red]⚠ {len(flapping)} tunnel(s) flapping:[/bold red]")
        for name, t in flapping:
            console.print(f"  {name}: {_count_flaps(t.transitions)} flaps")


def _count_flaps(transitions: list[tuple[datetime, str]]) -> int:
    flaps = 0
    for i in range(1, len(transitions)):
        prev_time, prev_state = transitions[i - 1]
        curr_time, curr_state = transitions[i]
        if prev_state == "up" and curr_state == "down":
            delta = (curr_time - prev_time).total_seconds()
            if delta <= _FLAP_WINDOW_SEC:
                flaps += 1
    return flaps


def _calc_uptime(transitions: list[tuple[datetime, str]]) -> float:
    """Calculate uptime percentage from transition history."""
    if len(transitions) < 2:
        return -1

    total = (transitions[-1][0] - transitions[0][0]).total_seconds()
    if total <= 0:
        return -1

    up_time = 0
    for i in range(len(transitions) - 1):
        if transitions[i][1] == "up":
            seg = (transitions[i + 1][0] - transitions[i][0]).total_seconds()
            up_time += seg

    return (up_time / total) * 100
