#!/usr/bin/env python3
"""Authentication analyzer — success/failure, lockouts, privilege escalation."""

from __future__ import annotations

import re
from collections import Counter
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


# Windows Security Event IDs
_SUCCESS_IDS = {"4624", "4648", "4634"}
_FAILURE_IDS = {"4625", "4771", "6273"}
_LOCKOUT_IDS = {"4740"}
_PRIV_IDS = {"4672", "4728", "4732"}
_ALL_AUTH_IDS = _SUCCESS_IDS | _FAILURE_IDS | _LOCKOUT_IDS | _PRIV_IDS

# FortiGate auth actions
_FG_SUCCESS_ACTIONS = {"ssl-login"}
_FG_FAILURE_ACTIONS = {"ssl-login-fail"}

# Generic failure patterns
_FAIL_PATTERNS = re.compile(
    r"deny|denied|failed|failure|reject|rejected|auth-fail|login.fail",
    re.IGNORECASE,
)
_SUCCESS_PATTERNS = re.compile(
    r"success|accept|allow|login(?!.fail)|logon|authenticated",
    re.IGNORECASE,
)

# Service account heuristics
_SVC_ACCOUNT_RE = re.compile(
    r"^svc[_-]|^service[_-]|\$$|^SYSTEM$|^LOCAL SERVICE$|^NETWORK SERVICE$",
    re.IGNORECASE,
)


def _is_auth_event(event: LogEvent) -> bool:
    """Detect authentication-related events."""
    eid = get_field(event, "EventID") or ""
    if eid in _ALL_AUTH_IDS:
        return True
    subtype = (get_field(event, "subtype") or "").lower()
    if subtype in ("auth", "user"):
        return True
    action = (get_field(event, "action") or "").lower()
    if action in _FG_SUCCESS_ACTIONS or action in _FG_FAILURE_ACTIONS:
        return True
    msg = event.message.lower()
    return any(
        kw in msg
        for kw in ("login", "logon", "logoff", "authentication", "credential")
    )


def _classify_auth(event: LogEvent) -> str:
    """Classify as 'success', 'failure', or 'other'."""
    eid = get_field(event, "EventID") or ""
    if eid in _SUCCESS_IDS:
        return "success"
    if eid in _FAILURE_IDS or eid in _LOCKOUT_IDS:
        return "failure"
    action = (get_field(event, "action") or "").lower()
    if action in _FG_SUCCESS_ACTIONS:
        return "success"
    if action in _FG_FAILURE_ACTIONS:
        return "failure"
    if action in ("deny", "denied", "blocked", "drop"):
        return "failure"
    if action in ("accept", "allow", "pass"):
        return "success"
    msg = event.message
    if _FAIL_PATTERNS.search(msg):
        return "failure"
    if _SUCCESS_PATTERNS.search(msg):
        return "success"
    return "other"


def _get_user(event: LogEvent) -> str:
    """Extract username from event."""
    for field in ("TargetUserName", "user", "username", "srcuser",
                  "SubjectUserName", "account", "samaccountname"):
        val = get_field(event, field)
        if val and val.strip() and val != "-":
            return val.strip()
    return "(unknown)"


def analyze_auth(events: list[LogEvent], console: Console) -> None:
    """Comprehensive authentication analysis."""
    auth_events = [e for e in events if _is_auth_event(e)]
    if not auth_events:
        console.print("[dim]No authentication events found.[/dim]")
        return

    console.rule("Authentication Analysis", style="bold cyan")

    # Classify all events
    success_events: list[LogEvent] = []
    failure_events: list[LogEvent] = []
    for e in auth_events:
        cls = _classify_auth(e)
        if cls == "success":
            success_events.append(e)
        elif cls == "failure":
            failure_events.append(e)

    success_n = len(success_events)
    failure_n = len(failure_events)

    # Per-user tracking
    user_total: Counter[str] = Counter()
    user_success: Counter[str] = Counter()
    user_failure: Counter[str] = Counter()
    user_ips: dict[str, set[str]] = {}
    user_lockouts: dict[str, list[LogEvent]] = {}
    user_priv: list[LogEvent] = []

    for e in auth_events:
        user = _get_user(e)
        cls = _classify_auth(e)
        user_total[user] += 1
        if cls == "success":
            user_success[user] += 1
        elif cls == "failure":
            user_failure[user] += 1

        # Track source IPs
        ip = get_field(e, "srcip") or get_field(e, "src") or get_field(e, "IpAddress") or ""
        if ip:
            user_ips.setdefault(user, set()).add(ip)

        # Track lockouts
        eid = get_field(event, "EventID") if (event := e) else ""
        if eid in _LOCKOUT_IDS:
            user_lockouts.setdefault(user, []).append(e)

        # Track privilege events
        if eid in _PRIV_IDS:
            user_priv.append(e)

    unique_users = len(user_total)
    all_ips = set()
    for ips in user_ips.values():
        all_ips.update(ips)

    # Overview
    if failure_n > 0:
        ratio_color = "green" if failure_n < success_n * 0.1 else "yellow" if failure_n < success_n else "red"
        console.print(
            f"  {format_number(len(auth_events))} auth events  |  "
            f"[green]{format_number(success_n)} success[/green]  |  "
            f"[{ratio_color}]{format_number(failure_n)} failures[/{ratio_color}]  |  "
            f"{unique_users} users  |  {format_number(len(all_ips))} source IPs"
        )
    else:
        console.print(
            f"  {format_number(len(auth_events))} auth events  |  "
            f"{format_number(success_n)} success  |  "
            f"{unique_users} users"
        )
    console.print()

    # Top Users table
    _top_users(
        user_total, user_success, user_failure, user_ips,
        user_lockouts, user_priv, console,
    )

    # Lockout alerts
    if user_lockouts:
        _lockout_alerts(user_lockouts, console)

    # After-hours auth
    _after_hours(auth_events, console)

    # Privilege escalation
    if user_priv:
        _privilege_events(user_priv, console)


def _top_users(
    user_total: Counter, user_success: Counter, user_failure: Counter,
    user_ips: dict, user_lockouts: dict, user_priv: list,
    console: Console,
) -> None:
    """Top users by auth events with flags."""
    priv_users = {_get_user(e) for e in user_priv}

    table = Table(title="Top Users", border_style="dim")
    table.add_column("USER", style="bold")
    table.add_column("TOTAL", justify="right", style="cyan")
    table.add_column("SUCCESS", justify="right", style="green")
    table.add_column("FAILURES", justify="right")
    table.add_column("FAIL%", justify="right")
    table.add_column("FLAGS")

    for user, total in user_total.most_common(20):
        succ = user_success.get(user, 0)
        fail = user_failure.get(user, 0)
        fail_pct = fail / max(total, 1) * 100
        fail_color = "red" if fail_pct > 50 else "yellow" if fail_pct > 20 else ""
        fail_str = f"[{fail_color}]{fail_pct:.0f}%[/{fail_color}]" if fail_color else f"{fail_pct:.0f}%"

        flags = []
        if user in user_lockouts:
            flags.append("[bold red]LOCKED-OUT[/bold red]")
        if user in priv_users:
            flags.append("[yellow]PRIV-USE[/yellow]")
        if fail >= 10:
            flags.append("[red]BRUTE-FORCE[/red]")
        n_ips = len(user_ips.get(user, set()))
        if n_ips >= 5:
            flags.append("[yellow]DISTRIBUTED[/yellow]")
        if _SVC_ACCOUNT_RE.search(user):
            flags.append("[dim]SVC-ACCT[/dim]")

        fail_display = format_number(fail) if fail else ""
        table.add_row(
            user, format_number(total), format_number(succ),
            fail_display, fail_str, " ".join(flags),
        )

    console.print(table)
    console.print()


def _lockout_alerts(
    user_lockouts: dict[str, list[LogEvent]], console: Console,
) -> None:
    """Show account lockout events."""
    console.print("[bold red]Account Lockouts:[/bold red]")
    for user, lockout_events in sorted(user_lockouts.items()):
        for e in lockout_events[:3]:
            ts = e.timestamp.strftime("%H:%M:%S") if e.timestamp else "?"
            src = e.source or e.source_file or ""
            console.print(f"  {user:<25} {ts}  ({src})")
    console.print()


def _after_hours(auth_events: list[LogEvent], console: Console) -> None:
    """Detect after-hours authentication."""
    total_ts = 0
    after_hours_count = 0
    weekend_count = 0

    for e in auth_events:
        if not e.timestamp:
            continue
        total_ts += 1
        hour = e.timestamp.hour
        weekday = e.timestamp.weekday()
        if weekday >= 5:  # Saturday=5, Sunday=6
            weekend_count += 1
        elif hour < 7 or hour >= 18:
            after_hours_count += 1

    off_hours = after_hours_count + weekend_count
    if total_ts > 0 and off_hours > 0:
        pct = off_hours / total_ts * 100
        color = "red" if pct > 20 else "yellow" if pct > 10 else ""
        label = f"[{color}]{pct:.1f}%[/{color}]" if color else f"{pct:.1f}%"
        console.print(
            f"[bold]After-Hours Auth:[/bold]  "
            f"{format_number(off_hours)} events ({label}) — "
            f"{format_number(after_hours_count)} off-hours, "
            f"{format_number(weekend_count)} weekend"
        )
        console.print()


def _privilege_events(priv_events: list[LogEvent], console: Console) -> None:
    """Show privilege escalation indicators."""
    _PRIV_LABELS = {
        "4672": "Special Privileges Assigned",
        "4728": "Added to Global Security Group",
        "4732": "Added to Local Security Group",
    }

    table = Table(title="Privilege Escalation Indicators", border_style="dim")
    table.add_column("TIME")
    table.add_column("USER", style="bold")
    table.add_column("EVENT")
    table.add_column("DETAILS")

    for e in priv_events[:20]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "?"
        user = _get_user(e)
        eid = get_field(e, "EventID") or ""
        label = _PRIV_LABELS.get(eid, f"EventID {eid}")
        details = get_field(e, "TargetUserName") or get_field(e, "MemberName") or ""
        table.add_row(ts, user, label, details)

    console.print(table)
