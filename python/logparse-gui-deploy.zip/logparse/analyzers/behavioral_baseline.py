#!/usr/bin/env python3
"""Behavioral baseline engine.

Builds statistical baselines from historical log data and detects
deviations.  Baselines are stored as JSON in ``~/.logparse/baselines/``.
"""

from __future__ import annotations

import json
import logging
import math
from collections import Counter
from dataclasses import asdict, dataclass, field
from datetime import datetime
from pathlib import Path

from logparse.models import SEVERITY_LEVELS, LogEvent

log = logging.getLogger(__name__)


# -- data structures ---------------------------------------------------------


@dataclass
class BaselineMetric:
    """Statistics for one measured dimension."""

    field: str
    aggregation: str  # count_per_hour, unique_per_day, severity_dist
    mean: float = 0.0
    stddev: float = 0.0
    p95: float = 0.0
    sample_count: int = 0


@dataclass
class BaselineProfile:
    """A persisted behavioral baseline."""

    name: str
    created: str = ""  # ISO 8601
    event_count: int = 0
    time_span_hours: float = 0.0
    metrics: dict[str, BaselineMetric] = field(default_factory=dict)


@dataclass
class BaselineDeviation:
    """A deviation from the baseline."""

    metric_name: str
    current_value: float
    expected_mean: float
    stddev: float
    sigma: float  # how many stddevs away
    severity: str  # Critical >3σ, High >2σ, Medium >1σ


# -- baseline building -------------------------------------------------------


def _compute_stats(values: list[float]) -> tuple[float, float, float]:
    """Return (mean, stddev, p95) for a list of values."""
    if not values:
        return 0.0, 0.0, 0.0
    n = len(values)
    mean = sum(values) / n
    if n < 2:
        return mean, 0.0, mean
    variance = sum((v - mean) ** 2 for v in values) / (n - 1)
    stddev = math.sqrt(variance)
    sorted_vals = sorted(values)
    p95_idx = min(int(n * 0.95), n - 1)
    p95 = sorted_vals[p95_idx]
    return mean, stddev, p95


def build_baseline(events: list[LogEvent], name: str) -> BaselineProfile:
    """Build a behavioral baseline from events."""
    profile = BaselineProfile(
        name=name,
        created=datetime.now().isoformat(),
        event_count=len(events),
    )

    if not events:
        return profile

    # Time span
    timestamps = [e.timestamp for e in events if e.timestamp is not None]
    if len(timestamps) >= 2:
        span = max(timestamps) - min(timestamps)
        profile.time_span_hours = span.total_seconds() / 3600.0
    elif timestamps:
        profile.time_span_hours = 0.0

    # Events per hour
    hourly: Counter[str] = Counter()
    for e in events:
        if e.timestamp:
            hour_key = e.timestamp.strftime("%Y-%m-%d-%H")
            hourly[hour_key] += 1

    if hourly:
        hour_counts = list(hourly.values())
        mean, std, p95 = _compute_stats(hour_counts)
        profile.metrics["events_per_hour"] = BaselineMetric(
            field="timestamp",
            aggregation="count_per_hour",
            mean=mean,
            stddev=std,
            p95=p95,
            sample_count=len(hour_counts),
        )

    # Severity distribution (fraction of total per hour)
    sev_per_hour: dict[str, Counter[str]] = {}
    for e in events:
        if e.timestamp:
            hk = e.timestamp.strftime("%Y-%m-%d-%H")
            sev_per_hour.setdefault(hk, Counter())[e.severity] += 1
    total = len(events)
    for sev in SEVERITY_LEVELS:
        if sev_per_hour:
            hourly_fracs = []
            for hk, hcounts in sev_per_hour.items():
                htotal = sum(hcounts.values())
                hourly_fracs.append(hcounts.get(sev, 0) / htotal if htotal else 0.0)
            mean_frac, std_frac, p95_frac = _compute_stats(hourly_fracs)
        else:
            frac = (Counter(e.severity for e in events).get(sev, 0) / total) if total else 0.0
            mean_frac, std_frac, p95_frac = frac, 0.0, frac
        profile.metrics[f"severity_frac_{sev.lower()}"] = BaselineMetric(
            field="severity",
            aggregation="severity_dist",
            mean=mean_frac,
            stddev=std_frac,
            p95=p95_frac,
            sample_count=len(sev_per_hour) if sev_per_hour else total,
        )

    # Unique sources per hour
    src_per_hour: dict[str, set[str]] = {}
    for e in events:
        if e.timestamp and e.source:
            hour_key = e.timestamp.strftime("%Y-%m-%d-%H")
            src_per_hour.setdefault(hour_key, set()).add(e.source)

    if src_per_hour:
        unique_counts = [len(s) for s in src_per_hour.values()]
        mean, std, p95 = _compute_stats(unique_counts)
        profile.metrics["unique_sources_per_hour"] = BaselineMetric(
            field="source",
            aggregation="unique_per_hour",
            mean=mean,
            stddev=std,
            p95=p95,
            sample_count=len(unique_counts),
        )

    # High-severity events per hour
    high_hourly: Counter[str] = Counter()
    for e in events:
        if e.timestamp and e.severity in ("Critical", "High"):
            hour_key = e.timestamp.strftime("%Y-%m-%d-%H")
            high_hourly[hour_key] += 1

    if hourly:  # Use all hours as denominator (including zero-count hours)
        high_counts = [high_hourly.get(h, 0) for h in hourly]
        mean, std, p95 = _compute_stats(high_counts)
        profile.metrics["high_sev_per_hour"] = BaselineMetric(
            field="severity",
            aggregation="count_per_hour",
            mean=mean,
            stddev=std,
            p95=p95,
            sample_count=len(high_counts),
        )

    return profile


# -- baseline checking -------------------------------------------------------


def check_baseline(
    events: list[LogEvent], profile: BaselineProfile
) -> list[BaselineDeviation]:
    """Compare current events against a stored baseline.

    Returns deviations sorted by sigma descending.
    """
    if not events or not profile.metrics:
        return []

    current = build_baseline(events, "_check")
    deviations: list[BaselineDeviation] = []

    for name, baseline_m in profile.metrics.items():
        current_m = current.metrics.get(name)
        if current_m is None:
            continue
        if baseline_m.stddev <= 0:
            continue  # Can't compute sigma without variance

        sigma = abs(current_m.mean - baseline_m.mean) / baseline_m.stddev

        if sigma >= 1.0:
            if sigma >= 3.0:
                sev = "Critical"
            elif sigma >= 2.0:
                sev = "High"
            else:
                sev = "Medium"

            deviations.append(
                BaselineDeviation(
                    metric_name=name,
                    current_value=current_m.mean,
                    expected_mean=baseline_m.mean,
                    stddev=baseline_m.stddev,
                    sigma=round(sigma, 2),
                    severity=sev,
                )
            )

    return sorted(deviations, key=lambda d: d.sigma, reverse=True)


# -- persistence -------------------------------------------------------------


def save_baseline(profile: BaselineProfile, baselines_dir: Path) -> Path:
    """Save baseline to JSON file."""
    baselines_dir.mkdir(parents=True, exist_ok=True)
    path = baselines_dir / f"{profile.name}.json"
    data = {
        "name": profile.name,
        "created": profile.created,
        "event_count": profile.event_count,
        "time_span_hours": profile.time_span_hours,
        "metrics": {
            k: asdict(v) for k, v in profile.metrics.items()
        },
    }
    path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    return path


def load_baseline(name: str, baselines_dir: Path) -> BaselineProfile | None:
    """Load baseline from JSON file."""
    path = baselines_dir / f"{name}.json"
    if not path.exists():
        return None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        metrics = {}
        for k, v in data.get("metrics", {}).items():
            metrics[k] = BaselineMetric(**v)
        return BaselineProfile(
            name=data["name"],
            created=data.get("created", ""),
            event_count=data.get("event_count", 0),
            time_span_hours=data.get("time_span_hours", 0.0),
            metrics=metrics,
        )
    except (json.JSONDecodeError, KeyError, TypeError) as exc:
        log.warning("Could not load baseline %s: %s", name, exc)
        return None


def list_baselines(baselines_dir: Path) -> list[str]:
    """Return names of all stored baselines."""
    if not baselines_dir.is_dir():
        return []
    return sorted(p.stem for p in baselines_dir.glob("*.json"))


def delete_baseline(name: str, baselines_dir: Path) -> bool:
    """Delete a stored baseline. Returns True if deleted."""
    path = baselines_dir / f"{name}.json"
    if path.exists():
        path.unlink()
        return True
    return False
