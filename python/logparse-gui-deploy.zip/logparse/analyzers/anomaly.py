#!/usr/bin/env python3
"""Anomaly detection — four detector functions for event analysis."""

from __future__ import annotations

import statistics
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone

from logparse.models import LogEvent, get_field
from logparse.network import is_external


@dataclass
class AnomalyFinding:
    """A single anomaly detection result."""

    detector: str  # "first-seen" | "time" | "volume" | "patterns"
    severity: str
    title: str
    description: str
    evidence: list[str] = field(default_factory=list)
    events: list[LogEvent] = field(default_factory=list)
    score: float = 0.0


def detect_first_seen(events: list[LogEvent]) -> list[AnomalyFinding]:
    """Detect values that appear only in the recent 20% of the time window."""
    if len(events) < 10:
        return []

    ts_events = [e for e in events if e.timestamp]
    if len(ts_events) < 10:
        return []

    ts_events.sort(key=lambda e: e.timestamp)
    split = int(len(ts_events) * 0.8)
    baseline = ts_events[:split]
    recent = ts_events[split:]

    findings: list[AnomalyFinding] = []
    fields_to_check = ["srcip", "dstip", "user", "dstport"]

    for field_name in fields_to_check:
        baseline_vals = {get_field(e, field_name) or "" for e in baseline} - {""}
        recent_vals = {get_field(e, field_name) or "" for e in recent} - {""}
        new_vals = recent_vals - baseline_vals

        if not new_vals:
            continue

        evidence = []
        score = 3.0
        for val in sorted(new_vals)[:10]:
            flag = ""
            if field_name in ("srcip", "dstip") and is_external(val):
                flag = " [external]"
                score = max(score, 6.0)
            evidence.append(f"{val}{flag}")

        matching = [
            e for e in recent
            if (get_field(e, field_name) or "") in new_vals
        ]

        findings.append(AnomalyFinding(
            detector="first-seen",
            severity="Medium" if score < 5 else "High",
            title=f"New {field_name} values in recent window",
            description=f"{len(new_vals)} {field_name} value(s) appeared only in the last 20% of events.",
            evidence=evidence,
            events=matching[:50],
            score=score,
        ))

    return findings


def detect_time_anomaly(events: list[LogEvent]) -> list[AnomalyFinding]:
    """Detect after-hours activity and burst patterns."""
    ts_events = [e for e in events if e.timestamp]
    if len(ts_events) < 20:
        return []

    findings: list[AnomalyFinding] = []

    # After-hours detection (outside 07:00-18:00 weekdays)
    after_hours = [
        e for e in ts_events
        if e.timestamp.weekday() < 5
        and (e.timestamp.hour < 7 or e.timestamp.hour >= 18)
    ]
    weekend = [e for e in ts_events if e.timestamp.weekday() >= 5]
    off_hours = after_hours + weekend

    if off_hours:
        pct = len(off_hours) / len(ts_events) * 100
        if pct > 5:
            findings.append(AnomalyFinding(
                detector="time",
                severity="Medium",
                title="Significant off-hours activity",
                description=(
                    f"{len(off_hours)} events ({pct:.1f}%) occurred outside "
                    f"business hours (07:00-18:00 weekdays)."
                ),
                evidence=[
                    f"After-hours weekday: {len(after_hours)}",
                    f"Weekend: {len(weekend)}",
                ],
                events=off_hours[:50],
                score=min(pct / 10, 8.0),
            ))

    # Burst detection: 5-minute buckets
    buckets: Counter[int] = Counter()
    for e in ts_events:
        bucket = int(e.timestamp.timestamp()) // 300
        buckets[bucket] += 1

    if len(buckets) >= 3:
        counts = list(buckets.values())
        try:
            mu = statistics.mean(counts)
            sd = statistics.stdev(counts)
            if sd > 0:
                bursts = [
                    (bucket_id, count)
                    for bucket_id, count in buckets.items()
                    if (count - mu) / sd > 2
                ]
                if bursts:
                    evidence = []
                    for bid, cnt in sorted(bursts, key=lambda x: -x[1])[:5]:
                        ts = datetime.fromtimestamp(bid * 300, tz=timezone.utc)
                        evidence.append(f"{ts:%H:%M}: {cnt} events (avg {mu:.0f})")
                    findings.append(AnomalyFinding(
                        detector="time",
                        severity="High" if len(bursts) <= 2 else "Medium",
                        title="Event burst detected",
                        description=(
                            f"{len(bursts)} time bucket(s) exceeded 2σ threshold "
                            f"(mean={mu:.1f}, σ={sd:.1f})."
                        ),
                        evidence=evidence,
                        score=min(max(bursts, key=lambda x: x[1])[1] / mu * 3, 9.0),
                    ))
        except statistics.StatisticsError:
            pass

    return findings


def detect_volume_anomaly(events: list[LogEvent]) -> list[AnomalyFinding]:
    """Detect IPs or ports with anomalous event volumes."""
    findings: list[AnomalyFinding] = []

    for field_name in ("srcip", "dstport"):
        counter: Counter[str] = Counter()
        for e in events:
            val = get_field(e, field_name) or ""
            if val:
                counter[val] += 1

        if len(counter) < 3:
            continue

        counts = list(counter.values())
        try:
            mu = statistics.mean(counts)
            sd = statistics.stdev(counts)
            if sd == 0:
                continue
        except statistics.StatisticsError:
            continue

        outliers = [
            (val, cnt) for val, cnt in counter.items()
            if (cnt - mu) / sd > 2
        ]

        if not outliers:
            continue

        evidence = []
        for val, cnt in sorted(outliers, key=lambda x: -x[1])[:5]:
            z = (cnt - mu) / sd
            flag = ""
            if field_name == "srcip" and is_external(val):
                flag = " [external]"
            evidence.append(f"{val}: {cnt} events (z={z:.1f}){flag}")

        matching = [
            e for e in events
            if (get_field(e, field_name) or "") in {v for v, _ in outliers}
        ]

        findings.append(AnomalyFinding(
            detector="volume",
            severity="Medium",
            title=f"Volume outlier on {field_name}",
            description=(
                f"{len(outliers)} {field_name} value(s) have event counts "
                f">2σ from mean (mean={mu:.1f}, σ={sd:.1f})."
            ),
            evidence=evidence,
            events=matching[:50],
            score=min(max(outliers, key=lambda x: x[1])[1] / max(mu, 1) * 2, 8.0),
        ))

    return findings


def detect_patterns(events: list[LogEvent]) -> list[AnomalyFinding]:
    """Detect scanning and credential stuffing patterns."""
    findings: list[AnomalyFinding] = []
    srcip_index: dict[str, list] = {}  # lazily built if needed

    # Port scanning: same srcip hitting 10+ unique dstports
    src_ports: dict[str, set[str]] = defaultdict(set)
    for e in events:
        src = get_field(e, "srcip") or ""
        port = get_field(e, "dstport") or ""
        if src and port:
            src_ports[src].add(port)

    scanners = [(ip, ports) for ip, ports in src_ports.items() if len(ports) >= 10]
    if scanners:
        # Pre-build srcip → events index to avoid O(events * top_ips) rescanning
        srcip_index: dict[str, list] = defaultdict(list)
        for e in events:
            sip = get_field(e, "srcip") or ""
            if sip:
                srcip_index[sip].append(e)

        evidence = []
        scan_events = []
        for ip, ports in sorted(scanners, key=lambda x: -len(x[1]))[:5]:
            flag = " [external]" if is_external(ip) else ""
            evidence.append(f"{ip}: {len(ports)} unique ports{flag}")
            scan_events.extend(srcip_index.get(ip, []))
        findings.append(AnomalyFinding(
            detector="patterns",
            severity="High",
            title="Port scanning detected",
            description=f"{len(scanners)} source IP(s) contacted 10+ unique destination ports.",
            evidence=evidence,
            events=scan_events[:50],
            score=min(len(scanners) * 2 + max(len(p) for _, p in scanners) / 5, 9.0),
        ))

    # Credential stuffing: same srcip, 5+ unique usernames, all failures
    src_users: dict[str, set[str]] = defaultdict(set)
    src_fails: dict[str, int] = Counter()
    src_total: dict[str, int] = Counter()
    for e in events:
        src = get_field(e, "srcip") or ""
        user = get_field(e, "user") or get_field(e, "srcuser") or ""
        action = (get_field(e, "action") or "").lower()
        if src and user:
            src_users[src].add(user)
            src_total[src] += 1
            if "fail" in action or "deny" in action or "denied" in action:
                src_fails[src] += 1

    stuffers = [
        (ip, users)
        for ip, users in src_users.items()
        if len(users) >= 5 and src_fails.get(ip, 0) > src_total.get(ip, 1) * 0.8
    ]
    if stuffers:
        evidence = []
        stuff_events = []
        # Reuse srcip index if available, otherwise build one
        if not srcip_index:
            srcip_index = defaultdict(list)
            for e in events:
                sip = get_field(e, "srcip") or ""
                if sip:
                    srcip_index[sip].append(e)

        for ip, users in sorted(stuffers, key=lambda x: -len(x[1]))[:5]:
            evidence.append(
                f"{ip}: {len(users)} users, "
                f"{src_fails.get(ip, 0)}/{src_total.get(ip, 0)} failed"
            )
            stuff_events.extend(srcip_index.get(ip, []))
        findings.append(AnomalyFinding(
            detector="patterns",
            severity="High",
            title="Credential stuffing detected",
            description=f"{len(stuffers)} source IP(s) tried 5+ usernames with >80% failure rate.",
            evidence=evidence,
            events=stuff_events[:50],
            score=min(len(stuffers) * 3 + 4, 10.0),
        ))

    return findings


def run_all_detectors(events: list[LogEvent]) -> list[AnomalyFinding]:
    """Run all anomaly detectors and return findings sorted by score."""
    findings = []
    findings.extend(detect_first_seen(events))
    findings.extend(detect_time_anomaly(events))
    findings.extend(detect_volume_anomaly(events))
    findings.extend(detect_patterns(events))
    findings.sort(key=lambda f: f.score, reverse=True)
    return findings
