#!/usr/bin/env python3
"""Log analyzers — structured analysis of event patterns."""

from __future__ import annotations

from logparse.analyzers.failed_logins import analyze_failed_logins
from logparse.analyzers.vpn_sessions import analyze_vpn_sessions, analyze_vpn_health
from logparse.analyzers.ipsec_tunnel import analyze_ipsec_tunnel
from logparse.analyzers.sdwan import analyze_sdwan
from logparse.analyzers.dns import analyze_dns
from logparse.analyzers.correlation import analyze_correlation
from logparse.analyzers.incident import analyze_incident
from logparse.analyzers.sla import analyze_sla
from logparse.analyzers.firewall import analyze_firewall
from logparse.analyzers.auth import analyze_auth
from logparse.analyzers.traffic import analyze_traffic
from logparse.analyzers.windows import analyze_windows


def _analyze_anomaly_wrapper(events, console):
    """Wrapper bridging anomaly detectors into analyzer signature."""
    from rich.table import Table
    from logparse.analyzers.anomaly import run_all_detectors

    findings = run_all_detectors(events)
    if not findings:
        console.print("[dim]No anomalies detected.[/dim]")
        return

    table = Table(title="Anomaly Detection Results", border_style="dim")
    table.add_column("DETECTOR", style="bold")
    table.add_column("SEVERITY")
    table.add_column("FINDING")
    table.add_column("EVENTS", justify="right")
    table.add_column("SCORE", justify="right")

    sev_styles = {
        "Critical": "bold red", "High": "bright_red",
        "Medium": "yellow", "Low": "green",
    }
    for f in findings:
        style = sev_styles.get(f.severity, "")
        table.add_row(
            f.detector,
            f"[{style}]{f.severity}[/{style}]" if style else f.severity,
            f.title,
            str(len(f.events)),
            f"{f.score:.1f}",
        )

    console.print(table)

    for f in findings[:5]:
        if f.evidence:
            console.print(f"\n  [bold]{f.title}:[/bold] {f.description}")
            for ev in f.evidence[:5]:
                console.print(f"    - {ev}")


def _analyze_entity_wrapper(events, console):
    """Wrapper bridging entity scoring into analyzer signature."""
    from rich.table import Table
    from logparse.entity_scoring import score_entities
    from logparse.util import format_number

    profiles = score_entities(events)
    if not profiles:
        console.print("[dim]No scoreable entities found.[/dim]")
        return

    tier_colors = {
        "Critical": "bold red", "High": "bright_red",
        "Medium": "yellow", "Low": "green",
    }

    table = Table(title="Entity Risk Scores", border_style="dim")
    table.add_column("ENTITY", style="bold")
    table.add_column("TYPE")
    table.add_column("SCORE", justify="right")
    table.add_column("TIER")
    table.add_column("EVENTS", justify="right", style="cyan")
    table.add_column("SOURCES", justify="right")
    table.add_column("TOP EVENT TYPES")

    for p in profiles[:20]:
        style = tier_colors.get(p.risk_tier, "")
        tier_str = f"[{style}]{p.risk_tier}[/{style}]" if style else p.risk_tier
        top_types = ", ".join(
            f"{t} ({c})" for t, c in p.event_types.most_common(3)
        )
        table.add_row(
            p.entity_value,
            p.entity_type,
            f"{p.score:.1f}",
            tier_str,
            format_number(p.event_count),
            str(len(p.source_files - {""})),
            top_types,
        )

    console.print(table)

    # Summary
    tier_counts = {}
    for p in profiles:
        tier_counts[p.risk_tier] = tier_counts.get(p.risk_tier, 0) + 1
    parts = []
    for tier in ("Critical", "High", "Medium", "Low"):
        count = tier_counts.get(tier, 0)
        if count:
            style = tier_colors.get(tier, "")
            parts.append(f"[{style}]{tier}: {count}[/{style}]" if style else f"{tier}: {count}")
    if parts:
        console.print(f"  {', '.join(parts)}  ({len(profiles)} total entities)")


ANALYZERS = {
    # Security
    "auth": analyze_auth,
    "failed-logins": analyze_failed_logins,
    "anomaly": _analyze_anomaly_wrapper,
    "entity": _analyze_entity_wrapper,
    "incident": analyze_incident,
    # Network
    "firewall": analyze_firewall,
    "traffic": analyze_traffic,
    "dns": analyze_dns,
    "correlation": analyze_correlation,
    # Infrastructure
    "vpn-sessions": analyze_vpn_sessions,
    "vpn-health": analyze_vpn_health,
    "ipsec-tunnel": analyze_ipsec_tunnel,
    "sdwan": analyze_sdwan,
    "sla": analyze_sla,
    # Platform
    "windows": analyze_windows,
}

ANALYZER_INFO: dict[str, tuple[str, str]] = {
    # name → (category, description)
    "auth": ("Security", "Comprehensive authentication analysis"),
    "failed-logins": ("Security", "Brute-force and credential attack detection"),
    "anomaly": ("Security", "Statistical anomaly detection (4 detectors)"),
    "entity": ("Security", "Entity risk scoring for IPs, users, hosts"),
    "incident": ("Security", "Incident timeline reconstruction with MITRE mapping"),
    "firewall": ("Network", "Firewall traffic, deny patterns, geo enrichment"),
    "traffic": ("Network", "Network flow analysis and bandwidth stats"),
    "dns": ("Network", "DNS traffic patterns, tunneling, beaconing"),
    "correlation": ("Network", "Cross-source entity correlation"),
    "vpn-sessions": ("Infrastructure", "VPN session lifecycle and impossible travel"),
    "vpn-health": ("Infrastructure", "VPN health scoring and metrics"),
    "ipsec-tunnel": ("Infrastructure", "IPsec tunnel state and flap detection"),
    "sdwan": ("Infrastructure", "SD-WAN link health and failover timeline"),
    "sla": ("Infrastructure", "SLA / availability metrics"),
    "windows": ("Platform", "Windows Event Log security analysis"),
}
