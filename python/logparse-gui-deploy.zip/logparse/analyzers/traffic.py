#!/usr/bin/env python3
"""Network traffic flow analyzer — conversations, protocols, bandwidth."""

from __future__ import annotations

import re
import statistics
from collections import Counter

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


_IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")


def _human_bytes(n: float) -> str:
    """Format byte count to human-readable string."""
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024:
            return f"{n:.1f} {unit}" if n != int(n) else f"{int(n)} {unit}"
        n /= 1024
    return f"{n:.1f} PB"


def _is_flow_event(event: LogEvent) -> bool:
    """Detect events with network flow data."""
    srcip = get_field(event, "srcip") or get_field(event, "src") or ""
    dstip = get_field(event, "dstip") or get_field(event, "dst") or ""
    return bool(srcip and _IP_RE.match(srcip) and dstip and _IP_RE.match(dstip))


def analyze_traffic(events: list[LogEvent], console: Console) -> None:
    """Network traffic flow analysis."""
    flow_events = [e for e in events if _is_flow_event(e)]
    if not flow_events:
        console.print("[dim]No network flow events found (need srcip + dstip).[/dim]")
        return

    console.rule("Traffic Flow Analysis", style="bold cyan")

    # Collect per-event data in a single pass
    pair_counts: Counter[tuple[str, str]] = Counter()
    pair_bytes: Counter[tuple[str, str]] = Counter()
    pair_proto: dict[tuple[str, str], str] = {}
    src_ips: set[str] = set()
    dst_ips: set[str] = set()
    proto_counts: Counter[str] = Counter()
    total_sent = 0
    total_recv = 0
    has_bytes = False
    durations: list[float] = []
    duration_events: list[tuple[float, LogEvent]] = []
    has_duration = False

    # Direction tracking
    int_int = 0
    int_ext = 0
    ext_int = 0
    ext_ext = 0

    from logparse.network import is_internal

    for e in flow_events:
        srcip = get_field(e, "srcip") or get_field(e, "src") or ""
        dstip = get_field(e, "dstip") or get_field(e, "dst") or ""
        src_ips.add(srcip)
        dst_ips.add(dstip)

        pair = (srcip, dstip)
        pair_counts[pair] += 1

        proto = get_field(e, "proto") or ""
        if proto:
            proto_counts[proto] += 1
            if pair not in pair_proto:
                pair_proto[pair] = proto

        # Bytes
        sent = _safe_int(get_field(e, "sentbyte"))
        recv = _safe_int(get_field(e, "rcvdbyte"))
        if sent > 0 or recv > 0:
            has_bytes = True
            total_sent += sent
            total_recv += recv
            pair_bytes[pair] += sent + recv

        # Duration
        dur = _safe_float(get_field(e, "duration"))
        if dur > 0:
            has_duration = True
            durations.append(dur)
            duration_events.append((dur, e))

        # Direction
        src_int = is_internal(srcip)
        dst_int = is_internal(dstip)
        if src_int and dst_int:
            int_int += 1
        elif src_int:
            int_ext += 1
        elif dst_int:
            ext_int += 1
        else:
            ext_ext += 1

    total = len(flow_events)

    # Overview
    console.print(
        f"  {format_number(total)} flow events  |  "
        f"{format_number(len(src_ips))} sources  |  "
        f"{format_number(len(dst_ips))} destinations  |  "
        f"{format_number(len(pair_counts))} unique pairs"
    )
    console.print()

    # Top conversations
    _top_conversations(pair_counts, pair_bytes, pair_proto, has_bytes, console)

    # Internal vs External
    _direction_split(int_int, int_ext, ext_int, ext_ext, total, console)

    # Protocol distribution
    if proto_counts:
        _protocol_distribution(proto_counts, total, console)

    # Volume stats
    if has_bytes:
        _volume_stats(total_sent, total_recv, pair_bytes, total, console)

    # Duration outliers
    if has_duration and len(durations) >= 10:
        _duration_outliers(durations, duration_events, console)


def _safe_int(val: str | None) -> int:
    """Parse integer, return 0 on failure."""
    if not val:
        return 0
    try:
        return int(val)
    except (ValueError, TypeError):
        return 0


def _safe_float(val: str | None) -> float:
    """Parse float, return 0.0 on failure."""
    if not val:
        return 0.0
    try:
        return float(val)
    except (ValueError, TypeError):
        return 0.0


def _top_conversations(
    pair_counts: Counter, pair_bytes: Counter,
    pair_proto: dict, has_bytes: bool, console: Console,
) -> None:
    """Top source-destination pairs."""
    table = Table(title="Top Conversations", border_style="dim")
    table.add_column("SOURCE", style="bold")
    table.add_column("DESTINATION", style="bold")
    table.add_column("EVENTS", justify="right", style="cyan")
    if has_bytes:
        table.add_column("BYTES", justify="right")
    table.add_column("PROTO")

    for pair, count in pair_counts.most_common(15):
        src, dst = pair
        row = [src, dst, format_number(count)]
        if has_bytes:
            b = pair_bytes.get(pair, 0)
            row.append(_human_bytes(b) if b else "")
        row.append(pair_proto.get(pair, ""))
        table.add_row(*row)

    console.print(table)
    console.print()


def _direction_split(
    int_int: int, int_ext: int, ext_int: int, ext_ext: int,
    total: int, console: Console,
) -> None:
    """Internal vs external traffic breakdown."""
    console.print("[bold]Traffic Direction:[/bold]")

    def _pct(n: int) -> str:
        return f"{n / max(total, 1) * 100:.1f}%"

    console.print(f"  Internal → Internal   {format_number(int_int):>10}  ({_pct(int_int)})")
    console.print(f"  Internal → External   {format_number(int_ext):>10}  ({_pct(int_ext)})")
    console.print(f"  External → Internal   {format_number(ext_int):>10}  ({_pct(ext_int)})")
    console.print(f"  External → External   {format_number(ext_ext):>10}  ({_pct(ext_ext)})")
    console.print()


def _protocol_distribution(
    proto_counts: Counter, total: int, console: Console,
) -> None:
    """Protocol breakdown."""
    console.print("[bold]Protocols:[/bold]")
    for proto, count in proto_counts.most_common(10):
        pct = count / max(total, 1) * 100
        console.print(f"  {proto:<10} {format_number(count):>10}  ({pct:.1f}%)")
    console.print()


def _volume_stats(
    total_sent: int, total_recv: int, pair_bytes: Counter,
    total: int, console: Console,
) -> None:
    """Bandwidth / volume statistics."""
    console.print("[bold]Volume:[/bold]")
    console.print(f"  Total sent       {_human_bytes(total_sent)}")
    console.print(f"  Total received   {_human_bytes(total_recv)}")
    avg = (total_sent + total_recv) / max(total, 1)
    console.print(f"  Avg per session  {_human_bytes(avg)}")

    # Top talkers by bytes
    if pair_bytes:
        console.print("\n  [bold]Top Talkers (by volume):[/bold]")
        for pair, b in pair_bytes.most_common(5):
            src, dst = pair
            console.print(f"    {src} → {dst}  {_human_bytes(b)}")
    console.print()


def _duration_outliers(
    durations: list[float],
    duration_events: list[tuple[float, LogEvent]],
    console: Console,
) -> None:
    """Flag sessions with duration > 2 standard deviations above mean."""
    mean = statistics.mean(durations)
    stdev = statistics.stdev(durations) if len(durations) > 1 else 0
    threshold = mean + 2 * stdev

    if stdev == 0:
        return

    outliers = [(dur, e) for dur, e in duration_events if dur > threshold]
    if not outliers:
        return

    outliers.sort(key=lambda x: x[0], reverse=True)

    table = Table(
        title=f"Duration Outliers (>{threshold:.0f}s, mean={mean:.0f}s)",
        border_style="dim",
    )
    table.add_column("SOURCE", style="bold")
    table.add_column("DESTINATION")
    table.add_column("DURATION", justify="right", style="cyan")
    table.add_column("BYTES", justify="right")

    for dur, e in outliers[:10]:
        src = get_field(e, "srcip") or get_field(e, "src") or ""
        dst = get_field(e, "dstip") or get_field(e, "dst") or ""
        sent = _safe_int(get_field(e, "sentbyte"))
        recv = _safe_int(get_field(e, "rcvdbyte"))
        b = _human_bytes(sent + recv) if (sent + recv) > 0 else ""
        table.add_row(src, dst, f"{dur:.0f}s", b)

    console.print(table)
