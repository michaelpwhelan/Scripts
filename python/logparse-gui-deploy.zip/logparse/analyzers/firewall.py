#!/usr/bin/env python3
"""Firewall traffic analyzer — deny patterns, policy hits, geo enrichment."""

from __future__ import annotations

import re
from collections import Counter

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


_IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")

_DENY_ACTIONS = {"deny", "denied", "blocked", "drop", "dropped"}
_ALLOW_ACTIONS = {"accept", "allow", "pass", "permitted"}

_SERVICES = {
    "21": "FTP", "22": "SSH", "23": "Telnet", "25": "SMTP",
    "53": "DNS", "80": "HTTP", "110": "POP3", "123": "NTP",
    "135": "RPC", "137": "NetBIOS", "139": "NetBIOS", "143": "IMAP",
    "161": "SNMP", "389": "LDAP", "443": "HTTPS", "445": "SMB",
    "465": "SMTPS", "500": "IKE", "587": "SMTP-sub", "636": "LDAPS",
    "993": "IMAPS", "995": "POP3S", "1433": "MSSQL", "1723": "PPTP",
    "3306": "MySQL", "3389": "RDP", "4500": "NAT-T", "5060": "SIP",
    "5432": "PostgreSQL", "5900": "VNC", "5985": "WinRM",
    "8080": "HTTP-alt", "8443": "HTTPS-alt",
}


def _is_firewall_event(event: LogEvent) -> bool:
    """Detect firewall/traffic events."""
    if event.source_format == "fortigate_kv":
        return True
    action = (get_field(event, "action") or "").lower()
    if action in _DENY_ACTIONS or action in _ALLOW_ACTIONS:
        return True
    if get_field(event, "policyid"):
        return True
    subtype = (get_field(event, "subtype") or "").lower()
    return subtype in ("forward", "local", "multicast")


def analyze_firewall(events: list[LogEvent], console: Console) -> None:
    """Firewall traffic analysis — deny patterns, policies, geo enrichment."""
    fw_events = [e for e in events if _is_firewall_event(e)]
    if not fw_events:
        console.print("[dim]No firewall/traffic events found.[/dim]")
        return

    console.rule("Firewall Traffic Analysis", style="bold cyan")

    # Classify events
    deny_events: list[LogEvent] = []
    allow_events: list[LogEvent] = []
    for e in fw_events:
        action = (get_field(e, "action") or "").lower()
        if action in _DENY_ACTIONS:
            deny_events.append(e)
        elif action in _ALLOW_ACTIONS:
            allow_events.append(e)

    allow_n = len(allow_events)
    deny_n = len(deny_events)
    total = len(fw_events)

    # Overview
    if deny_n > 0 and allow_n > 0:
        ratio = allow_n / deny_n
        ratio_color = "green" if ratio > 10 else "yellow" if ratio > 5 else "red"
        console.print(
            f"  {format_number(total)} events  |  "
            f"[green]{format_number(allow_n)} allowed[/green]  |  "
            f"[red]{format_number(deny_n)} denied[/red]  |  "
            f"ratio [{ratio_color}]{ratio:.1f}:1[/{ratio_color}]"
        )
    else:
        console.print(
            f"  {format_number(total)} events  |  "
            f"{format_number(allow_n)} allowed  |  "
            f"{format_number(deny_n)} denied"
        )
    console.print()

    # Top Denied Source IPs
    if deny_events:
        _denied_source_ips(deny_events, console)
        _denied_dest_ports(deny_events, console)
        _denied_geo_distribution(deny_events, console)

    # Policy hit distribution
    _policy_distribution(fw_events, console)

    # Alerts
    _alerts(deny_events, console)


def _denied_source_ips(deny_events: list[LogEvent], console: Console) -> None:
    """Top denied source IPs with geo + threat enrichment."""
    from logparse.geoip import lookup
    from logparse.threat_intel import classify_ip

    ip_counts: Counter[str] = Counter()
    for e in deny_events:
        ip = get_field(e, "srcip") or get_field(e, "src") or ""
        if ip and _IP_RE.match(ip):
            ip_counts[ip] += 1

    if not ip_counts:
        return

    table = Table(title="Top Denied Source IPs", border_style="dim")
    table.add_column("IP", style="bold")
    table.add_column("HITS", justify="right", style="cyan")
    table.add_column("COUNTRY")
    table.add_column("CATEGORY")

    for ip, count in ip_counts.most_common(15):
        geo = lookup(ip)
        threat = classify_ip(ip)
        country = geo.get("country", "")
        cat = threat.get("category", "")
        cat_style = ""
        if cat == "tor":
            cat_style = "bold red"
        elif cat == "scanner":
            cat_style = "red"
        elif cat == "cloud":
            cat_style = "yellow"
        cat_str = f"[{cat_style}]{cat}[/{cat_style}]" if cat_style else cat
        table.add_row(ip, format_number(count), country, cat_str)

    console.print(table)
    console.print()


def _denied_dest_ports(deny_events: list[LogEvent], console: Console) -> None:
    """Top denied destination ports with service names."""
    port_counts: Counter[str] = Counter()
    for e in deny_events:
        port = get_field(e, "dstport") or get_field(e, "port") or ""
        if port:
            port_counts[port] += 1

    if not port_counts:
        return

    table = Table(title="Top Denied Destination Ports", border_style="dim")
    table.add_column("PORT", justify="right", style="bold")
    table.add_column("SERVICE")
    table.add_column("HITS", justify="right", style="cyan")

    for port, count in port_counts.most_common(15):
        service = _SERVICES.get(port, "")
        table.add_row(port, service, format_number(count))

    console.print(table)
    console.print()


def _denied_geo_distribution(
    deny_events: list[LogEvent], console: Console,
) -> None:
    """Geo distribution of denied external IPs."""
    from logparse.geoip import lookup
    from logparse.network import is_external

    country_counts: Counter[str] = Counter()
    for e in deny_events:
        ip = get_field(e, "srcip") or get_field(e, "src") or ""
        if ip and _IP_RE.match(ip) and is_external(ip):
            geo = lookup(ip)
            country = geo.get("country", "Unknown")
            country_counts[country] += 1

    if not country_counts:
        return

    console.print("[bold]Denied Traffic by Country (external only):[/bold]")
    for country, count in country_counts.most_common(10):
        console.print(f"  {country:<25} {format_number(count)}")
    console.print()


def _policy_distribution(fw_events: list[LogEvent], console: Console) -> None:
    """Policy hit distribution — only if policyid field present."""
    policy_allow: Counter[str] = Counter()
    policy_deny: Counter[str] = Counter()
    has_policy = False

    for e in fw_events:
        pid = get_field(e, "policyid")
        if not pid:
            continue
        has_policy = True
        action = (get_field(e, "action") or "").lower()
        if action in _DENY_ACTIONS:
            policy_deny[pid] += 1
        else:
            policy_allow[pid] += 1

    if not has_policy:
        return

    all_policies = set(policy_allow) | set(policy_deny)
    policy_total = {
        pid: policy_allow.get(pid, 0) + policy_deny.get(pid, 0)
        for pid in all_policies
    }
    top_policies = sorted(
        policy_total.items(), key=lambda x: x[1], reverse=True,
    )[:10]

    table = Table(title="Policy Hit Distribution", border_style="dim")
    table.add_column("POLICY", style="bold")
    table.add_column("ALLOW", justify="right", style="green")
    table.add_column("DENY", justify="right", style="red")
    table.add_column("TOTAL", justify="right", style="cyan")

    for pid, total in top_policies:
        table.add_row(
            pid,
            format_number(policy_allow.get(pid, 0)),
            format_number(policy_deny.get(pid, 0)),
            format_number(total),
        )

    console.print(table)
    console.print()


def _alerts(deny_events: list[LogEvent], console: Console) -> None:
    """Flag aggressive scanners and heavily targeted ports."""
    ip_counts: Counter[str] = Counter()
    port_counts: Counter[str] = Counter()
    for e in deny_events:
        ip = get_field(e, "srcip") or get_field(e, "src") or ""
        if ip and _IP_RE.match(ip):
            ip_counts[ip] += 1
        port = get_field(e, "dstport") or get_field(e, "port") or ""
        if port:
            port_counts[port] += 1

    aggressive = [(ip, c) for ip, c in ip_counts.items() if c > 100]
    targeted = [(p, c) for p, c in port_counts.items() if c > 500]

    if aggressive:
        console.print(f"[bold red]Aggressive scanners ({len(aggressive)}):[/bold red]")
        for ip, count in sorted(aggressive, key=lambda x: x[1], reverse=True)[:5]:
            console.print(f"  {ip:<20} {format_number(count)} denied")

    if targeted:
        console.print(f"[bold yellow]Heavily targeted ports ({len(targeted)}):[/bold yellow]")
        for port, count in sorted(targeted, key=lambda x: x[1], reverse=True)[:5]:
            svc = _SERVICES.get(port, "")
            label = f"{port}/{svc}" if svc else port
            console.print(f"  {label:<20} {format_number(count)} denied")
