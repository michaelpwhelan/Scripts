#!/usr/bin/env python3
"""Failed login analysis — aggregate by user, detect brute force."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

# Event IDs and patterns indicating failed authentication
_FAIL_EVENT_IDS = {"4625", "4771", "6273"}
_FAIL_PATTERNS = {
    "deny", "denied", "failed", "failure", "reject", "rejected",
    "authentication failed", "login failed", "auth-fail",
}

_BRUTE_FORCE_THRESHOLD = 10  # attempts from same source


@dataclass
class LoginAttempt:
    """Tracks failed login attempts per user."""

    user: str
    count: int = 0
    source_ips: set[str] = field(default_factory=set)
    first_seen: datetime | None = None
    last_seen: datetime | None = None


def _is_auth_failure(event: LogEvent) -> bool:
    """Check if event represents a failed authentication."""
    eid = event.extra.get("EventID", "")
    if eid in _FAIL_EVENT_IDS:
        return True

    # FortiGate auth deny
    action = event.extra.get("action", "").lower()
    subtype = event.extra.get("subtype", "").lower()
    if action in ("deny", "denied") and subtype in ("auth", "user"):
        return True

    # NPS reject
    if "reject" in event.message.lower() and "nps" in event.source.lower():
        return True

    # generic pattern match
    msg = event.message.lower()
    return any(p in msg for p in _FAIL_PATTERNS)


def analyze_failed_logins(events: list[LogEvent], console: Console) -> None:
    """Aggregate failed login attempts by user."""
    attempts: dict[str, LoginAttempt] = defaultdict(lambda: LoginAttempt(user=""))

    for e in events:
        if not _is_auth_failure(e):
            continue

        # extract user
        user = (
            get_field(e, "TargetUserName")
            or get_field(e, "user")
            or get_field(e, "username")
            or get_field(e, "srcuser")
            or "(unknown)"
        )

        # extract source IP
        src_ip = (
            get_field(e, "IpAddress")
            or get_field(e, "srcip")
            or get_field(e, "src")
            or ""
        )

        attempt = attempts[user]
        attempt.user = user
        attempt.count += 1
        if src_ip:
            attempt.source_ips.add(src_ip)
        if e.timestamp:
            if attempt.first_seen is None or e.timestamp < attempt.first_seen:
                attempt.first_seen = e.timestamp
            if attempt.last_seen is None or e.timestamp > attempt.last_seen:
                attempt.last_seen = e.timestamp

    if not attempts:
        console.print("[dim]No failed login events found.[/dim]")
        return

    # sort by count descending
    sorted_attempts = sorted(
        attempts.values(), key=lambda a: a.count, reverse=True
    )

    console.rule("Failed Login Analysis", style="bold red")
    console.print(
        f"  Total failed attempts: {format_number(sum(a.count for a in sorted_attempts))}"
    )
    console.print(f"  Unique users: {len(sorted_attempts)}")
    console.print()

    # main table
    table = Table(show_header=True, expand=True)
    table.add_column("USER", style="bold")
    table.add_column("ATTEMPTS", justify="right", style="red")
    table.add_column("UNIQUE IPs", justify="right", style="cyan")
    table.add_column("FIRST SEEN")
    table.add_column("LAST SEEN")
    table.add_column("FLAGS", style="yellow")

    for a in sorted_attempts[:25]:
        flags = []
        if a.count >= _BRUTE_FORCE_THRESHOLD:
            flags.append("BRUTE-FORCE")
        if len(a.source_ips) >= 5:
            flags.append("DISTRIBUTED")

        table.add_row(
            a.user,
            format_number(a.count),
            str(len(a.source_ips)),
            a.first_seen.strftime("%Y-%m-%d %H:%M") if a.first_seen else "",
            a.last_seen.strftime("%Y-%m-%d %H:%M") if a.last_seen else "",
            " ".join(flags),
        )

    console.print(table)

    # brute force alerts
    brute = [a for a in sorted_attempts if a.count >= _BRUTE_FORCE_THRESHOLD]
    if brute:
        console.print()
        console.print(
            f"[bold red]⚠ {len(brute)} user(s) with {_BRUTE_FORCE_THRESHOLD}+ "
            f"failed attempts (possible brute force)[/bold red]"
        )
    console.print()
    console.print(
        "[dim]Drill down: where user=<name> | "
        "where action=deny | where failed[/dim]"
    )
    has_unknown = any(a.user == "(unknown)" for a in sorted_attempts)
    if has_unknown:
        console.print(
            "[dim](unknown) = events with no user field. "
            "Try: where failed not user:*[/dim]"
        )
