#!/usr/bin/env python3
"""Cross-source correlation analyzer — find entities appearing across multiple sources."""

from __future__ import annotations

from collections import defaultdict

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_IP_FIELDS = {"srcip", "dstip", "src", "dst", "ipaddr", "ip", "clientip",
              "remip", "natip", "natsrcip", "natdstip", "local_ip", "remote_ip"}
_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser", "account", "samaccountname", "upn"}


def analyze_correlation(events: list[LogEvent], console: Console) -> None:
    """Find entities (IPs, users) that appear across multiple log sources."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    console.rule("Cross-Source Correlation", style="bold cyan")

    # Build entity-to-sources maps
    ip_sources: defaultdict[str, set[str]] = defaultdict(set)
    user_sources: defaultdict[str, set[str]] = defaultdict(set)

    for e in events:
        source_file = e.source_file or e.source or "unknown"

        for field in _IP_FIELDS:
            val = get_field(e, field)
            if val and not _is_private_ip(val):
                ip_sources[val].add(source_file)

        for field in _USER_FIELDS:
            val = get_field(e, field)
            if val and len(val) > 1:
                user_sources[val.lower()].add(source_file)

    # Filter to entities in 2+ sources
    multi_source_ips = {
        ip: sources for ip, sources in ip_sources.items() if len(sources) >= 2
    }
    multi_source_users = {
        user: sources for user, sources in user_sources.items() if len(sources) >= 2
    }

    # IP correlations
    if multi_source_ips:
        sorted_ips = sorted(
            multi_source_ips.items(), key=lambda x: len(x[1]), reverse=True
        )
        table = Table(title=f"IPs Across Sources ({len(sorted_ips)})", border_style="dim")
        table.add_column("IP", style="bold")
        table.add_column("Sources", justify="right", style="cyan")
        table.add_column("Source Files")

        for ip, sources in sorted_ips[:20]:
            source_list = ", ".join(sorted(sources))
            if len(source_list) > 60:
                source_list = source_list[:57] + "..."
            table.add_row(ip, str(len(sources)), source_list)

        console.print(table)
    else:
        console.print("[dim]No IPs found across multiple sources.[/dim]")

    # User correlations
    if multi_source_users:
        sorted_users = sorted(
            multi_source_users.items(), key=lambda x: len(x[1]), reverse=True
        )
        table = Table(title=f"Users Across Sources ({len(sorted_users)})", border_style="dim")
        table.add_column("User", style="bold")
        table.add_column("Sources", justify="right", style="cyan")
        table.add_column("Source Files")

        for user, sources in sorted_users[:20]:
            source_list = ", ".join(sorted(sources))
            if len(source_list) > 60:
                source_list = source_list[:57] + "..."
            table.add_row(user, str(len(sources)), source_list)

        console.print(table)
    else:
        console.print("\n[dim]No users found across multiple sources.[/dim]")

    total = len(multi_source_ips) + len(multi_source_users)
    console.print(f"\n  [dim]{format_number(total)} entities linked across sources[/dim]")


def _is_private_ip(ip: str) -> bool:
    """Quick check for private/reserved IPs."""
    import ipaddress
    try:
        addr = ipaddress.ip_address(ip)
        return addr.is_private or addr.is_loopback or addr.is_reserved
    except ValueError:
        return False
