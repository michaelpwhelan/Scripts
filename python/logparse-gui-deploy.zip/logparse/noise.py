#!/usr/bin/env python3
"""Noise profile loading — YAML/JSON presets for excluding known-noisy sources."""

from __future__ import annotations

import json
from fnmatch import fnmatch
from pathlib import Path

from logparse.config_loader import get_config_dir
from logparse.models import LogEvent, get_field

_PROFILE_DIRS = [
    Path(__file__).parent / "profiles",  # shipped (future)
    get_config_dir() / "noise",
]


def find_profile(name: str) -> Path | None:
    """Search profile dirs for a matching file."""
    # direct path
    p = Path(name)
    if p.exists():
        return p

    for d in _PROFILE_DIRS:
        for ext in ("", ".json", ".yaml", ".yml"):
            candidate = d / f"{name}{ext}"
            if candidate.exists():
                return candidate
    return None


def load_profile(path: Path) -> dict:
    """Load a noise profile from file."""
    text = path.read_text(encoding="utf-8")

    # try YAML first
    if path.suffix in (".yaml", ".yml"):
        try:
            import yaml
            return yaml.safe_load(text) or {}
        except ImportError:
            pass

    # fall back to JSON
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        # try simple line-based format
        exclude = []
        for line in text.splitlines():
            line = line.strip()
            if line and not line.startswith("#"):
                exclude.append(line)
        return {"exclude": exclude}


def apply_noise_filter(
    events: list[LogEvent],
    profile: dict,
) -> tuple[list[LogEvent], int]:
    """Apply noise profile exclusions. Returns (filtered_events, removed_count)."""
    exclude_patterns = profile.get("exclude", [])
    if not exclude_patterns:
        return events, 0

    # parse patterns into (field, pattern) tuples
    parsed: list[tuple[str, str]] = []
    for pat in exclude_patterns:
        if ":" in pat:
            field, value = pat.split(":", 1)
            parsed.append((field.strip(), value.strip()))
        else:
            parsed.append(("", pat.strip()))

    def _is_noisy(event: LogEvent) -> bool:
        for field, pattern in parsed:
            if field:
                val = get_field(event, field) or ""
                if fnmatch(val, pattern):
                    return True
            else:
                # match against any field
                searchable = [event.source, event.message]
                searchable.extend(event.extra.values())
                if any(fnmatch(s, pattern) for s in searchable if s):
                    return True
        return False

    filtered = [e for e in events if not _is_noisy(e)]
    removed = len(events) - len(filtered)
    return filtered, removed
