#!/usr/bin/env python3
"""CLI subcommand handlers — fetch and diff."""

from __future__ import annotations

import difflib
import sys
from pathlib import Path

from rich.console import Console
from rich.text import Text


def handle_fetch(argv: list[str]) -> None:
    """Handle the ``logparse fetch`` subcommand."""
    import argparse as _ap

    p = _ap.ArgumentParser(prog="logparse fetch")
    p.add_argument("connector", nargs="?", default="",
                    help="Connector name (graph, fortianalyzer)")
    p.add_argument("--endpoint", "-e", metavar="EP",
                    help="Specific endpoint (omit for all)")
    p.add_argument("--time", "-t", default="24h", metavar="RANGE",
                    help="Time range (default: 24h)")
    p.add_argument("--output-dir", "-o", default=".", metavar="DIR",
                    help="Output directory for JSONL files")
    p.add_argument("--max", type=int, default=10_000,
                    help="Max records per endpoint")
    p.add_argument("--list", action="store_true",
                    help="List available connectors and endpoints")

    try:
        args = p.parse_args(argv)
    except SystemExit:
        return

    from logparse.connectors import get_connector, list_connectors
    from logparse.config_loader import load_config

    if args.list or not args.connector:
        print("Available connectors:")
        for name, endpoints in list_connectors():
            print(f"  {name}: {endpoints}")
        return

    try:
        connector = get_connector(args.connector)
    except ValueError as exc:
        print(str(exc), file=sys.stderr)
        sys.exit(1)

    config = load_config()
    connector_config = config.get("connectors", {}).get(args.connector, {})

    try:
        connector.configure(connector_config)
        connector.authenticate()
    except (ValueError, ConnectionError) as exc:
        print(f"Error: {exc}", file=sys.stderr)
        sys.exit(1)

    output_dir = Path(args.output_dir)
    if args.endpoint:
        result = connector.fetch(
            args.endpoint, time_range=args.time,
            output_dir=output_dir, max_records=args.max,
        )
        print(f"{result.endpoint}: {result.event_count} records \u2192 {result.output_path}")
    else:
        results = connector.fetch_all(
            time_range=args.time, output_dir=output_dir,
            max_records=args.max,
        )
        for r in results:
            status = "OK" if not r.errors else "ERR"
            print(f"  {r.endpoint}: {status} {r.event_count} records \u2192 {r.output_path}")


def handle_diff(argv: list[str]) -> None:
    """Handle the ``logparse diff`` subcommand."""
    if len(argv) < 2:
        print("Usage: logparse diff <file1> <file2>", file=sys.stderr)
        sys.exit(1)

    file_a, file_b = Path(argv[0]), Path(argv[1])
    if not file_a.exists() or not file_b.exists():
        print(f"File not found: {file_a if not file_a.exists() else file_b}",
              file=sys.stderr)
        sys.exit(1)

    console = Console()

    # try config-aware diff first
    from logparse.parsers import detect_format
    fmt_a = detect_format(file_a)
    fmt_b = detect_format(file_b)

    if fmt_a == "fortigate_conf" and fmt_b == "fortigate_conf":
        lines_a = file_a.read_text(encoding="utf-8", errors="replace").splitlines()
        lines_b = file_b.read_text(encoding="utf-8", errors="replace").splitlines()
        _config_diff(lines_a, lines_b, file_a.name, file_b.name, console)
        return

    # fallback: line-level diff
    lines_a = set(file_a.read_text(encoding="utf-8", errors="replace").splitlines())
    lines_b = set(file_b.read_text(encoding="utf-8", errors="replace").splitlines())

    only_a = lines_a - lines_b
    only_b = lines_b - lines_a
    common = lines_a & lines_b

    console.rule(f"Only in {file_a.name}", style="red")
    for line in sorted(only_a)[:50]:
        console.print(Text(f"- {line}", style="red"))
    if len(only_a) > 50:
        console.print(f"  ... and {len(only_a) - 50} more lines")

    console.rule(f"Only in {file_b.name}", style="green")
    for line in sorted(only_b)[:50]:
        console.print(Text(f"+ {line}", style="green"))
    if len(only_b) > 50:
        console.print(f"  ... and {len(only_b) - 50} more lines")

    console.print()
    console.print(
        f"[dim]Common: {len(common)} lines | "
        f"Only in {file_a.name}: {len(only_a)} | "
        f"Only in {file_b.name}: {len(only_b)}[/dim]"
    )


def _config_diff(
    lines_a: list[str], lines_b: list[str],
    name_a: str, name_b: str, console: Console,
) -> None:
    """Section-aware config diff for FortiGate .conf files."""
    diff = list(difflib.unified_diff(
        lines_a, lines_b,
        fromfile=name_a, tofile=name_b,
        lineterm="",
    ))
    if not diff:
        console.print("[green]Files are identical.[/green]")
        return

    for line in diff:
        if line.startswith("---") or line.startswith("+++"):
            console.print(Text(line, style="bold"))
        elif line.startswith("@@"):
            console.print(Text(line, style="cyan"))
        elif line.startswith("-"):
            console.print(Text(line, style="red"))
        elif line.startswith("+"):
            console.print(Text(line, style="green"))
        else:
            console.print(line)
