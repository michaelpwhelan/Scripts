#!/usr/bin/env python3
"""Interactive REPL for log investigation."""

from __future__ import annotations

try:
    import readline
except ImportError:
    readline = None  # Windows — tab completion/history unavailable
from typing import Callable

from rich.console import Console

from logparse.commands import CommandContext, get_registry
from logparse.dispatch import execute_input
from logparse.models import LogEvent
from logparse.session import Session
from logparse.util import format_number


def _build_completer(session: Session) -> Callable:
    """Build a readline tab-completer from session state."""
    _commands = [cmd.name for cmd in get_registry()]
    _keywords = [
        "sources", "fields", "skip", "timeline", "filter", "history",
        "star", "starred", "export",
    ]

    def completer(text: str, state: int) -> str | None:
        """Readline tab-completion callback for REPL commands."""
        line = readline.get_line_buffer().lstrip() if readline else text
        candidates: list[str] = []

        if " " not in line:
            # completing verb
            candidates = [c for c in _commands if c.startswith(text.lower())]
        else:
            parts = line.split()
            verb = parts[0].lower() if parts else ""
            if verb == "show":
                candidates = [k for k in _keywords if k.startswith(text.lower())]
            elif verb in ("where", "search", "count", "sort", "select"):
                # suggest field names
                fields = session.all_field_names()
                candidates = [f for f in fields if f.lower().startswith(text.lower())]
            elif verb in ("set",):
                opts = ["time", "filter", "ip", "relativetime"]
                candidates = [o for o in opts if o.startswith(text.lower())]

        if state < len(candidates):
            return candidates[state]
        return None

    return completer


def _prompt(session: Session) -> str:
    """Build the REPL prompt string."""
    count = len(session.filtered_events)
    if session.active_filter:
        return f"logparse ({session.active_filter}) [{format_number(count)}]> "
    return f"logparse [{format_number(count)}]> "


def run_repl(
    events: list[LogEvent],
    loaded_files: list[str],
    loaded_formats: list[str],
    load_summary=None,
) -> None:
    """Main REPL entry point."""
    console = Console()
    session = Session(
        all_events=events,
        filtered_events=list(events),
        source_files=loaded_files,
        loaded_formats=loaded_formats,
    )
    ctx = CommandContext(console=console)

    # readline setup
    if readline is not None:
        readline.parse_and_bind("tab: complete")
        readline.set_completer(_build_completer(session))
        readline.set_completer_delims(" \t\n:=")

    # history file
    from logparse.config_loader import get_cache_dir
    hist_dir = get_cache_dir()
    hist_dir.mkdir(parents=True, exist_ok=True)
    hist_file = str(hist_dir / "repl_history")
    if readline is not None:
        try:
            readline.read_history_file(hist_file)
        except FileNotFoundError:
            pass

    # load user config
    from logparse.config_loader import ensure_dirs, load_config, HINTS
    ensure_dirs()
    session.config = load_config()

    if load_summary:
        from logparse.verbose import VerboseOutput, InputMode
        repl_verbose = VerboseOutput(console, InputMode.MULTI)
        repl_verbose.render_dashboard(load_summary)
    else:
        console.print(
            f"[bold]logparse interactive[/bold] — "
            f"{format_number(len(events))} events from "
            f"{len(loaded_files)} file(s)"
        )
    console.print("[dim]Type 'help' for commands, 'quit' to exit.[/dim]\n")

    while True:
        try:
            raw = input(_prompt(session))
        except (EOFError, KeyboardInterrupt):
            console.print()
            break

        try:
            execute_input(session, raw, ctx)
        except SystemExit:
            break

    # save history on exit
    if readline is not None:
        try:
            readline.write_history_file(hist_file)
        except OSError:
            pass
