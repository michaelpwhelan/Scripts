#!/usr/bin/env python3
"""report command — generate structured reports."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "report",
    r"^report\s+.+",
    category="Analysis",
    usage="report <summary|morning|audit|compliance|timeline> [--export file]",
    help="Generate a structured report.",
)
def cmd_report(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Generate a structured report."""
    from logparse.reports import REPORTS

    console = ctx.console
    args = parsed.args.strip()

    # parse --export
    export_path = None
    m = re.search(r"--export\s+(\S+)", args)
    if m:
        export_path = m.group(1)
        args = args[:m.start()].strip()

    name = args.lower()
    report_fn = REPORTS.get(name)
    if report_fn is None:
        console.print(f"[red]Unknown report: {name}[/red]")
        console.print(f"Available: {', '.join(REPORTS.keys())}")
        return

    report_fn(session.filtered_events, console)

    if export_path:
        from logparse.output.html import render_html_report
        render_html_report(
            session.filtered_events, export_path,
            title=f"logparse {name.title()} Report",
        )
        console.print(f"\nExported to {export_path}")

    session.log_command(parsed.raw, f"report {name}")
