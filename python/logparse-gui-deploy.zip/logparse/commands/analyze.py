#!/usr/bin/env python3
"""analyze command — unified security assessment and structured analyzers."""

from __future__ import annotations

from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import LogEvent, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "analyze",
    r"^analyze(\s+.*)?$",
    category="Analysis",
    usage="analyze | analyze <name> | analyze list",
    help="Run security assessment or a specific analyzer.",
)
def cmd_analyze(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Run security assessment or a specific analyzer."""
    from logparse.analyzers import ANALYZERS

    console = ctx.console
    name = parsed.args.strip().lower()

    # No args → unified assessment
    if not name:
        _unified_assessment(session, console)
        session.log_command(parsed.raw, "analyze: unified assessment")
        return

    # List all analyzers
    if name == "list":
        _list_analyzers(console)
        return

    # Dispatch to specific analyzer
    analyzer = ANALYZERS.get(name)
    if analyzer is None:
        console.print(f"[red]Unknown analyzer: {name}[/red]")
        console.print(f"[dim]Run 'analyze list' to see all available analyzers.[/dim]")
        return

    analyzer(session.filtered_events, console)
    session.log_command(parsed.raw, f"analyze {name}")


def _list_analyzers(console) -> None:
    """List all available analyzers grouped by category."""
    from logparse.analyzers import ANALYZER_INFO

    console.print("[bold]Available Analyzers[/bold]\n")

    # Group by category, preserving insertion order
    categories: dict[str, list[tuple[str, str]]] = {}
    for name, (category, description) in ANALYZER_INFO.items():
        categories.setdefault(category, []).append((name, description))

    for category, items in categories.items():
        console.print(f"  [bold yellow]{category}[/bold yellow]")
        for name, desc in items:
            console.print(f"    [cyan]analyze {name:<16}[/cyan] {desc}")
        console.print()

    console.print("[dim]Run 'analyze' with no args for a unified security assessment.[/dim]")


# ------------------------------------------------------------------
# Unified security assessment
# ------------------------------------------------------------------

def _unified_assessment(session: Session, console) -> None:
    """Run a unified security assessment across all available data."""
    from rich.panel import Panel
    from rich.table import Table
    from logparse.analyzers.anomaly import run_all_detectors
    from logparse.entity_scoring import score_entities

    events = session.filtered_events
    if not events:
        console.print("[dim]No events to analyze.[/dim]")
        return

    console.rule("Security Assessment", style="bold cyan")

    # -- Data profile --
    data_profile = _detect_data_types(events)
    _show_data_profile(data_profile, events, console)

    # -- Entity risk scoring --
    profiles = score_entities(events)
    top_entities = profiles[:10]

    # -- Anomaly detection --
    findings = run_all_detectors(events)

    # -- Compute overall risk score --
    risk_score = _compute_risk_score(events, profiles, findings)
    risk_color = "bold red" if risk_score >= 70 else "yellow" if risk_score >= 40 else "green"

    console.print()
    console.print(
        f"  [bold]Overall Risk:[/bold]  "
        f"[{risk_color}]{risk_score}/100[/{risk_color}]"
    )
    console.print()

    # -- Top findings --
    if findings:
        _show_top_findings(findings, console)

    # -- Entity watchlist --
    if top_entities:
        _show_entity_watchlist(top_entities, console)

    # -- Recommendations --
    _show_recommendations(data_profile, events, profiles, findings, console)

    # -- Drill-down hints --
    _show_drill_hints(data_profile, console)


def _detect_data_types(events: list[LogEvent]) -> dict[str, bool]:
    """Single-pass scan to detect what data types are present."""
    has_firewall = False
    has_windows = False
    has_vpn = False
    has_dns = False
    has_auth = False

    _deny_actions = {"deny", "denied", "blocked", "drop", "accept", "allow"}
    _auth_subtypes = {"auth", "user"}
    _vpn_keywords = {"vpn", "sslvpn", "tunnel", "ipsec"}
    _auth_ids = {"4624", "4625", "4648", "4740", "4672", "4771"}

    for e in events:
        if has_firewall and has_windows and has_vpn and has_dns and has_auth:
            break

        action = (get_field(e, "action") or "").lower()
        subtype = (get_field(e, "subtype") or "").lower()
        eid = get_field(e, "EventID") or ""

        if not has_firewall:
            if (action in _deny_actions or get_field(e, "policyid")
                    or e.source_format == "fortigate_kv"):
                has_firewall = True

        if not has_windows:
            if e.source_format in ("evtx", "windows_xml") or eid:
                has_windows = True

        if not has_vpn:
            if subtype in _vpn_keywords or any(
                kw in e.message.lower() for kw in ("tunnel-up", "tunnel-down", "vpn")
            ):
                has_vpn = True

        if not has_dns:
            if subtype == "dns" or get_field(e, "qname"):
                has_dns = True

        if not has_auth:
            if (subtype in _auth_subtypes or eid in _auth_ids
                    or action in ("ssl-login", "ssl-login-fail")):
                has_auth = True

    return {
        "firewall": has_firewall,
        "windows": has_windows,
        "vpn": has_vpn,
        "dns": has_dns,
        "auth": has_auth,
    }


def _show_data_profile(
    profile: dict[str, bool], events: list[LogEvent], console,
) -> None:
    """Show what data types are present."""
    total = len(events)
    ts_events = [e for e in events if e.timestamp]

    parts = []
    for dtype, present in profile.items():
        if present:
            parts.append(f"[green]{dtype}[/green]")

    console.print(f"  {format_number(total)} events  |  data: {', '.join(parts) if parts else '[dim]generic[/dim]'}")
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        console.print(f"  Time range: {first:%Y-%m-%d %H:%M} — {last:%Y-%m-%d %H:%M}")

    # Severity breakdown
    sev_counts = Counter(e.severity for e in events)
    sev_parts = []
    for sev in ("Critical", "High", "Medium", "Low", "Info"):
        count = sev_counts.get(sev, 0)
        if count:
            color = {"Critical": "bold red", "High": "bright_red", "Medium": "yellow"}.get(sev, "")
            if color:
                sev_parts.append(f"[{color}]{sev}:{format_number(count)}[/{color}]")
            else:
                sev_parts.append(f"{sev}:{format_number(count)}")
    if sev_parts:
        console.print(f"  Severity: {', '.join(sev_parts)}")


def _compute_risk_score(
    events: list[LogEvent],
    profiles: list,
    findings: list,
) -> int:
    """Compute overall risk score 0-100."""
    score = 0.0

    # Entity risk contribution (top entity score, capped at 40)
    if profiles:
        top_score = profiles[0].score
        # Normalize: 50+ entity score → full 40 points
        score += min(top_score / 50 * 40, 40)

    # Anomaly contribution (up to 30 points)
    if findings:
        sev_weights = {"Critical": 10, "High": 5, "Medium": 2, "Low": 1}
        anomaly_score = sum(
            sev_weights.get(f.severity, 1) for f in findings
        )
        score += min(anomaly_score, 30)

    # Failure ratio contribution (up to 20 points)
    deny_count = sum(
        1 for e in events
        if (get_field(e, "action") or "").lower()
        in ("deny", "denied", "blocked", "drop")
    )
    if events:
        deny_ratio = deny_count / len(events)
        score += min(deny_ratio * 100, 20)

    # Severity contribution (up to 10 points)
    crit_high = sum(
        1 for e in events if e.severity in ("Critical", "High")
    )
    if events:
        severity_ratio = crit_high / len(events)
        score += min(severity_ratio * 50, 10)

    return min(int(score), 100)


def _show_top_findings(findings: list, console) -> None:
    """Show top anomaly findings."""
    from rich.table import Table

    table = Table(title="Top Findings", border_style="dim")
    table.add_column("SEVERITY")
    table.add_column("FINDING")
    table.add_column("EVENTS", justify="right")
    table.add_column("SCORE", justify="right")

    sev_styles = {
        "Critical": "bold red", "High": "bright_red",
        "Medium": "yellow", "Low": "green",
    }
    for f in findings[:8]:
        style = sev_styles.get(f.severity, "")
        table.add_row(
            f"[{style}]{f.severity}[/{style}]" if style else f.severity,
            f.title,
            str(len(f.events)),
            f"{f.score:.1f}",
        )

    console.print(table)

    # Brief evidence for top 3
    for f in findings[:3]:
        if f.evidence:
            console.print(f"  [bold]{f.title}:[/bold] {f.description}")
            for ev in f.evidence[:3]:
                console.print(f"    - {ev}")
    console.print()


def _show_entity_watchlist(top_entities: list, console) -> None:
    """Show top risk entities."""
    from rich.table import Table

    tier_colors = {
        "Critical": "bold red", "High": "bright_red",
        "Medium": "yellow", "Low": "green",
    }

    table = Table(title="Entity Watchlist", border_style="dim")
    table.add_column("ENTITY", style="bold")
    table.add_column("TYPE")
    table.add_column("SCORE", justify="right")
    table.add_column("TIER")
    table.add_column("EVENTS", justify="right", style="cyan")

    for p in top_entities[:5]:
        style = tier_colors.get(p.risk_tier, "")
        tier_str = f"[{style}]{p.risk_tier}[/{style}]" if style else p.risk_tier
        table.add_row(
            p.entity_value, p.entity_type,
            f"{p.score:.1f}", tier_str,
            format_number(p.event_count),
        )

    console.print(table)
    console.print()


def _show_recommendations(
    data_profile: dict, events: list, profiles: list,
    findings: list, console,
) -> None:
    """Generate actionable recommendations."""
    recs: list[str] = []

    # From entities
    for p in profiles[:3]:
        if p.risk_tier in ("Critical", "High"):
            top_type = p.event_types.most_common(1)
            reason = top_type[0][0] if top_type else "suspicious activity"
            recs.append(
                f"Investigate {p.entity_type} [bold]{p.entity_value}[/bold] "
                f"— {format_number(p.event_count)} events, {reason}"
            )

    # From anomalies
    for f in findings[:3]:
        if f.severity in ("Critical", "High"):
            recs.append(f"{f.title} — {f.description}")

    # From deny ratio
    deny_count = sum(
        1 for e in events
        if (get_field(e, "action") or "").lower()
        in ("deny", "denied", "blocked", "drop")
    )
    if events and deny_count / len(events) > 0.3:
        recs.append(
            f"High deny rate ({deny_count / len(events) * 100:.0f}%) "
            f"— review firewall rules with 'analyze firewall'"
        )

    if recs:
        console.print("[bold]Recommendations:[/bold]")
        for i, rec in enumerate(recs[:5], 1):
            console.print(f"  {i}. {rec}")
        console.print()


def _show_drill_hints(data_profile: dict, console) -> None:
    """Suggest relevant drill-down analyzers."""
    hints = []
    if data_profile.get("firewall"):
        hints.append("analyze firewall")
    if data_profile.get("auth"):
        hints.append("analyze auth")
    if data_profile.get("windows"):
        hints.append("analyze windows")
    if data_profile.get("vpn"):
        hints.append("analyze vpn-sessions")
    if data_profile.get("dns"):
        hints.append("analyze dns")
    hints.append("analyze entity")

    console.print(f"  [dim]Drill down: {' | '.join(hints)}[/dim]")


# ------------------------------------------------------------------
# SD-WAN (separate command, kept here)
# ------------------------------------------------------------------

@register(
    "sdwan",
    r"^sdwan(\s+.*)?$",
    category="Analysis",
    usage="sdwan | sdwan failovers",
    help="SD-WAN link health dashboard and failover timeline.",
)
def cmd_sdwan(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """SD-WAN link health dashboard and failover timeline."""
    from logparse.analyzers.sdwan import analyze_sdwan, analyze_sdwan_failovers

    console = ctx.console
    args = (parsed.args or "").strip().lower()

    if args == "failovers":
        analyze_sdwan_failovers(session.filtered_events, console)
        session.log_command(parsed.raw, "sdwan failovers")
    else:
        analyze_sdwan(session.filtered_events, console)
        session.log_command(parsed.raw, "sdwan dashboard")
