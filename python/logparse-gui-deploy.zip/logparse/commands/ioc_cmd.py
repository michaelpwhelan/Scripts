#!/usr/bin/env python3
"""ioc command — import, match, and manage indicators of compromise."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "ioc",
    r"^ioc(?:\s+.+)?$",
    category="Threat Intel",
    usage="ioc import <path> | ioc match | ioc list | ioc clear",
    help=(
        "Manage indicators of compromise.  "
        "'ioc import file.csv' loads IOCs (value[,type] per line).  "
        "'ioc match' scans current events against loaded IOCs.  "
        "'ioc list' shows loaded IOC sets.  "
        "'ioc clear' removes all loaded IOCs."
    ),
)
def cmd_ioc(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Manage indicators of compromise."""
    from pathlib import Path

    from logparse.ioc import (
        load_ioc_csv,
        match_events,
        matched_event_set,
    )

    console = ctx.console
    args_str = (parsed.args or "").strip()
    parts = args_str.split(None, 1)
    subcmd = parts[0].lower() if parts else ""

    if subcmd == "import" and len(parts) > 1:
        path = Path(parts[1].strip())
        if not path.exists():
            console.print(f"[red]File not found: {path}[/red]")
            return
        try:
            ioc_set = load_ioc_csv(path)
        except (OSError, ValueError, UnicodeDecodeError) as exc:
            console.print(f"[red]Error loading IOCs: {exc}[/red]")
            return
        var_name = f"_ioc_{path.stem}"
        session.variables[var_name] = ioc_set
        console.print(
            f"[green]Loaded {len(ioc_set.indicators)} IOCs from "
            f"{path.name}[/green] (stored as {var_name})"
        )
        session.log_command(ctx.raw_input, f"loaded {len(ioc_set.indicators)} IOCs")

    elif subcmd == "stix" and len(parts) > 1:
        import json as _json

        path = Path(parts[1].strip())
        if not path.exists():
            console.print(f"[red]File not found: {path}[/red]")
            return
        try:
            bundle = _json.loads(path.read_text(encoding="utf-8"))
            from logparse.ioc import load_ioc_stix
            ioc_set = load_ioc_stix(bundle, feed_name=path.stem)
        except (_json.JSONDecodeError, OSError, ValueError, KeyError) as exc:
            console.print(f"[red]Error loading STIX: {exc}[/red]")
            return
        var_name = f"_ioc_{path.stem}"
        session.variables[var_name] = ioc_set
        console.print(
            f"[green]Loaded {len(ioc_set.indicators)} IOCs from "
            f"STIX bundle {path.name}[/green]"
        )
        session.log_command(ctx.raw_input, f"loaded STIX IOCs from {path.name}")

    elif subcmd == "match":
        ioc_sets = _get_ioc_sets(session)
        if not ioc_sets:
            console.print("[dim]No IOCs loaded. Use 'ioc import <file>' first.[/dim]")
            return
        results = match_events(session.filtered_events, ioc_sets)
        if not results:
            console.print("[dim]No IOC matches found.[/dim]")
            return

        from rich.table import Table

        table = Table(title="IOC Matches")
        table.add_column("IOC", style="red")
        table.add_column("Type")
        table.add_column("Hits", justify="right")
        for m in results[:50]:
            table.add_row(m.ioc_value, m.ioc_type, str(m.match_count))
        console.print(table)

        # Push filter to matching events
        matching = matched_event_set(session.filtered_events, ioc_sets)
        if matching:
            total_iocs = sum(len(s.indicators) for s in ioc_sets)
            session.push_filter(f"ioc match ({len(results)} hits / {total_iocs} IOCs)")
            session.filtered_events = matching
            console.print(
                f"[green]Filtered to {len(matching)} events matching IOCs[/green]"
            )
        session.log_command(ctx.raw_input, f"{len(results)} IOC matches")

    elif subcmd == "list":
        ioc_sets = _get_ioc_sets(session)
        if not ioc_sets:
            console.print("[dim]No IOCs loaded.[/dim]")
            return
        console.print("[bold]Loaded IOC Sets:[/bold]")
        for s in ioc_sets:
            console.print(
                f"  [cyan]{s.name}[/cyan]: {len(s.indicators)} indicators "
                f"({s.source}, loaded {s.loaded_at:%H:%M:%S})"
            )

    elif subcmd == "clear":
        cleared = [k for k in list(session.variables) if k.startswith("_ioc_")]
        for k in cleared:
            del session.variables[k]
        console.print(f"[green]Cleared {len(cleared)} IOC set(s)[/green]")
        session.log_command(ctx.raw_input, f"cleared {len(cleared)} IOC sets")

    else:
        console.print("[dim]Usage: ioc import <path> | ioc match | ioc list | ioc clear[/dim]")


def _get_ioc_sets(session: Session) -> list:
    """Collect all IOCSet objects stored in session variables."""
    from logparse.ioc import IOCSet

    return [
        v for k, v in session.variables.items()
        if k.startswith("_ioc_") and isinstance(v, IOCSet)
    ]
