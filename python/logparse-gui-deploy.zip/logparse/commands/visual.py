#!/usr/bin/env python3
"""visual command — terminal charts with session chart storage."""

from __future__ import annotations

import re as _re

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.pipeline import AggResult
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number
from logparse.visual import ChartData


_VALID_BUCKETS = {"1m", "5m", "10m", "15m", "30m", "1h", "hour", "1d", "day"}


@register(
    "visual",
    r"^visual(\s+.*)?$",
    category="Display",
    usage=(
        "visual bar|pie|heatmap | visual severity | visual top <field> | "
        "visual timeline | visual line | visual scatter <x> <y> | "
        "visual flow <src> <dst> | visual stacked <field> | visual dist <field> | "
        "visual treemap <f1> <f2> | visual sparkline <field> | "
        "visual compare <ts>|<field> <a> <b> | visual geo [field]"
    ),
    help="Render terminal chart. Works standalone or after aggregation commands.",
)
def cmd_visual(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Render terminal chart."""
    from logparse.pipeline import _op_count_by, _op_timeline

    console = ctx.console
    args = (parsed.args or "").strip()
    args_lower = args.lower()

    # visual (bare) — show help
    if not args:
        console.print("[bold]Visual chart types:[/bold]")
        console.print("  visual bar             — bar chart of last aggregation")
        console.print("  visual pie             — pie chart of last aggregation")
        console.print("  visual heatmap         — hour×day activity heatmap")
        console.print("  visual severity        — severity distribution bar chart")
        console.print("  visual top <field>     — top values bar chart")
        console.print("  visual timeline [bucket] — event density over time")
        console.print("  visual line [bucket]   — sparkline time series")
        console.print("  visual scatter <x> <y> — two-field scatter plot")
        console.print("  visual flow <src> <dst> — source→dest flow diagram")
        console.print("  visual flow internal external — outbound traffic flows")
        console.print("  visual flow external internal — inbound traffic flows")
        console.print("  visual flow internal internal — lateral movement")
        console.print("  visual stacked <field> — stacked bar by field")
        console.print("  visual dist <field>    — distribution histogram")
        console.print("  visual treemap <f1> <f2> [f3] — hierarchical treemap")
        console.print("  visual sparkline <field> [bucket] — sparkline table")
        console.print("  visual compare <timestamp> — time-split comparison")
        console.print("  visual compare <field> <a> <b> — filter comparison")
        console.print("[dim]Or use after aggregation: count by srcip | visual bar[/dim]")
        return

    # visual heatmap — hour×day grid (standalone, uses events directly)
    if args_lower == "heatmap":
        from logparse.visual.terminal.heatmap import build_heatmap_data, render_heatmap
        chart = build_heatmap_data(session.filtered_events)
        chart.source_command = parsed.raw
        render_heatmap(chart, console)
        _store_chart(session, chart, parsed.raw, "visual heatmap")
        return

    # visual line [bucket]
    line_m = _re.match(r"^line(?:\s+(\w+))?$", args_lower)
    if line_m:
        from logparse.visual.terminal.line import build_line_data, render_line
        bucket = line_m.group(1) or "hour"
        agg_data = _op_timeline(session.filtered_events, bucket)
        session.last_output = list(agg_data)
        chart = build_line_data(agg_data, f"Timeline ({bucket})")
        chart.source_command = parsed.raw
        render_line(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual line {bucket}")
        return

    # visual scatter <x> <y>
    scatter_m = _re.match(r"^scatter\s+(\w+)\s+(\w+)$", args_lower)
    if scatter_m:
        from logparse.visual.terminal.scatter import build_scatter_data, render_scatter
        field_x, field_y = scatter_m.group(1), scatter_m.group(2)
        chart = build_scatter_data(session.filtered_events, field_x, field_y)
        chart.source_command = parsed.raw
        render_scatter(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual scatter {field_x} {field_y}")
        return

    # visual sankey <src> <dst> — alias for flow
    sankey_m = _re.match(r"^sankey\s+(\w+)\s+(\w+)$", args_lower)
    if sankey_m:
        from logparse.visual.terminal.flow import build_flow_data, render_flow
        src_field, dst_field = sankey_m.group(1), sankey_m.group(2)
        chart = build_flow_data(session.filtered_events, src_field, dst_field)
        chart.source_command = parsed.raw
        render_flow(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual sankey {src_field} {dst_field}")
        return

    # visual geo <field> — geographic map (HTML export)
    geo_m = _re.match(r"^geo(?:\s+(\w+))?$", args_lower)
    if geo_m:
        from logparse.visual.html.geo_map import build_geo_data
        field = geo_m.group(1) or "srcip"
        chart = build_geo_data(session.filtered_events, field)
        chart.source_command = parsed.raw
        if not chart.labels:
            console.print(f"[dim]No geographic data for field '{field}'.[/dim]")
            return
        # Terminal fallback: country table
        from rich.table import Table
        table = Table(title=f"Geographic Distribution — {field}", border_style="dim")
        table.add_column("Country", style="bold")
        table.add_column("Events", justify="right", style="cyan")
        table.add_column("%", justify="right")
        total = sum(chart.values)
        for label, val in zip(chart.labels[:20], chart.values[:20]):
            pct = val / max(total, 1) * 100
            table.add_row(label, format_number(int(val)), f"{pct:.1f}%")
        console.print(table)
        console.print("[dim]Export to HTML for interactive map: export report.html[/dim]")
        _store_chart(session, chart, parsed.raw, f"visual geo {field}")
        return

    # visual flow internal/external — directional network flow
    dir_flow_m = _re.match(r"^flow\s+(internal|external)\s+(internal|external)$", args_lower)
    if dir_flow_m:
        from logparse.visual.terminal.flow import build_directional_flow_data, render_flow
        src_dir, dst_dir = dir_flow_m.group(1), dir_flow_m.group(2)
        chart = build_directional_flow_data(session.filtered_events, src_dir, dst_dir)
        chart.source_command = parsed.raw
        render_flow(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual flow {src_dir} {dst_dir}")
        return

    # visual flow <src_field> <dst_field>
    flow_m = _re.match(r"^flow\s+(\w+)\s+(\w+)$", args_lower)
    if flow_m:
        from logparse.visual.terminal.flow import build_flow_data, render_flow
        src_field, dst_field = flow_m.group(1), flow_m.group(2)
        chart = build_flow_data(session.filtered_events, src_field, dst_field)
        chart.source_command = parsed.raw
        render_flow(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual flow {src_field} {dst_field}")
        return

    # visual stacked <field>
    stacked_m = _re.match(r"^stacked\s+(\w+)$", args_lower)
    if stacked_m:
        from logparse.visual.terminal.stacked import render_stacked
        sub_field = stacked_m.group(1)
        chart = _build_stacked(session, sub_field)
        chart.source_command = parsed.raw
        render_stacked(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual stacked {sub_field}")
        return

    # visual dist <field>
    dist_m = _re.match(r"^dist\s+(\w+)$", args_lower)
    if dist_m:
        from logparse.visual.terminal.dist import render_dist
        field_name = dist_m.group(1)
        chart = _build_dist(session.filtered_events, field_name)
        chart.source_command = parsed.raw
        render_dist(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual dist {field_name}")
        return

    # visual treemap <field1> <field2> [field3]
    treemap_m = _re.match(r"^treemap\s+(\w+)\s+(\w+)(?:\s+(\w+))?$", args_lower)
    if treemap_m:
        from logparse.visual.terminal.treemap import build_treemap_data, render_treemap
        fields = [treemap_m.group(i) for i in (1, 2, 3) if treemap_m.group(i)]
        chart = build_treemap_data(session.filtered_events, *fields)
        chart.source_command = parsed.raw
        render_treemap(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual treemap {' '.join(fields)}")
        return

    # visual sparkline <field> [bucket]
    spark_m = _re.match(r"^sparkline\s+(\w+)(?:\s+(\w+))?$", args_lower)
    if spark_m:
        from logparse.visual.terminal.sparkline_table import (
            build_sparkline_table, render_sparkline_table,
        )
        field = spark_m.group(1)
        bucket = spark_m.group(2) or "hour"
        chart = build_sparkline_table(session.filtered_events, field, bucket)
        chart.source_command = parsed.raw
        render_sparkline_table(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual sparkline {field}")
        return

    # visual compare <timestamp> OR visual compare <field> <value_a> <value_b>
    compare_m = _re.match(r"^compare\s+(.+)$", args_lower)
    if compare_m:
        from logparse.visual.terminal.comparison import (
            build_filter_comparison, build_time_comparison, render_comparison,
        )
        compare_args = compare_m.group(1).strip().split()
        if len(compare_args) == 1:
            # Time-split: visual compare <timestamp>
            from datetime import datetime as _dt
            try:
                ts = _dt.fromisoformat(compare_args[0])
            except ValueError:
                console.print(f"[red]Cannot parse timestamp: {compare_args[0]}[/red]")
                console.print("[dim]Use ISO format: 2024-01-15T12:00:00[/dim]")
                return
            chart = build_time_comparison(session.filtered_events, ts)
        elif len(compare_args) == 3:
            # Filter comparison: visual compare <field> <value_a> <value_b>
            field, val_a, val_b = compare_args
            chart = build_filter_comparison(
                session.filtered_events, field, val_a, val_b,
            )
        else:
            console.print("[red]Usage: visual compare <timestamp> or visual compare <field> <a> <b>[/red]")
            return
        chart.source_command = parsed.raw
        render_comparison(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual compare {' '.join(compare_args)}")
        return

    # visual severity — standalone severity distribution
    if args_lower == "severity":
        agg_data = _op_count_by(session.filtered_events, "severity")
        session.last_output = list(agg_data)
        chart = _agg_to_chart(agg_data, "bar", "Severity Distribution")
        chart.source_command = parsed.raw
        _render_bar_from_chart(chart, console)
        _store_chart(session, chart, parsed.raw, "visual severity")
        return

    # visual top <field>
    top_m = _re.match(r"^top\s+(\w+)$", args_lower)
    if top_m:
        field = top_m.group(1)
        agg_data = _op_count_by(session.filtered_events, field)[:10]
        session.last_output = list(agg_data)
        chart = _agg_to_chart(agg_data, "bar", f"Top {field}")
        chart.source_command = parsed.raw
        _render_bar_from_chart(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual top {field}")
        return

    # visual timeline [bucket]
    tl_m = _re.match(r"^timeline(?:\s+(\w+))?$", args_lower)
    if tl_m:
        bucket = tl_m.group(1) or "hour"
        agg_data = _op_timeline(session.filtered_events, bucket)
        session.last_output = list(agg_data)
        chart = _agg_to_chart(agg_data, "bar", f"Timeline ({bucket})")
        chart.source_command = parsed.raw
        _render_bar_from_chart(chart, console)
        _store_chart(session, chart, parsed.raw, f"visual timeline {bucket}")
        return

    # Prefix matching for standalone visual subcommands
    _STANDALONE_TYPES = {
        "severity": "severity",
        "heatmap": "heatmap",
        "timeline": "timeline",
        "line": "line",
        "scatter": "scatter",
        "flow": "flow",
        "stacked": "stacked",
        "dist": "dist",
        "treemap": "treemap",
        "sparkline": "sparkline",
        "compare": "compare",
        "geo": "geo",
    }
    first_word = args_lower.split()[0] if args_lower else ""
    if first_word and first_word not in ("bar", "pie"):
        matches = [name for name in _STANDALONE_TYPES if name.startswith(first_word)]
        if len(matches) == 1:
            resolved = matches[0] + args_lower[len(first_word):]
            # Only re-dispatch if prefix expansion actually changed the args
            # (avoids infinite recursion when args already use the full keyword
            # but the regex above didn't match due to trailing garbage)
            if resolved != args_lower:
                parsed_copy = ParsedCommand(
                    raw=f"visual {resolved}",
                    verb="visual",
                    args=resolved,
                    pipe_ops=parsed.pipe_ops,
                )
                return cmd_visual(session, parsed_copy, ctx)
        elif len(matches) > 1:
            console.print(f"[red]Ambiguous chart type: {first_word}[/red]")
            console.print(f"[dim]Did you mean: {', '.join(matches)}?[/dim]")
            return

    # Standard chart type: bar, pie — use last_output
    chart_type = args_lower

    if chart_type not in ("bar", "pie"):
        console.print(f"[red]Unknown chart type: {args}[/red]")
        console.print(
            "[dim]Use: bar, pie, heatmap, line, scatter, flow, stacked, "
            "dist, treemap, sparkline, compare[/dim]"
        )
        return

    if not session.last_output:
        console.print(
            "[yellow]No previous aggregation to chart.[/yellow]\n"
            "[dim]Run an aggregation first, then chart it:[/dim]\n"
            "  count by Severity | visual bar\n"
            "  count by srcip | visual pie\n"
            "[dim]Or use standalone charts:[/dim]\n"
            "  visual severity   visual top <field>   visual timeline"
        )
        return

    agg_data = [r for r in session.last_output if isinstance(r, AggResult)]
    if not agg_data:
        console.print(
            "[yellow]Last command output is not aggregation data.[/yellow]\n"
            "[dim]Run an aggregation first:[/dim]\n"
            "  count by <field>     then: visual bar\n"
            "  timeline <bucket>    then: visual bar\n"
            "[dim]Or use standalone charts: visual severity, visual top <field>[/dim]"
        )
        return

    chart = _agg_to_chart(agg_data, chart_type, chart_type.title())
    chart.source_command = parsed.raw

    if chart_type == "bar":
        _render_bar_from_chart(chart, console)
    elif chart_type == "pie":
        from logparse.visual.terminal.pie import render_pie
        render_pie(chart, console)

    _store_chart(session, chart, parsed.raw, f"visual {chart_type}")


def _agg_to_chart(data: list[AggResult], chart_type: str, title: str) -> ChartData:
    """Convert AggResult list to ChartData."""
    return ChartData(
        chart_type=chart_type,
        title=title,
        labels=[r.key for r in data],
        values=[float(r.count) for r in data],
    )


def _store_chart(session: Session, chart: ChartData, raw: str, summary: str) -> None:
    """Store chart in session and log command."""
    if not hasattr(session, "charts"):
        session.charts = []
    session.charts.append(chart)
    session.log_command(raw, summary)


def _render_bar_from_chart(chart: ChartData, console: Console) -> None:
    """Render bar chart from ChartData."""
    from logparse.visual.terminal.bar import render_bar
    render_bar(chart, console)


def _build_stacked(session: Session, sub_field: str) -> ChartData:
    """Build stacked bar data from last_output grouped by sub_field."""
    from logparse.models import get_field
    from collections import Counter, defaultdict

    # Use last_output keys as primary groups
    agg_data = [r for r in session.last_output if isinstance(r, AggResult)]
    if not agg_data:
        return ChartData(chart_type="stacked", title="Stacked", labels=[], values=[])

    primary_field = agg_data[0].field or "key"
    primary_keys = [r.key for r in agg_data]

    # For each primary key, count sub_field values
    groups: dict[str, Counter[str]] = defaultdict(Counter)
    for e in session.filtered_events:
        pval = get_field(e, primary_field) or "(empty)"
        if pval in primary_keys:
            sval = get_field(e, sub_field) or "(empty)"
            groups[pval][sval] += 1

    # Collect all sub-values
    all_subs: set[str] = set()
    for cnt in groups.values():
        all_subs.update(cnt.keys())
    sub_keys = sorted(all_subs)

    series = {}
    for sk in sub_keys:
        series[sk] = [groups[pk].get(sk, 0) for pk in primary_keys]

    return ChartData(
        chart_type="stacked",
        title=f"Stacked by {sub_field}",
        labels=primary_keys,
        values=[sum(groups[pk].values()) for pk in primary_keys],
        series=series,
        metadata={"sub_field": sub_field, "sub_keys": sub_keys},
    )


def _build_dist(events, field_name: str) -> ChartData:
    """Build distribution histogram data for a numeric field."""
    from logparse.models import get_field

    values = []
    for e in events:
        raw = get_field(e, field_name)
        if raw is None:
            continue
        try:
            values.append(float(raw))
        except (ValueError, TypeError):
            continue

    if not values:
        return ChartData(
            chart_type="dist", title=f"Distribution of {field_name}",
            labels=[], values=[],
        )

    # Create buckets
    min_v, max_v = min(values), max(values)
    num_buckets = min(20, max(5, len(set(values))))
    if min_v == max_v:
        return ChartData(
            chart_type="dist", title=f"Distribution of {field_name}",
            labels=[str(min_v)], values=[float(len(values))],
            metadata={"field": field_name, "raw_values": values},
        )

    step = (max_v - min_v) / num_buckets
    buckets: dict[str, int] = {}
    for v in values:
        idx = min(int((v - min_v) / step), num_buckets - 1)
        low = min_v + idx * step
        high = low + step
        label = f"{low:.0f}-{high:.0f}"
        buckets[label] = buckets.get(label, 0) + 1

    labels = list(buckets.keys())
    counts = [float(buckets[label]) for label in labels]

    return ChartData(
        chart_type="dist",
        title=f"Distribution of {field_name}",
        labels=labels,
        values=counts,
        metadata={"field": field_name, "raw_values": values},
    )


