#!/usr/bin/env python3
"""Anomaly detection command."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "anomaly",
    r"^anomaly(\s+.*)?$",
    category="Analysis",
    usage="anomaly | anomaly new | anomaly time | anomaly volume | anomaly patterns",
    help="Run anomaly detection on current events.",
)
def cmd_anomaly(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Run anomaly detection on current events."""
    from rich.table import Table

    from logparse.analyzers.anomaly import (
        detect_first_seen, detect_time_anomaly,
        detect_volume_anomaly, detect_patterns,
        run_all_detectors,
    )

    console = ctx.console
    args = (parsed.args or "").strip().lower()

    events = session.filtered_events

    if args == "new":
        findings = detect_first_seen(events)
    elif args == "time":
        findings = detect_time_anomaly(events)
    elif args == "volume":
        findings = detect_volume_anomaly(events)
    elif args == "patterns":
        findings = detect_patterns(events)
    else:
        findings = run_all_detectors(events)

    if not findings:
        console.print("[dim]No anomalies detected.[/dim]")
        session.log_command(parsed.raw, "anomaly: 0 findings")
        return

    table = Table(title="Anomaly Detection Results", show_header=True)
    table.add_column("DETECTOR", style="bold")
    table.add_column("SEVERITY")
    table.add_column("FINDING")
    table.add_column("EVENTS", justify="right")
    table.add_column("SCORE", justify="right")

    for f in findings:
        sev_style = {
            "Critical": "bold red", "High": "bright_red",
            "Medium": "yellow", "Low": "green",
        }.get(f.severity, "")
        table.add_row(
            f.detector,
            f"[{sev_style}]{f.severity}[/{sev_style}]",
            f.title,
            str(len(f.events)),
            f"{f.score:.1f}",
        )

    console.print(table)

    # Show evidence details
    for f in findings[:5]:
        if f.evidence:
            console.print(f"\n  [bold]{f.title}:[/bold] {f.description}")
            for ev in f.evidence[:5]:
                console.print(f"    • {ev}")

    session.log_command(
        parsed.raw,
        f"anomaly{' ' + args if args else ''}: {len(findings)} findings"
    )
