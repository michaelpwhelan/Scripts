#!/usr/bin/env python3
"""star/unstar commands — bookmark events."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


def _parse_star_args(args: str) -> list[int]:
    """Parse star arguments supporting individual, range, and mixed syntax.

    Examples: '5', '1, 5, 12', '5-15', '1-5, 12, 20-25'
    """
    indices: list[int] = []
    for part in re.split(r"[,\s]+", args):
        part = part.strip()
        if not part:
            continue
        range_match = re.match(r"^(\d+)-(\d+)$", part)
        if range_match:
            start = int(range_match.group(1))
            end = int(range_match.group(2))
            if start > end:
                start, end = end, start
            indices.extend(range(start, end + 1))
        elif part.isdigit():
            indices.append(int(part))
    return indices


@register(
    "star",
    r"^star\s+.+",
    category="Bookmark",
    usage="star <N>[, N, ...] | star <N>-<M> | star clear",
    help="Bookmark events by index, range, or mixed.",
)
def cmd_star(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Bookmark events by index, range, or mixed."""
    console = ctx.console
    args = parsed.args.strip()

    if args.lower() == "clear":
        count = len(session.starred)
        session.starred.clear()
        console.print(f"Cleared {count} starred events.")
        session.log_command(parsed.raw, "stars cleared")
        return

    indices = _parse_star_args(args)

    if not indices:
        console.print("[red]Usage: star 1, 5, 10 or star 5-15 or star 1-5, 12[/red]")
        return

    total = len(session.filtered_events)
    if total == 0:
        console.print("[dim]No events to star (current view is empty).[/dim]")
        session.log_command(parsed.raw, "starred 0")
        return
    added = 0
    _id_to_abs = {id(e): i for i, e in enumerate(session.all_events)}
    for idx in indices:
        if 1 <= idx <= total:
            event = session.filtered_events[idx - 1]
            abs_idx = _id_to_abs.get(id(event))
            if abs_idx is not None:
                session.starred.add(abs_idx)
                added += 1

    console.print(f"Starred {added} event(s). Total starred: {len(session.starred)}")
    session.log_command(parsed.raw, f"starred {added}")


@register(
    "unstar",
    r"^unstar\s+.+",
    category="Bookmark",
    usage="unstar <N>[, N, ...] | unstar <N>-<M>",
    help="Remove bookmark from events.",
)
def cmd_unstar(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Remove bookmark from events."""
    console = ctx.console
    args = parsed.args.strip()

    indices = _parse_star_args(args)

    removed = 0
    _id_to_abs = {id(e): i for i, e in enumerate(session.all_events)}
    for idx in indices:
        if 1 <= idx <= len(session.filtered_events):
            event = session.filtered_events[idx - 1]
            abs_idx = _id_to_abs.get(id(event))
            if abs_idx is not None:
                session.starred.discard(abs_idx)
                removed += 1

    console.print(f"Unstarred {removed} event(s). Total starred: {len(session.starred)}")
    session.log_command(parsed.raw, f"unstarred {removed}")
