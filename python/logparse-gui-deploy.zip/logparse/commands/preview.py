#!/usr/bin/env python3
"""preview command — opinionated triage view."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.models import SEV_ORDER
from logparse.util import format_number


@register(
    "preview",
    r"^preview(\s+.*)?$",
    category="Display",
    usage="preview [critical|high|medium|low|info]",
    help="Show top 10 events by severity (opinionated triage).",
)
def cmd_preview(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show top 10 events ranked by severity then recency."""
    from logparse.output.table import render_table

    console = ctx.console
    events = session.filtered_events
    sev_filter = parsed.args.strip().lower() if parsed.args else ""

    # filter by severity if specified
    if sev_filter:
        # support "critical|high" or "critical" or "high"
        allowed = set(s.strip() for s in sev_filter.split("|"))
        events = [e for e in events if e.severity.lower() in allowed]

    ranked = sorted(
        events,
        key=lambda e: (
            SEV_ORDER.get(e.severity, 5),
            -(e.timestamp.timestamp() if e.timestamp else 0),
        ),
    )
    top = ranked[:10]

    label = f"Top 10 {sev_filter} events" if sev_filter else "Top 10 events by severity"
    console.print(f"[bold]{label}[/bold] (of {format_number(len(events))})")
    render_table(
        top, console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=10,
    )
    session.log_command(parsed.raw, f"top 10 of {len(events)}")
