#!/usr/bin/env python3
"""MITRE ATT&CK technique detection and mapping command."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "mitre",
    r"^mitre(\s+.*)?$",
    category="Analysis",
    usage="mitre scan | mitre <T1234> | mitre visual | mitre list",
    help="MITRE ATT&CK technique detection and mapping.",
)
def cmd_mitre(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """MITRE ATT&CK technique detection and mapping."""
    from rich.table import Table
    from rich.panel import Panel

    from logparse.mitre import (
        TECHNIQUES, TACTIC_ORDER,
        scan_events, detect_kill_chains,
    )

    console = ctx.console
    args = (parsed.args or "").strip().lower()

    # mitre list — show all bundled signatures
    if args == "list":
        table = Table(title="Bundled MITRE ATT&CK Signatures", show_header=True)
        table.add_column("ID", style="bold cyan")
        table.add_column("NAME")
        table.add_column("TACTIC")
        table.add_column("SEVERITY")
        table.add_column("MIN COUNT", justify="right")

        for sig in sorted(TECHNIQUES.values(), key=lambda s: s.technique_id):
            sev_style = _sev_style(sig.severity)
            table.add_row(
                sig.technique_id,
                sig.name,
                sig.tactic,
                f"[{sev_style}]{sig.severity}[/{sev_style}]",
                str(sig.min_count),
            )
        console.print(table)
        session.log_command(parsed.raw, f"mitre list: {len(TECHNIQUES)} techniques")
        return

    # mitre T1234 — filter events matching a specific technique
    tid_match = re.match(r"^(t\d{4}(?:\.\d{3})?)$", args, re.I)
    if tid_match:
        tid = tid_match.group(1).upper()
        sig = TECHNIQUES.get(tid)
        if not sig:
            console.print(f"[red]Unknown technique: {tid}[/red]")
            return

        from logparse.mitre import _matches_technique
        matching = [e for e in session.filtered_events if _matches_technique(e, sig)]

        console.print(Panel(
            f"[bold]{tid}[/bold]: {sig.name}\n"
            f"Tactic: {sig.tactic}\n"
            f"Severity: {sig.severity}\n"
            f"Matching events: {len(matching)}",
            title=f"MITRE ATT&CK — {tid}",
        ))

        if matching:
            session.push_filter(f"mitre {tid}")
            session.filtered_events = matching
            console.print(f"[green]Filtered to {len(matching)} events matching {tid}.[/green]")

        session.log_command(parsed.raw, f"mitre {tid}: {len(matching)} matches")
        return

    # mitre visual — tactic heatmap
    if args == "visual":
        matches = scan_events(session.filtered_events)
        if not matches:
            console.print("[dim]No MITRE techniques detected.[/dim]")
            return

        tactic_techniques: dict[str, list] = {}
        for m in matches:
            tactic = m.technique.tactic
            tactic_techniques.setdefault(tactic, []).append(m)

        table = Table(title="MITRE ATT&CK Tactic Heatmap", show_header=True)
        table.add_column("TACTIC", style="bold")
        table.add_column("TECHNIQUES")
        table.add_column("TOTAL EVENTS", justify="right")

        for tactic in TACTIC_ORDER:
            if tactic not in tactic_techniques:
                continue
            techniques = tactic_techniques[tactic]
            tech_list = ", ".join(
                f"[cyan]{m.technique.technique_id}[/cyan]" for m in techniques
            )
            total = sum(m.count for m in techniques)
            table.add_row(tactic, tech_list, str(total))

        console.print(table)
        session.log_command(parsed.raw, f"mitre visual: {len(matches)} techniques")
        return

    # mitre scan (default) — full scan
    matches = scan_events(session.filtered_events)
    if not matches:
        console.print("[dim]No MITRE ATT&CK techniques detected in current events.[/dim]")
        session.log_command(parsed.raw, "mitre scan: 0 matches")
        return

    table = Table(title="MITRE ATT&CK Detection Results", show_header=True)
    table.add_column("TECHNIQUE", style="bold cyan")
    table.add_column("NAME")
    table.add_column("TACTIC")
    table.add_column("EVENTS", justify="right")
    table.add_column("FIRST SEEN")
    table.add_column("SCORE", justify="right")

    for m in matches:
        sev_style = _sev_style(m.technique.severity)
        first = m.first_seen.strftime("%Y-%m-%d %H:%M") if m.first_seen else ""
        table.add_row(
            m.technique.technique_id,
            m.technique.name,
            m.technique.tactic,
            str(m.count),
            first,
            f"[{sev_style}]{m.score:.1f}[/{sev_style}]",
        )

    console.print(table)

    # Kill chain detection
    chains = detect_kill_chains(matches)
    if chains:
        console.print()
        for chain, chain_matches in chains:
            stage_ids = " → ".join(m.technique.technique_id for m in chain_matches)
            console.print(
                f"  [bold red]⚠ Kill Chain: {chain.name}[/bold red]\n"
                f"    Stages: {stage_ids}\n"
                f"    {chain.description}"
            )

    session.log_command(parsed.raw, f"mitre scan: {len(matches)} techniques, {len(chains)} chains")


def _sev_style(severity: str) -> str:
    return {
        "Critical": "bold red",
        "High": "bright_red",
        "Medium": "yellow",
        "Low": "green",
        "Info": "dim",
    }.get(severity, "")
