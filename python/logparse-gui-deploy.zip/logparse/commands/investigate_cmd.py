#!/usr/bin/env python3
"""investigate command — combined entity investigation playbook."""

from __future__ import annotations

from logparse.commands import register, sev_color, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "investigate",
    r"^investigate\s+.+$",
    category="Analysis",
    usage="investigate <entity>",
    help=(
        "Run a combined investigation on an entity (IP, user, host).  "
        "Performs entity scoring, correlation rule evaluation, "
        "MITRE technique scan, and IOC check."
    ),
)
def cmd_investigate(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:

    """Run a combined investigation on an entity (IP, user, host)."""
    from logparse.entity_scoring import score_entity
    from logparse.ioc import IOCSet, match_events
    from logparse.mitre import scan_events

    console = ctx.console
    target = (parsed.args or "").strip()
    if not target:
        console.print("[dim]Usage: investigate <entity>[/dim]")
        return

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    console.print(f"\n[bold]Investigation: {target}[/bold]\n")

    # 1. Entity scoring
    console.print("[bold cyan]1. Entity Risk Profile[/bold cyan]")
    profile = score_entity(target, events)
    if profile:
        tier = sev_color(profile.risk_tier)
        console.print(f"   Score: {profile.score:.1f} ({tier})")
        console.print(f"   Events: {profile.event_count}")
        console.print(
            f"   Sources: {len(profile.source_files - {''})}"
        )
        if profile.event_types:
            top = ", ".join(f"{t}({c})" for t, c in profile.event_types.most_common(5))
            console.print(f"   Top types: {top}")
        if profile.first_seen and profile.last_seen:
            console.print(
                f"   Time span: {profile.first_seen:%Y-%m-%d %H:%M} → "
                f"{profile.last_seen:%Y-%m-%d %H:%M}"
            )
    else:
        console.print("   [dim]No risk score for this entity.[/dim]")

    # 2. Related events
    console.print("\n[bold cyan]2. Related Events[/bold cyan]")
    from logparse.models import get_field

    related = [
        e for e in events
        if any(
            target.lower() in (get_field(e, f) or "").lower()
            for f in ("srcip", "dstip", "user", "devname",
                      "userPrincipalName", "userId")
        )
    ]
    console.print(f"   {len(related)} events involve '{target}'")
    if related:
        sev_dist = {}
        for e in related:
            sev_dist[e.severity] = sev_dist.get(e.severity, 0) + 1
        sev_str = ", ".join(f"{s}: {c}" for s, c in sorted(sev_dist.items()))
        console.print(f"   Severity: {sev_str}")

    # 3. MITRE techniques
    console.print("\n[bold cyan]3. MITRE ATT&CK Techniques[/bold cyan]")
    if related:
        mitre_matches = scan_events(related)
        if mitre_matches:
            for m in mitre_matches[:10]:
                console.print(
                    f"   [{m.technique.severity}] {m.technique.technique_id} "
                    f"{m.technique.name} ({m.count} events, score {m.score:.1f})"
                )
        else:
            console.print("   [dim]No technique matches.[/dim]")
    else:
        console.print("   [dim]No related events to scan.[/dim]")

    # 4. Correlation rules
    console.print("\n[bold cyan]4. Correlation Rules[/bold cyan]")
    rules = session.variables.get("_correlation_rules", [])
    if rules and related:
        from logparse.correlation_rules import evaluate_all_rules

        rule_matches = evaluate_all_rules(rules, related)
        if rule_matches:
            for rm in rule_matches[:5]:
                console.print(
                    f"   [{rm.rule.severity}] {rm.rule.name}: "
                    f"{rm.total_events} events"
                )
        else:
            console.print("   [dim]No rule matches.[/dim]")
    else:
        console.print("   [dim]No rules loaded or no related events.[/dim]")

    # 5. IOC check
    console.print("\n[bold cyan]5. IOC Check[/bold cyan]")
    ioc_sets = [
        v for k, v in session.variables.items()
        if k.startswith("_ioc_") and isinstance(v, IOCSet)
    ]
    if ioc_sets and related:
        ioc_matches = match_events(related, ioc_sets)
        if ioc_matches:
            for im in ioc_matches[:10]:
                console.print(
                    f"   [red]HIT[/red] {im.ioc_value} ({im.ioc_type}): "
                    f"{im.match_count} events"
                )
        else:
            console.print("   [green]No IOC matches.[/green]")
    else:
        console.print("   [dim]No IOCs loaded.[/dim]")

    console.print()
    session.log_command(ctx.raw_input, f"investigate {target}")


