#!/usr/bin/env python3
"""Variable storage and expansion commands."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "vars",
    r"^vars$",
    category="Variables",
    usage="vars",
    help="List all stored variables.",
)
def cmd_vars(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """List all stored variables."""
    console = ctx.console
    if not session.variables:
        console.print("[dim]No variables stored.[/dim]")
        return
    from logparse.util import compact_table
    table = compact_table()
    table.add_column("NAME", style="bold")
    table.add_column("VALUE")
    for name, val in sorted(session.variables.items()):
        if isinstance(val, list):
            display = ", ".join(val[:5])
            if len(val) > 5:
                display += f" ... ({len(val)} total)"
        else:
            display = str(val)
        table.add_row(f"${name}", display)
    console.print(table)
    session.log_command(parsed.raw, f"{len(session.variables)} variables")


@register(
    "$time_arith",
    r"^\$\w+\s*[+-]=\s*.+",
    category="Variables",
    usage="$name += 5m | $name -= 2h",
    help="Add or subtract a duration from a datetime variable.",
)
def cmd_time_arith(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Add or subtract a duration from a datetime variable."""
    import re
    from datetime import datetime
    from logparse.util import parse_duration

    console = ctx.console
    raw = parsed.raw.strip()

    m = re.match(r"^\$(\w+)\s*([+-])=\s*(.+)$", raw)
    if not m:
        console.print("[red]Usage: $name += 5m | $name -= 2h[/red]")
        return

    name = m.group(1)
    operator = m.group(2)
    rhs = m.group(3).strip()

    val = session.variables.get(name)
    if val is None:
        console.print(f"[red]Variable ${name} not found.[/red]")
        return

    # parse current value as datetime
    dt = None
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%H:%M:%S"):
        try:
            dt = datetime.strptime(str(val), fmt)
            used_fmt = fmt
            break
        except ValueError:
            continue

    if dt is None:
        console.print(f"[red]${name} is not a recognized datetime: {val}[/red]")
        return

    delta = parse_duration(rhs)
    if delta is None:
        console.print(f"[red]Invalid duration: {rhs}[/red]")
        return

    if operator == "+":
        dt = dt + delta
    else:
        dt = dt - delta

    result = dt.strftime(used_fmt)
    session.variables[name] = result
    console.print(f"${name} = {result}")
    session.log_command(parsed.raw, f"${name} {operator}= {rhs}")


@register(
    "$props",
    r"^\$\w+\s+properties$",
    category="Variables",
    usage="$name properties",
    help="Inspect variable value — type, event count, IP info.",
)
def cmd_props(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Inspect variable value — type, event count, IP info."""
    import re
    console = ctx.console
    raw = parsed.raw.strip()

    m = re.match(r"^\$(\w+)\s+properties$", raw, re.I)
    if not m:
        console.print("[red]Usage: $name properties[/red]")
        return

    name = m.group(1)
    val = session.variables.get(name)
    if val is None:
        console.print(f"[dim]Variable ${name} not found.[/dim]")
        return

    console.print(f"[bold]${name}[/bold]")

    if isinstance(val, list):
        console.print(f"  Type    : list ({len(val)} values)")
        for v in val[:10]:
            console.print(f"    {v}")
        if len(val) > 10:
            console.print(f"    [dim]... and {len(val) - 10} more[/dim]")
        session.log_command(parsed.raw, f"${name} properties")
        return

    console.print(f"  Value   : {val}")

    # check if it's an IP
    try:
        from ipaddress import ip_address
        _addr = ip_address(str(val).strip())
        from logparse.network import is_internal, get_site
        loc = "internal" if is_internal(str(val)) else "external"
        console.print(f"  IP type : {loc}")
        site = get_site(str(val))
        if site:
            console.print(f"  Site    : {site}")
    except (ValueError, AttributeError):
        console.print(f"  Length  : {len(str(val))}")

    # count events where value appears
    val_lower = str(val).lower()
    count = 0
    first_seen = None
    last_seen = None
    for e in session.all_events:
        fields_to_check = [e.severity, e.source, e.message]
        fields_to_check.extend(e.extra.values())
        if any(val_lower in (f or "").lower() for f in fields_to_check):
            count += 1
            if e.timestamp:
                if first_seen is None or e.timestamp < first_seen:
                    first_seen = e.timestamp
                if last_seen is None or e.timestamp > last_seen:
                    last_seen = e.timestamp

    console.print(f"  Events  : {count}")
    if first_seen:
        console.print(f"  First   : {first_seen:%Y-%m-%d %H:%M:%S}")
    if last_seen:
        console.print(f"  Last    : {last_seen:%Y-%m-%d %H:%M:%S}")

    session.log_command(parsed.raw, f"${name} properties")


@register(
    "$assign",
    r"^\$\w+\s*(?<![+-])=\s*.+",
    category="Variables",
    usage="$name = value | $name = N.field, N.field",
    help="Assign a value or list to a variable.",
)
def cmd_assign(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Assign a value or list to a variable."""
    import re
    console = ctx.console
    raw = parsed.raw.strip()

    m = re.match(r"^\$(\w+)\s*=\s*(.+)$", raw)
    if not m:
        console.print("[red]Usage: $name = value[/red]")
        return

    name = m.group(1)
    rhs = m.group(2).strip()

    # check for N.field references
    from logparse.commands.show import _resolve_row_field
    parts = [p.strip() for p in rhs.split(",")]
    resolved: list[str] = []
    _has_refs = False

    for part in parts:
        ref_m = re.match(r"^(\d+)\.(\w+)$", part)
        if ref_m:
            _has_refs = True
            val = _resolve_row_field(session, int(ref_m.group(1)), ref_m.group(2))
            if val:
                resolved.append(val)
        else:
            resolved.append(part)

    if len(resolved) == 1:
        session.variables[name] = resolved[0]
        console.print(f"${name} = {resolved[0]}")
    else:
        session.variables[name] = resolved
        console.print(f"${name} = [{len(resolved)} values: {', '.join(resolved[:5])}]")
    session.log_command(parsed.raw, f"${name} assigned")


@register(
    "unset",
    r"^unset\s+\$?\w+$",
    category="Variables",
    usage="unset $name",
    help="Remove a stored variable.",
)
def cmd_unset(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Remove a stored variable."""
    name = parsed.args.strip().lstrip("$")
    if name in session.variables:
        del session.variables[name]
        ctx.console.print(f"Variable ${name} removed.")
    else:
        ctx.console.print(f"[dim]Variable ${name} not found.[/dim]")
    session.log_command(parsed.raw, f"unset ${name}")


def store_variable(session: Session, name: str, events: list, field_name: str | None = None) -> str:
    """Extract and store a variable from events. Returns summary."""
    from logparse.models import LogEvent

    if not events:
        session.variables[name] = ""
        return f"${name} = (empty)"

    if len(events) == 1 and isinstance(events[0], LogEvent):
        if field_name:
            val = get_field(events[0], field_name) or ""
            session.variables[name] = val
            return f"${name} = {val}"
        session.variables[name] = events[0].message
        return f"${name} = {events[0].message}"

    if field_name:
        values = list(dict.fromkeys(
            get_field(e, field_name) or ""
            for e in events
            if isinstance(e, LogEvent)
        ))
        session.variables[name] = values
        return f"${name} = [{len(values)} values]"

    session.variables[name] = str(len(events))
    return f"${name} = {len(events)}"
