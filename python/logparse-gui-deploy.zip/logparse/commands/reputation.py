#!/usr/bin/env python3
"""reputation command — IP threat reputation scoring."""

from __future__ import annotations

import re as _re
from collections import Counter

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number

_IP_RE = _re.compile(
    r"^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$"
)

# Risk weights by category
_RISK_WEIGHTS = {
    "tor": 8,
    "scanner": 5,
    "cloud": 2,
    "internal": 0,
    "public": 1,
    "invalid": 0,
}


@register(
    "reputation",
    r"^reputation\s+\S+$",
    category="Analysis",
    usage="reputation <IP|field>",
    help=(
        "Assess threat reputation for an IP or aggregate across a field. "
        "Composes threat intel classification, geo data, and event evidence "
        "into a 0-10 risk score. No external API calls."
    ),
)
def cmd_reputation(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Assess threat reputation for an IP or aggregate across a field."""
    console = ctx.console
    target = (parsed.args or "").strip()

    if _IP_RE.match(target):
        _single_ip(target, session, console)
    else:
        _field_aggregate(target, session, console)

    session.log_command(parsed.raw, f"reputation {target}")


def _compute_score(ip: str, deny_rate: float = 0.0) -> tuple[int, list[str]]:
    """Compute risk score (0-10) and list of indicators."""
    from logparse.threat_intel import classify_ip
    from logparse.geoip import lookup

    threat = classify_ip(ip)
    geo = lookup(ip)
    indicators: list[str] = []

    # Base score from category
    score = _RISK_WEIGHTS.get(threat["category"], 1)

    if threat["category"] == "tor":
        indicators.append("Tor exit node")
    elif threat["category"] == "scanner":
        indicators.append(f"Known scanner: {threat['provider']}")
    elif threat["category"] == "cloud":
        indicators.append(f"Cloud hosting: {threat['provider']}")

    # Deny rate boost
    if deny_rate > 0.8:
        score += 2
        indicators.append(f"High deny rate: {deny_rate:.0%}")
    elif deny_rate > 0.5:
        score += 1
        indicators.append(f"Elevated deny rate: {deny_rate:.0%}")

    # Cap at 10
    score = min(score, 10)

    if geo.get("country_code") not in ("--", "??"):
        indicators.append(f"Country: {geo.get('country', 'Unknown')}")

    return score, indicators


def _risk_color(score: int) -> str:
    if score >= 7:
        return "red"
    if score >= 4:
        return "yellow"
    return "green"


def _single_ip(ip: str, session: Session, console: Console) -> None:
    from rich.panel import Panel

    # Calculate deny rate from events
    events = session.filtered_events
    ip_events = [e for e in events if get_field(e, "srcip") == ip or get_field(e, "dstip") == ip]
    deny_count = sum(1 for e in ip_events if (get_field(e, "action") or "").lower() in ("deny", "denied", "blocked"))
    deny_rate = deny_count / max(len(ip_events), 1)

    score, indicators = _compute_score(ip, deny_rate)
    color = _risk_color(score)

    lines = [
        f"  [bold]IP:[/bold]          {ip}",
        f"  [bold]Risk Score:[/bold]  [{color}]{score}/10[/{color}]",
        f"  [bold]Events:[/bold]      {format_number(len(ip_events))} ({deny_count} denied)",
        "",
    ]
    if indicators:
        lines.append("  [bold]Indicators:[/bold]")
        for ind in indicators:
            lines.append(f"    - {ind}")

    console.print(Panel("\n".join(lines), title="IP Reputation", border_style=color))


def _field_aggregate(field: str, session: Session, console: Console) -> None:
    from rich.table import Table

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # Collect IPs and their deny rates
    ip_total: Counter[str] = Counter()
    ip_deny: Counter[str] = Counter()
    for e in events:
        ip = get_field(e, field)
        if not ip or not _IP_RE.match(ip):
            continue
        ip_total[ip] += 1
        action = (get_field(e, "action") or "").lower()
        if action in ("deny", "denied", "blocked"):
            ip_deny[ip] += 1

    if not ip_total:
        console.print(f"[dim]No IP values found in field '{field}'.[/dim]")
        return

    # Score each IP
    scored: list[tuple[str, int, int, list[str]]] = []
    for ip, count in ip_total.most_common():
        deny_rate = ip_deny[ip] / max(count, 1)
        score, indicators = _compute_score(ip, deny_rate)
        scored.append((ip, score, count, indicators))

    # Sort by risk score descending
    scored.sort(key=lambda x: x[1], reverse=True)

    table = Table(title=f"IP Reputation — {field}", border_style="dim")
    table.add_column("IP", style="bold")
    table.add_column("Risk", justify="center")
    table.add_column("Events", justify="right")
    table.add_column("Indicators")

    for ip, score, count, indicators in scored[:20]:
        color = _risk_color(score)
        table.add_row(
            ip,
            f"[{color}]{score}/10[/{color}]",
            format_number(count),
            ", ".join(indicators[:3]),
        )

    console.print(table)
    high_risk = sum(1 for _, s, _, _ in scored if s >= 7)
    if high_risk:
        console.print(f"  [bold red]{high_risk} high-risk IPs detected[/bold red]")
