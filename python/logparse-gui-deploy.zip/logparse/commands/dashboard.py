#!/usr/bin/env python3
"""dashboard command — synthesized overview of current data."""

from __future__ import annotations

from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import SEVERITY_LEVELS, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number
from logparse.visual.terminal.common import sparkline


@register(
    "dashboard",
    r"^dashboard$",
    category="Analysis",
    usage="dashboard",
    help="Show a synthesized overview of current filtered events.",
)
def cmd_dashboard(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:

    """Show a synthesized overview of current filtered events."""
    console = ctx.console
    events = session.filtered_events
    total = len(events)

    if not events:
        console.print("[dim]No events to summarize.[/dim]")
        return

    # -- Header --
    ts_events = [e for e in events if e.timestamp]
    file_count = len(set(e.source_file for e in events if e.source_file))

    console.print("[bold]Dashboard[/bold]")
    console.print(f"  Events: {format_number(total)}  |  Files: {file_count}", end="")

    if ts_events:
        first = ts_events[0].timestamp
        last = ts_events[-1].timestamp
        console.print(f"  |  Range: {first:%Y-%m-%d %H:%M} — {last:%H:%M:%S}")
    else:
        console.print()

    # -- Activity sparkline (24-hour distribution) --
    if ts_events:
        hourly = [0] * 24
        for e in ts_events:
            hourly[e.timestamp.hour] += 1
        spark = sparkline(hourly, width=24, color="cyan")
        console.print(f"  Activity: {spark}")
    console.print()

    # -- Severity breakdown (inline bar + sparkline) --
    sev_counts = Counter(e.severity for e in events)
    sev_colors = {
        "Critical": "bold red", "High": "red", "Medium": "yellow",
        "Low": "cyan", "Info": "dim",
    }
    sev_rich = {
        "Critical": "red", "High": "bright_red", "Medium": "yellow",
        "Low": "cyan", "Info": "dim",
    }
    max_count = max(sev_counts.values()) if sev_counts else 1

    console.print("  [bold]Severity[/bold]")
    for sev in SEVERITY_LEVELS:
        count = sev_counts.get(sev, 0)
        if count == 0:
            continue
        pct = count / max(total, 1) * 100
        bar_w = int(count / max_count * 30) if max_count else 0
        bar = "\u2588" * bar_w
        style = sev_colors.get(sev, "")
        console.print(
            f"    [{style}]{sev:<10}[/{style}]"
            f" [cyan]{bar}[/cyan]  {format_number(count)}  ({pct:.1f}%)"
        )
        # Hourly sparkline for this severity
        sev_ts = [e for e in ts_events if e.severity == sev]
        if sev_ts:
            sev_hourly = [0] * 24
            for e in sev_ts:
                sev_hourly[e.timestamp.hour] += 1
            sev_spark = sparkline(sev_hourly, width=24, color=sev_rich.get(sev, "dim"))
            console.print(f"    {'':10} {sev_spark}")
    console.print()

    # -- Critical/High callout --
    crit_high = [e for e in events if e.severity in ("Critical", "High")]
    if crit_high:
        console.print(f"  [bold red]Critical/High events: {format_number(len(crit_high))}[/bold red]")
        for e in crit_high[:5]:
            ts = f"{e.timestamp:%H:%M:%S}" if e.timestamp else "     "
            msg = e.message[:80] if e.message else "(no message)"
            console.print(f"    [{sev_colors.get(e.severity, '')}]{ts} [{e.severity}] {msg}[/{sev_colors.get(e.severity, '')}]")
        if len(crit_high) > 5:
            console.print(f"    [dim]... and {len(crit_high) - 5} more[/dim]")
        console.print()

    # -- Top 5 sources (with mini-bars) --
    source_counts = Counter(e.source for e in events if e.source)
    if source_counts:
        top_sources = source_counts.most_common(5)
        max_src = top_sources[0][1] if top_sources else 1
        console.print("  [bold]Top Sources[/bold]")
        for src, count in top_sources:
            ratio = count / max(max_src, 1)
            bar_w = max(1, int(ratio * 20))
            bar = "█" * bar_w
            console.print(f"    {src:<30} [cyan]{bar}[/cyan] {format_number(count)}")
        console.print()

    # -- Top 5 IPs (with mini-bars) --
    ip_counts = Counter(
        get_field(e, "srcip") for e in events if get_field(e, "srcip")
    )
    if ip_counts:
        top_ips = ip_counts.most_common(5)
        max_ip = top_ips[0][1] if top_ips else 1
        console.print("  [bold]Top Source IPs[/bold]")
        for ip, count in top_ips:
            ratio = count / max(max_ip, 1)
            bar_w = max(1, int(ratio * 20))
            bar = "█" * bar_w
            console.print(f"    {ip:<30} [cyan]{bar}[/cyan] {format_number(count)}")
        console.print()

    # -- Drill-down suggestions --
    console.print("  [bold]Suggested commands[/bold]")
    if crit_high:
        console.print("    [dim]where severity:Critical[/dim]     — investigate critical events")
    if source_counts and len(source_counts) > 1:
        top_src = source_counts.most_common(1)[0][0]
        console.print(f"    [dim]where source:{top_src}[/dim]     — focus on top source")
    if ip_counts:
        top_ip = ip_counts.most_common(1)[0][0]
        console.print(f"    [dim]where srcip:{top_ip}[/dim]     — investigate top IP")
    console.print("    [dim]count by severity[/dim]         — aggregate by severity")
    console.print()

    session.log_command(parsed.raw, f"dashboard ({total} events)")
