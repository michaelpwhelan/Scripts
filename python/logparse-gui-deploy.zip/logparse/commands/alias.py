#!/usr/bin/env python3
"""alias command — create command shortcuts."""

from __future__ import annotations

import re as _re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "alias",
    r"^alias(?:\s+.*)?$",
    category="Session",
    usage="alias <name> <command> | alias list | alias delete <name>",
    help=(
        "Create command shortcuts. Aliases are stored in the session "
        "and expand automatically when used as commands."
    ),
)
def cmd_alias(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Create command shortcuts."""
    console = ctx.console
    args = (parsed.args or "").strip()

    # Ensure aliases dict exists
    if "_aliases" not in session.variables:
        session.variables["_aliases"] = {}

    aliases = session.variables["_aliases"]

    # alias list (or bare alias)
    if not args or args.lower() in ("list", "show"):
        if not aliases:
            console.print("[dim]No aliases defined. Usage: alias <name> <command>[/dim]")
            return
        console.print("[bold]Aliases:[/bold]")
        for name, cmd in sorted(aliases.items()):
            console.print(f"  [bold]{name}[/bold] = {cmd}")
        return

    # alias delete <name>
    m = _re.match(r"^delete\s+(\w+)$", args, _re.IGNORECASE)
    if m:
        name = m.group(1)
        if name in aliases:
            del aliases[name]
            console.print(f"[dim]Deleted alias '{name}'.[/dim]")
        else:
            console.print(f"[dim]Alias '{name}' not found.[/dim]")
        return

    # alias <name> <command>
    m = _re.match(r"^(\w+)\s+(.+)$", args)
    if not m:
        console.print("[red]Usage: alias <name> <command>[/red]")
        console.print("[dim]Example: alias ft where action deny[/dim]")
        return

    name = m.group(1)
    command = m.group(2)

    # Prevent aliasing built-in commands
    from logparse.commands import get_registry
    builtins = {cmd.name for cmd in get_registry()}
    if name in builtins:
        console.print(f"[red]Cannot alias built-in command '{name}'.[/red]")
        return

    aliases[name] = command
    console.print(f"[bold]Alias set:[/bold] {name} = {command}")
    session.log_command(parsed.raw, f"alias {name} = {command}")
