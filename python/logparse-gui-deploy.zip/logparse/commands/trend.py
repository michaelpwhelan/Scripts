#!/usr/bin/env python3
"""trend command — rate-of-change analysis over time windows."""

from __future__ import annotations

import re as _re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "trend",
    r"^trend\s+\w+(?:\s+\w+)?$",
    category="Analysis",
    usage="trend <field> [window]",
    help=(
        "Show rate-of-change for a field over time windows. "
        "Detects spikes (>200%), drops (>50%), and steady states. "
        "Window options: 1m, 5m, 10m, 30m, 1h (default), 1d."
    ),
)
def cmd_trend(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show rate-of-change for a field over time windows."""
    from logparse.pipeline import _op_timeline

    console = ctx.console
    m = _re.match(r"^(\w+)(?:\s+(\w+))?$", (parsed.args or "").strip())
    if not m:
        console.print("[red]Usage: trend <field> [window][/red]")
        return

    field = m.group(1)
    bucket = m.group(2) or "1h"
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # Build timeline aggregation
    timeline = _op_timeline(events, bucket)
    if not timeline or len(timeline) < 2:
        console.print("[dim]Not enough time buckets for trend analysis.[/dim]")
        return

    # Also get per-bucket field counts
    from collections import Counter, defaultdict
    from logparse.models import get_field
    from math import floor
    from datetime import datetime

    bucket_minutes = {
        "1m": 1, "5m": 5, "10m": 10, "15m": 15, "30m": 30,
        "1h": 60, "hour": 60, "1d": 1440, "day": 1440,
    }.get(bucket, 60)
    bucket_secs = bucket_minutes * 60
    fmt = "%Y-%m-%d %H:%M" if bucket_minutes < 1440 else "%Y-%m-%d"

    # Count field values per time bucket
    bucket_field_counts: defaultdict[str, Counter[str]] = defaultdict(Counter)
    for e in events:
        if e.timestamp is None:
            continue
        ts_epoch = e.timestamp.timestamp()
        bucket_epoch = floor(ts_epoch / bucket_secs) * bucket_secs
        try:
            bucket_dt = datetime.fromtimestamp(bucket_epoch)
        except (OSError, OverflowError, ValueError):
            continue
        label = bucket_dt.strftime(fmt)
        val = get_field(e, field) or "(empty)"
        bucket_field_counts[label][val] += 1

    # Compute rate of change
    from rich.table import Table

    sorted_buckets = sorted(bucket_field_counts.keys())

    # Overall event count per bucket
    bucket_totals = {b: sum(bucket_field_counts[b].values()) for b in sorted_buckets}

    table = Table(title=f"Trend: {field} ({bucket})", border_style="dim")
    table.add_column("Time", style="dim")
    table.add_column("Events", justify="right")
    table.add_column("Change", justify="right")
    table.add_column("Signal", width=10)

    spikes = 0
    drops = 0
    prev_count = None
    for b in sorted_buckets:
        count = bucket_totals[b]

        if prev_count is not None and prev_count > 0 and count != prev_count:
            change_pct = (count - prev_count) / max(prev_count, 1) * 100
            if change_pct > 200:
                signal = "[bold red]SPIKE[/bold red]"
                spikes += 1
            elif change_pct < -50:
                signal = "[yellow]DROP[/yellow]"
                drops += 1
            elif abs(change_pct) < 10:
                signal = "[green]steady[/green]"
            elif change_pct > 0:
                signal = "[cyan]up[/cyan]"
            else:
                signal = "[dim]down[/dim]"
            change_str = f"{change_pct:+.0f}%"
        elif prev_count == 0 and count > 0:
            change_str = "new"
            signal = "[cyan]new[/cyan]"
        else:
            change_str = ""
            signal = ""

        table.add_row(b, format_number(count), change_str, signal)
        prev_count = count

    console.print(table)

    # Summary
    if spikes or drops:
        console.print(
            f"\n  [bold]Detected:[/bold] {spikes} spike(s), {drops} drop(s) "
            f"across {len(sorted_buckets)} time buckets"
        )

    # Top values in field
    all_field_counts: Counter[str] = Counter()
    for counts in bucket_field_counts.values():
        all_field_counts.update(counts)
    top_vals = all_field_counts.most_common(5)
    if top_vals:
        console.print(f"\n  [bold]Top {field} values:[/bold]")
        for val, count in top_vals:
            console.print(f"    {val}: {format_number(count)}")

    session.log_command(parsed.raw, f"trend {field} {bucket}: {spikes} spikes, {drops} drops")
