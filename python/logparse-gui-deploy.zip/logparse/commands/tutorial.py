#!/usr/bin/env python3
"""tutorial command — interactive walkthrough using loaded data."""

from __future__ import annotations

import logging

from collections import Counter

from logparse.commands import register, CommandContext, dispatch
from logparse.session import Session
from logparse.syntax import ParsedCommand, parse_command


@register(
    "tutorial",
    r"^tutorial$",
    category="Meta",
    usage="tutorial",
    help="Interactive step-by-step walkthrough using your loaded data.",
)
def cmd_tutorial(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Interactive step-by-step walkthrough using your loaded data."""
    console = ctx.console

    # detect useful field names and values from loaded data
    fields = session.all_field_names()
    sev_counter = Counter(e.severity for e in session.all_events)
    _source_counter = Counter(e.source for e in session.all_events if e.source)
    ip_field = _find_field(fields, ("srcip", "src", "IpAddress", "dst", "dstip"))
    source_field = "Source"

    # pick a filter value that exists in the data
    filter_field, filter_value = _pick_filter(session)
    search_keyword = _pick_search_keyword(session)
    agg_field = ip_field or source_field

    _top_sev = sev_counter.most_common(1)[0][0] if sev_counter else "High"

    steps = [
        (
            "Step 1: Orientation",
            "Let's see what data is loaded. We'll check sources and fields.",
            "show sources",
        ),
        (
            "Step 1b: Available Fields",
            "Now let's see what fields are available for filtering.",
            "show fields",
        ),
        (
            "Step 2: Filtering",
            "Filter events by a specific value. Filters stack — each narrows the previous result.",
            f"where {filter_field}:{filter_value}",
        ),
        (
            "Step 3: Search",
            "Search event messages for a keyword. This is like grep across all messages.",
            f"search \"{search_keyword}\"",
        ),
        (
            "Step 4: Aggregation",
            "Count events grouped by a field to find patterns and top talkers.",
            f"count by {agg_field}",
        ),
        (
            "Step 5: Detail View",
            "Look at the full detail of a single event — all fields, metadata, and raw text.",
            "show 1",
        ),
        (
            "Step 6: Undo",
            "Step back through filter history. Each undo restores the previous filter state.",
            "undo",
        ),
        (
            "Step 7: Starring",
            "Star events to bookmark them for later review or export.",
            "star 1",
        ),
        (
            "Step 8: Export",
            "Export filtered events to HTML, CSV, or JSON.\n"
            "  Example: [bold]export investigation.html[/bold]\n"
            "  (We won't run this — just showing the syntax.)",
            None,  # no auto-execute
        ),
    ]

    console.print("[bold]logparse Tutorial[/bold]")
    console.print("Walk through the core workflow using your loaded data.")
    console.print("[dim]Press Enter to execute each step. Type 'skip' to skip or 'quit' to exit.[/dim]\n")

    for title, explanation, command in steps:
        console.print(f"[bold cyan]── {title} ──[/bold cyan]")
        console.print(f"  {explanation}")

        if command:
            console.print(f"\n  Command: [bold green]{command}[/bold green]")

        console.print()

        try:
            response = input("  [Enter to continue, 'skip' to skip, 'quit' to exit] ").strip().lower()
        except (EOFError, KeyboardInterrupt, OSError):
            console.print("\n[dim]Tutorial ended.[/dim]")
            return

        if response == "quit":
            console.print("[dim]Tutorial ended.[/dim]")
            return
        if response == "skip":
            console.print("[dim]Skipped.[/dim]\n")
            continue

        if command:
            console.print(f"  [dim]> {command}[/dim]")
            pcmd = parse_command(command)
            try:
                dispatch(session, pcmd, ctx)
            except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
                logging.getLogger(__name__).debug(
                    "Tutorial command error: %s", exc, exc_info=True)
                console.print(f"  [red]Error: {exc}[/red]")
            console.print()

    # undo tutorial's filters
    console.print("[bold cyan]── Tutorial Complete ──[/bold cyan]")
    console.print("  You've learned the core workflow: filter → aggregate → inspect → export.")
    console.print("  Type [bold]cheatsheet[/bold] for a quick reference card.")
    console.print("  Type [bold]help[/bold] for the full command list.\n")

    # try to mark tutorial completed in config
    if hasattr(session, "config") and isinstance(session.config, dict):
        session.config["tutorial_completed"] = True

    session.log_command(parsed.raw, "tutorial completed")


def _find_field(fields: list[str], candidates: tuple[str, ...]) -> str | None:
    """Find the first matching field name (case-insensitive)."""
    fields_lower = {f.lower(): f for f in fields}
    for c in candidates:
        if c.lower() in fields_lower:
            return fields_lower[c.lower()]
    return None


def _pick_filter(session: Session) -> tuple[str, str]:
    """Pick a field:value pair that exists in the data for demonstration."""
    # try severity first — always populated
    sev_counter = Counter(e.severity for e in session.all_events)
    if sev_counter:
        most_common_sev = sev_counter.most_common(1)[0][0]
        return "severity", most_common_sev

    # fallback to source
    source_counter = Counter(e.source for e in session.all_events if e.source)
    if source_counter:
        top_source = source_counter.most_common(1)[0][0]
        return "source", top_source

    return "severity", "High"


def _pick_search_keyword(session: Session) -> str:
    """Pick a keyword that appears in message text."""
    word_counts: Counter[str] = Counter()
    for e in session.all_events[:200]:
        words = (e.message or "").lower().split()
        for w in words:
            if len(w) >= 4 and w.isalpha():
                word_counts[w] += 1

    # pick a common but not too common word
    for word, count in word_counts.most_common(20):
        if 3 <= count <= len(session.all_events) // 2:
            return word

    return "error"
