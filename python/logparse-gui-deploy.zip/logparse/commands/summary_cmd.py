#!/usr/bin/env python3
"""summary command — quick presets for common analysis views."""

from __future__ import annotations

from collections import Counter

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import SEVERITY_LEVELS, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "summary",
    r"^summary(\s+.*)?$",
    category="Analysis",
    usage="summary [security|health] [-v]",
    help="Quick summary overview with optional presets.",
)
def cmd_summary(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Quick summary overview with optional presets."""
    console = ctx.console
    args = parsed.args.strip().lower()
    verbose = "-v" in args
    args = args.replace("-v", "").strip()

    events = session.filtered_events
    if not events:
        console.print("[dim]No events to summarize.[/dim]")
        return

    if args == "security":
        _summary_security(events, console, verbose)
    elif args == "health":
        _summary_health(events, console, verbose)
    else:
        _summary_default(events, console, verbose)

    session.log_command(parsed.raw, f"summary {args or 'default'}")


def _summary_default(events: list, console: Console, verbose: bool) -> None:
    """5-line overview: count, severity inline, top 3 sources, verdict."""
    total = len(events)
    sev_counts = Counter(e.severity for e in events)
    source_counts = Counter(e.source for e in events if e.source)
    ts_events = [e for e in events if e.timestamp]

    # line 1: count + time range
    line1 = f"  {format_number(total)} events"
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        line1 += f"  ({first:%Y-%m-%d %H:%M} — {last:%H:%M:%S})"
    console.print(line1)

    # line 2: severity inline
    sev_parts = []
    for sev in SEVERITY_LEVELS:
        count = sev_counts.get(sev, 0)
        if count:
            sev_parts.append(f"{sev}:{format_number(count)}")
    console.print(f"  Severity: {', '.join(sev_parts)}")

    # line 3: top 3 sources
    top3 = source_counts.most_common(3)
    if top3:
        src_parts = [f"{s} ({format_number(c)})" for s, c in top3]
        console.print(f"  Top sources: {', '.join(src_parts)}")

    # line 4: verdict
    crit = sev_counts.get("Critical", 0) + sev_counts.get("High", 0)
    if crit > total * 0.2:
        console.print(f"  [bold red]Verdict: {format_number(crit)} critical/high events — investigate[/bold red]")
    elif crit > 0:
        console.print(f"  [yellow]Verdict: {format_number(crit)} critical/high events present[/yellow]")
    else:
        console.print("  [green]Verdict: No critical/high severity events[/green]")

    if verbose:
        console.print()
        # extra: unique fields, file breakdown
        fields = set()
        for e in events:
            fields.update(e.extra.keys())
        console.print(f"  Extra fields: {len(fields)}")
        file_counts = Counter(e.source_file for e in events if e.source_file)
        for f, c in file_counts.most_common(5):
            console.print(f"    {f}: {format_number(c)}")


def _summary_security(events: list, console: Console, verbose: bool) -> None:
    """Security-focused: failed auth, denied traffic, critical events, top attack IPs."""
    console.print("[bold]Security Summary[/bold]\n")

    total = len(events)

    # failed auth
    fail_patterns = {"deny", "denied", "failed", "failure", "reject", "auth-fail"}
    failed = [e for e in events if any(p in (e.message or "").lower() for p in fail_patterns)]
    console.print(f"  Failed/denied events: {format_number(len(failed))} ({len(failed)/max(total,1)*100:.1f}%)")

    # critical events
    crit = [e for e in events if e.severity == "Critical"]
    high = [e for e in events if e.severity == "High"]
    console.print(f"  Critical: {format_number(len(crit))}  |  High: {format_number(len(high))}")

    # top attack IPs (from denied/failed events)
    ip_counts = Counter(
        get_field(e, "srcip") for e in failed if get_field(e, "srcip")
    )
    if ip_counts:
        console.print("  Top source IPs (denied/failed):")
        for ip, count in ip_counts.most_common(5):
            console.print(f"    {ip:<20} {format_number(count)}")

    # after-hours events (before 6am or after 10pm)
    after_hours = [
        e for e in events
        if e.timestamp and (e.timestamp.hour < 6 or e.timestamp.hour >= 22)
    ]
    if after_hours:
        console.print(f"  After-hours events (22:00-06:00): {format_number(len(after_hours))}")

    if verbose:
        console.print()
        # denied actions breakdown
        action_counts = Counter(
            get_field(e, "action") for e in events if get_field(e, "action")
        )
        if action_counts:
            console.print("  Actions:")
            for action, count in action_counts.most_common(10):
                console.print(f"    {action:<20} {format_number(count)}")


def _summary_health(events: list, console: Console, verbose: bool) -> None:
    """Health-focused: errors, tunnel status, event rate, timeouts."""
    console.print("[bold]Health Summary[/bold]\n")

    total = len(events)
    ts_events = [e for e in events if e.timestamp]

    # error events
    errors = [e for e in events if e.severity in ("Critical", "High")]
    console.print(f"  Error events: {format_number(len(errors))} / {format_number(total)}")

    # event rate
    if len(ts_events) >= 2:
        first = ts_events[0].timestamp
        last = ts_events[-1].timestamp
        span_seconds = max((last - first).total_seconds(), 1)
        rate = total / span_seconds * 60
        console.print(f"  Event rate: {rate:.1f} events/min")

    # timeout/down events
    timeout_patterns = {"timeout", "timed out", "down", "unreachable", "expired"}
    timeout_events = [
        e for e in events
        if any(p in e.message.lower() for p in timeout_patterns)
    ]
    console.print(f"  Timeout/down events: {format_number(len(timeout_events))}")

    # tunnel status (FortiGate specific)
    tunnel_events = [
        e for e in events
        if any(kw in e.message.lower() for kw in ("tunnel", "ipsec", "vpn", "phase"))
    ]
    if tunnel_events:
        tunnel_up = [e for e in tunnel_events if any(kw in e.message.lower() for kw in ("up", "established", "success"))]
        tunnel_down = [e for e in tunnel_events if any(kw in e.message.lower() for kw in ("down", "failed", "timeout"))]
        console.print(f"  Tunnel events: {format_number(len(tunnel_events))} (up:{len(tunnel_up)} down:{len(tunnel_down)})")

    if verbose:
        console.print()
        # source health
        source_errors = Counter(
            e.source for e in errors if e.source
        )
        if source_errors:
            console.print("  Error sources:")
            for src, count in source_errors.most_common(5):
                console.print(f"    {src:<30} {format_number(count)}")
