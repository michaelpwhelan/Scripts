#!/usr/bin/env python3
"""asn command — ASN ownership lookup for IPs."""

from __future__ import annotations

import re as _re
from collections import Counter

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number

_IP_RE = _re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")


@register(
    "asn",
    r"^asn\s+\S+$",
    category="Analysis",
    usage="asn <IP|field>",
    help=(
        "Look up ASN ownership for an IP or aggregate ASN data for a field. "
        "Single IP: show ASN, org, country. "
        "Field name: aggregate events by ASN and show counts."
    ),
)
def cmd_asn(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:

    """Look up ASN ownership for an IP or aggregate ASN data for a field."""
    console = ctx.console
    target = (parsed.args or "").strip()

    if _IP_RE.match(target):
        _single_ip(target, console)
    else:
        _field_aggregate(target, session, console)

    session.log_command(parsed.raw, f"asn {target}")


def _single_ip(ip: str, console: Console) -> None:
    from rich.panel import Panel
    from logparse.asn_data import lookup_asn
    from logparse.geoip import lookup

    asn_info = lookup_asn(ip)
    geo_info = lookup(ip)

    lines = [
        f"  [bold]IP:[/bold]       {ip}",
        f"  [bold]ASN:[/bold]      AS{asn_info['asn']}" if asn_info["asn"] else "  [bold]ASN:[/bold]      Unknown",
        f"  [bold]Org:[/bold]      {asn_info['org']}",
        f"  [bold]Country:[/bold]  {geo_info.get('country', asn_info['country_code'])}",
    ]
    console.print(Panel("\n".join(lines), title="ASN Lookup", border_style="cyan"))


def _field_aggregate(field: str, session: Session, console: Console) -> None:
    from rich.table import Table
    from logparse.asn_data import lookup_asn

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    asn_counts: Counter[tuple[int, str]] = Counter()
    for e in events:
        ip = get_field(e, field)
        if not ip or not _IP_RE.match(ip):
            continue
        info = lookup_asn(ip)
        asn_num = info["asn"]
        org = info["org"]
        if asn_num:
            asn_counts[(asn_num, org)] += 1

    if not asn_counts:
        console.print(f"[dim]No IP values found in field '{field}'.[/dim]")
        return

    table = Table(title=f"ASN Distribution — {field}", border_style="dim")
    table.add_column("ASN", style="bold")
    table.add_column("Organization")
    table.add_column("Events", justify="right", style="cyan")
    table.add_column("%", justify="right")

    total = sum(asn_counts.values())
    for (asn_num, org), count in asn_counts.most_common(20):
        pct = count / total * 100
        table.add_row(f"AS{asn_num}", org, format_number(count), f"{pct:.1f}%")

    console.print(table)
    console.print(f"  [dim]{format_number(len(asn_counts))} unique ASNs across {format_number(total)} IPs[/dim]")
