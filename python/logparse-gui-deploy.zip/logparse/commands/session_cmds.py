#!/usr/bin/env python3
"""Session management commands: set, undo, reset, save filter, select, add, stop."""

from __future__ import annotations

import re
from datetime import datetime

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number, parse_duration


@register(
    "undo",
    r"^undo(\s+\d+)?$",
    category="Session",
    usage="undo [N]",
    help="Undo the last N filter operations (default 1).",
)
def cmd_undo(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Undo the last N filter operations (default 1)."""
    try:
        count = int(parsed.args.strip()) if parsed.args.strip() else 1
    except (ValueError, OverflowError):
        ctx.console.print("[red]Usage: undo [N] (N must be a positive integer)[/red]")
        return
    undone = 0
    for _ in range(count):
        if not session.undo():
            break
        undone += 1
    if undone:
        ctx.console.print(
            f"[bold]Undo x{undone}[/bold] \u2192 {format_number(len(session.filtered_events))} events"
            f" ({session.active_filter or 'no filter'})"
        )
    else:
        ctx.console.print("[dim]Nothing to undo.[/dim]")
    session.log_command(parsed.raw, f"{len(session.filtered_events)} events")


@register(
    "reset",
    r"^reset$",
    category="Session",
    usage="reset",
    help="Clear all filters and scopes. Nuclear option.",
)
def cmd_reset(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Clear all filters and scopes."""
    session.reset()
    ctx.console.print(
        f"[bold]Reset[/bold] \u2192 {format_number(len(session.all_events))} events"
    )
    session.log_command(parsed.raw, f"reset to {len(session.all_events)} events")


@register(
    "save",
    r"^save\s+filter$",
    category="Session",
    usage="save filter",
    help="Save current filter as a numbered snapshot.",
)
def cmd_save_filter(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Save current filter as a numbered snapshot."""
    fid = session.save_filter()
    ctx.console.print(
        f"Saved filter #{fid}: "
        f"{session.active_filter or '(all)'} "
        f"({format_number(len(session.filtered_events))} events)"
    )
    session.log_command(parsed.raw, f"saved as #{fid}")


@register(
    "set",
    r"^set\s+.+",
    category="Session",
    usage="set <source VALUE | time RANGE | filter N | ip VALUE | relativetime TZ>",
    help="Set session parameters.",
)
def cmd_set(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Set session parameters."""
    console = ctx.console
    args = parsed.args.strip()

    # set filter N
    m = re.match(r"^filter\s+(\d+)$", args, re.I)
    if m:
        fid = int(m.group(1))
        if session.restore_filter(fid):
            console.print(
                f"[bold]Restored filter #{fid}[/bold] \u2192 "
                f"{format_number(len(session.filtered_events))} events"
            )
        else:
            console.print(f"[red]No saved filter #{fid}[/red]")
            session.log_command(parsed.raw, f"failed to restore #{fid}")
            return
        session.log_command(parsed.raw, f"restored #{fid}")
        return

    # set time <range>
    m = re.match(r"^time\s+(.+)$", args, re.I)
    if m:
        delta = parse_duration(m.group(1).strip())
        if delta is None:
            console.print(f"[red]Invalid time range: {m.group(1)}[/red]")
            return
        ts_events = [e for e in session.all_events if e.timestamp]
        if not ts_events:
            console.print("[red]No timestamps in dataset.[/red]")
            return
        max_ts = max(e.timestamp for e in ts_events)
        cutoff = max_ts - delta
        session.push_filter(f"time >= {cutoff:%H:%M:%S}")
        session.filtered_events = [
            e for e in session.filtered_events
            if e.timestamp is not None and e.timestamp >= cutoff
        ]
        console.print(
            f"[bold]Time window set[/bold] \u2192 "
            f"{format_number(len(session.filtered_events))} events"
        )
        session.log_command(parsed.raw, f"{len(session.filtered_events)} events")
        return

    # set source <value>
    m = re.match(r"^source\s+(.+)$", args, re.I)
    if m:
        val = m.group(1).strip()
        session.push_filter(f"source={val}")
        val_lower = val.lower()
        session.filtered_events = [
            e for e in session.filtered_events
            if val_lower in (e.source or "").lower()
            or val_lower in (e.source_file or "").lower()
        ]
        console.print(
            f"[bold]Source scope: {val}[/bold] \u2192 "
            f"{format_number(len(session.filtered_events))} events"
        )
        session.log_command(parsed.raw, f"source={val}, {len(session.filtered_events)} events")
        return

    # set ip <value>
    m = re.match(r"^ip\s+(.+)$", args, re.I)
    if m:
        val = m.group(1).strip()
        if val.lower() == "clear":
            session.ip_scope = None
            console.print("[bold]IP scope cleared.[/bold]")
            session.log_command(parsed.raw, "ip scope cleared")
            return
        session.ip_scope = val
        # apply scope: filter to events where value appears in any field
        session.push_filter(f"ip={val}")
        val_lower = val.lower()
        session.filtered_events = [
            e for e in session.filtered_events
            if val_lower in (e.source or "").lower()
            or val_lower in (e.message or "").lower()
            or any(val_lower in (v or "").lower() for v in e.extra.values())
        ]
        console.print(
            f"[bold]IP scope: {val}[/bold] \u2192 "
            f"{format_number(len(session.filtered_events))} events"
        )
        session.log_command(parsed.raw, f"ip={val}, {len(session.filtered_events)} events")
        return

    # set relativetime <tz>
    m = re.match(r"^relativetime\s+(.+)$", args, re.I)
    if m:
        console.print(f"Timezone display set to: {m.group(1)}")
        session.log_command(parsed.raw, f"tz={m.group(1)}")
        return

    # set timestamp time|datetime|relative
    m = re.match(r"^timestamp\s+(time|datetime|relative)$", args, re.I)
    if m:
        fmt = m.group(1).lower()
        session.timestamp_format = fmt
        console.print(f"Timestamp display set to: {fmt}")
        session.log_command(parsed.raw, f"timestamp={fmt}")
        return

    # Check if the user meant hide/where (e.g., "set source:ESENT")
    if ":" in args or "=" in args:
        console.print(f"[red]Unknown set parameter: {args}[/red]")
        console.print(f"[yellow]Tip: to filter by field value, use 'where {args}' or 'hide {args}'[/yellow]")
    else:
        console.print(f"[red]Unknown set parameter: {args}[/red]")


@register(
    "select",
    r"^select\s+.+",
    category="Session",
    usage="select <file|time date>",
    help="Filter by source file or date.",
)
def cmd_select(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Filter by source file or date."""
    console = ctx.console
    args = parsed.args.strip()

    # select time <date>
    m = re.match(r"^time\s+(.+)$", args, re.I)
    if m:
        date_str = m.group(1).strip()
        session.push_filter(f"date={date_str}")
        session.filtered_events = [
            e for e in session.filtered_events
            if e.timestamp and date_str in e.timestamp.strftime("%Y-%m-%d")
        ]
        console.print(
            f"[bold]Selected date {date_str}[/bold] \u2192 "
            f"{format_number(len(session.filtered_events))} events"
        )
        session.log_command(parsed.raw, f"{len(session.filtered_events)} events")
        return

    # select source <pattern> — filter by Source field (with glob support)
    source_match = re.match(r"^source\s+(.+)$", args, re.I)
    if source_match:
        pattern = source_match.group(1).strip()
        session.push_filter(f"source={pattern}")
        from fnmatch import fnmatch
        if "*" in pattern or "?" in pattern:
            session.filtered_events = [
                e for e in session.filtered_events
                if fnmatch((e.source or "").lower(), pattern.lower())
            ]
        else:
            session.filtered_events = [
                e for e in session.filtered_events
                if pattern.lower() in (e.source or "").lower()
            ]
        console.print(
            f"[bold]Selected source {pattern}[/bold] \u2192 "
            f"{format_number(len(session.filtered_events))} events"
        )
        session.log_command(parsed.raw, f"{len(session.filtered_events)} events")
        return

    # select <file>
    filename = args
    candidates = [
        e for e in session.filtered_events
        if filename.lower() in (e.source_file or "").lower()
    ]
    if not candidates:
        console.print(
            f"[yellow]No files matching '{filename}'[/yellow]"
        )
        return
    session.push_filter(f"file={filename}")
    session.filtered_events = candidates
    console.print(
        f"[bold]Selected {filename}[/bold] \u2192 "
        f"{format_number(len(session.filtered_events))} events"
    )
    session.log_command(parsed.raw, f"{len(session.filtered_events)} events")


@register(
    "add",
    r"^add\s+.+",
    category="Session",
    usage="add <file>",
    help="Load additional file into session.",
)
def cmd_add(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Load additional file into session."""
    from logparse.loader import load_files

    console = ctx.console
    filepath = parsed.args.strip()

    events, files, fmts = load_files([filepath], quiet=True)
    if not events:
        console.print(f"[red]No events loaded from {filepath}[/red]")
        return

    session.all_events.extend(events)
    session.all_events.sort(
        key=lambda e: e.timestamp if e.timestamp is not None else datetime.max
    )
    session.filtered_events = list(session.all_events)
    session.invalidate_caches()
    session.source_files.extend(files)
    session.loaded_formats.extend(f for f in fmts if f not in session.loaded_formats)

    # re-apply current filter? For simplicity, reset to all
    console.print(
        f"[bold]Added {format_number(len(events))} events from {filepath}.[/bold] "
        f"Total: {format_number(len(session.all_events))} events."
    )
    session.log_command(parsed.raw, f"added {len(events)} events")


@register(
    "stop",
    r"^stop$",
    category="Session",
    usage="stop",
    help="Exit interactive mode.",
)
def cmd_stop(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Exit interactive mode."""
    raise SystemExit(0)
