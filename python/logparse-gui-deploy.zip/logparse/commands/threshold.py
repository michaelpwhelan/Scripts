#!/usr/bin/env python3
"""threshold command — set alert thresholds on field counts."""

from __future__ import annotations

import operator
import re as _re
from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number

_OPS = {
    ">": operator.gt,
    "<": operator.lt,
    ">=": operator.ge,
    "<=": operator.le,
    "==": operator.eq,
}


@register(
    "threshold",
    r"^threshold(?:\s+.*)?$",
    category="Analysis",
    usage="threshold <field> <op> <value> | threshold list | threshold clear",
    help=(
        "Set alert thresholds on event counts for field values. "
        "Operators: >, <, >=, <=, ==. "
        "Values exceeding the threshold are highlighted."
    ),
)
def cmd_threshold(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Set alert thresholds on event counts for field values."""
    console = ctx.console
    args = (parsed.args or "").strip()

    # threshold list
    if args.lower() in ("list", "show"):
        thresholds = session.variables.get("_thresholds", {})
        if not thresholds:
            console.print("[dim]No active thresholds.[/dim]")
            return
        console.print("[bold]Active Thresholds:[/bold]")
        for field, (op_str, val) in thresholds.items():
            console.print(f"  {field} {op_str} {val}")
        return

    # threshold clear
    if args.lower() in ("clear", "reset"):
        session.variables.pop("_thresholds", None)
        console.print("[dim]All thresholds cleared.[/dim]")
        session.log_command(parsed.raw, "threshold clear")
        return

    # Parse: <field> <op> <value>
    m = _re.match(r"^(\w+)\s*(>=|<=|==|>|<)\s*(\d+(?:\.\d+)?)$", args)
    if not m:
        console.print("[red]Usage: threshold <field> <op> <value>[/red]")
        console.print("[dim]Example: threshold srcip > 100[/dim]")
        console.print("[dim]Commands: threshold list, threshold clear[/dim]")
        return

    field = m.group(1)
    op_str = m.group(2)
    value = float(m.group(3))

    # Store threshold
    if "_thresholds" not in session.variables:
        session.variables["_thresholds"] = {}
    session.variables["_thresholds"][field] = (op_str, value)

    # Evaluate against current data
    events = session.filtered_events
    if not events:
        console.print(f"[bold]Threshold set:[/bold] {field} {op_str} {value}")
        return

    op_fn = _OPS[op_str]
    field_counts: Counter[str] = Counter()
    for e in events:
        val = get_field(e, field)
        if val is not None:
            field_counts[val] += 1

    violations = [
        (val, count) for val, count in field_counts.most_common()
        if op_fn(count, value)
    ]

    console.print(f"[bold]Threshold set:[/bold] {field} {op_str} {int(value)}")

    if violations:
        console.print(f"\n[bold yellow]{len(violations)} violation(s) in current data:[/bold yellow]")
        from rich.table import Table
        table = Table(border_style="yellow")
        table.add_column("Value", style="bold")
        table.add_column("Count", justify="right", style="red")
        for val, count in violations[:15]:
            table.add_row(val, format_number(count))
        console.print(table)
    else:
        console.print("  [green]No violations in current data.[/green]")

    session.log_command(parsed.raw, f"threshold {field} {op_str} {value}: {len(violations)} violations")
