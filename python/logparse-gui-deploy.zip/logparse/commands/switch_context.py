#!/usr/bin/env python3
"""switch context command — parallel investigation workspaces."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number

# module-level storage for contexts (shared across the session)
_contexts: dict[int, Session] = {}
_active_context: list[int] = [0]  # mutable container for current context ID


def get_contexts() -> dict[int, Session]:
    """Return the map of context IDs to sessions."""
    return _contexts


def get_active_context_id() -> int:
    """Return the currently active context ID."""
    return _active_context[0]


@register(
    "switch",
    r"^switch\s+context",
    category="Session",
    usage="switch context [N]",
    help="Switch to or create a parallel investigation workspace.",
)
def cmd_switch_context(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Switch to or create a parallel investigation workspace."""
    console = ctx.console
    m = re.match(r"^context\s*(\d+)?$", parsed.args.strip(), re.I)
    if not m:
        console.print("[red]Usage: switch context [N][/red]")
        return

    target_str = m.group(1)

    # list contexts if no number given
    if target_str is None:
        console.print("[bold]Active contexts:[/bold]")
        current = _active_context[0]
        # snapshot current for display
        _contexts[current] = session  # reference is fine for listing
        for cid, s in sorted(_contexts.items()):
            marker = " *" if cid == current else "  "
            console.print(
                f"{marker}Context {cid}: "
                f"{format_number(len(s.filtered_events))} events"
                f" ({s.active_filter or 'no filter'})"
                f" | {len(s.notes)} notes"
            )
        session.log_command(parsed.raw, f"{len(_contexts)} contexts")
        return

    target = int(target_str)

    # snapshot current session state before switching
    import copy
    saved = Session(
        all_events=session.all_events,
        filtered_events=list(session.filtered_events),
    )
    # Deep-copy mutable state so contexts are independent
    for attr, val in session.__dict__.items():
        if attr in ("all_events", "filtered_events"):
            continue  # already set above
        try:
            setattr(saved, attr, copy.deepcopy(val))
        except TypeError:
            setattr(saved, attr, val)
    _contexts[_active_context[0]] = saved

    if target in _contexts:
        # switch to existing
        target_session = _contexts[target]
        console.print(
            f"[bold]Switched to context {target}[/bold] "
            f"({format_number(len(target_session.filtered_events))} events, "
            f"{target_session.active_filter or 'no filter'})"
        )
    else:
        # create new context sharing all_events
        target_session = Session(
            all_events=session.all_events,
            filtered_events=list(session.all_events),
            source_files=list(session.source_files),
            loaded_formats=list(session.loaded_formats),
        )
        _contexts[target] = target_session
        console.print(
            f"[bold]Created context {target}[/bold] "
            f"({format_number(len(target_session.all_events))} events)"
        )

    _active_context[0] = target

    # copy state into the live session object (in-place mutation so repl.py
    # continues referencing the same object)
    for attr, val in target_session.__dict__.items():
        if attr == "all_events":
            continue  # shared across contexts
        setattr(session, attr, val)

    session.log_command(parsed.raw, f"context {target}")
