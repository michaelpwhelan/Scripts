#!/usr/bin/env python3
"""entity command — score and inspect entities by risk."""

from __future__ import annotations

from rich.console import Console

from logparse.commands import register, sev_color, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "entity",
    r"^entity(?:\s+.+)?$",
    category="Analysis",
    usage="entity score | entity top [N] | entity <value>",
    help=(
        "Score entities (IPs, users, hosts) by accumulated risk.  "
        "'entity score' shows all scored entities.  "
        "'entity top 10' shows top 10.  "
        "'entity 10.0.0.1' shows detail for one entity."
    ),
)
def cmd_entity(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Score entities (IPs, users, hosts) by accumulated risk."""
    from logparse.entity_scoring import score_entities, score_entity

    console = ctx.console
    args_str = (parsed.args or "").strip()
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    if not args_str or args_str == "score":
        _show_entity_table(console, score_entities(events), limit=30)
        session.log_command(ctx.raw_input, "entity scoring")
        return

    if args_str.startswith("top"):
        parts = args_str.split()
        n = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 10
        _show_entity_table(console, score_entities(events), limit=n)
        session.log_command(ctx.raw_input, f"entity top {n}")
        return

    # Lookup a specific entity
    profile = score_entity(args_str, events)
    if profile is None:
        console.print(f"[dim]Entity '{args_str}' not found or has no risk score.[/dim]")
        return

    from rich.panel import Panel

    lines = [
        f"[bold]{profile.entity_type.upper()}:[/bold] {profile.entity_value}",
        f"[bold]Risk Tier:[/bold] {sev_color(profile.risk_tier)}",
        f"[bold]Score:[/bold] {profile.score:.1f}",
        f"[bold]Events:[/bold] {profile.event_count}",
        f"[bold]Sources:[/bold] {len(profile.source_files - {''})}",
    ]
    if profile.first_seen:
        lines.append(f"[bold]First Seen:[/bold] {profile.first_seen:%Y-%m-%d %H:%M:%S}")
    if profile.last_seen:
        lines.append(f"[bold]Last Seen:[/bold] {profile.last_seen:%Y-%m-%d %H:%M:%S}")
    if profile.event_types:
        top_types = profile.event_types.most_common(5)
        type_str = ", ".join(f"{t}({c})" for t, c in top_types)
        lines.append(f"[bold]Event Types:[/bold] {type_str}")

    console.print(Panel("\n".join(lines), title="Entity Profile"))
    session.log_command(ctx.raw_input, f"entity lookup {args_str}")


def _show_entity_table(console: Console, profiles: list, limit: int = 30) -> None:
    from rich.table import Table

    table = Table(title="Entity Risk Scores")
    table.add_column("Entity", style="bold")
    table.add_column("Type")
    table.add_column("Score", justify="right")
    table.add_column("Tier")
    table.add_column("Events", justify="right")
    table.add_column("Sources", justify="right")
    table.add_column("Top Event Types")

    for p in profiles[:limit]:
        top_types = ", ".join(t for t, _ in p.event_types.most_common(3))
        table.add_row(
            p.entity_value,
            p.entity_type,
            f"{p.score:.1f}",
            sev_color(p.risk_tier),
            str(p.event_count),
            str(len(p.source_files - {""})),
            top_types,
        )

    console.print(table)
    if len(profiles) > limit:
        console.print(f"[dim]Showing {limit}/{len(profiles)} entities. Use 'entity top N' for more.[/dim]")


