#!/usr/bin/env python3
"""Meta commands: help, ?, history."""

from __future__ import annotations

import json
from pathlib import Path

from logparse.commands import register, CommandContext, get_categories
from logparse.session import Session
from logparse.syntax import ParsedCommand


def _load_examples() -> dict[str, list[str]]:
    """Load command examples from examples.json."""
    path = Path(__file__).parent / "examples.json"
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


_EXAMPLES: dict[str, list[str]] = _load_examples()


@register(
    "help",
    r"^(help|\?)(\s+\w+)?$",
    category="Meta",
    usage="help [command]",
    help="Show help for all commands or a specific command.",
)
def cmd_help(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show help for all commands or a specific command."""
    from logparse.commands import get_registry

    console = ctx.console
    args = parsed.args.strip()

    if args:
        # help for specific command
        for cmd in get_registry():
            if cmd.name == args.lower():
                console.print(f"[bold]{cmd.name}[/bold]")
                console.print(f"  Usage: {cmd.usage}")
                console.print(f"  {cmd.help}")
                # show examples
                examples = _EXAMPLES.get(cmd.name)
                if examples:
                    console.print()
                    console.print("  [bold]Examples:[/bold]")
                    for ex in examples:
                        console.print(f"    [dim]{ex}[/dim]")
                return
        console.print(f"[dim]No help for '{args}'[/dim]")
        return

    # full help
    console.print("[bold]logparse interactive commands[/bold]\n")
    for cat, cmds in sorted(get_categories().items()):
        console.print(f"[bold cyan]{cat}[/bold cyan]")
        for cmd in cmds:
            console.print(f"  [bold]{cmd.usage:<45}[/bold] {cmd.help}")
        console.print()

    console.print("[dim]Unrecognized input is treated as a 'where' filter query.[/dim]")
    session.log_command(parsed.raw, "help")


@register(
    "quit",
    r"^(quit|exit|q)$",
    category="Meta",
    usage="quit",
    help="Exit interactive mode.",
)
def cmd_quit(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Exit interactive mode."""
    raise SystemExit(0)


@register(
    "clear",
    r"^(clear|cls)$",
    category="Meta",
    usage="clear",
    help="Clear the terminal screen.",
)
def cmd_clear(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Clear the terminal screen."""
    import os
    os.system("cls" if os.name == "nt" else "clear")


def context_help(cmd_text: str, session: Session, ctx: CommandContext) -> None:
    """Position-aware ? context help — called from repl.py before dispatch."""
    console = ctx.console
    text = cmd_text.rstrip()
    if text.endswith("?"):
        text = text[:-1].strip()
    else:
        text = ""

    verb = text.split()[0].lower() if text else ""

    # build field list with sample values
    fields = session.all_field_names()
    field_samples: dict[str, str] = {}
    if session.all_events:
        from logparse.models import get_field
        sample_event = session.all_events[0]
        for f in fields:
            val = get_field(sample_event, f)
            if val:
                field_samples[f] = val[:30]

    _HELP: dict[str, list[tuple[str, str]]] = {
        "where": [
            ("Syntax", "where <field>:<value> | where !<field>:<value> | where <field> in a,b,c"),
            ("Network", "where <ip_field> internal | where <ip_field> external"),
            ("Fields", ", ".join(fields)),
            ("Example", f"where {fields[0]}:{field_samples.get(fields[0], 'value')}" if fields else "where severity:High"),
            ("Example", f"where {fields[-1]}:{field_samples.get(fields[-1], 'value')}" if len(fields) > 1 else ""),
        ],
        "show": [
            ("show", "Display filtered events"),
            ("show sources", "List all sources with counts"),
            ("show fields", "List available field names"),
            ("show severity", "Severity breakdown with counts"),
            ("show high|critical", "Filter by severity (supports |, and, or)"),
            ("show N", "Full detail of event #N"),
            ("show N, N, N", "Detail view of multiple events"),
            ("show star", "Display starred events"),
            ("show annotate", "Display annotated events"),
            ("show timeline", "Time range summary"),
            ("show filter", "List saved filter snapshots"),
            ("show history", "Command history"),
            ("show -a <value>", "Cross-field search"),
            ("show * where sev:crit", "Inline filter with field abbreviations"),
            ("show *", "Set display to all fields"),
        ],
        "count": [
            ("Syntax", "count by <field>"),
            ("Fields", ", ".join(f for f in fields if f.lower() not in ("message", "timestamp"))),
            ("Example", "count by severity"),
            ("Example", f"count by {fields[-1]}" if len(fields) > 1 else "count by source"),
        ],
        "set": [
            ("set time <range>", "Filter to time range (e.g., 'last 2h')"),
            ("set filter N", "Restore saved filter snapshot"),
            ("set ip <addr>", "Set IP scope constraint"),
            ("set relativetime", "Toggle relative timestamps"),
        ],
        "export": [
            ("export file.html", "Export filtered events to HTML"),
            ("export file.csv", "Export to CSV"),
            ("export file.json", "Export to JSON"),
            ("export star file.ext", "Export starred events"),
            ("export summary [file]", "Export investigation transcript"),
            ("export profile file.zip", "Export full session profile"),
            ("export ... include annotate", "Include annotations in export"),
        ],
        "visual": [
            ("visual severity", "Bar chart of severity distribution"),
            ("visual timeline", "Event timeline"),
            ("visual top <field>", "Top N by field"),
        ],
        "star": [
            ("star N", "Star event #N"),
            ("star N, N, N", "Star multiple events"),
            ("star N-M", "Star a range"),
            ("unstar N", "Remove star from event #N"),
            ("star clear", "Clear all stars"),
            ("show star", "Display all starred events"),
            ("export star file.csv", "Export starred events"),
        ],
        "hide": [
            ("Syntax", "hide <field>:<value> — hide events matching field:value"),
            ("Multiple", "hide Source:WMI-Activity, DCOM, ESENT"),
            ("Undo", "unhide <field>:<value>"),
            ("Fields", ", ".join(fields)),
            ("Example", f"hide Source:{session.all_events[0].source}" if session.all_events else "hide Source:noise"),
        ],
        "unhide": [
            ("Syntax", "unhide <field>:<value>"),
            ("Example", "unhide Source:WMI-Activity"),
        ],
        "head": [
            ("head", "Show first 10 events"),
            ("head N", "Show first N events"),
            ("head N where <filter>", "First N events matching filter (scratch)"),
            ("Example", "head 5 where severity:High"),
        ],
        "tail": [
            ("tail", "Show last 10 events"),
            ("tail N", "Show last N events"),
            ("tail N where <filter>", "Last N events matching filter (scratch)"),
            ("Example", "tail 10 where action:deny"),
        ],
        "search": [
            ("Syntax", 'search "pattern" — grep across all fields'),
            ("Once", 'search once "pattern" — search without changing filter'),
            ("Case", 'search --case-sensitive "pattern"'),
            ("Example", 'search "tunnel.*down"'),
            ("Example", 'search once "error"'),
        ],
        "sort": [
            ("sort by <field>", "Sort events by field"),
            ("sort by <field> desc", "Sort descending"),
            ("sort flip", "Reverse current sort order"),
            ("Example", "sort by severity"),
            ("Example", "show | sort by srcip | head 20"),
        ],
        "annotate": [
            ('annotate N "text"', "Attach note to event #N"),
            ("annotate list", "Show all annotations"),
            ("annotate delete N", "Remove annotation from event #N"),
            ("annotate clear", "Clear all annotations"),
            ("Pipe", 'show N | annotate "text"'),
        ],
        "remember": [
            ('remember "text"', "Save an investigation note"),
            ("remember", "List all notes"),
            ("remember | delete N", "Delete note #N"),
        ],
        "dashboard": [
            ("dashboard", "Overview: severity, top sources, top IPs, suggestions"),
        ],
        "summary": [
            ("summary", "5-line quick overview"),
            ("summary security", "Failed auth, denied traffic, top attack IPs"),
            ("summary health", "Errors, tunnel status, event rate, timeouts"),
            ("summary -v", "Verbose mode with extra detail"),
        ],
        "dedup": [
            ("dedup", "Remove duplicate events (by message)"),
            ("dedup field:dstip", "Deduplicate by specific field"),
        ],
        "context": [
            ("context 60s", "Expand to events within +/-60s of current set"),
            ("context 5m", "Expand to +/-5 minutes"),
            ("context 60s ro", "Preview expansion without committing"),
        ],
        "analyze": [
            ("analyze", "Run unified security assessment (auto-detects data types)"),
            ("analyze list", "List all available analyzers"),
            ("analyze firewall", "Firewall traffic: denies, policies, geo enrichment"),
            ("analyze auth", "Authentication: success/fail, lockouts, priv escalation"),
            ("analyze traffic", "Network flows: top pairs, internal/external, bandwidth"),
            ("analyze windows", "Windows events: logons, account mgmt, services, audit"),
            ("analyze anomaly", "Statistical anomaly detection (4 detectors)"),
            ("analyze entity", "Entity risk scoring across all sources"),
            ("analyze failed-logins", "Brute-force and credential attack detection"),
            ("analyze vpn-sessions", "VPN session lifecycle and impossible travel"),
            ("analyze vpn-health", "VPN health scoring"),
            ("analyze ipsec-tunnel", "IPsec tunnel state and flap detection"),
            ("analyze dns", "DNS traffic, tunneling, beaconing"),
            ("analyze correlation", "Cross-source entity correlation"),
            ("analyze incident", "Incident timeline reconstruction"),
            ("analyze sla", "SLA / availability metrics"),
        ],
        "anomaly": [
            ("anomaly", "Run all anomaly detectors"),
            ("anomaly new", "Find new/unseen values"),
            ("anomaly time", "Unusual time-of-day activity"),
            ("anomaly volume", "Traffic volume spikes"),
            ("anomaly patterns", "Unusual event patterns"),
        ],
        "correlate": [
            ("correlate <field>", "Trace entity across all sources"),
            ("correlate <field> <value>", "Trace specific value"),
            ("correlate from N", "Correlate from event #N"),
        ],
        "diff": [
            ("diff <f1> <f2>", "Compare two log files"),
            ("diff time T1 D1 time T2 D2", "Compare two time windows"),
            ("diff session A B", "Compare two sessions"),
            ("diff *", "Diff all loaded sources"),
        ],
        "geo": [
            ("geo <IP>", "GeoIP lookup for a single IP"),
            ("geo <field>", "GeoIP summary for an IP field"),
        ],
        "mitre": [
            ("mitre scan", "Scan events for ATT&CK techniques"),
            ("mitre <T1234>", "Look up a specific technique"),
            ("mitre visual", "Visual ATT&CK matrix"),
            ("mitre list", "List detected techniques"),
        ],
        "profile": [
            ("profile <IP>", "Threat assessment: geo, ASN, reputation, activity"),
        ],
        "report": [
            ("report summary", "Executive summary"),
            ("report morning", "Morning briefing report"),
            ("report audit", "Audit trail report"),
            ("report compliance", "FFIEC compliance domain evidence"),
            ("report evidence", "Examiner-ready log review evidence"),
            ("report timeline", "Timeline narrative"),
            ("--export file", "Append to any report to save to file"),
        ],
        "sdwan": [
            ("sdwan", "SD-WAN link health overview"),
            ("sdwan failovers", "Show failover events"),
        ],
        "top": [
            ("top <field>", "Top 10 values for a field"),
            ("top <field> N", "Top N values"),
            ("top N <field>", "Top N values (alternate syntax)"),
        ],
        "sample": [
            ("sample", "Show 10 random events"),
            ("sample N", "Show N random events"),
        ],
        "timeline": [
            ("timeline", "Auto-bucketed time distribution"),
            ("timeline 5m", "5-minute buckets"),
            ("timeline 1h", "Hourly buckets"),
        ],
        "find": [
            ("Syntax", "find <pattern> — search within current view"),
            ("Example", 'find "error"'),
            ("Example", "find in severity:High"),
        ],
        "stats": [
            ("stats <field>", "Statistics: unique count, top values, distribution"),
        ],
        "copy": [
            ("copy table", "Copy current view as table to clipboard"),
            ("copy <field>", "Copy field values to clipboard"),
        ],
        "undo": [
            ("undo", "Undo last filter/action"),
            ("undo N", "Undo last N steps"),
        ],
        "reset": [
            ("reset", "Clear all filters, return to full dataset"),
        ],
        "save": [
            ("save filter", "Save current filter as a named snapshot"),
        ],
        "select": [
            ("select <file>", "Narrow to a specific loaded file"),
            ("select time <date>", "Narrow to a specific date"),
            ("select source <pattern>", "Narrow to matching sources"),
        ],
        "add": [
            ("add <file>", "Load an additional log file into the session"),
        ],
        "save session": [
            ("save session <name>", "Persist the current session to disk"),
            ("save session list", "List saved sessions"),
        ],
        "resume": [
            ("resume <name>", "Restore a previously saved session"),
        ],
        "switch": [
            ("switch context", "List available contexts"),
            ("switch context N", "Switch to context #N"),
        ],
        "ditto": [
            ("ditto", "Duplicate current session for comparison"),
            ("ditto <file>", "Open file in a parallel context"),
            ("ditto AND <cond>", "Intersect with condition"),
            ("ditto OR <cond>", "Union with condition"),
        ],
        "not": [
            ("Syntax", "not <field>:<value> — shorthand for where !field:value"),
            ("Example", "not severity:Low"),
        ],
        "where!": [
            ("Syntax", "where! <filter> — filter from ALL events, ignoring current filters"),
            ("Example", "where! srcip:10.0.0.1"),
        ],
        "last": [
            ("last Nh", "Filter to last N hours"),
            ("last Nm", "Filter to last N minutes"),
            ("last Nd", "Filter to last N days"),
        ],
        "vars": [
            ("vars", "List all stored variables"),
            ("$name = value", "Assign a variable"),
            ("$name = N.field", "Capture field from event #N"),
            ("$name += 5m", "Time arithmetic on variable"),
            ("$name properties", "Show variable properties"),
            ("unset $name", "Delete a variable"),
        ],
        "tag": [
            ("tag N label", "Label event #N"),
            ("tag N,M,O label", "Label multiple events"),
            ("tag list", "Show all tags"),
            ("tag clear [label]", "Clear tags, optionally by label"),
        ],
        "macro": [
            ("macro define <name>", "Start recording commands as a macro"),
            ("macro run <name>", "Execute a saved macro"),
            ("macro list", "List all macros"),
            ("macro delete <name>", "Delete a macro"),
        ],
        "alias": [
            ("alias <name> <cmd>", "Create command shorthand"),
            ("alias list", "List all aliases"),
            ("alias delete <name>", "Remove an alias"),
        ],
        "playbook": [
            ("playbook list", "List available playbooks"),
            ("playbook create <name>", "Create a new playbook"),
        ],
        "run": [
            ("run <routine>", "Execute a named routine or playbook"),
        ],
        "load": [
            ("load config <file>", "Load a configuration/playbook file"),
        ],
        "asn": [
            ("asn <IP>", "ASN lookup for a single IP"),
            ("asn <field>", "ASN summary for an IP field"),
        ],
        "reputation": [
            ("reputation <IP>", "Threat reputation check for an IP"),
            ("reputation <field>", "Reputation summary for an IP field"),
        ],
        "dns": [
            ("dns", "DNS query analysis for current events"),
            ("dns summary", "DNS query summary"),
        ],
        "ports": [
            ("ports", "Port analysis for current events"),
            ("ports summary", "Port usage summary"),
            ("ports <N>", "Details for a specific port"),
        ],
        "trend": [
            ("trend <field>", "Show value trend over time"),
            ("trend <field> 5m", "Trend with custom time window"),
        ],
        "threshold": [
            ("threshold <field> > N", "Alert when field exceeds value"),
            ("threshold list", "Show active thresholds"),
            ("threshold clear", "Remove all thresholds"),
        ],
        "baseline": [
            ("baseline", "Show stored baselines"),
            ("baseline <field>", "Compute baseline for a field"),
        ],
        "user": [
            ("user <name>", "Activity summary for a user"),
            ("user <name> timeline", "User activity timeline"),
        ],
        "derive": [
            ("Syntax", 'derive <new> from <source> regex:<pattern>'),
            ("Example", 'derive domain from url regex:"https?://([^/]+)"'),
        ],
        "!": [
            ("!<command>", "Run a shell command (e.g., !ls, !ping 8.8.8.8)"),
            ("!", "Open an interactive shell"),
        ],
        "preview": [
            ("preview", "Show top 10 events by severity"),
        ],
        "unstar": [
            ("unstar N", "Remove star from event #N"),
            ("unstar N, N, N", "Unstar multiple events"),
            ("unstar N-M", "Unstar a range"),
        ],
        "unset": [
            ("unset $name", "Delete a stored variable"),
        ],
        "stop": [
            ("stop", "End the current session"),
        ],
        "deduplicate": [
            ("deduplicate", "Remove duplicate events (by message)"),
            ("deduplicate by <field>", "Deduplicate by specific field"),
            ("deduplicate --smart", "Smart deduplication"),
        ],
        "help": [
            ("help", "Show all commands grouped by category"),
            ("help <command>", "Usage and examples for a specific command"),
        ],
        "quit": [
            ("quit | exit | q", "Exit interactive mode"),
        ],
        "cheatsheet": [
            ("cheatsheet", "Print the full command reference card"),
        ],
        "tutorial": [
            ("tutorial", "Launch the interactive walkthrough"),
        ],
        "$assign": [
            ("$name = value", "Assign a variable"),
            ("$name = N.field", "Capture a field value from event #N"),
            ("See also", "vars ?, unset ?"),
        ],
        "$props": [
            ("$name properties", "Show type, value, and metadata of a variable"),
        ],
        "$time_arith": [
            ("$name += 5m", "Add duration to a time variable"),
            ("$name -= 2h", "Subtract duration from a time variable"),
        ],
    }

    # map $variable commands to their registered names
    if verb.startswith("$") and verb not in _HELP:
        if "+=" in text or "-=" in text:
            verb = "$time_arith"
        elif "properties" in text.lower():
            verb = "$props"
        elif "=" in text:
            verb = "$assign"
        else:
            verb = "vars"

    # try two-word key first for compound commands (save session, switch context)
    words = text.split()
    two_word = " ".join(words[:2]).lower() if len(words) >= 2 else ""
    entries = _HELP.get(two_word) or _HELP.get(verb)
    if entries:
        console.print(f"[bold]{text or verb} — context help[/bold]\n")
        for label, desc in entries:
            if desc:
                console.print(f"  [cyan]{label:<25}[/cyan] {desc}")
        console.print()
        return

    # bare ? — categorised quick reference
    console.print("[bold]logparse — Quick Help[/bold]\n")

    console.print("  [bold yellow]Filtering[/bold yellow]")
    console.print("    [cyan]where[/cyan] field:value          Filter events")
    console.print("    [cyan]not[/cyan] field:value            Exclude events")
    console.print("    [cyan]hide[/cyan] field:value           Suppress matching events")
    console.print("    [cyan]search[/cyan] \"text\"              Search all fields")
    console.print("    [cyan]last[/cyan] 2h                    Filter by recency")
    console.print("    [cyan]context[/cyan] 5m                 Expand ±duration")
    console.print()

    console.print("  [bold yellow]Display[/bold yellow]")
    console.print("    [cyan]show[/cyan]                       Display events")
    console.print("    [cyan]show[/cyan] N                     Event detail")
    console.print("    [cyan]count by[/cyan] field             Aggregate")
    console.print("    [cyan]top[/cyan] field                  Top N values")
    console.print("    [cyan]sort by[/cyan] field              Sort events")
    console.print("    [cyan]head[/cyan] / [cyan]tail[/cyan] [N]            First / last events")
    console.print("    [cyan]timeline[/cyan]                   Time distribution")
    console.print("    [cyan]dedup[/cyan]                      Remove duplicates")
    console.print("    [cyan]sample[/cyan] N                   Random events")
    console.print()

    console.print("  [bold yellow]Analysis[/bold yellow]")
    console.print("    [cyan]dashboard[/cyan]                  Data overview")
    console.print("    [cyan]summary[/cyan] [security|health]  Quick summary")
    console.print("    [cyan]analyze[/cyan]                    Security assessment")
    console.print("    [cyan]anomaly[/cyan]                    Anomaly detection")
    console.print("    [cyan]correlate[/cyan] field            Cross-source trace")
    console.print("    [cyan]mitre[/cyan] scan                 ATT&CK mapping")
    console.print("    [cyan]profile[/cyan] <IP>               IP threat assessment")
    console.print("    [cyan]geo[/cyan] <IP>                   GeoIP lookup")
    console.print("    [cyan]trend[/cyan] field                Value trend over time")
    console.print()

    console.print("  [bold yellow]Investigation[/bold yellow]")
    console.print("    [cyan]star[/cyan] N                     Bookmark event")
    console.print("    [cyan]annotate[/cyan] N \"note\"          Attach note")
    console.print("    [cyan]remember[/cyan] \"note\"            Save investigation note")
    console.print("    [cyan]tag[/cyan] N label                Label events")
    console.print()

    console.print("  [bold yellow]Session[/bold yellow]")
    console.print("    [cyan]undo[/cyan] / [cyan]reset[/cyan]               Step back / clear")
    console.print("    [cyan]set[/cyan] time|source|ip         Configure scope")
    console.print("    [cyan]add[/cyan] <file>                 Add log file")
    console.print("    [cyan]save session[/cyan] <name>        Persist session")
    console.print("    [cyan]switch context[/cyan]             Switch context")
    console.print()

    console.print("  [bold yellow]Export & Reporting[/bold yellow]")
    console.print("    [cyan]export[/cyan] file.html           Export to file")
    console.print("    [cyan]copy[/cyan] table                 Copy to clipboard")
    console.print("    [cyan]report[/cyan] <type>              Generate report")
    console.print("    [cyan]visual[/cyan] <chart>             Visualization")
    console.print()

    console.print("  [bold yellow]Automation[/bold yellow]")
    console.print("    [cyan]macro[/cyan] define <name>        Record command macro")
    console.print("    [cyan]alias[/cyan] name command         Create shorthand")
    console.print("    [cyan]playbook[/cyan] list              Manage playbooks")
    console.print("    [cyan]$name[/cyan] = value              Variables")
    console.print()

    console.print("[dim]Type '<command> ?' for detailed help on any command.[/dim]")
    console.print("[dim]Type 'help' for usage strings · 'cheatsheet' for full reference.[/dim]")
    console.print()
