#!/usr/bin/env python3
"""deduplicate command — collapse duplicate events."""

from __future__ import annotations

import re as _re
from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import LogEvent, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


# Pattern to normalize messages for fuzzy grouping
_NORMALIZE_RE = _re.compile(r"\b(?:0x[0-9a-fA-F]+|\d+\.\d+\.\d+\.\d+|\d+)\b")


@register(
    "deduplicate",
    r"^dedup(?:licate)?(?:\s+.*)?$",
    category="Filter",
    usage="deduplicate [by <field>] [--smart]",
    help=(
        "Collapse duplicate events. By default deduplicates by message. "
        "Use 'by <field>' to dedup by a specific field. "
        "Use --smart for fuzzy grouping (normalizes numbers/IPs before comparing)."
    ),
)
def cmd_deduplicate(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Collapse duplicate events."""
    from logparse.output.table import render_table

    console = ctx.console
    args = (parsed.args or "").strip()
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    smart = "--smart" in args
    args_clean = args.replace("--smart", "").strip()

    # Parse optional field
    field = None
    m = _re.match(r"^(?:by\s+)?(\w+)$", args_clean)
    if m and args_clean:
        field = m.group(1)

    original_count = len(events)

    if smart:
        deduped, pattern_counts = _smart_dedup(events, field)
    else:
        deduped, pattern_counts = _exact_dedup(events, field)

    if len(deduped) != original_count:
        session.push_filter(f"deduplicate{' by ' + field if field else ''}{' --smart' if smart else ''}")
    session.filtered_events = deduped

    console.print(
        f"[bold]{format_number(len(deduped))} unique patterns[/bold] "
        f"from {format_number(original_count)} events "
        f"({format_number(original_count - len(deduped))} duplicates removed)"
    )

    # Show top repeated patterns
    if pattern_counts:
        top_patterns = pattern_counts.most_common(10)
        repeated = [(k, c) for k, c in top_patterns if c > 1]
        if repeated:
            console.print("\n[bold]Most repeated patterns:[/bold]")
            max_key_len = min(max(len(k) for k, _ in repeated), 80)
            for key, count in repeated:
                display_key = key[:max_key_len] + "\u2026" if len(key) > max_key_len else key
                console.print(f"  [dim]{count:>5}x[/dim]  {display_key}")

    render_table(
        deduped[:20], console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=20,
    )
    session.log_command(parsed.raw, f"deduplicate: {len(deduped)} unique from {original_count}")


def _exact_dedup(
    events: list[LogEvent], field: str | None
) -> tuple[list[LogEvent], Counter[str]]:
    """Exact deduplication by field value or message."""
    seen: dict[str, LogEvent] = {}
    counts: Counter[str] = Counter()
    for e in events:
        key = get_field(e, field) if field else e.message
        key = key or ""
        counts[key] += 1
        if key not in seen:
            seen[key] = e
    return list(seen.values()), counts


def _smart_dedup(
    events: list[LogEvent], field: str | None
) -> tuple[list[LogEvent], Counter[str]]:
    """Fuzzy deduplication — normalize numbers/IPs/hex before comparing."""
    seen: dict[str, LogEvent] = {}
    counts: Counter[str] = Counter()
    for e in events:
        raw_key = get_field(e, field) if field else e.message
        raw_key = raw_key or ""
        normalized = _NORMALIZE_RE.sub("<N>", raw_key)
        counts[normalized] += 1
        if normalized not in seen:
            seen[normalized] = e
    return list(seen.values()), counts
