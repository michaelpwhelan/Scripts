#!/usr/bin/env python3
"""derive command — extract new fields via regex capture groups."""

from __future__ import annotations

import re as _re

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "derive",
    r"^derive\s+.+$",
    category="Analysis",
    usage="derive <new_field> from <source_field> regex:<pattern>",
    help=(
        "Extract a new field from an existing one using regex capture groups. "
        "Named groups create fields with those names. Positional group 1 "
        "populates the new_field name. Fields persist for the session."
    ),
)
def cmd_derive(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Extract a new field from an existing one using regex capture groups."""
    console = ctx.console
    args = (parsed.args or "").strip()

    # Parse: <new_field> from <source_field> regex:<pattern>
    m = _re.match(
        r"^(\w+)\s+from\s+(\w+)\s+regex:(.+)$", args, _re.IGNORECASE
    )
    if not m:
        console.print("[red]Usage: derive <new_field> from <source_field> regex:<pattern>[/red]")
        console.print("[dim]Example: derive domain from url regex:https?://([^/]+)[/dim]")
        return

    new_field = m.group(1)
    source_field = m.group(2)
    pattern_str = m.group(3).strip().strip('"').strip("'")

    try:
        pattern = _re.compile(pattern_str)
    except _re.error as exc:
        console.print(f"[red]Invalid regex: {exc}[/red]")
        return

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    matched = 0
    for e in events:
        source_val = get_field(e, source_field)
        if source_val is None:
            continue
        match = pattern.search(source_val)
        if match:
            # Named groups take priority
            named = match.groupdict()
            if named:
                any_set = False
                for name, val in named.items():
                    if val is not None:
                        e.extra[name] = val
                        any_set = True
                if any_set:
                    matched += 1
            elif match.lastindex and match.lastindex >= 1:
                try:
                    e.extra[new_field] = match.group(1)
                    matched += 1
                except IndexError:
                    pass

    # Invalidate field name cache
    session._field_name_cache = None

    console.print(
        f"[bold]Derived '{new_field}'[/bold] from '{source_field}': "
        f"{format_number(matched)} matches in {format_number(len(events))} events"
    )
    if matched > 0:
        # Show sample values
        samples = []
        for e in events:
            val = e.extra.get(new_field)
            if val and val not in samples:
                samples.append(val)
            if len(samples) >= 5:
                break
        if samples:
            console.print(f"  [dim]Sample values: {', '.join(samples)}[/dim]")

    session.log_command(parsed.raw, f"derive {new_field}: {matched} matches")
