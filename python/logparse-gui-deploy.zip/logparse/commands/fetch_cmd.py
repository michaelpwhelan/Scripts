#!/usr/bin/env python3
"""fetch command — retrieve logs from remote connectors."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "fetch",
    r"^fetch(?:\s+.+)?$",
    category="Data",
    usage="fetch <connector> [endpoint] | fetch list",
    help=(
        "Fetch logs from a remote source.  "
        "'fetch list' shows available connectors and endpoints.  "
        "'fetch graph alerts' fetches Defender alerts.  "
        "Options: --time 24h, --max 10000, --output-dir ."
    ),
)
def cmd_fetch(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Fetch logs from a remote source."""
    from pathlib import Path

    from logparse.config_loader import load_config
    from logparse.connectors import get_connector, list_connectors

    console = ctx.console
    args_str = (parsed.args or "").strip()

    if not args_str or args_str == "list":
        console.print("[bold]Available Connectors:[/bold]")
        for name, endpoints in list_connectors():
            console.print(f"  [cyan]{name}[/cyan]: {endpoints}")
        console.print("\n[dim]Usage: fetch <connector> [endpoint] [--time 24h][/dim]")
        return

    parts = args_str.split()
    connector_name = parts[0]

    # Parse optional flags
    endpoint = None
    time_range = "24h"
    max_records = 10_000
    output_dir = Path(".")
    i = 1
    while i < len(parts):
        if parts[i] == "--time" and i + 1 < len(parts):
            time_range = parts[i + 1]
            i += 2
        elif parts[i] == "--max" and i + 1 < len(parts):
            try:
                max_records = int(parts[i + 1])
            except ValueError:
                pass
            i += 2
        elif parts[i] == "--output-dir" and i + 1 < len(parts):
            output_dir = Path(parts[i + 1])
            i += 2
        elif parts[i].startswith("-"):
            i += 1
        else:
            endpoint = parts[i]
            i += 1

    try:
        connector = get_connector(connector_name)
    except ValueError as exc:
        console.print(f"[red]{exc}[/red]")
        return

    config = load_config()
    connector_config = config.get("connectors", {}).get(connector_name, {})

    try:
        connector.configure(connector_config)
    except ValueError as exc:
        console.print(f"[red]Config error: {exc}[/red]")
        return

    try:
        connector.authenticate()
        console.print(f"[green]Authenticated to {connector_name}[/green]")
    except (ConnectionError, OSError, TimeoutError, ValueError) as exc:
        console.print(f"[red]Auth failed: {exc}[/red]")
        return

    if endpoint:
        try:
            result = connector.fetch(
                endpoint,
                time_range=time_range,
                output_dir=output_dir,
                max_records=max_records,
            )
            console.print(
                f"  {result.endpoint}: [green]{result.event_count}[/green] "
                f"records → {result.output_path}"
            )
            if result.errors:
                for err in result.errors:
                    console.print(f"  [red]{err}[/red]")
        except ValueError as exc:
            console.print(f"[red]{exc}[/red]")
    else:
        results = connector.fetch_all(
            time_range=time_range,
            output_dir=output_dir,
            max_records=max_records,
        )
        for result in results:
            status = "[green]OK[/green]" if not result.errors else "[red]ERR[/red]"
            console.print(
                f"  {result.endpoint}: {status} "
                f"{result.event_count} records → {result.output_path}"
            )

    session.log_command(ctx.raw_input, f"fetch {connector_name}")
