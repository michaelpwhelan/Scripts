#!/usr/bin/env python3
"""Shell escape command."""

from __future__ import annotations

import os
import subprocess

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "!",
    r"^!.*",
    category="Meta",
    usage="!<command>",
    help="Shell escape. '!' alone opens a shell.",
)
def cmd_shell(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Shell escape."""
    raw = parsed.raw.strip()
    cmd = raw[1:].strip() if len(raw) > 1 else ""

    if not cmd:
        if os.name == "nt":
            shell = os.environ.get("COMSPEC", "cmd.exe")
        else:
            shell = os.environ.get("SHELL", "/bin/sh")
        os.system(shell)
    else:
        try:
            _result = subprocess.run(
                cmd, shell=True, capture_output=False,
                text=True, timeout=30,
            )
        except subprocess.TimeoutExpired:
            ctx.console.print("[red]Command timed out.[/red]")
        except OSError as exc:
            ctx.console.print(f"[red]Error: {exc}[/red]")

    session.log_command(parsed.raw, f"shell: {cmd[:50]}" if cmd else "shell (interactive)")
