#!/usr/bin/env python3
"""cheatsheet command — compact reference card."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "cheatsheet",
    r"^cheatsheet$",
    category="Meta",
    usage="cheatsheet",
    help="Show a compact one-screen reference card.",
)
def cmd_cheatsheet(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show a compact one-screen reference card."""
    console = ctx.console
    console.print("[bold]logparse Quick Reference[/bold]\n")

    sections = [
        ("FILTER", [
            "where field:value          Filter events (stackable)",
            "where !field:value         Negate filter",
            "where field in a,b,c       Match multiple values",
            "where srcip internal       RFC 1918 addresses only",
            "undo / reset               Step back / clear all filters",
        ]),
        ("DISPLAY", [
            "show                       Display filtered events",
            "show N                     Full detail of event #N",
            "show N, N, N               Detail view of multiple events",
            "show sources / fields      List sources or field names",
            "show star                  Show starred events",
            "show annotate              Show annotated events",
            "show -a <value>            Cross-field search",
        ]),
        ("AGGREGATE", [
            "count by <field>           Group and count",
            "sort <field> [asc|desc]    Sort events",
            "| count by / sort / head   Pipeline operators",
        ]),
        ("SESSION", [
            "star N / unstar N          Bookmark events",
            "annotate N \"note\"          Attach note to event",
            "remember \"text\"            Save investigation note",
            "save filter / restore N    Named filter snapshots",
        ]),
        ("VARIABLES", [
            "$name = value              Assign variable",
            "$name = N.field            Capture from result row",
            "$name += 5m                Time arithmetic",
            "$name properties           Inspect variable value",
            "vars                       List all variables",
        ]),
        ("EXPORT", [
            "export file.html           Export to HTML/CSV/JSON",
            "export star file.csv       Export starred events",
            "export profile file.zip    Full session profile",
            "copy table / copy field    Copy to clipboard",
        ]),
        ("META", [
            "help [command]             Show help",
            "cheatsheet                 This reference card",
            "tutorial                   Interactive walkthrough",
            "dashboard                  Overview of current data",
            "summary [security|health]  Quick summary",
        ]),
    ]

    for title, lines in sections:
        console.print(f"  [bold cyan]{title}[/bold cyan]")
        for line in lines:
            console.print(f"    [dim]{line}[/dim]")
        console.print()

    session.log_command(parsed.raw, "cheatsheet")
