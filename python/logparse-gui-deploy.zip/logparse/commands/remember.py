#!/usr/bin/env python3
"""remember command — investigation notes."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "remember",
    r"^remember(\s+.*)?$",
    category="Notes",
    usage='remember ["text"] | remember | remember | delete N',
    help="Add, list, or delete investigation notes.",
)
def cmd_remember(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Add, list, or delete investigation notes."""
    console = ctx.console
    args = parsed.args.strip() if parsed.args else ""

    # remember | delete N
    if parsed.pipe_ops:
        for op in parsed.pipe_ops:
            op = op.strip()
            m = re.match(r"^delete\s+(\d+)$", op, re.I)
            if m:
                nid = int(m.group(1))
                if session.delete_note(nid):
                    console.print(f"Deleted note #{nid}.")
                    session.log_command(parsed.raw, f"deleted note #{nid}")
                else:
                    console.print(f"[red]Note #{nid} not found.[/red]")
                return
        console.print("[red]Usage: remember | delete N[/red]")
        return

    # remember "text" — add note
    if args:
        text = args.strip('"').strip("'")
        nid = session.add_note(text)
        console.print(f"Note #{nid} saved.")
        session.log_command(parsed.raw, f"note #{nid}")
        return

    # bare remember — list notes
    if not session.notes:
        console.print("[dim]No notes.[/dim]")
    else:
        for i, note in enumerate(session.notes, 1):
            console.print(
                f"  [bold]#{i}[/bold]  [dim]{note.timestamp:%H:%M}[/dim]  {note.text}"
            )
    session.log_command(parsed.raw, f"{len(session.notes)} notes")
