#!/usr/bin/env python3
"""ports command — protocol/port analysis."""

from __future__ import annotations

import re as _re
from collections import Counter

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


# Well-known port to service mapping
_SERVICES: dict[str, str] = {
    "21": "FTP", "22": "SSH", "23": "Telnet", "25": "SMTP",
    "53": "DNS", "67": "DHCP", "68": "DHCP", "69": "TFTP",
    "80": "HTTP", "110": "POP3", "119": "NNTP", "123": "NTP",
    "135": "RPC", "137": "NetBIOS", "138": "NetBIOS", "139": "NetBIOS",
    "143": "IMAP", "161": "SNMP", "162": "SNMP-trap", "179": "BGP",
    "389": "LDAP", "443": "HTTPS", "445": "SMB", "465": "SMTPS",
    "500": "IKE", "514": "Syslog", "515": "LPD", "520": "RIP",
    "587": "SMTP-sub", "636": "LDAPS", "993": "IMAPS", "995": "POP3S",
    "1433": "MSSQL", "1434": "MSSQL-mon", "1521": "Oracle",
    "1723": "PPTP", "3306": "MySQL", "3389": "RDP",
    "4500": "NAT-T", "5060": "SIP", "5061": "SIPS",
    "5432": "PostgreSQL", "5900": "VNC", "5985": "WinRM",
    "5986": "WinRM-S", "6379": "Redis", "8080": "HTTP-alt",
    "8443": "HTTPS-alt", "8888": "HTTP-alt2", "9200": "Elasticsearch",
    "27017": "MongoDB",
}


@register(
    "ports",
    r"^ports?(?:\s+.*)?$",
    category="Analysis",
    usage="ports [summary|<port>]",
    help=(
        "Port/protocol analysis. 'ports summary' shows top ports with "
        "service names and deny rates. 'ports <port>' shows details for "
        "a specific port."
    ),
)
def cmd_ports(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Port/protocol analysis."""
    from rich.table import Table

    console = ctx.console
    args = (parsed.args or "").strip().lower()
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # Check if a specific port was requested
    port_m = _re.match(r"^(\d+)$", args)
    if port_m:
        _port_detail(port_m.group(1), events, console)
        session.log_command(parsed.raw, f"ports {args}")
        return

    # Summary mode (default)
    port_total: Counter[str] = Counter()
    port_deny: Counter[str] = Counter()
    proto_count: Counter[str] = Counter()

    for e in events:
        port = get_field(e, "dstport") or get_field(e, "port") or ""
        if not port:
            continue
        port_total[port] += 1
        action = (get_field(e, "action") or "").lower()
        if action in ("deny", "denied", "blocked", "drop"):
            port_deny[port] += 1
        proto = get_field(e, "proto") or ""
        if proto:
            proto_count[proto] += 1

    if not port_total:
        console.print("[dim]No port data found in events.[/dim]")
        return

    console.rule("Port Analysis", style="bold cyan")

    # Top ports table
    table = Table(title="Top Destination Ports", border_style="dim")
    table.add_column("Port", style="bold", justify="right")
    table.add_column("Service")
    table.add_column("Events", justify="right", style="cyan")
    table.add_column("Denied", justify="right")
    table.add_column("Deny %", justify="right")

    for port, count in port_total.most_common(20):
        service = _SERVICES.get(port, "")
        denied = port_deny[port]
        deny_pct = denied / max(count, 1) * 100
        deny_color = "red" if deny_pct > 50 else "yellow" if deny_pct > 20 else "dim"
        table.add_row(
            port, service,
            format_number(count),
            format_number(denied),
            f"[{deny_color}]{deny_pct:.0f}%[/{deny_color}]",
        )

    console.print(table)

    # Protocol breakdown
    if proto_count:
        console.print("\n[bold]Protocols:[/bold]")
        for proto, count in proto_count.most_common(10):
            console.print(f"  {proto:>6}  {format_number(count)}")

    console.print(f"\n  [dim]{format_number(len(port_total))} unique ports, "
                  f"{format_number(sum(port_total.values()))} total events[/dim]")
    session.log_command(parsed.raw, f"ports: {len(port_total)} unique ports")


def _port_detail(port: str, events: list, console: Console) -> None:
    """Show detailed breakdown for a specific port."""
    from rich.table import Table

    port_events = [
        e for e in events
        if (get_field(e, "dstport") or get_field(e, "port") or "") == port
    ]

    if not port_events:
        console.print(f"[dim]No events for port {port}.[/dim]")
        return

    service = _SERVICES.get(port, "Unknown")
    console.rule(f"Port {port} ({service})", style="bold cyan")
    console.print(f"  Events: {format_number(len(port_events))}")

    # Source IPs
    src_ips: Counter[str] = Counter()
    actions: Counter[str] = Counter()
    for e in port_events:
        srcip = get_field(e, "srcip") or get_field(e, "src") or "(unknown)"
        src_ips[srcip] += 1
        action = get_field(e, "action") or "(none)"
        actions[action] += 1

    if src_ips:
        table = Table(title="Source IPs", border_style="dim")
        table.add_column("Source IP", style="bold")
        table.add_column("Events", justify="right", style="cyan")
        for ip, count in src_ips.most_common(10):
            table.add_row(ip, format_number(count))
        console.print(table)

    if actions:
        console.print("\n[bold]Actions:[/bold]")
        for action, count in actions.most_common():
            console.print(f"  {action:>12}  {format_number(count)}")
