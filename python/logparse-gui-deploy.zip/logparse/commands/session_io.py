#!/usr/bin/env python3
"""Session save and restore commands."""

from __future__ import annotations

import json
from pathlib import Path

from logparse.commands import register, CommandContext
from logparse.config_loader import get_config_dir
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


_SESSIONS_DIR = get_config_dir() / "sessions"


def _ensure_dir() -> None:
    _SESSIONS_DIR.mkdir(parents=True, exist_ok=True)


def _serialize_session(session: Session) -> dict:
    """Serialize session state to a JSON-safe dict."""
    return {
        "source_files": list(session.source_files),
        "filter_history": [snap.description for snap in session.filter_history],
        "active_filter": session.active_filter,
        "hide_rules": [
            {"field": r.field, "values": r.values, "mode": r.mode}
            for r in session.hide_rules
        ],
        "display_columns": list(session.display_columns),
        "annotations": {str(k): v for k, v in session.annotations.items()},
        "starred": sorted(session.starred),
        "notes": [
            {"text": n.text, "timestamp": n.timestamp.isoformat()}
            for n in session.notes
        ],
        "variables": {
            k: v if isinstance(v, (str, list)) else str(v)
            for k, v in session.variables.items()
            if not k.startswith("_")
        },
        "transcript": [
            {
                "timestamp": e.timestamp.isoformat(),
                "command": e.command,
                "summary": e.summary,
                "event_count": e.event_count,
            }
            for e in session.transcript
        ],
        "sort_field": session.sort_field,
        "sort_descending": session.sort_descending,
        "highlight": session.highlight,
    }


@register(
    "save session",
    r"^save\s+session\s+.+",
    category="Session",
    usage="save session <name> | save session list",
    help="Save current session state for later resumption.",
)
def cmd_save_session(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Save current session state for later resumption."""
    import re
    console = ctx.console
    args = parsed.args.strip()

    # strip "session" prefix from args
    m = re.match(r"^session\s+(.+)$", args, re.I)
    if not m:
        console.print("[red]Usage: save session <name>[/red]")
        return
    name = m.group(1).strip()

    # list subcommand
    if name.lower() == "list":
        _ensure_dir()
        files = sorted(_SESSIONS_DIR.glob("*.json"))
        if not files:
            console.print("[dim]No saved sessions.[/dim]")
            return
        console.print("[bold]Saved sessions:[/bold]")
        for f in files:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                n_files = len(data.get("source_files", []))
                n_filters = len(data.get("filter_history", []))
                console.print(f"  {f.stem}  ({n_files} files, {n_filters} filters)")
            except (json.JSONDecodeError, OSError):
                console.print(f"  {f.stem}  (unreadable)")
        session.log_command(parsed.raw, f"{len(files)} sessions")
        return

    # save
    if not session.source_files:
        console.print("[red]No source files loaded — nothing to save.[/red]")
        return

    _ensure_dir()
    safe_name = "".join(c for c in name if c.isalnum() or c in "._- ")
    if not safe_name or safe_name != name:
        console.print("[red]Session name must contain only alphanumeric characters, dots, hyphens, underscores, and spaces.[/red]")
        return
    data = _serialize_session(session)
    filepath = _SESSIONS_DIR / f"{safe_name}.json"
    filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")
    console.print(f"Session saved to [bold]{filepath}[/bold]")
    session.log_command(parsed.raw, f"saved session '{name}'")


@register(
    "resume",
    r"^resume\s+.+",
    category="Session",
    usage="resume <name>",
    help="Resume a previously saved session (reloads source files and replays filters).",
)
def cmd_resume(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Resume a previously saved session (reloads source files and replays filters)."""
    from datetime import datetime

    console = ctx.console
    name = parsed.args.strip()

    # Validate session name (same rules as save)
    safe_name = "".join(c for c in name if c.isalnum() or c in "._- ")
    if not safe_name or safe_name != name:
        console.print("[red]Session name must contain only alphanumeric characters, dots, hyphens, underscores, and spaces.[/red]")
        return
    filepath = _SESSIONS_DIR / f"{name}.json"
    if not filepath.exists():
        console.print(f"[red]Session not found: {name}[/red]")
        # suggest available
        files = sorted(_SESSIONS_DIR.glob("*.json"))
        if files:
            names = ", ".join(f.stem for f in files)
            console.print(f"[dim]Available: {names}[/dim]")
        return

    try:
        data = json.loads(filepath.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        console.print(f"[red]Failed to load session: {exc}[/red]")
        return

    # Verify source files exist
    source_files = data.get("source_files", [])
    missing = [f for f in source_files if not Path(f).exists()]
    if missing:
        console.print("[red]Missing source files:[/red]")
        for f in missing:
            console.print(f"  {f}")
        console.print("[dim]Cannot resume — source files must be accessible.[/dim]")
        return

    # Reload events from source files
    from logparse.parsers import parse_file
    all_events = []
    for src in source_files:
        path = Path(src)
        try:
            events = parse_file(path, source_file=path.name)
            all_events.extend(events)
        except (OSError, ValueError) as exc:
            console.print(f"[yellow]Warning: failed to reload {src}: {exc}[/yellow]")

    if not all_events:
        console.print("[red]No events loaded from source files.[/red]")
        return

    # Sort by timestamp
    all_events.sort(key=lambda e: (e.timestamp or datetime.max))

    # Replace session state
    session.all_events = all_events
    session.filtered_events = list(all_events)
    session.invalidate_caches()
    session.source_files = source_files
    session.active_filter = ""
    session.filter_history.clear()

    # Replay filter history
    from logparse.filter_engine import parse_conditions, match_event
    filter_descriptions = data.get("filter_history", [])
    for desc in filter_descriptions:
        if not desc:
            continue
        extra = {f.lower() for f in session.all_field_names()}
        conditions = parse_conditions(desc, extra_fields=extra)
        if conditions:
            session.push_filter(desc)
            session.filtered_events = [
                e for e in session.filtered_events
                if match_event(e, conditions)
            ]

    # Restore active filter
    active = data.get("active_filter", "")
    if active and active not in filter_descriptions:
        extra = {f.lower() for f in session.all_field_names()}
        conditions = parse_conditions(active, extra_fields=extra)
        if conditions:
            session.push_filter(active)
            session.filtered_events = [
                e for e in session.filtered_events
                if match_event(e, conditions)
            ]

    # Restore display state
    session.display_columns = data.get("display_columns",
        ["Timestamp", "Severity", "Source", "Message"])
    session.sort_field = data.get("sort_field", "")
    session.sort_descending = data.get("sort_descending", True)
    session.highlight = data.get("highlight", "")

    # Restore annotations
    session.annotations = {}
    for k, v in data.get("annotations", {}).items():
        try:
            session.annotations[int(k)] = v
        except (ValueError, TypeError):
            pass

    # Restore starred
    session.starred = set(data.get("starred", []))

    # Restore notes
    from logparse.session import Note
    notes = []
    for n in data.get("notes", []):
        try:
            notes.append(Note(
                text=n.get("text", ""),
                timestamp=datetime.fromisoformat(n["timestamp"]),
            ))
        except (KeyError, ValueError):
            continue
    session.notes = notes

    # Restore variables (skip internal ones)
    session.variables = {
        k: v for k, v in data.get("variables", {}).items()
    }

    # Restore hide rules
    from logparse.session import HideRule
    hide_rules = []
    for r in data.get("hide_rules", []):
        try:
            hide_rules.append(HideRule(field=r["field"], values=r["values"], mode=r.get("mode", "")))
        except KeyError:
            continue
    session.hide_rules = hide_rules
    if session.hide_rules:
        session.apply_hide_rules()

    n_events = len(session.filtered_events)
    n_filters = len(session.filter_history)
    console.print(
        f"Resumed session [bold]{name}[/bold] — "
        f"{format_number(n_events)} events, {n_filters} filters"
    )
    session.log_command(parsed.raw, f"resumed '{name}' ({n_events} events)")
