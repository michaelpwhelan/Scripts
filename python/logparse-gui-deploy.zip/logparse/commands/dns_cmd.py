#!/usr/bin/env python3
"""dns command — DNS event analysis."""

from __future__ import annotations

import math
from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import LogEvent, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "dns",
    r"^dns(\s+.*)?$",
    category="Analysis",
    usage="dns [summary]",
    help=(
        "Analyze DNS events: top queried domains, NXDOMAIN rates, "
        "query type breakdown, and suspicious pattern detection "
        "(tunneling, high entropy)."
    ),
)
def cmd_dns(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Analyze DNS events: top queried domains, NXDOMAIN rates, query type breakdown, and suspicious pattern detection (tunneling, high entropy)."""
    from rich.table import Table

    console = ctx.console
    events = session.filtered_events

    # Filter DNS events
    dns_events = [e for e in events if _is_dns_event(e)]

    if not dns_events:
        console.print("[dim]No DNS events found.[/dim]")
        console.print("[dim]Look for events with subtype=dns, qname fields, or DNS-related messages.[/dim]")
        return

    console.rule("DNS Analysis", style="bold cyan")
    console.print(f"  DNS events: {format_number(len(dns_events))} of {format_number(len(events))} total\n")

    # Extract domains
    domains: Counter[str] = Counter()
    qtypes: Counter[str] = Counter()
    nxdomain_count = 0
    querier_ips: set[str] = set()
    suspicious: list[tuple[str, str]] = []

    for e in dns_events:
        domain = _get_domain(e)
        if domain:
            domains[domain] += 1
            # Check for suspicious patterns
            entropy = _shannon_entropy(domain.split(".")[0])
            if entropy > 3.5 and len(domain.split(".")[0]) > 30:
                suspicious.append((domain, f"High entropy ({entropy:.1f}), long label"))
            elif len(domain) > 100:
                suspicious.append((domain[:80] + "...", "Unusually long domain"))

        qtype = get_field(e, "qtype") or ""
        if qtype:
            qtypes[qtype] += 1

        # NXDOMAIN detection
        rcode = get_field(e, "rcode") or ""
        msg_lower = e.message.lower()
        if rcode == "3" or "nxdomain" in msg_lower or "no such" in msg_lower:
            nxdomain_count += 1

        # Querier IPs
        srcip = get_field(e, "srcip") or get_field(e, "clientip") or ""
        if srcip:
            querier_ips.add(srcip)

    # Top domains
    if domains:
        table = Table(title="Top Queried Domains", border_style="dim")
        table.add_column("Domain", style="bold")
        table.add_column("Queries", justify="right", style="cyan")
        table.add_column("%", justify="right")
        total_queries = sum(domains.values())
        for domain, count in domains.most_common(15):
            pct = count / total_queries * 100
            table.add_row(domain, format_number(count), f"{pct:.1f}%")
        console.print(table)

    # Query types
    if qtypes:
        console.print("\n[bold]Query Types:[/bold]")
        for qtype, count in qtypes.most_common(10):
            console.print(f"  {qtype:>6}  {format_number(count)}")

    # NXDOMAIN
    total_dns = len(dns_events)
    nxdomain_pct = nxdomain_count / max(total_dns, 1) * 100
    nxcolor = "red" if nxdomain_pct > 30 else "yellow" if nxdomain_pct > 10 else "green"
    console.print(f"\n  NXDOMAIN: [{nxcolor}]{format_number(nxdomain_count)} ({nxdomain_pct:.1f}%)[/{nxcolor}]")
    console.print(f"  Unique querier IPs: {format_number(len(querier_ips))}")
    console.print(f"  Unique domains: {format_number(len(domains))}")

    # Suspicious patterns
    if suspicious:
        console.print(f"\n[bold yellow]Suspicious Patterns ({len(suspicious)}):[/bold yellow]")
        for domain, reason in suspicious[:10]:
            console.print(f"  [yellow]![/yellow] {domain}  ({reason})")

    session.log_command(parsed.raw, f"dns: {len(dns_events)} events, {len(domains)} domains")


def _is_dns_event(event: LogEvent) -> bool:
    """Check if event is DNS-related."""
    subtype = (event.extra.get("subtype", "") or "").lower()
    if subtype == "dns":
        return True
    qname = event.extra.get("qname", "")
    if qname:
        return True
    msg = event.message.lower()
    return "dns" in msg and ("query" in msg or "response" in msg)


def _get_domain(event: LogEvent) -> str:
    """Extract domain name from DNS event."""
    return (
        get_field(event, "qname")
        or get_field(event, "domain")
        or get_field(event, "hostname")
        or ""
    )


def _shannon_entropy(text: str) -> float:
    """Calculate Shannon entropy of a string."""
    if not text:
        return 0.0
    counter = Counter(text.lower())
    length = len(text)
    return -sum(
        (count / length) * math.log2(count / length)
        for count in counter.values()
        if count > 0
    )
