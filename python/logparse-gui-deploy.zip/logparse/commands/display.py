#!/usr/bin/env python3
"""Display commands: head, tail, sort by, count by, dedup, timeline."""

from __future__ import annotations

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.pipeline import (
    apply_pipeline, AggResult, StatsResult,
    _op_head, _op_tail, _op_sort, _op_count, _op_count_by,
    _op_dedup, _op_timeline,
)
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


def _render_result(result: list, session: Session, console: Console, parsed: ParsedCommand) -> None:
    """Render pipeline result (events or aggregation)."""
    if result and isinstance(result[0], StatsResult):
        from logparse.output.table import render_stats
        render_stats(result[0], console)
        return
    if result and isinstance(result[0], AggResult):
        from logparse.output.table import render_agg
        render_agg(result, console)
    else:
        from logparse.output.table import render_table
        render_table(
            result, console,
            fields=session.display_columns,
            highlight=session.highlight,
            max_results=50,
        )


def _parse_head_tail_args(args: str) -> tuple[int, str | None]:
    """Parse 'N', 'N where ...', 'where ...', or '' from head/tail args."""
    import re
    _MAX_N = 5_000
    args = args.strip()
    if not args:
        return 10, None
    m = re.match(r"^(\d+)\s+where\s+(.+)$", args, re.I)
    if m:
        return min(int(m.group(1)), _MAX_N), m.group(2).strip()
    m = re.match(r"^where\s+(.+)$", args, re.I)
    if m:
        return 10, m.group(1).strip()
    m = re.match(r"^(\d+)$", args)
    if m:
        return min(int(m.group(1)), _MAX_N), None
    # N <filter-like> — implicit where when args contain field:value patterns
    m = re.match(r"^(\d+)\s+(.+)$", args)
    if m and ":" in m.group(2):
        return min(int(m.group(1)), _MAX_N), m.group(2).strip()
    # treat the whole thing as a where clause
    return 10, args


def _apply_inline_filter(events, where_clause, extra_fields=None) -> list:
    """Apply a where clause without pushing to session filter stack."""
    from logparse.filter_engine import parse_conditions, match_event
    conditions = parse_conditions(where_clause, extra_fields=extra_fields)
    if conditions:
        return [e for e in events if match_event(e, conditions)]
    return events


@register(
    "head",
    r"^head(\s+.*)?$",
    category="Display",
    usage="head [N] [where <filter>]",
    help="Show first N events (default 10). Optional inline filter.",
)
def cmd_head(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show first N events (default 10)."""
    n, where = _parse_head_tail_args(parsed.args)
    events = session.filtered_events
    if where:
        extra = {f.lower() for f in session.all_field_names()}
        events = _apply_inline_filter(events, where, extra_fields=extra)
    events = _op_head(events, n)
    from logparse.output.table import render_table
    render_table(
        events, ctx.console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=n,
        annotations=session.annotations if session.annotations else None,
    )
    session.log_command(parsed.raw, f"first {n}")


@register(
    "tail",
    r"^tail(\s+.*)?$",
    category="Display",
    usage="tail [N] [where <filter>]",
    help="Show last N events (default 10). Optional inline filter.",
)
def cmd_tail(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show last N events (default 10)."""
    n, where = _parse_head_tail_args(parsed.args)
    events = session.filtered_events
    if where:
        extra = {f.lower() for f in session.all_field_names()}
        events = _apply_inline_filter(events, where, extra_fields=extra)
    events = _op_tail(events, n)
    from logparse.output.table import render_table
    render_table(
        events, ctx.console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=n,
    )
    session.log_command(parsed.raw, f"last {n}")


@register(
    "sort",
    r"^sort(\s+.*)?$",
    category="Display",
    usage="sort [by] <field> [asc|desc] | sort flip",
    help="Sort events by field (default: severity), or toggle sort direction.",
)
def cmd_sort(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Sort events by field (default: severity), or toggle sort direction."""
    import re
    console = ctx.console
    args = (parsed.args or "").strip()

    # bare "sort" — default to severity
    if not args:
        args = "severity"

    # sort flip — toggle direction
    if args.lower() == "flip":
        if not session.sort_field:
            console.print("[dim]No active sort to flip.[/dim]")
            return
        session.sort_descending = not session.sort_descending
        direction = "desc" if session.sort_descending else "asc"
        result = _op_sort(session.filtered_events, session.sort_field, direction)
        _render_result(result, session, console, parsed)
        session.log_command(parsed.raw, f"sort flip ({direction}ending)")
        return

    m = re.match(r"(?:by\s+)?(\w+)\s*(asc|desc|flip)?$", args, re.I)
    if not m:
        console.print("[red]Usage: sort [by] <field> [asc|desc|flip] | sort flip[/red]")
        return
    field = m.group(1)
    dir_input = m.group(2)  # None, "asc", "desc", or "flip"
    if dir_input and dir_input.lower() == "flip":
        session.sort_descending = not session.sort_descending if session.sort_field == field else True
        dir_input = "desc" if session.sort_descending else "asc"
    elif dir_input:
        session.sort_descending = dir_input.lower() == "desc"
    # else: no direction specified — leave session.sort_descending as-is
    session.sort_field = field
    result = _op_sort(session.filtered_events, field, dir_input)
    if parsed.pipe_ops:
        from logparse.pipeline import extract_visual
        ops, visual_type = extract_visual(parsed.pipe_ops)
        pipe_warnings = []
        result = apply_pipeline(result, ops, warnings=pipe_warnings,
                               all_events=session.all_events)
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            session.last_output = list(result)
            render_agg_visual(result, visual_type, console)
            session.log_command(parsed.raw, f"sorted by {field}")
            return
    _render_result(result, session, console, parsed)
    session.log_command(parsed.raw, f"sorted by {field}")


@register(
    "count",
    r"^count(\s+(?:by\s+)?\w+)?$",
    category="Display",
    usage="count [by] <field>",
    help="Count events, optionally grouped by field.",
)
def cmd_count(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Count events, optionally grouped by field."""
    import re
    console = ctx.console
    args = parsed.args.strip()
    m = re.match(r"(?:by\s+)?(\w+)$", args, re.I)
    if m:
        from logparse.pipeline import extract_visual
        result = _op_count_by(session.filtered_events, m.group(1))
        if parsed.pipe_ops:
            ops, visual_type = extract_visual(parsed.pipe_ops)
            pipe_warnings = []
            result = apply_pipeline(result, ops, warnings=pipe_warnings)
            for w in pipe_warnings:
                console.print(f"[yellow]{w}[/yellow]")
        else:
            visual_type = None
        session.last_output = list(result)
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            render_agg_visual(result, visual_type, console)
        else:
            _render_result(result, session, console, parsed)
        session.log_command(parsed.raw, f"count by {m.group(1)}")
    else:
        result = _op_count(session.filtered_events)
        console.print(f"[bold]{format_number(result[0].count)} events[/bold]")
        session.log_command(parsed.raw, f"{result[0].count} events")


@register(
    "dedup",
    r"^dedup(\s+.+)?$",
    category="Display",
    usage="dedup [field | field:<name>]",
    help="Remove duplicate events. Optionally key by specific field.",
)
def cmd_dedup(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Remove duplicate events."""
    import re
    args = parsed.args.strip() if parsed.args else ""
    # support both "dedup dstip" and "dedup field:dstip"
    field = None
    if args:
        m = re.match(r"^field[:=](\w+)$", args, re.I)
        if m:
            field = m.group(1)
        else:
            field = args.strip()

    before = len(session.filtered_events)
    deduped = _op_dedup(session.filtered_events, field)
    after = len(deduped)
    if after != before:
        session.push_filter(f"dedup {field}" if field else "dedup")
    session.filtered_events = deduped
    ctx.console.print(
        f"[bold]{format_number(after)} unique[/bold] "
        f"(removed {format_number(before - after)} duplicates)"
    )
    session.log_command(parsed.raw, f"{after} unique")


_VALID_BUCKETS = {"1m", "5m", "10m", "15m", "30m", "1h", "hour", "1d", "day"}


@register(
    "timeline",
    r"^timeline(\s+\w+)?$",
    category="Display",
    usage="timeline [bucket]",
    help="Show event timeline (buckets: 1m, 5m, 10m, 15m, 30m, 1h/hour, 1d/day).",
)
def cmd_timeline(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show event timeline (buckets: 1m, 5m, 10m, 15m, 30m, 1h/hour, 1d/day)."""
    console = ctx.console
    interval = parsed.args.strip() if parsed.args.strip() else None

    if not interval:
        # summary mode — show stats, then auto-bucket for last_output
        ts_events = [e for e in session.filtered_events if e.timestamp]
        if not ts_events:
            console.print("[dim]No timestamps.[/dim]")
            return
        first = ts_events[0].timestamp
        last = ts_events[-1].timestamp
        span = last - first
        console.print(f"  First  : {first:%Y-%m-%d %H:%M:%S}")
        console.print(f"  Last   : {last:%Y-%m-%d %H:%M:%S}")
        console.print(f"  Span   : {span}")
        console.print(f"  Events : {format_number(len(ts_events))}")
        density = len(ts_events) / max(span.total_seconds() / 60, 1)
        console.print(f"  Density: {density:.1f} events/min")
        # Auto-bucket so `visual bar` works after bare `timeline`
        secs = span.total_seconds()
        if secs <= 7200:         # ≤ 2 hours → 5m buckets
            auto_bucket = "5m"
        elif secs <= 86400:      # ≤ 1 day → 1h buckets
            auto_bucket = "1h"
        else:                    # > 1 day → 1d buckets
            auto_bucket = "1d"
        session.last_output = list(_op_timeline(session.filtered_events, auto_bucket))
        console.print(f"[dim]  (use 'visual bar' to chart, or 'timeline {auto_bucket}' for detail)[/dim]")
        session.log_command(parsed.raw, "timeline summary")
        return

    if interval.lower() not in _VALID_BUCKETS:
        console.print(f"[red]Invalid bucket size: {interval}[/red]")
        console.print(
            "[dim]Valid buckets: 1m, 5m, 10m, 15m, 30m, 1h/hour, 1d/day[/dim]"
        )
        return

    result = _op_timeline(session.filtered_events, interval)

    # Support pipe ops (including visual)
    if parsed.pipe_ops:
        from logparse.pipeline import extract_visual
        ops, visual_type = extract_visual(parsed.pipe_ops)
        pipe_warnings = []
        result = apply_pipeline(result, ops, warnings=pipe_warnings)
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")
        session.last_output = list(result)
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            render_agg_visual(result, visual_type, console)
            session.log_command(parsed.raw, f"timeline {interval}")
            return

    session.last_output = list(result)
    from logparse.output.table import render_agg
    render_agg(result, console)
    session.log_command(parsed.raw, f"timeline {interval}")


@register(
    "find",
    r"^find\s+(?:in\s+)?.+",
    category="Display",
    usage="find [in] <pattern>",
    help="Highlight pattern in current view without filtering.",
)
def cmd_find_in(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Highlight pattern in current view without filtering."""
    import re as _re
    console = ctx.console
    m = _re.match(r"^(?:in\s+)?(.+)$", parsed.args.strip(), _re.I)
    if not m:
        console.print("[red]Usage: find [in] <pattern>[/red]")
        return
    pattern = m.group(1).strip().strip('"').strip("'")
    session.highlight = pattern
    from logparse.output.table import render_table
    render_table(
        session.filtered_events, console,
        fields=session.display_columns,
        highlight=pattern,
        max_results=50,
    )
    session.log_command(parsed.raw, f"highlight '{pattern}'")


@register(
    "stats",
    r"^stats\s+\w+$",
    category="Display",
    usage="stats <field>",
    help=(
        "Compute statistics for a field. Numeric fields: min, max, mean, "
        "median, P95, P99, stddev. Categorical: top-N value counts."
    ),
)
def cmd_stats(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Compute statistics for a field."""
    import statistics as _stats_mod
    from collections import Counter
    from rich.panel import Panel
    from rich.table import Table

    console = ctx.console
    field = parsed.args.strip()
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # Collect values and try numeric conversion
    raw_values: list[str] = []
    numeric_values: list[float] = []
    for e in events:
        val = get_field(e, field)
        if val is None:
            continue
        raw_values.append(val)
        try:
            numeric_values.append(float(val))
        except (ValueError, TypeError):
            pass

    if not raw_values:
        console.print(f"[dim]No values for field '{field}'.[/dim]")
        return

    # Decide: numeric if >50% of values convert
    is_numeric = len(numeric_values) > len(raw_values) * 0.5

    if is_numeric and len(numeric_values) >= 2:
        sorted_vals = sorted(numeric_values)
        n = len(sorted_vals)
        mean = _stats_mod.mean(numeric_values)
        median = _stats_mod.median(numeric_values)
        stddev = _stats_mod.stdev(numeric_values) if n >= 2 else 0.0
        p95 = sorted_vals[min(int(n * 0.95), n - 1)] if n >= 20 else sorted_vals[-1]
        p99 = sorted_vals[min(int(n * 0.99), n - 1)]

        lines = [
            f"  [bold]Field:[/bold]   {field}",
            f"  [bold]Count:[/bold]   {format_number(n)} values ({format_number(len(events))} events)",
            "",
            f"  [bold]Min:[/bold]     {sorted_vals[0]:,.2f}",
            f"  [bold]Max:[/bold]     {sorted_vals[-1]:,.2f}",
            f"  [bold]Mean:[/bold]    {mean:,.2f}",
            f"  [bold]Median:[/bold]  {median:,.2f}",
            f"  [bold]Stddev:[/bold]  {stddev:,.2f}",
            f"  [bold]P95:[/bold]     {p95:,.2f}",
            f"  [bold]P99:[/bold]     {p99:,.2f}",
            f"  [bold]Sum:[/bold]     {sum(numeric_values):,.2f}",
        ]
        console.print(Panel("\n".join(lines), title=f"Statistics: {field}", border_style="cyan"))
    else:
        counter = Counter(raw_values)
        unique = len(counter)

        table = Table(title=f"Top values: {field}", border_style="dim")
        table.add_column("Value", style="bold")
        table.add_column("Count", justify="right")
        table.add_column("%", justify="right")

        for val, count in counter.most_common(15):
            pct = count / len(raw_values) * 100
            table.add_row(val, format_number(count), f"{pct:.1f}%")

        console.print(table)
        console.print(
            f"  [dim]{format_number(unique)} unique values across "
            f"{format_number(len(raw_values))} entries[/dim]"
        )

    session.log_command(parsed.raw, f"stats {field}")


@register(
    "top",
    r"^top\s+\d+\s+\w+",
    category="Display",
    usage="top <N> <field>",
    help="Top N values by count (shortcut for count by field | head N).",
)
def cmd_top(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Top N values by count (shortcut for count by field | head N)."""
    import re
    console = ctx.console
    m = re.match(r"^(\d+)\s+(\w+)$", parsed.args.strip())
    if not m:
        console.print("[red]Usage: top <N> <field>[/red]")
        return
    n = int(m.group(1))
    field = m.group(2)
    result = _op_count_by(session.filtered_events, field)[:n]
    session.last_output = list(result)

    if parsed.pipe_ops:
        from logparse.pipeline import extract_visual
        ops, visual_type = extract_visual(parsed.pipe_ops)
        pipe_warnings = []
        result = apply_pipeline(result, ops, warnings=pipe_warnings)
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            render_agg_visual(result, visual_type, console)
            session.last_output = list(result)
            session.log_command(parsed.raw, f"top {n} {field}")
            return

    from logparse.output.table import render_agg
    render_agg(result, console)
    session.log_command(parsed.raw, f"top {n} {field}")
