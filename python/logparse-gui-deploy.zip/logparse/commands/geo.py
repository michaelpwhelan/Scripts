#!/usr/bin/env python3
"""GeoIP lookup command — IP investigation and geographic analysis."""

from __future__ import annotations

import re
from collections import Counter, defaultdict

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.pipeline import AggResult, apply_pipeline, extract_visual
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


_IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")

# Minimal service map for port labels in drill-downs
_SERVICES = {
    "21": "FTP", "22": "SSH", "23": "Telnet", "25": "SMTP",
    "53": "DNS", "80": "HTTP", "110": "POP3", "123": "NTP",
    "135": "RPC", "139": "NetBIOS", "143": "IMAP", "161": "SNMP",
    "389": "LDAP", "443": "HTTPS", "445": "SMB", "465": "SMTPS",
    "500": "IKE", "587": "SMTP-sub", "636": "LDAPS", "993": "IMAPS",
    "1433": "MSSQL", "3306": "MySQL", "3389": "RDP", "4500": "NAT-T",
    "5060": "SIP", "5432": "PostgreSQL", "5900": "VNC", "5985": "WinRM",
    "8080": "HTTP-alt", "8443": "HTTPS-alt",
}


@register(
    "geo",
    r"^geo\s+.+",
    category="Analysis",
    usage="geo <IP> | geo <field> [country]",
    help=(
        "GeoIP lookup and IP investigation. "
        "Single IP: full profile (country, ASN, threat, activity). "
        "Field name: aggregate by country with unique IP counts. "
        "Field + country: drill down to see IPs, ASN orgs, and targeted ports."
    ),
)
def cmd_geo(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """GeoIP lookup and IP investigation."""
    from logparse.geoip import lookup

    console = ctx.console
    args = parsed.args.strip()

    # Initialize geo cache
    if "_geo_cache" not in session.variables:
        session.variables["_geo_cache"] = {}

    # Single IP profile
    first_token = args.split()[0]
    if _IP_RE.match(first_token):
        _ip_profile(first_token, session, console)
        session.log_command(parsed.raw, f"profile {first_token}")
        return

    # Field-based modes
    parts = args.split(None, 1)
    field = parts[0]
    country_filter = parts[1].strip() if len(parts) > 1 else None

    # Single-pass scan of all events
    scan = _scan_field(field, session, lookup)

    if not scan["ip_counts"]:
        console.print(f"[dim]No IP addresses found in field '{field}'.[/dim]")
        session.log_command(parsed.raw, "no IPs found")
        return

    if country_filter:
        _country_drilldown(country_filter, field, scan, session, parsed, console)
    else:
        _field_summary(field, scan, session, parsed, console)


# ------------------------------------------------------------------
# Single IP profile
# ------------------------------------------------------------------

def _ip_profile(ip: str, session: Session, console) -> None:
    """Full profile for a single IP — geo, ASN, threat, activity."""
    from rich.panel import Panel
    from logparse.geoip import lookup
    from logparse.asn_data import lookup_asn
    from logparse.threat_intel import classify_ip

    geo = lookup(ip)
    asn = lookup_asn(ip)
    threat = classify_ip(ip)

    # Activity in current view
    events = session.filtered_events
    ip_events = [
        e for e in events
        if get_field(e, "srcip") == ip or get_field(e, "dstip") == ip
    ]
    deny_count = sum(
        1 for e in ip_events
        if (get_field(e, "action") or "").lower()
        in ("deny", "denied", "blocked", "drop")
    )

    # Targeted ports
    port_counts: Counter[str] = Counter()
    for e in ip_events:
        port = get_field(e, "dstport") or get_field(e, "port") or ""
        if port:
            port_counts[port] += 1

    # Risk score
    deny_rate = deny_count / max(len(ip_events), 1)
    risk_weights = {
        "tor": 8, "scanner": 5, "cloud": 2, "public": 1, "internal": 0,
    }
    risk_base = risk_weights.get(threat.get("category", "public"), 1)
    if deny_rate > 0.8:
        risk_base += 2
    elif deny_rate > 0.5:
        risk_base += 1
    risk = min(risk_base, 10)
    risk_color = "red" if risk >= 7 else "yellow" if risk >= 4 else "green"

    # Build panel
    lines = []
    country_str = geo["country"]
    if geo["country_code"] not in ("--", "??"):
        country_str += f" ({geo['country_code']})"
    lines.append(f"  [bold]Country :[/bold]  {country_str}")

    if asn["asn"]:
        lines.append(f"  [bold]ASN     :[/bold]  AS{asn['asn']} — {asn['org']}")
    else:
        lines.append(f"  [bold]ASN     :[/bold]  [dim]Unknown[/dim]")

    cat = threat.get("category", "")
    if cat and cat not in ("public", "internal"):
        cat_str = cat
        if threat.get("provider"):
            cat_str += f" — {threat['provider']}"
        lines.append(f"  [bold]Category:[/bold]  {cat_str}")

    lines.append(f"  [bold]Risk    :[/bold]  [{risk_color}]{risk}/10[/{risk_color}]")

    if ip_events:
        lines.append(
            f"  [bold]Events  :[/bold]  {format_number(len(ip_events))}"
            f" ({format_number(deny_count)} denied)"
        )
        if port_counts:
            parts = []
            for p, c in port_counts.most_common(5):
                svc = _SERVICES.get(p)
                label = f"{p}/{svc}" if svc else p
                parts.append(f"{label} ({c})")
            lines.append(f"  [bold]Targets :[/bold]  {', '.join(parts)}")
    else:
        lines.append(f"  [bold]Events  :[/bold]  [dim]0 in current view[/dim]")

    if geo.get("type") == "private":
        border = "dim"
    elif risk >= 7:
        border = "red"
    elif risk >= 4:
        border = "yellow"
    else:
        border = "cyan"

    console.print(Panel("\n".join(lines), title=f"[bold]{ip}[/bold]", border_style=border))

    if ip_events:
        console.print(f"  [dim]Filter: where srcip:{ip}  |  where dstip:{ip}[/dim]")


# ------------------------------------------------------------------
# Field scan (shared by summary and drill-down)
# ------------------------------------------------------------------

def _scan_field(field: str, session: Session, lookup_fn) -> dict:
    """Single-pass scan collecting per-IP and per-country metrics."""
    ip_counts: Counter[str] = Counter()
    ip_deny: Counter[str] = Counter()
    ip_ports: dict[str, Counter] = defaultdict(Counter)
    ip_geo: dict[str, dict[str, str]] = {}

    for event in session.filtered_events:
        val = get_field(event, field)
        if not val or not _IP_RE.match(val):
            continue

        if val not in ip_geo:
            info = _cached_lookup(val, session, lookup_fn)
            ip_geo[val] = {
                "country": info["country"],
                "country_code": info["country_code"],
            }

        ip_counts[val] += 1

        action = (get_field(event, "action") or "").lower()
        if action in ("deny", "denied", "blocked", "drop"):
            ip_deny[val] += 1

        port = get_field(event, "dstport") or get_field(event, "port") or ""
        if port:
            ip_ports[val][port] += 1

    # Aggregate by country
    country_counts: Counter[str] = Counter()
    country_ips: dict[str, set] = defaultdict(set)
    for ip, geo in ip_geo.items():
        country = geo["country"]
        country_counts[country] += ip_counts[ip]
        country_ips[country].add(ip)

    return {
        "ip_counts": ip_counts,
        "ip_deny": ip_deny,
        "ip_ports": dict(ip_ports),
        "ip_geo": ip_geo,
        "country_counts": country_counts,
        "country_ips": dict(country_ips),
    }


# ------------------------------------------------------------------
# Field summary — enriched country table
# ------------------------------------------------------------------

def _field_summary(
    field: str, scan: dict, session: Session,
    parsed: ParsedCommand, console,
) -> None:
    """Country summary with unique IP counts and top ASN org."""
    country_counts = scan["country_counts"]
    country_ips = scan["country_ips"]
    ip_counts = scan["ip_counts"]

    # AggResult for pipeline compatibility
    result = [
        AggResult(key=country, count=cnt, field="country")
        for country, cnt in country_counts.most_common()
    ]

    # Pipe ops → pass through pipeline
    if parsed.pipe_ops:
        ops, visual_type = extract_visual(parsed.pipe_ops)
        result = apply_pipeline(result, ops)
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            session.last_output = list(result)
            render_agg_visual(result, visual_type, console)
            session.log_command(
                parsed.raw, f"geo {field}: {len(country_counts)} countries",
            )
            return
        session.last_output = list(result)
        from logparse.output.table import render_agg
        render_agg(result, console)
        session.log_command(
            parsed.raw, f"geo {field}: {len(country_counts)} countries",
        )
        return

    # Enhanced table (no pipe ops)
    from rich.table import Table
    from logparse.asn_data import lookup_asn

    table = Table(border_style="dim")
    table.add_column("COUNTRY", style="bold")
    table.add_column("EVENTS", justify="right", style="cyan")
    table.add_column("IPS", justify="right")
    table.add_column("TOP ORG")

    for country, cnt in country_counts.most_common():
        ips = country_ips.get(country, set())

        # Top ASN org — sample top 3 IPs by event count
        top_ips = sorted(ips, key=lambda ip: ip_counts[ip], reverse=True)[:3]
        org_counts: Counter[str] = Counter()
        for ip in top_ips:
            asn_info = lookup_asn(ip)
            org = asn_info.get("org", "")
            if org and org != "Unknown":
                org_counts[org] += ip_counts[ip]
        top_org = org_counts.most_common(1)[0][0] if org_counts else ""

        table.add_row(country, format_number(cnt), str(len(ips)), top_org)

    session.last_output = list(result)
    console.print(table)

    total_events = sum(country_counts.values())
    total_ips = sum(len(v) for v in country_ips.values())
    console.print(
        f"  [dim]{len(country_counts)} countries, "
        f"{format_number(total_events)} events, "
        f"{format_number(total_ips)} unique IPs[/dim]"
    )

    # Note about regional labels
    regional = [
        c for c in country_counts
        if c in ("Europe", "Asia Pacific", "Africa", "South America")
    ]
    if regional:
        console.print(
            f"  [dim]{', '.join(regional)} = RIR-level "
            f"(install geoip2 for country detail)[/dim]"
        )

    # Drill-down hint
    for country, _ in country_counts.most_common():
        if country != "Private":
            console.print(f"  [dim]Drill down: geo {field} {country}[/dim]")
            break

    session.log_command(
        parsed.raw,
        f"geo {field}: {len(country_counts)} countries, "
        f"{total_events} events, {total_ips} IPs",
    )


# ------------------------------------------------------------------
# Country drill-down — IPs, ASN orgs, targeted ports
# ------------------------------------------------------------------

def _country_drilldown(
    country_filter: str, field: str, scan: dict,
    session: Session, parsed: ParsedCommand, console,
) -> None:
    """Drill into a country — show IPs with ASN, deny rates, ports."""
    from logparse.asn_data import lookup_asn

    country_counts = scan["country_counts"]
    country_ips = scan["country_ips"]
    ip_counts = scan["ip_counts"]
    ip_deny = scan["ip_deny"]
    ip_ports = scan["ip_ports"]

    # Match country name (exact first, then substring)
    matched = None
    lower = country_filter.lower()
    for country in country_counts:
        if country.lower() == lower:
            matched = country
            break
    if not matched:
        for country in country_counts:
            if lower in country.lower():
                matched = country
                break

    if not matched:
        console.print(
            f"[dim]No events from '{country_filter}' in field '{field}'.[/dim]"
        )
        available = ", ".join(c for c, _ in country_counts.most_common(10))
        console.print(f"  [dim]Available: {available}[/dim]")
        session.log_command(parsed.raw, f"no match for '{country_filter}'")
        return

    ips = sorted(
        country_ips[matched], key=lambda ip: ip_counts[ip], reverse=True,
    )
    total = country_counts[matched]

    # AggResult for pipeline
    result = [
        AggResult(key=ip, count=ip_counts[ip], field=field)
        for ip in ips
    ]

    # Pipe ops
    if parsed.pipe_ops:
        ops, visual_type = extract_visual(parsed.pipe_ops)
        result = apply_pipeline(result, ops)
        if visual_type and result and isinstance(result[0], AggResult):
            from logparse.visual import render_agg_visual
            session.last_output = list(result)
            render_agg_visual(result, visual_type, console)
            session.log_command(
                parsed.raw, f"geo {field} {matched}: {len(ips)} IPs",
            )
            return
        session.last_output = list(result)
        from logparse.output.table import render_agg
        render_agg(result, console)
        session.log_command(
            parsed.raw, f"geo {field} {matched}: {len(ips)} IPs",
        )
        return

    # Rich drill-down display
    from rich.table import Table

    console.rule(
        f"{matched} — {format_number(total)} events, {len(ips)} unique IPs",
        style="bold cyan",
    )

    table = Table(border_style="dim")
    table.add_column("IP", style="bold")
    table.add_column("EVENTS", justify="right", style="cyan")
    table.add_column("DENIED", justify="right")
    table.add_column("ORG")

    for ip in ips[:20]:
        cnt = ip_counts[ip]
        denied = ip_deny.get(ip, 0)
        asn_info = lookup_asn(ip)
        org = asn_info["org"] if asn_info["asn"] else ""
        deny_str = format_number(denied) if denied else ""
        table.add_row(ip, format_number(cnt), deny_str, org)

    console.print(table)

    if len(ips) > 20:
        console.print(
            f"  [dim]... and {len(ips) - 20} more IPs"
            f" (pipe to see all: geo {field} {matched} | head 50)[/dim]"
        )

    # Targeted ports
    all_ports: Counter[str] = Counter()
    for ip in ips:
        if ip in ip_ports:
            all_ports.update(ip_ports[ip])

    if all_ports:
        console.print("\n[bold]Targeted Ports:[/bold]")
        for port, cnt in all_ports.most_common(10):
            svc = _SERVICES.get(port)
            label = f"{port}/{svc}" if svc else port
            console.print(f"  {label:>16}  {format_number(cnt)}")

    # Hints
    if ips:
        console.print(
            f"\n  [dim]Profile: geo {ips[0]}"
            f"  |  Filter: where {field}:{ips[0]}[/dim]"
        )

    session.last_output = list(result)
    session.log_command(
        parsed.raw,
        f"geo {field} {matched}: {len(ips)} IPs, {total} events",
    )


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------

def _cached_lookup(ip: str, session: Session, lookup_fn) -> dict[str, str]:
    """Lookup with session-level caching."""
    cache = session.variables.get("_geo_cache", {})
    if isinstance(cache, dict) and ip in cache:
        return cache[ip]
    info = lookup_fn(ip)
    if isinstance(cache, dict):
        cache[ip] = info
        session.variables["_geo_cache"] = cache
    return info
