#!/usr/bin/env python3
"""top command — quick top-N values for a field."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "top",
    r"^top\s+(\w+)(?:\s+(\d+))?$",
    category="Display",
    usage="top <field> [N]",
    help="Show top N values for a field (default 10). Shortcut for count by <field> | head N.",
)
def cmd_top(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show top N values for a field (default 10)."""
    from logparse.pipeline import _op_count_by
    from logparse.output.table import render_agg

    console = ctx.console
    import re
    m = re.match(r"^(\w+)(?:\s+(\d+))?$", (parsed.args or "").strip())
    if not m:
        console.print("[red]Usage: top <field> [N][/red]")
        return

    field = m.group(1)
    n = int(m.group(2)) if m.group(2) else 10
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    agg_data = _op_count_by(events, field)[:n]
    if not agg_data:
        console.print(f"[dim]No values for field '{field}'.[/dim]")
        return

    session.last_output = list(agg_data)
    console.print(f"[bold]Top {min(n, len(agg_data))} — {field}[/bold] ({format_number(len(events))} events)")
    render_agg(agg_data, console)
    session.log_command(parsed.raw, f"top {field} {n}")
