#!/usr/bin/env python3
"""IP threat profile command."""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "profile",
    r"^profile\s+.+",
    category="Analysis",
    usage="profile <IP>",
    help="IP threat assessment — GeoIP, classification, event summary.",
)
def cmd_profile(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """IP threat assessment — GeoIP, classification, event summary."""
    from collections import Counter

    from rich.panel import Panel

    from logparse.geoip import lookup
    from logparse.models import get_field
    from logparse.threat_intel import classify_ip

    console = ctx.console
    ip = parsed.args.strip()

    # GeoIP lookup
    geo = lookup(ip)
    threat = classify_ip(ip)

    # Event analysis
    matching = []
    for e in session.filtered_events:
        for f in ("srcip", "dstip", "remip", "srcaddr", "dstaddr"):
            if (get_field(e, f) or "") == ip:
                matching.append(e)
                break

    # Build profile
    lines = [
        f"[bold]IP:[/bold] {ip}",
        f"[bold]Country:[/bold] {geo.get('country', 'Unknown')} ({geo.get('country_code', '??')})",
        f"[bold]Type:[/bold] {geo.get('type', 'unknown')}",
        f"[bold]Category:[/bold] {threat.get('category', 'unknown')}",
    ]
    if threat.get("provider"):
        lines.append(f"[bold]Provider:[/bold] {threat['provider']}")

    risk = threat.get("risk", "unknown")
    risk_style = {"high": "bold red", "medium": "yellow", "low": "green"}.get(risk, "")
    if risk_style:
        lines.append(f"[bold]Risk:[/bold] [{risk_style}]{risk}[/{risk_style}]")
    else:
        lines.append(f"[bold]Risk:[/bold] {risk}")

    if matching:
        lines.append("")
        lines.append(f"[bold]Events:[/bold] {len(matching)}")

        # Time range
        ts_events = [e for e in matching if e.timestamp]
        if ts_events:
            ts_events.sort(key=lambda e: e.timestamp)
            first = ts_events[0].timestamp.strftime("%Y-%m-%d %H:%M:%S")
            last = ts_events[-1].timestamp.strftime("%Y-%m-%d %H:%M:%S")
            lines.append(f"[bold]First seen:[/bold] {first}")
            lines.append(f"[bold]Last seen:[/bold] {last}")

        # Ports targeted
        ports: Counter[str] = Counter()
        for e in matching:
            port = get_field(e, "dstport") or ""
            if port:
                ports[port] += 1
        if ports:
            top_ports = ", ".join(f"{p}({c})" for p, c in ports.most_common(5))
            lines.append(f"[bold]Ports:[/bold] {top_ports}")

        # Users
        users: set[str] = set()
        for e in matching:
            user = get_field(e, "user") or get_field(e, "srcuser") or ""
            if user:
                users.add(user)
        if users:
            lines.append(f"[bold]Users:[/bold] {', '.join(sorted(users)[:10])}")

        # Action breakdown
        actions: Counter[str] = Counter()
        for e in matching:
            action = get_field(e, "action") or ""
            if action:
                actions[action] += 1
        if actions:
            action_str = ", ".join(f"{a}({c})" for a, c in actions.most_common(5))
            lines.append(f"[bold]Actions:[/bold] {action_str}")
    else:
        lines.append("\n[dim]No events found for this IP.[/dim]")

    console.print(Panel(
        "\n".join(lines),
        title=f"IP Profile — {ip}",
        border_style="cyan",
    ))

    session.log_command(parsed.raw, f"profile {ip}: {len(matching)} events")
