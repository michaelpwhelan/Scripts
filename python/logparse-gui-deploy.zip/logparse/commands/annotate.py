#!/usr/bin/env python3
"""annotate command — attach notes to individual events."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "annotate",
    r"^annotate\s+.+",
    category="Notes",
    usage='annotate N "text" | annotate list | annotate clear | annotate delete N',
    help="Attach notes to specific events.",
)
def cmd_annotate(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Attach notes to specific events."""
    console = ctx.console
    args = parsed.args.strip()

    # annotate list
    if args.lower() == "list":
        if not session.annotations:
            console.print("[dim]No annotations.[/dim]")
        else:
            from logparse.util import compact_table
            table = compact_table()
            table.add_column("#", style="bold")
            table.add_column("NOTE")
            table.add_column("EVENT PREVIEW", style="dim")
            for idx, note in sorted(session.annotations.items()):
                preview = ""
                events = session.filtered_events
                if 0 < idx <= len(events):
                    e = events[idx - 1]
                    preview = (e.message or "")[:60]
                table.add_row(str(idx), note, preview)
            console.print(table)
        session.log_command(parsed.raw, f"{len(session.annotations)} annotations")
        return

    # annotate clear
    if args.lower() == "clear":
        count = len(session.annotations)
        session.annotations.clear()
        console.print(f"Cleared {count} annotation(s).")
        session.log_command(parsed.raw, "annotations cleared")
        return

    # annotate delete N
    m = re.match(r"^delete\s+(\d+)$", args, re.I)
    if m:
        idx = int(m.group(1))
        if idx in session.annotations:
            del session.annotations[idx]
            console.print(f"Removed annotation for event #{idx}.")
        else:
            console.print(f"[dim]No annotation for event #{idx}.[/dim]")
        session.log_command(parsed.raw, f"annotation delete #{idx}")
        return

    # annotate N "text"
    m = re.match(r'^(\d+)\s+["\'](.+?)["\']$', args)
    if not m:
        # also support without quotes: annotate N text...
        m = re.match(r"^(\d+)\s+(.+)$", args)
    if m:
        idx = int(m.group(1))
        text = m.group(2).strip()
        events = session.filtered_events
        if idx < 1 or idx > len(events):
            console.print(f"[red]Event {idx} out of range (1-{len(events)})[/red]")
            return
        session.annotations[idx] = text
        console.print(f"Annotated event #{idx}: {text}")
        session.log_command(parsed.raw, f"annotated #{idx}")
        return

    console.print('[red]Usage: annotate N "text" | annotate list | annotate clear | annotate delete N[/red]')
