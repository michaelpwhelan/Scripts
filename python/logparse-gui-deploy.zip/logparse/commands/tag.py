#!/usr/bin/env python3
"""tag command — label events with custom tags."""

from __future__ import annotations

import re as _re

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "tag",
    r"^tag(?:\s+.*)?$",
    category="Session",
    usage="tag <indices> <label> | tag list | tag clear [label]",
    help=(
        "Label events with custom tags for grouping and filtering. "
        "Supports ranges: tag 1-5 ioc, tag 3,7,12 suspicious. "
        "Use 'where tag=<label>' to filter by tag."
    ),
)
def cmd_tag(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Label events with custom tags for grouping and filtering."""
    console = ctx.console
    args = (parsed.args or "").strip()

    # Ensure tags dict exists on session
    if not hasattr(session, "tags"):
        session.tags = {}

    # tag list
    if args.lower() in ("list", "show", ""):
        if not args or args.lower() in ("list", "show"):
            _list_tags(session, console)
            return

    # tag clear [label]
    clear_m = _re.match(r"^clear(?:\s+(\w+))?$", args, _re.IGNORECASE)
    if clear_m:
        label = clear_m.group(1)
        if label:
            removed = 0
            for idx in list(session.tags.keys()):
                if label in session.tags.get(idx, set()):
                    session.tags[idx].discard(label)
                    if not session.tags[idx]:
                        del session.tags[idx]
                    removed += 1
            console.print(f"[dim]Removed tag '{label}' from {removed} events.[/dim]")
        else:
            session.tags = {}
            console.print("[dim]All tags cleared.[/dim]")
        session.log_command(parsed.raw, f"tag clear {label or 'all'}")
        return

    # tag <indices> <label>
    m = _re.match(r"^([\d,\s\-]+)\s+(\w+)$", args)
    if not m:
        console.print("[red]Usage: tag <indices> <label>[/red]")
        console.print("[dim]Examples: tag 1-5 ioc | tag 3,7 suspicious | tag list | tag clear[/dim]")
        return

    indices_str = m.group(1)
    label = m.group(2)

    # Parse indices (1-based)
    indices = _parse_indices(indices_str)
    max_idx = len(session.filtered_events)

    tagged = 0
    for idx in indices:
        if 1 <= idx <= max_idx:
            if idx not in session.tags:
                session.tags[idx] = set()
            session.tags[idx].add(label)
            tagged += 1

    console.print(f"[bold]Tagged {tagged} events[/bold] with '{label}'")
    session.log_command(parsed.raw, f"tag {tagged} events: {label}")


def _parse_indices(text: str) -> list[int]:
    """Parse index expressions like '1-5, 7, 10-12'."""
    indices: list[int] = []
    for part in text.split(","):
        part = part.strip()
        range_m = _re.match(r"^(\d+)\s*-\s*(\d+)$", part)
        if range_m:
            start = int(range_m.group(1))
            end = int(range_m.group(2))
            indices.extend(range(start, end + 1))
        elif part.isdigit():
            indices.append(int(part))
    return indices


def _list_tags(session: Session, console: Console) -> None:
    """Show all tagged events."""
    tags = getattr(session, "tags", {})
    if not tags:
        console.print("[dim]No tagged events. Usage: tag <indices> <label>[/dim]")
        return

    # Group by label
    from collections import defaultdict
    label_indices: defaultdict[str, list[int]] = defaultdict(list)
    for idx, labels in tags.items():
        for label in labels:
            label_indices[label].append(idx)

    from rich.table import Table
    table = Table(title="Tags", border_style="dim")
    table.add_column("Label", style="bold")
    table.add_column("Events", justify="right", style="cyan")
    table.add_column("Indices")

    for label, indices in sorted(label_indices.items()):
        indices.sort()
        idx_str = _compress_indices(indices)
        table.add_row(label, str(len(indices)), idx_str)

    console.print(table)


def _compress_indices(indices: list[int]) -> str:
    """Compress [1,2,3,5,7,8,9] to '1-3, 5, 7-9'."""
    if not indices:
        return ""
    parts: list[str] = []
    start = indices[0]
    end = start
    for idx in indices[1:]:
        if idx == end + 1:
            end = idx
        else:
            parts.append(f"{start}-{end}" if start != end else str(start))
            start = end = idx
    parts.append(f"{start}-{end}" if start != end else str(start))
    result = ", ".join(parts)
    return result[:60] + "..." if len(result) > 60 else result
