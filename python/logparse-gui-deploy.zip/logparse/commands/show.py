#!/usr/bin/env python3
"""show command — context-aware Swiss army knife."""

from __future__ import annotations

import re
from collections import Counter

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.severity import SEV_KEYWORDS, SEV_NORMALIZE
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import compact_table, format_number

# Priority fields shown by `show *` beyond the 4 defaults
_PRIORITY_EXTRA_FIELDS = [
    "action", "srcip", "dstip", "srcport", "dstport",
    "user", "policyid", "protocol", "service", "hostname",
    "srcintf", "dstintf", "app", "url", "logid",
]

# Max extra columns beyond the 4 defaults
_MAX_EXTRA_COLS = 8


def _is_number(s: str) -> bool:
    try:
        int(s)
        return True
    except ValueError:
        return False


def _smart_columns(session: Session) -> list[str]:
    """Build a smart column list for `show *`: defaults + top populated extras, capped."""
    default = ["Timestamp", "Severity", "Source", "Message"]
    # Collect population counts from a sample of events
    sample = session.filtered_events[:200]
    pop: Counter[str] = Counter()
    all_extra_keys: set[str] = set()
    for e in sample:
        for k, v in e.extra.items():
            all_extra_keys.add(k)
            if v:
                pop[k] += 1

    # Priority fields first (if they exist and are populated)
    chosen: list[str] = []
    for f in _PRIORITY_EXTRA_FIELDS:
        if len(chosen) >= _MAX_EXTRA_COLS:
            break
        # Check case-insensitive match against actual keys
        for ek in all_extra_keys:
            if ek.lower() == f.lower() and pop.get(ek, 0) > 0:
                chosen.append(ek)
                break

    # Fill remaining slots with most-populated fields not already chosen
    chosen_lower = {c.lower() for c in chosen}
    for field, _ in pop.most_common():
        if len(chosen) >= _MAX_EXTRA_COLS:
            break
        if field.lower() not in chosen_lower and field not in default:
            chosen.append(field)
            chosen_lower.add(field.lower())

    total_available = len(all_extra_keys)
    return default + chosen, total_available


@register(
    "show",
    r"^show(\s+.*)?$",
    category="Display",
    usage="show [sources|fields|skip|timeline|filter|history|star|<N>|<N> -a|<field1>,<field2>|*]",
    help="Context-sensitive display command.",
)
def cmd_show(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Context-sensitive display command."""
    from rich.console import Console

    console: Console = ctx.console
    args = parsed.args.strip()

    # no args — show current filtered events
    if not args:
        _show_events(session, console, parsed)
        session.log_command(parsed.raw, f"{len(session.filtered_events)} events")
        return

    lower = args.lower()

    # show [columns] where/from <filter> — inline scratch filter
    where_match = re.match(r"^(.*?)(?:^|\s+)(?:where|from)\s+(.+)$", args, re.I)
    if where_match:
        col_part = where_match.group(1).strip()
        filter_part = where_match.group(2).strip()

        # apply column selection if present
        if col_part in ("*", "all"):
            display_cols, _ = _smart_columns(session)
        elif col_part == "**" or col_part.lower() == "all-fields":
            display_cols = session.all_field_names()
        elif col_part:
            display_cols = [c.strip() for c in col_part.split(",")]
        else:
            display_cols = session.display_columns

        # apply scratch filter (doesn't modify session)
        from logparse.filter_engine import parse_conditions, match_event, grep_events

        # "* contains value" → cross-field grep
        star_contains = re.match(
            r"^\*\s+contains?\s+(.+)$", filter_part, re.I,
        )
        if star_contains:
            grep_pattern = star_contains.group(1).strip().strip('"').strip("'").strip("*")
            events = grep_events(session.filtered_events, grep_pattern)
            filter_part = grep_pattern
        else:
            extra = {f.lower() for f in session.all_field_names()}
            conditions = parse_conditions(filter_part, extra_fields=extra)
            if conditions:
                events = [e for e in session.filtered_events if match_event(e, conditions)]
            else:
                # strip quotes and use as grep across all fields
                grep_pattern = filter_part.strip('"').strip("'")
                events = grep_events(session.filtered_events, grep_pattern)
                filter_part = grep_pattern

        # apply pipe ops if present
        if parsed.pipe_ops:
            from logparse.pipeline import apply_pipeline, AggResult, extract_visual
            ops, visual_type = extract_visual(parsed.pipe_ops)
            pipe_warnings: list[str] = []
            events = apply_pipeline(events, ops, warnings=pipe_warnings,
                                    all_events=session.all_events)
            for w in pipe_warnings:
                console.print(f"[yellow]{w}[/yellow]")
            if events and isinstance(events[0], AggResult):
                session.last_output = list(events)
                if visual_type:
                    from logparse.visual import render_agg_visual
                    render_agg_visual(events, visual_type, console)
                    session.log_command(parsed.raw, f"{len(events)} groups (scratch)")
                    return
                from logparse.output.table import render_agg
                render_agg(events, console)
                session.log_command(parsed.raw, f"{len(events)} groups (scratch)")
                return

        from logparse.output.table import render_table
        render_table(
            events, console,
            fields=display_cols,
            highlight=filter_part,
            max_results=50,
            annotations=session.annotations if session.annotations else None,
        )
        session.log_command(parsed.raw, f"{len(events)} events (scratch)")
        return

    # show sources
    if lower == "sources":
        counter: Counter[str] = Counter()
        for e in session.all_events:
            if e.source:
                counter[e.source] += 1
        table = compact_table()
        table.add_column("SOURCE", style="bold")
        table.add_column("COUNT", justify="right", style="cyan")
        for src, count in counter.most_common():
            table.add_row(src, format_number(count))
        console.print(table)
        session.log_command(parsed.raw, f"{len(counter)} unique sources")
        return

    # show fields
    if lower == "fields":
        names = session.all_field_names()
        console.print(", ".join(names))
        session.log_command(parsed.raw, f"{len(names)} fields")
        return

    # show skip
    if lower == "skip":
        if session.skipped_files:
            for f in session.skipped_files:
                console.print(f"  {f}")
        else:
            console.print("[dim]No skipped files.[/dim]")
        session.log_command(parsed.raw, f"{len(session.skipped_files)} skipped")
        return

    # show timeline
    if lower == "timeline":
        ts_events = [e for e in session.all_events if e.timestamp]
        if not ts_events:
            console.print("[dim]No timestamps available.[/dim]")
        else:
            first = ts_events[0].timestamp
            last = ts_events[-1].timestamp
            span = last - first
            console.print(f"  First : {first:%Y-%m-%d %H:%M:%S}")
            console.print(f"  Last  : {last:%Y-%m-%d %H:%M:%S}")
            console.print(f"  Span  : {span}")
            console.print(f"  Events: {format_number(len(ts_events))}")
        session.log_command(parsed.raw, "timeline summary")
        return

    # show filter (saved filters)
    if lower == "filter" or lower == "filters":
        if not session.saved_filters:
            console.print("[dim]No saved filters.[/dim]")
        else:
            table = compact_table()
            table.add_column("#", style="bold")
            table.add_column("FILTER")
            table.add_column("EVENTS", justify="right", style="cyan")
            for fid, snap in sorted(session.saved_filters.items()):
                table.add_row(
                    str(fid), snap.description or "(all)",
                    format_number(len(snap.events)),
                )
            console.print(table)
        session.log_command(parsed.raw, f"{len(session.saved_filters)} saved filters")
        return

    # show history
    if lower == "history":
        if not session.transcript:
            console.print("[dim]No history.[/dim]")
        else:
            entries = session.transcript
            total = len(entries)
            if total > 100:
                entries = entries[-100:]
                console.print(f"[dim]Showing last 100 of {total} entries:[/dim]")
            offset = total - len(entries)
            for i, entry in enumerate(entries, offset + 1):
                console.print(
                    f"  [dim][{i}] {entry.timestamp:%H:%M:%S}[/dim]  "
                    f"{entry.command}  [cyan]\u2192 {entry.summary}[/cyan]"
                )
        session.log_command(parsed.raw, f"{len(session.transcript)} entries")
        return

    # show star
    if lower == "star" or lower == "starred":
        if not session.starred:
            console.print("[dim]No starred events.[/dim]")
        else:
            starred = [
                session.all_events[i]
                for i in sorted(session.starred)
                if i < len(session.all_events)
            ]
            _show_event_list(starred, session, console, parsed)
        session.log_command(parsed.raw, f"{len(session.starred)} starred")
        return

    # show export (preview)
    if lower == "export":
        count = len(session.filtered_events)
        console.print("[bold]Export preview[/bold]")
        console.print(f"  Events to export: {format_number(count)}")
        console.print(f"  Active filter: {session.active_filter or '(none)'}")
        console.print(f"  Starred events: {len(session.starred)}")
        console.print(f"  Annotations: {len(session.annotations)}")
        console.print(f"  Notes: {len(session.notes)}")
        console.print()
        console.print("[dim]Usage: export <file.html|csv|json>[/dim]")
        console.print("[dim]       export star <file.ext>[/dim]")
        console.print("[dim]       export profile <file.zip>[/dim]")
        session.log_command(parsed.raw, "export preview")
        return

    # show annotate / show annotated
    if lower in ("annotate", "annotated"):
        if not session.annotations:
            console.print("[dim]No annotated events.[/dim]")
        else:
            ann_table = compact_table()
            ann_table.add_column("#", style="bold")
            ann_table.add_column("NOTE")
            ann_table.add_column("EVENT PREVIEW", style="dim")
            events = session.filtered_events
            for idx, note in sorted(session.annotations.items()):
                preview = ""
                if 0 < idx <= len(events):
                    e = events[idx - 1]
                    preview = (e.message or "")[:60]
                ann_table.add_row(str(idx), note, preview)
            console.print(ann_table)
        session.log_command(parsed.raw, f"{len(session.annotations)} annotated")
        return

    # show N.field — value from row N
    nf_match = re.match(r"^(\d+)\.(\w+)$", args)
    if nf_match:
        row_num = int(nf_match.group(1))
        field_name = nf_match.group(2)
        val = _resolve_row_field(session, row_num, field_name)
        if val is not None:
            console.print(val)
        else:
            console.print(f"[red]Could not resolve {row_num}.{field_name}[/red]")
        session.log_command(parsed.raw, f"{row_num}.{field_name}")
        return

    # show -a N.field — pivot: all events matching value in any field
    pivot_match = re.match(r"^-a\s+(\d+)\.(\w+)$", args)
    if pivot_match:
        row_num = int(pivot_match.group(1))
        field_name = pivot_match.group(2)
        val = _resolve_row_field(session, row_num, field_name)
        if val is None:
            console.print(f"[red]Could not resolve {row_num}.{field_name}[/red]")
            return
        # pivot: find all events where this value appears in any field
        val_lower = val.lower()
        matches = []
        for e in session.all_events:
            fields_to_check = [e.severity, e.source, e.message]
            fields_to_check.extend(e.extra.values())
            if any(val_lower in (f or "").lower() for f in fields_to_check):
                matches.append(e)
        console.print(f"[bold]{len(matches)} events matching '{val}' in any field[/bold]")
        _show_event_list(matches[:50], session, console, parsed)
        session.log_command(parsed.raw, f"{len(matches)} matches for {val}")
        return

    # show N-M — range of event details
    range_match = re.match(r"^(\d+)\s*-\s*(\d+)$", args)
    if range_match:
        start = int(range_match.group(1))
        end = int(range_match.group(2))
        events = session.filtered_events
        if start < 1:
            start = 1
        if end > len(events):
            end = len(events)
        if start > end or start > len(events):
            console.print(f"[red]Range {start}-{end} out of bounds (1-{len(events)})[/red]")
            return
        _MAX_RANGE_DISPLAY = 500
        if end - start + 1 > _MAX_RANGE_DISPLAY:
            console.print(f"[yellow]Range too large ({end - start + 1} events). "
                          f"Capping display to first {_MAX_RANGE_DISPLAY}.[/yellow]")
            end = start + _MAX_RANGE_DISPLAY - 1
        for idx in range(start, end + 1):
            event = events[idx - 1]
            console.print(f"[bold]Event #{idx}[/bold]")
            console.print(f"  Timestamp : {event.timestamp:%Y-%m-%d %H:%M:%S}" if event.timestamp else "  Timestamp : (none)")
            console.print(f"  Severity  : {event.severity}")
            console.print(f"  Source    : {event.source}")
            console.print(f"  Message   : {event.message}")
            for k, v in sorted(event.extra.items()):
                console.print(f"  {k:<12}: {v}")
            if idx in session.annotations:
                console.print(f"  [bold yellow]Note: {session.annotations[idx]}[/bold yellow]")
            console.print()
        session.log_command(parsed.raw, f"events {start}-{end}")
        return

    # show <N> [-a]
    num_match = re.match(r"^(\d+)(\s+-a)?$", args)
    if num_match:
        idx = int(num_match.group(1))
        show_all = bool(num_match.group(2))
        events = session.filtered_events
        if idx < 1 or idx > len(events):
            console.print(f"[red]Event {idx} out of range (1-{len(events)})[/red]")
            return
        event = events[idx - 1]

        # handle pipe ops: field extraction and variable storage
        if parsed.pipe_ops:
            _apply_pipe_extraction(session, [event], parsed.pipe_ops, console)
            session.log_command(parsed.raw, f"event #{idx} piped")
            return

        console.print(f"[bold]Event #{idx}[/bold]")
        console.print(f"  Timestamp : {event.timestamp:%Y-%m-%d %H:%M:%S}" if event.timestamp else "  Timestamp : (none)")
        console.print(f"  Severity  : {event.severity}")
        console.print(f"  Source    : {event.source}")
        console.print(f"  Message   : {event.message}")
        for k, v in sorted(event.extra.items()):
            console.print(f"  {k:<12}: {v}")
        if show_all:
            console.print(f"  [dim]Raw: {event.raw[:500]}[/dim]")
        # show annotation if present
        if idx in session.annotations:
            console.print(f"  [bold yellow]Note: {session.annotations[idx]}[/bold yellow]")
        session.log_command(parsed.raw, f"event #{idx}")
        return

    # show -a <value> — cross-field search
    cross_match = re.match(r"^-a\s+(.+)$", args)
    if cross_match:
        search_val = cross_match.group(1).strip().lower()
        matches = []
        for e in session.filtered_events:
            fields_to_check = [e.severity, e.source, e.message]
            fields_to_check.extend(e.extra.values())
            if any(search_val in (f or "").lower() for f in fields_to_check):
                matches.append(e)
        console.print(f"[bold]{len(matches)} events matching '{search_val}' in any field[/bold]")
        _show_event_list(matches[:50], session, console, parsed)
        session.log_command(parsed.raw, f"{len(matches)} matches")
        return

    # show N, N, N — multi-event detail
    if "," in args:
        parts = [p.strip() for p in args.split(",")]
        if all(_is_number(p) for p in parts):
            events = session.filtered_events
            for p in parts:
                idx = int(p)
                if idx < 1 or idx > len(events):
                    console.print(f"[red]Event {idx} out of range (1-{len(events)})[/red]")
                    continue
                event = events[idx - 1]
                console.print(f"[bold]Event #{idx}[/bold]")
                console.print(f"  Timestamp : {event.timestamp:%Y-%m-%d %H:%M:%S}" if event.timestamp else "  Timestamp : (none)")
                console.print(f"  Severity  : {event.severity}")
                console.print(f"  Source    : {event.source}")
                console.print(f"  Message   : {event.message}")
                for k, v in sorted(event.extra.items()):
                    console.print(f"  {k:<12}: {v}")
                if idx in session.annotations:
                    console.print(f"  [bold yellow]Note: {session.annotations[idx]}[/bold yellow]")
                console.print()
            session.log_command(parsed.raw, f"{len(parts)} events")
            return

    # show <field1>, <field2> — set display columns and render
    if "," in args:
        session.display_columns = [f.strip() for f in args.split(",")]
        _show_events(session, console, parsed)
        session.log_command(parsed.raw, f"columns: {', '.join(session.display_columns)}")
        return

    # show ** / show all-fields — truly everything (warn about width)
    if args.strip() in ("**", "all-fields"):
        all_cols = session.all_field_names()
        session.display_columns = all_cols
        console.print(
            f"[yellow]Showing all {len(all_cols)} fields. "
            f"Use 'show N -a' for single-event detail.[/yellow]"
        )
        _show_events(session, console, parsed)
        session.log_command(parsed.raw, f"all {len(all_cols)} columns")
        return

    # show * / show all — smart expansion (defaults + top populated extras)
    if args.strip() in ("*", "all"):
        smart_cols, total_avail = _smart_columns(session)
        session.display_columns = smart_cols
        n_shown = len(smart_cols)
        if total_avail > n_shown - 4:  # subtract 4 defaults
            console.print(
                f"[dim]Showing {n_shown} of {total_avail + 4} fields. "
                f"Use 'show <field>' to add columns or 'show N -a' for all fields.[/dim]"
            )
        _show_events(session, console, parsed)
        session.log_command(parsed.raw, f"smart {n_shown} columns")
        return

    # "show severity" — bare target shows severity breakdown
    if lower == "severity":
        from logparse.models import SEVERITY_LEVELS
        counter: Counter[str] = Counter()
        for e in session.filtered_events:
            counter[e.severity or "Unknown"] += 1
        table = compact_table()
        table.add_column("SEVERITY", style="bold")
        table.add_column("COUNT", justify="right", style="cyan")
        for sev in SEVERITY_LEVELS:
            if sev in counter:
                table.add_row(sev, format_number(counter[sev]))
        if "Unknown" in counter:
            table.add_row("Unknown", format_number(counter["Unknown"]))
        console.print(table)
        session.log_command(parsed.raw, f"severity breakdown ({len(counter)} levels)")
        return

    # Detect severity keywords: "show High and Critical", "show crit", etc.
    # Strip optional "severity" prefix: "show severity high"
    sev_check = lower
    if sev_check.startswith("severity "):
        sev_check = sev_check[len("severity "):].strip()

    sev_tokens = re.split(r"\s+(?:and|or|,)\s+|\s*,\s*", sev_check)
    sev_tokens = [t.strip() for t in sev_tokens if t.strip()]

    # Merge pipe_ops that are severity keywords (e.g., "show high|critical")
    for pop in parsed.pipe_ops:
        pop_lower = pop.strip().lower()
        if pop_lower in SEV_KEYWORDS:
            sev_tokens.append(pop_lower)

    if sev_tokens and all(t in SEV_KEYWORDS for t in sev_tokens):
        # Treat as severity filter
        sev_values = {SEV_NORMALIZE.get(t, t.capitalize()) for t in sev_tokens}
        events = [e for e in session.filtered_events if e.severity in sev_values]

        # Apply remaining (non-severity) pipe_ops
        remaining_ops = [p for p in parsed.pipe_ops if p.strip().lower() not in SEV_KEYWORDS]
        if remaining_ops and events:
            from logparse.pipeline import apply_pipeline, AggResult, extract_visual
            from logparse.output.table import render_agg
            ops, visual_type = extract_visual(remaining_ops)
            pipe_warnings: list[str] = []
            result = apply_pipeline(events, ops, warnings=pipe_warnings,
                                    all_events=session.all_events)
            for w in pipe_warnings:
                console.print(f"[yellow]{w}[/yellow]")
            if result and isinstance(result[0], AggResult):
                session.last_output = list(result)
                if visual_type:
                    from logparse.visual import render_agg_visual
                    render_agg_visual(result, visual_type, console)
                    session.log_command(parsed.raw, f"{len(result)} groups (severity: {', '.join(sorted(sev_values))})")
                    return
                render_agg(result, console)
                session.log_command(parsed.raw, f"{len(result)} groups (severity: {', '.join(sorted(sev_values))})")
                return
            events = result

        if not events:
            console.print(f"[dim]No events with severity: {', '.join(sorted(sev_values))}[/dim]")
        else:
            from logparse.output.table import render_table
            render_table(
                events, console,
                fields=session.display_columns,
                highlight=session.highlight,
                max_results=50,
                annotations=session.annotations if session.annotations else None,
            )
        session.log_command(parsed.raw, f"{len(events)} events (severity: {', '.join(sorted(sev_values))})")
        return

    # show <field>:<value> or <field>=<value> — treat as scratch filter
    # Catches "show Source:sw*", "show sev:High", "show * Source:sw*", etc.
    if re.search(r'\w+[:=]\S', args):
        from logparse.filter_engine import parse_conditions, match_event
        # Split optional column prefix from filter (e.g., "* Source:sw*")
        parts = args.split(None, 1)
        if len(parts) == 2 and parts[0] in ("*", "**", "all", "all-fields"):
            col_part, filter_part = parts
        elif len(parts) == 2 and not re.search(r'[:=]', parts[0]):
            col_part, filter_part = parts
        else:
            col_part, filter_part = "", args

        extra = {f.lower() for f in session.all_field_names()}
        conditions = parse_conditions(filter_part, extra_fields=extra)
        if conditions:
            if col_part in ("*", "all"):
                display_cols, _ = _smart_columns(session)
            elif col_part == "**" or col_part.lower() == "all-fields":
                display_cols = session.all_field_names()
            elif col_part:
                display_cols = [c.strip() for c in col_part.split(",")]
            else:
                display_cols = session.display_columns

            events = [e for e in session.filtered_events if match_event(e, conditions)]
            from logparse.output.table import render_table
            render_table(
                events, console,
                fields=display_cols,
                highlight=session.highlight,
                max_results=50,
                annotations=session.annotations if session.annotations else None,
            )
            session.log_command(parsed.raw, f"{len(events)} events (scratch)")
            return

    # show <field> contains <value> — delegate to filter_engine
    contains_m = re.match(r'^(\w+)\s+contains\s+(.+)$', args, re.I)
    if contains_m:
        from logparse.filter_engine import parse_conditions, match_event
        extra = {f.lower() for f in session.all_field_names()}
        conditions = parse_conditions(args, extra_fields=extra)
        if conditions:
            events = [e for e in session.filtered_events if match_event(e, conditions)]
            value = contains_m.group(2).strip().strip('"').strip("'")
            from logparse.output.table import render_table
            render_table(events, console, fields=session.display_columns,
                         highlight=value, max_results=50)
            session.log_command(parsed.raw, f"{len(events)} events (contains)")
            return

    # show config section — match against event sources (e.g. "vpn ipsec", "router bgp")
    args_lower = args.strip().lower()
    config_matches = [
        e for e in session.all_events
        if args_lower in (e.source or "").lower()
    ]
    if config_matches:
        console.print(f"[bold]{len(config_matches)} events matching source '{args}'[/bold]\n")
        for e in config_matches:
            if e.raw:
                console.print(f"[dim]{e.raw.rstrip()}[/dim]")
            else:
                console.print(f"  {e.message}")
        session.log_command(parsed.raw, f"{len(config_matches)} config entries")
        return

    # fallback: treat as field name — but only if it's a known field
    field_candidate = args.strip()
    all_fields = {f.lower() for f in session.all_field_names()}
    if field_candidate.lower() in all_fields:
        session.display_columns = [field_candidate]
        _show_events(session, console, parsed)
        session.log_command(parsed.raw, f"column: {field_candidate}")
        return

    # fallback: if it looks like a search pattern, grep for it
    from logparse.filter_engine import grep_events
    grep_pattern = args.strip().strip("*").strip('"').strip("'")
    if grep_pattern and len(grep_pattern) >= 2:
        hits = grep_events(session.filtered_events, grep_pattern)
        if hits:
            console.print(f"[dim]-> search \"{grep_pattern}\"[/dim]")
            from logparse.output.table import render_table
            render_table(
                hits, console,
                fields=session.display_columns,
                highlight=grep_pattern,
                max_results=50,
            )
            session.log_command(parsed.raw, f"{len(hits)} events (grep fallback)")
            return

    # nothing matched — helpful error
    console.print(f"[yellow]Unknown show target: '{args}'[/yellow]")
    console.print("[dim]Usage: show [sources|fields|N|N -a|*|<field>] or 'show ?' for help[/dim]")
    session.log_command(parsed.raw, "unrecognized")


def _apply_pipe_extraction(session, events, pipe_ops, console) -> None:
    """Handle pipe ops including field extraction and $variable storage."""
    from logparse.models import get_field
    from logparse.commands.variables import store_variable

    field_name = None
    var_name = None
    remaining_ops = []

    for op in pipe_ops:
        op = op.strip()
        if op.lower().startswith("field "):
            field_name = op[6:].strip()
        elif op.startswith("$"):
            var_name = op[1:]
            # Auto-extract field if variable name matches a known field
            if field_name is None and var_name:
                known = {f.lower() for f in session.all_field_names()}
                if var_name.lower() in known:
                    field_name = var_name
        elif op.lower().startswith("annotate "):
            # handle annotate as pipe op: show N | annotate "text"
            note_text = op[9:].strip().strip('"').strip("'")
            if note_text and events:
                # Build id-to-index map for O(1) lookup instead of O(n) list.index()
                _id_to_idx = {id(e): i + 1 for i, e in enumerate(session.filtered_events)}
                for e in events:
                    idx = _id_to_idx.get(id(e))
                    if idx is not None:
                        session.annotations[idx] = note_text
                        console.print(f"Annotated event #{idx}: {note_text}")
                        break
                else:
                    console.print("[red]Could not determine event index for annotation.[/red]")
            return
        elif op.lower().startswith("copy "):
            # handle copy as pipe op
            copy_target = op[5:].strip()
            from logparse.output.clipboard import copy_to_clipboard
            if field_name:
                values = [get_field(e, field_name) or "" for e in events]
                text = "\n".join(v for v in values if v)
            else:
                text = copy_target
            if copy_to_clipboard(text):
                console.print(f"Copied to clipboard ({len(text)} chars).")
            else:
                console.print("[yellow]Clipboard not available.[/yellow]")
            return
        else:
            remaining_ops.append(op)

    # apply remaining pipeline ops
    if remaining_ops:
        from logparse.pipeline import apply_pipeline
        pipe_warnings = []
        events = apply_pipeline(events, remaining_ops, warnings=pipe_warnings,
                               all_events=session.all_events)
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")

    # store variable
    if var_name:
        summary = store_variable(session, var_name, events, field_name)
        console.print(summary)
        return

    # just field extraction — show values
    if field_name:
        values = [get_field(e, field_name) or "" for e in events if hasattr(e, 'extra')]
        for v in values[:20]:
            console.print(f"  {v}")
        return

    # render events
    from logparse.output.table import render_table
    render_table(
        events, console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=50,
    )


def _show_events(session: Session, console, parsed: ParsedCommand) -> None:
    """Render current filtered events with session display columns."""
    from logparse.output.table import render_table
    from logparse.pipeline import apply_pipeline, AggResult, extract_visual

    events = session.filtered_events

    # apply pipe ops if present
    if parsed.pipe_ops:
        # check for $variable at end
        if any(op.strip().startswith("$") for op in parsed.pipe_ops):
            _apply_pipe_extraction(session, events, parsed.pipe_ops, console)
            return
        ops, visual_type = extract_visual(parsed.pipe_ops)
        pipe_warnings = []
        result = apply_pipeline(events, ops, warnings=pipe_warnings,
                               all_events=session.all_events)
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")
        if result and isinstance(result[0], AggResult):
            session.last_output = list(result)
            if visual_type:
                from logparse.visual import render_agg_visual
                render_agg_visual(result, visual_type, console)
                return
            from logparse.output.table import render_agg
            render_agg(result, console)
            return
        events = result

    render_table(
        events, console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=50,
        annotations=session.annotations if session.annotations else None,
    )


def _show_event_list(events, session, console, parsed) -> None:
    """Render a list of events."""
    from logparse.output.table import render_table
    render_table(
        events, console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=50,
    )


def _resolve_row_field(session: Session, row_num: int, field_name: str) -> str | None:
    """Resolve N.field from last output (events or AggResults)."""
    from logparse.pipeline import AggResult

    output = session.last_output
    if not output:
        # fall back to filtered_events
        output = session.filtered_events

    idx = row_num - 1
    if idx < 0 or idx >= len(output):
        return None

    item = output[idx]
    if isinstance(item, AggResult):
        # for aggregation results, "field" refers to the key column
        fl = field_name.lower()
        if fl == "key" or (fl == item.field.lower() if item.field else False):
            return item.key
        if fl == "count":
            return str(item.count)
        # try the key as the field name (most common: srcip, dstport, etc.)
        return item.key
    else:
        # LogEvent
        return get_field(item, field_name)
