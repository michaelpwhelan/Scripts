#!/usr/bin/env python3
"""rules command — load and evaluate JSON correlation rules."""

from __future__ import annotations

from logparse.commands import register, sev_color, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "rules",
    r"^rules(?:\s+.+)?$",
    category="Detection",
    usage="rules load [dir] | rules scan | rules list",
    help=(
        "Manage JSON-declarative correlation rules.  "
        "'rules load' loads from ~/.logparse/rules/.  "
        "'rules scan' evaluates loaded rules against current events.  "
        "'rules list' shows loaded rules."
    ),
)
def cmd_rules(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Manage JSON-declarative correlation rules."""
    from pathlib import Path

    from logparse.config_loader import get_config_dir
    from logparse.correlation_rules import (
        evaluate_all_rules,
        load_rules,
    )

    console = ctx.console
    args_str = (parsed.args or "").strip()
    parts = args_str.split(None, 1)
    subcmd = parts[0].lower() if parts else ""

    if subcmd == "load":
        rules_dir = Path(parts[1]) if len(parts) > 1 else get_config_dir() / "rules"
        if not rules_dir.is_dir():
            console.print(f"[dim]No rules directory at {rules_dir}[/dim]")
            return
        rules = load_rules(rules_dir)
        if not rules:
            console.print(f"[dim]No rule files found in {rules_dir}[/dim]")
            return
        session.variables["_correlation_rules"] = rules
        console.print(
            f"[green]Loaded {len(rules)} correlation rule(s) from {rules_dir}[/green]"
        )
        session.log_command(ctx.raw_input, f"loaded {len(rules)} rules")

    elif subcmd == "scan":
        rules = session.variables.get("_correlation_rules", [])
        if not rules:
            console.print("[dim]No rules loaded. Use 'rules load' first.[/dim]")
            return
        events = session.filtered_events
        if not events:
            console.print("[dim]No events.[/dim]")
            return

        matches = evaluate_all_rules(rules, events)
        if not matches:
            console.print("[dim]No correlation rule matches.[/dim]")
            return

        from rich.table import Table

        table = Table(title="Correlation Rule Matches")
        table.add_column("Rule", style="bold")
        table.add_column("Severity")
        table.add_column("Entity")
        table.add_column("Events", justify="right")
        table.add_column("MITRE")
        table.add_column("Time Span")

        for m in matches:
            sev = sev_color(m.rule.severity)
            mitre = ", ".join(m.rule.mitre_techniques) if m.rule.mitre_techniques else "-"
            span = ""
            if m.first_seen and m.last_seen:
                delta = m.last_seen - m.first_seen
                span = str(delta).split(".")[0]
            table.add_row(
                m.rule.name,
                sev,
                m.linked_value,
                str(m.total_events),
                mitre,
                span or "-",
            )
        console.print(table)
        session.log_command(ctx.raw_input, f"{len(matches)} rule matches")

    elif subcmd == "list":
        rules = session.variables.get("_correlation_rules", [])
        if not rules:
            console.print("[dim]No rules loaded. Use 'rules load' first.[/dim]")
            return
        console.print("[bold]Loaded Correlation Rules:[/bold]")
        for r in rules:
            sev = sev_color(r.severity)
            stages = len(r.conditions)
            console.print(
                f"  [cyan]{r.rule_id}[/cyan] {r.name} "
                f"({sev}, {stages} stage{'s' if stages != 1 else ''})"
            )
            if r.description:
                console.print(f"    {r.description}")

    else:
        console.print("[dim]Usage: rules load [dir] | rules scan | rules list[/dim]")


