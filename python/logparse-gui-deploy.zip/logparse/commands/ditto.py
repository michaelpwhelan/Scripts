#!/usr/bin/env python3
"""ditto command — replay session, append to last command, or modify last command."""

from __future__ import annotations

import logging

import re

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand, parse_command
from logparse.util import format_number


def _last_non_ditto(session: Session) -> str | None:
    """Walk transcript backward to find last command that isn't a ditto."""
    for entry in reversed(session.transcript):
        if not entry.command.startswith("ditto"):
            return entry.command
    return None


@register(
    "ditto",
    r"^ditto(\s+.*)?$",
    category="Session",
    usage="ditto [<file>|AND|OR <cond>|<mod>] | ditto | <pipe_op>",
    help="Replay session against file, append/modify last command, or replay with pipes.",
)
def cmd_ditto(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Replay session against file, append/modify last command, or replay with pipes."""
    from logparse.commands import dispatch

    console = ctx.console
    args = parsed.args.strip() if parsed.args else ""

    # need a previous command for bare/pipe/modify modes
    if not args and not session.transcript:
        console.print("[red]No previous command to replay.[/red]")
        return

    # Bare ditto — replay last command as-is
    if not args and not parsed.pipe_ops:
        last_cmd = _last_non_ditto(session)
        if not last_cmd:
            console.print("[red]No previous non-ditto command to replay.[/red]")
            return
        console.print(f"[dim]{last_cmd}[/dim]")
        dispatch(session, parse_command(last_cmd), ctx)
        session.log_command(parsed.raw, f"ditto replay: {last_cmd}")
        return

    # Pipe-only ditto — append pipe ops to last command
    if not args and parsed.pipe_ops:
        last_cmd = _last_non_ditto(session)
        if not last_cmd:
            console.print("[red]No previous non-ditto command to replay.[/red]")
            return
        new_cmd = last_cmd + " | " + " | ".join(parsed.pipe_ops)
        console.print(f"[dim]{new_cmd}[/dim]")
        dispatch(session, parse_command(new_cmd), ctx)
        session.log_command(parsed.raw, f"ditto pipe: {new_cmd}")
        return

    # Mode 1: file replay (arg looks like a filename with extension)
    # Reject shell metacharacters ($, `, (, ), |, ;) to avoid injection-like paths
    if (re.match(r"^[\w./_-]+\.\w+$", args)
            and not args.startswith("AND ") and not args.startswith("OR ")
            and not re.search(r"[$`()|;]", args)):
        _ditto_file(session, args, ctx)
        return

    # need a previous command to append/modify
    if not session.transcript:
        console.print("[red]No previous command to modify.[/red]")
        return

    # Find the last non-ditto command to avoid chaining ditto on ditto
    last_cmd = ""
    for entry in reversed(session.transcript):
        if not entry.command.strip().lower().startswith("ditto"):
            last_cmd = entry.command
            break
    if not last_cmd:
        last_cmd = session.transcript[-1].command

    # Mode 2: append (starts with AND or OR)
    if re.match(r"^(AND|OR)\s+", args, re.I):
        new_cmd = f"{last_cmd} {args}"
        # undo previous filter first
        session.undo()
        console.print(f"[dim]{new_cmd}[/dim]")
        pcmd = parse_command(new_cmd)
        try:
            dispatch(session, pcmd, ctx)
        except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
            logging.getLogger(__name__).debug("ditto error: %s", exc, exc_info=True)
            console.print(f"[red]Error: {exc}[/red]")
        session.log_command(parsed.raw, f"ditto append: {new_cmd}")
        return

    # Mode 3: modify — replace the tail of the last command
    # if last command had a pipe, replace everything after last pipe
    if "|" in last_cmd:
        parts = last_cmd.rsplit("|", 1)
        new_cmd = f"{parts[0].rstrip()}| {args}"
    else:
        # replace the whole command keeping the verb
        last_parts = last_cmd.split(None, 1)
        if last_parts:
            verb = last_parts[0]
            new_cmd = f"{verb} {args}" if not args.startswith(verb) else args
        else:
            new_cmd = args

    session.undo()
    console.print(f"[dim]{new_cmd}[/dim]")
    pcmd = parse_command(new_cmd)
    try:
        dispatch(session, pcmd, ctx)
    except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
        logging.getLogger(__name__).debug("ditto error: %s", exc, exc_info=True)
        console.print(f"[red]Error: {exc}[/red]")
    session.log_command(parsed.raw, f"ditto modify: {new_cmd}")


def _ditto_file(session: Session, filepath: str, ctx: CommandContext) -> None:
    """Mode 1: Replay session commands against a new file."""
    from logparse.loader import load_files
    from logparse.commands import dispatch

    console = ctx.console

    events, files, fmts = load_files([filepath], quiet=True)
    if not events:
        console.print(f"[red]No events loaded from {filepath}[/red]")
        return

    iso_session = Session(
        all_events=events,
        filtered_events=list(events),
        source_files=files,
        loaded_formats=fmts,
        display_columns=list(session.display_columns),
    )

    console.print(
        f"[bold]Replaying {len(session.transcript)} commands against {filepath}[/bold] "
        f"({format_number(len(events))} events)\n"
    )

    iso_ctx = CommandContext(console=console)

    for i, entry in enumerate(session.transcript, 1):
        console.print(f"[dim][{i}] {entry.command}[/dim]")
        pcmd = parse_command(entry.command)
        try:
            dispatch(iso_session, pcmd, iso_ctx)
        except SystemExit:
            pass
        except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
            logging.getLogger(__name__).debug("ditto replay error: %s", exc, exc_info=True)
            console.print(f"[red]  Error: {exc}[/red]")
        console.print()

    console.print(
        f"[bold]Replay complete.[/bold] "
        f"Result: {format_number(len(iso_session.filtered_events))} events"
    )
    console.print("[dim]Current session unchanged.[/dim]")
    session.log_command(f"ditto {filepath}", f"ditto {filepath}")
