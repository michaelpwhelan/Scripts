#!/usr/bin/env python3
"""Cross-source correlate command."""

from __future__ import annotations

import re
from collections import defaultdict
from datetime import datetime

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import LogEvent, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


_IP_RE = re.compile(r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
_IP_FIELDS = {"srcip", "dstip", "src", "dst", "ipaddr", "ip", "clientip",
              "remip", "natip", "natsrcip", "natdstip", "local_ip", "remote_ip"}
_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser", "account", "samaccountname", "upn"}


@register(
    "correlate",
    r"^correlate\s+.+",
    category="Analysis",
    usage="correlate <field> [<value>] | correlate from <N>",
    help="Trace an entity across all log sources.",
)
def cmd_correlate(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Trace an entity across all log sources."""
    console = ctx.console
    args = parsed.args.strip()

    # Mode 3: correlate from <N>
    m = re.match(r"^from\s+(\d+)$", args, re.I)
    if m:
        idx = int(m.group(1))
        if idx < 1 or idx > len(session.filtered_events):
            console.print(f"[red]Event #{idx} out of range (1-{len(session.filtered_events)})[/red]")
            return
        event = session.filtered_events[idx - 1]
        _correlate_from_event(event, idx, session, console)
        session.log_command(parsed.raw, f"correlate from #{idx}")
        return

    # Parse field and optional value
    parts = args.split(None, 1)
    field = parts[0]
    value = parts[1].strip() if len(parts) > 1 else None

    if value:
        # Mode 1/2: correlate field value
        _correlate_field_value(field, value, session, console)
        session.log_command(parsed.raw, f"correlate {field}={value}")
    else:
        # Mode 4: correlate field (breakdown by source)
        _correlate_field_breakdown(field, session, console)
        session.log_command(parsed.raw, f"correlate {field} breakdown")


def _correlate_field_value(field: str, value: str, session: Session, console: Console) -> None:
    """Find all events where field matches value across all sources."""
    matches: list[LogEvent] = []
    value_lower = value.lower()

    # Determine if we should also search related fields
    field_lower = field.lower()
    search_fields: set[str] = {field_lower}
    if field_lower in _IP_FIELDS:
        search_fields = _IP_FIELDS
    elif field_lower in _USER_FIELDS:
        search_fields = _USER_FIELDS

    for event in session.all_events:
        # Check specified field first
        for sf in search_fields:
            val = get_field(event, sf)
            if val and val.lower() == value_lower:
                matches.append(event)
                break
        else:
            # Also scan extra values for the target
            for v in event.extra.values():
                if v.lower() == value_lower:
                    matches.append(event)
                    break

    if not matches:
        console.print(f"[dim]No events found for {field}={value}[/dim]")
        return

    _render_correlated(matches, f"{field}={value}", session, console)


def _correlate_from_event(event: LogEvent, idx: int, session: Session, console: Console) -> None:
    """Extract key values from an event and find all related events."""
    # Extract interesting values
    search_values: set[str] = set()

    # IPs
    for f in _IP_FIELDS:
        val = get_field(event, f)
        if val and _IP_RE.match(val):
            search_values.add(val.lower())
    # Also scan raw for IPs
    for m in _IP_RE.finditer(event.raw):
        ip = m.group()
        # skip bogon-looking IPs
        if not ip.startswith("0.") and not ip.startswith("255."):
            search_values.add(ip)

    # Users
    for f in _USER_FIELDS:
        val = get_field(event, f)
        if val and len(val) > 1:
            search_values.add(val.lower())

    # Hostnames
    for f in ("hostname", "devname", "host", "computer"):
        val = get_field(event, f)
        if val and len(val) > 1:
            search_values.add(val.lower())

    if not search_values:
        console.print(f"[dim]No correlatable values found in event #{idx}[/dim]")
        return

    console.print(f"[bold]Correlating from event #{idx}[/bold]")
    console.print(f"[dim]Search values: {', '.join(sorted(search_values))}[/dim]")
    console.print()

    matches: list[LogEvent] = []
    for ev in session.all_events:
        # Check all extra values
        all_vals = set()
        for v in ev.extra.values():
            all_vals.add(v.lower())
        # Check core fields
        if ev.source:
            all_vals.add(ev.source.lower())
        # Check raw for IPs
        for m in _IP_RE.finditer(ev.raw):
            all_vals.add(m.group())

        if search_values & all_vals:
            matches.append(ev)

    label = f"event #{idx}"
    _render_correlated(matches, label, session, console)


def _correlate_field_breakdown(field: str, session: Session, console: Console) -> None:
    """Group events by field value, showing per-source breakdown."""
    groups: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))

    for event in session.all_events:
        val = get_field(event, field)
        if val:
            source = event.source_file or event.source or "(unknown)"
            groups[val][source] += 1

    if not groups:
        console.print(f"[dim]No values found for field '{field}'[/dim]")
        return

    # Sort by total count descending
    sorted_groups = sorted(
        groups.items(),
        key=lambda x: sum(x[1].values()),
        reverse=True,
    )

    console.print(f"[bold]Field '{field}' across {len(session.source_files)} sources[/bold]")
    console.print()

    for val, sources in sorted_groups[:20]:
        total = sum(sources.values())
        console.print(f"  [bold]{val}[/bold] — {format_number(total)} events")
        for src, cnt in sorted(sources.items(), key=lambda x: x[1], reverse=True):
            console.print(f"    {src}: {format_number(cnt)}")
        console.print()

    if len(sorted_groups) > 20:
        console.print(f"[dim]... and {len(sorted_groups) - 20} more values[/dim]")


def _render_correlated(matches: list[LogEvent], label: str, session: Session, console: Console) -> None:
    """Render correlated events grouped by source."""
    # Group by source file
    groups: dict[str, list[LogEvent]] = defaultdict(list)
    for ev in matches:
        key = ev.source_file or ev.source or "(unknown)"
        groups[key].append(ev)

    # Sort groups by earliest timestamp
    def group_sort_key(item) -> datetime:
        """Sort correlation groups by earliest timestamp."""
        _key, evts = item
        ts_list = [e.timestamp for e in evts if e.timestamp]
        return min(ts_list) if ts_list else datetime.max

    sorted_groups = sorted(groups.items(), key=group_sort_key)

    n_sources = len(sorted_groups)
    n_total = len(matches)
    console.print(f"[bold]Correlating {label} across {len(session.source_files)} files[/bold]")
    console.print()

    for source, events in sorted_groups:
        # Sort events by timestamp
        events.sort(key=lambda e: (e.timestamp or datetime.min))
        fmt_name = events[0].source_format if events[0].source_format else ""
        if fmt_name:
            fmt_name = f" ({fmt_name})"
        console.print(f"  [bold cyan]{source}[/bold cyan]{fmt_name} — {len(events)} events")
        for ev in events[:10]:
            ts = ev.timestamp.strftime("%Y-%m-%d %H:%M:%S") if ev.timestamp else "                   "
            msg = ev.message[:60] if ev.message else ""
            sev = ev.severity
            console.print(f"    {ts}  {msg:<60}  {sev}")
        if len(events) > 10:
            console.print(f"    [dim]... and {len(events) - 10} more[/dim]")
        console.print()

    console.print(
        f"  [bold]Total: {format_number(n_total)} events "
        f"across {n_sources} sources[/bold]"
    )
