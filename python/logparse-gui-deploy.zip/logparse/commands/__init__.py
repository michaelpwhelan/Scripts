#!/usr/bin/env python3
"""Command registry and dispatch for REPL."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Callable

from rich.console import Console

from logparse.session import Session
from logparse.syntax import ParsedCommand


@dataclass
class Command:
    """Registered REPL command."""

    name: str
    pattern: re.Pattern[str]
    handler: Callable[[Session, ParsedCommand, "CommandContext"], None]
    category: str
    usage: str
    help: str


@dataclass
class CommandContext:
    """Shared context passed to command handlers."""

    console: Console
    raw_input: str = ""


def sev_color(sev: str) -> str:
    """Wrap a severity/tier string in Rich color markup."""
    _COLORS = {
        "Critical": "[bold red]Critical[/bold red]",
        "High": "[red]High[/red]",
        "Medium": "[yellow]Medium[/yellow]",
        "Low": "[green]Low[/green]",
        "Info": "[cyan]Info[/cyan]",
    }
    return _COLORS.get(sev, sev)


_REGISTRY: list[Command] = []


def register(
    name: str,
    pattern: str,
    category: str = "General",
    usage: str = "",
    help: str = "",
) -> Callable:
    """Decorator to register a command handler."""
    compiled = re.compile(pattern, re.IGNORECASE)

    def decorator(fn) -> Callable:
        """Register fn as a command handler and return it."""
        _REGISTRY.append(Command(
            name=name,
            pattern=compiled,
            handler=fn,
            category=category,
            usage=usage or name,
            help=help or fn.__doc__ or "",
        ))
        return fn

    return decorator


def dispatch(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> bool:
    """Find and execute matching command. Returns True if handled."""
    raw = parsed.raw.strip()
    if not raw:
        return True

    # detect and strip `ro` (read-only) modifier from end
    ro_mode = False
    test_raw = raw
    if re.match(r".*\s+ro\s*$", raw, re.I):
        ro_mode = True
        test_raw = re.sub(r"\s+ro\s*$", "", raw, flags=re.I)
        # rebuild parsed with ro stripped
        from logparse.syntax import parse_command
        parsed = parse_command(test_raw)

    # When pipe ops are present, match against the verb+args portion only
    # so that $ anchors in patterns (e.g. count, dedup) aren't blocked.
    if parsed.pipe_ops:
        match_text = (parsed.verb + " " + parsed.args).strip() if parsed.args else parsed.verb
    else:
        match_text = test_raw

    for cmd in _REGISTRY:
        if cmd.pattern.match(match_text):
            if ro_mode:
                _run_readonly(session, parsed, ctx, cmd)
            else:
                cmd.handler(session, parsed, ctx)
            return True

    # fuzzy match suggestion
    best = _fuzzy_match(parsed.verb)
    if best:
        console = ctx.console
        console.print(f"[yellow]Unknown command. Did you mean: {best}?[/yellow]")
        return True

    return False


def _run_readonly(session: Session, parsed: ParsedCommand, ctx: CommandContext, cmd: Command) -> None:
    """Execute a command in read-only mode — snapshot, run, restore."""
    import copy
    # .copy() is atomic in CPython (C-level dict copy under lock), so it
    # avoids key/value misalignment when a timed-out daemon thread is
    # concurrently modifying session.__dict__.
    snapshot = copy.deepcopy(session.__dict__.copy())

    try:
        cmd.handler(session, parsed, ctx)
        ctx.console.print("[dim](read-only — session unchanged)[/dim]")
    finally:
        session.__dict__.update(snapshot)
        # Guard against deepcopy or daemon-thread races corrupting typed fields.
        # hide_rules must always be a list (not dict from a stale snapshot).
        if not isinstance(session.hide_rules, list):
            session.hide_rules = list(session.hide_rules) if session.hide_rules else []


def _fuzzy_match(verb: str) -> str | None:
    """Find closest command name by edit distance.

    Never suggests the exact verb that was typed (distance 0).
    """
    if not verb:
        return None
    best_name = None
    best_dist = 3  # threshold
    for cmd in _REGISTRY:
        d = _levenshtein(verb.lower(), cmd.name.lower())
        if d == 0:
            continue  # exact match — don't suggest what they already typed
        if d < best_dist:
            best_dist = d
            best_name = cmd.name
    return best_name


def _levenshtein(a: str, b: str) -> int:
    if len(a) < len(b):
        return _levenshtein(b, a)
    if not b:
        return len(a)
    prev = list(range(len(b) + 1))
    for i, ca in enumerate(a):
        curr = [i + 1]
        for j, cb in enumerate(b):
            curr.append(min(
                prev[j + 1] + 1,
                curr[j] + 1,
                prev[j] + (0 if ca == cb else 1),
            ))
        prev = curr
    return prev[-1]


def can_dispatch(raw_command: str) -> bool:
    """Check if a command string would match a registered handler (no execution)."""
    from logparse.syntax import parse_command as _parse
    parsed = _parse(raw_command)
    if not parsed.raw.strip():
        return False
    test_raw = parsed.raw.strip()
    if re.match(r".*\s+ro\s*$", test_raw, re.I):
        test_raw = re.sub(r"\s+ro\s*$", "", test_raw, flags=re.I)
        parsed = _parse(test_raw)
    if parsed.pipe_ops:
        match_text = (parsed.verb + " " + parsed.args).strip() if parsed.args else parsed.verb
    else:
        match_text = test_raw
    return any(cmd.pattern.match(match_text) for cmd in _REGISTRY)


def dispatch_readonly(session: Session, raw_command: str, ctx: CommandContext) -> bool:
    """Parse and dispatch a command in read-only mode. Returns True if handled."""
    from logparse.syntax import parse_command as _parse
    parsed = _parse(raw_command)
    raw = parsed.raw.strip()
    if not raw:
        return False
    if parsed.pipe_ops:
        match_text = (parsed.verb + " " + parsed.args).strip() if parsed.args else parsed.verb
    else:
        match_text = raw
    for cmd in _REGISTRY:
        if cmd.pattern.match(match_text):
            _run_readonly(session, parsed, ctx, cmd)
            return True
    return False


def get_registry() -> list[Command]:
    """Return a copy of the command registry."""
    return list(_REGISTRY)


def get_categories() -> dict[str, list[Command]]:
    """Return commands grouped by category."""
    cats: dict[str, list[Command]] = {}
    for cmd in _REGISTRY:
        cats.setdefault(cmd.category, []).append(cmd)
    return cats


# Import all command modules to trigger registration.
# NOTE: baseline_cmd must come BEFORE baseline so its more-specific
# patterns (baseline build/check/list/delete) match first.
from logparse.commands import (  # noqa: E402, F401
    show, where, search, preview, display,
    session_cmds, meta,
    variables, star, context, shell,
    export,
    diff, analyze, report, config, ditto,
    hide, remember, sample, visual, switch_context,
    cheatsheet, tutorial, dashboard, summary_cmd, annotate, run,
    session_io, geo, correlate,
    mitre_cmd, anomaly_cmd, profile,
    top, deduplicate, derive,
    asn, reputation, dns_cmd, ports,
    trend, threshold, baseline_cmd, baseline, user_activity,
    tag, macro, alias,
    fetch_cmd, ioc_cmd, entity_cmd, rules_cmd, investigate_cmd,
)
