#!/usr/bin/env python3
"""where command — filter with stack push.

All filter parsing is delegated to :mod:`filter_engine`.  This module
handles session integration (push_filter, undo), pipeline dispatch, and
the ``time_window`` cutoff pre-computation that the engine cannot do
per-event efficiently.
"""

from __future__ import annotations

from logparse.commands import register, CommandContext
from logparse.filter_engine import (
    Condition, is_known_field, match_event, parse_conditions,
)
from logparse.session import Session
from logparse.severity import SEV_KEYWORDS, SEV_NORMALIZE
from logparse.syntax import ParsedCommand
from logparse.util import format_number


def _resolve_time_window(conditions: list[Condition], events) -> None:
    """Convert time_window conditions from raw-seconds to epoch cutoff.

    ``parse_conditions("last 2h")`` stores seconds as the pattern.
    We need the max timestamp from *events* to compute a real cutoff,
    then mutate the condition in-place so ``match_event`` can compare
    directly.
    """
    from datetime import timedelta

    for cond in conditions:
        if cond.op != "time_window":
            continue
        try:
            seconds = float(cond.pattern)
        except (ValueError, TypeError):
            continue
        if seconds > 1_000_000_000:
            continue  # already an epoch cutoff

        ts_events = [e for e in events if e.timestamp]
        if not ts_events:
            continue
        max_ts = max(e.timestamp for e in ts_events)
        cutoff = max_ts - timedelta(seconds=seconds)
        cond.pattern = str(cutoff.timestamp())


def _do_where(session: Session, parsed: ParsedCommand, ctx: CommandContext,
               *, source: str = "filtered") -> None:
    """Core where implementation. source='filtered' (default) or 'all' (refilter)."""
    from logparse.pipeline import apply_pipeline, AggResult
    from logparse.output.table import render_agg, render_table

    console = ctx.console
    query = parsed.args.strip()
    pipe_ops = parsed.pipe_ops

    # Select event source
    events = session.filtered_events if source == "filtered" else list(session.all_events)

    if source == "filtered" and not session.filtered_events:
        console.print("[yellow]Warning: current view is empty — filter has no effect. "
                      "Use 'undo', 'reset', or 'where!' to filter from all events.[/yellow]")

    extra = session.field_names_lower()
    conditions = parse_conditions(query, extra_fields=extra)
    if not conditions:
        tokens = query.split()
        if len(tokens) >= 2 and is_known_field(tokens[0].lower(), extra):
            console.print(f"[yellow]Tip: try '{tokens[0]}:{tokens[1]}'[/yellow]")
        else:
            console.print("[red]Invalid filter expression.[/red]")
        return

    # Pre-compute time_window cutoffs (needs event timestamps)
    _resolve_time_window(conditions, events)

    # Merge bare severity keywords from pipe_ops into the filter
    # (e.g., "where severity high|critical" → treat |critical as OR, not pipe)
    sev_merge = []
    remaining_pipe = []
    for op in pipe_ops:
        if op.strip().lower() in SEV_KEYWORDS:
            sev_merge.append(op.strip().lower())
        else:
            remaining_pipe.append(op)
    if sev_merge:
        merged = False
        for cond in conditions:
            if cond.field.lower() == "severity" and cond.op in ("eq", "in"):
                existing = {v.strip() for v in cond.pattern.split(",")}
                for s in sev_merge:
                    existing.add(SEV_NORMALIZE.get(s, s.capitalize()))
                cond.pattern = ",".join(sorted(existing))
                cond.op = "in"
                merged = True
                break
        if not merged:
            # No existing severity condition — add one
            vals = ",".join(SEV_NORMALIZE.get(s, s.capitalize()) for s in sev_merge)
            conditions.append(Condition("severity", vals, "in", False, "OR"))
        pipe_ops = remaining_pipe

    session.push_filter(query)
    session.filtered_events = [
        e for e in events if match_event(e, conditions)
    ]

    count = len(session.filtered_events)
    summary = f"{format_number(count)} events"

    # apply pipeline if present
    if pipe_ops:
        from logparse.pipeline import extract_visual
        ops, visual_type = extract_visual(pipe_ops)
        pipe_warnings = []
        result = apply_pipeline(session.filtered_events, ops, warnings=pipe_warnings,
                               all_events=session.all_events)
        session._pipeline_warnings = pipe_warnings
        for w in pipe_warnings:
            console.print(f"[yellow]{w}[/yellow]")
        if result and isinstance(result[0], AggResult):
            session.last_output = list(result)
            if visual_type:
                from logparse.visual import render_agg_visual
                render_agg_visual(result, visual_type, console)
                session.log_command(parsed.raw, summary)
                return
            render_agg(result, console)
            session.log_command(parsed.raw, summary)
            return
        render_table(
            result, console,
            fields=session.display_columns,
            highlight=session.highlight,
            max_results=50,
        )
        session.log_command(parsed.raw, summary)
        return

    console.print(f"[bold]{summary}[/bold] (filter: {query})")
    session.log_command(parsed.raw, summary)


@register(
    "where",
    r"^where\s+.+",
    category="Filter",
    usage=(
        "where <field>:<value> | where <field>>=<N> | where has:<field> | "
        "where last <N>h | where between HH:MM and HH:MM"
    ),
    help="Filter events and push to history (stackable). Supports :, =, >, <, >=, <=, !=, has:, in, last, between.",
)
def cmd_where(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Filter events and push to history (stackable)."""
    _do_where(session, parsed, ctx, source="filtered")


@register(
    "where!",
    r"^where!\s+.+",
    category="Filter",
    usage="where! <filter> — filter from ALL events (ignoring current filters)",
    help="Like 'where' but refilters from all loaded events instead of the current view.",
)
def cmd_where_bang(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Like 'where' but refilters from all loaded events instead of the current view."""
    ctx.console.print("[dim]Refiltering from all events...[/dim]")
    _do_where(session, parsed, ctx, source="all")


@register(
    "not",
    r"^not\s+.+",
    category="Filter",
    usage="not <field>:<value> — shorthand for where !<field>:<value>",
    help="Exclude events matching the condition. Alias for 'where !' negation.",
)
def cmd_not(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Exclude events matching the condition."""
    query = parsed.args.strip()
    # Prepend ! to the first field:value condition
    if not query.startswith("!"):
        query = "!" + query
    parsed = ParsedCommand(verb="where", args=query, pipe_ops=parsed.pipe_ops, raw=parsed.raw)
    _do_where(session, parsed, ctx, source="filtered")


@register(
    "last",
    r"^last\s+\d+\s*[smhd]",
    category="Filter",
    usage="last <N>h | last <N>m | last <N>d",
    help="Shorthand for 'where last <N>h'. Filters to events within the time window.",
)
def cmd_last(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Shorthand for 'where last <N>h'."""
    parsed = ParsedCommand(verb="where", args=f"last {parsed.args}", pipe_ops=parsed.pipe_ops, raw=parsed.raw)
    _do_where(session, parsed, ctx, source="filtered")
