#!/usr/bin/env python3
"""Playbook / config loading commands."""

from __future__ import annotations

import logging

import json
from pathlib import Path

from logparse.commands import register, CommandContext
from logparse.config_loader import get_config_dir
from logparse.session import Session
from logparse.syntax import ParsedCommand

_config_dir = get_config_dir()

_PLAYBOOK_DIRS = [
    Path(__file__).parent.parent / "playbooks",  # shipped
    _config_dir / "playbooks",  # user
    _config_dir / "routines",  # routines
]


@register(
    "load",
    r"^load\s+config\s+.+",
    category="Playbook",
    usage="load config <file.json>",
    help="Execute a playbook (sequence of commands).",
)
def cmd_load_config(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Execute a playbook (sequence of commands)."""
    import re
    console = ctx.console
    m = re.match(r"^config\s+(.+)$", parsed.args.strip(), re.I)
    if not m:
        console.print("[red]Usage: load config <file.json>[/red]")
        return

    name = m.group(1).strip()
    filepath = _find_playbook(name)
    if not filepath:
        console.print(f"[red]Playbook not found: {name}[/red]")
        return

    execute_playbook(session, filepath, ctx)


@register(
    "playbook",
    r"^playbook\s+.+",
    category="Playbook",
    usage="playbook list | playbook create <name>",
    help="List or create playbooks.",
)
def cmd_playbook(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """List or create playbooks."""
    console = ctx.console
    args = parsed.args.strip()

    if args.lower() == "list":
        found = False
        for d in _PLAYBOOK_DIRS:
            if d.exists():
                for f in sorted(d.glob("*.json")):
                    try:
                        data = json.loads(f.read_text(encoding="utf-8"))
                        name = data.get("name", f.stem)
                        cmds = len(data.get("commands", []))
                        console.print(f"  {f.name:<30} {name} ({cmds} commands)")
                        found = True
                    except (json.JSONDecodeError, OSError):
                        pass
        if not found:
            console.print("[dim]No playbooks found.[/dim]")
        session.log_command(parsed.raw, "playbook list")
        return

    if args.lower().startswith("create "):
        name = args[7:].strip()
        if not name:
            console.print("[red]Usage: playbook create <name>[/red]")
            return

        commands = [entry.command for entry in session.transcript]
        data = {"name": name, "commands": commands}

        user_dir = _PLAYBOOK_DIRS[1]
        user_dir.mkdir(parents=True, exist_ok=True)
        filepath = user_dir / f"{name}.json"
        filepath.write_text(json.dumps(data, indent=2), encoding="utf-8")
        console.print(f"Playbook saved: {filepath} ({len(commands)} commands)")
        session.log_command(parsed.raw, f"created {name}")
        return

    console.print("[red]Usage: playbook list | playbook create <name>[/red]")


def execute_playbook(session: Session, filepath: Path, ctx: CommandContext) -> None:
    """Execute a playbook file — shared by load config and run."""
    console = ctx.console

    try:
        data = json.loads(filepath.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError) as exc:
        console.print(f"[red]Failed to load playbook: {exc}[/red]")
        return

    commands = data.get("commands", [])
    pb_name = data.get("name", filepath.stem)
    console.print(f"[bold]Running playbook: {pb_name}[/bold] ({len(commands)} commands)\n")

    from logparse.syntax import parse_command
    from logparse.commands import dispatch

    # Block shell commands in playbooks to prevent command injection
    _BLOCKED_PREFIXES = ("!", "shell ", "run ", "sh ", "bash ", "exec ")

    for i, cmd_text in enumerate(commands, 1):
        cmd_stripped = cmd_text.strip()
        if any(cmd_stripped.lower().startswith(p) for p in _BLOCKED_PREFIXES):
            console.print(
                f"[red]  [{i}/{len(commands)}] Blocked: {cmd_text} "
                f"(shell commands not allowed in playbooks)[/red]"
            )
            continue

        console.print(f"[dim][{i}/{len(commands)}] {cmd_text}[/dim]")
        pcmd = parse_command(cmd_text)
        try:
            handled = dispatch(session, pcmd, ctx)
            if not handled:
                console.print(f"[yellow]  Unrecognized: {cmd_text}[/yellow]")
        except SystemExit:
            return
        except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
            logging.getLogger(__name__).debug(
                "Playbook command error: %s", exc, exc_info=True)
            console.print(f"[red]  Error: {exc}[/red]")
        console.print()

    console.print("[bold]Playbook complete.[/bold]")
    session.log_command(f"run {filepath.stem}", f"playbook {pb_name}")


def _find_playbook(name: str) -> Path | None:
    """Search playbook dirs for a matching file."""
    for d in _PLAYBOOK_DIRS:
        # exact path
        p = Path(name)
        if p.exists():
            return p
        # in playbook dirs
        candidate = d / name
        if candidate.exists():
            return candidate
        if not name.endswith(".json"):
            candidate = d / f"{name}.json"
            if candidate.exists():
                return candidate
    return None
