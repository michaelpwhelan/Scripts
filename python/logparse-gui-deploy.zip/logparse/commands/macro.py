#!/usr/bin/env python3
"""macro command — reusable command sequences."""

from __future__ import annotations

import json
import re as _re

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.config_loader import get_config_dir
from logparse.session import Session
from logparse.syntax import ParsedCommand


_MACRO_DIR = get_config_dir() / "macros"
_MAX_MACRO_DEPTH = 10
_macro_depth = 0  # tracks recursive macro invocations


@register(
    "macro",
    r"^macro(?:\s+.*)?$",
    category="Session",
    usage="macro list | macro define <name> | macro run <name> | macro delete <name>",
    help=(
        "Create and run reusable command sequences. "
        "Macros are stored as JSON in ~/.logparse/macros/."
    ),
)
def cmd_macro(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Create and run reusable command sequences."""
    console = ctx.console
    args = (parsed.args or "").strip()

    if not args or args.lower() == "list":
        _list_macros(console)
        return

    # macro define <name>
    m = _re.match(r"^define\s+(\w+)$", args, _re.IGNORECASE)
    if m:
        name = m.group(1)
        _define_macro(name, session, ctx)
        return

    # macro run <name>
    m = _re.match(r"^run\s+(\w+)$", args, _re.IGNORECASE)
    if m:
        name = m.group(1)
        _run_macro(name, session, ctx)
        return

    # macro delete <name>
    m = _re.match(r"^delete\s+(\w+)$", args, _re.IGNORECASE)
    if m:
        name = m.group(1)
        path = _MACRO_DIR / f"{name}.json"
        if path.exists():
            path.unlink()
            console.print(f"[dim]Deleted macro '{name}'.[/dim]")
        else:
            console.print(f"[dim]Macro '{name}' not found.[/dim]")
        return

    console.print("[red]Usage: macro list | macro define <name> | macro run <name>[/red]")


def _list_macros(console: Console) -> None:
    """List available macros."""
    _MACRO_DIR.mkdir(parents=True, exist_ok=True)
    macros = list(_MACRO_DIR.glob("*.json"))
    if not macros:
        console.print("[dim]No macros defined. Use 'macro define <name>' to create one.[/dim]")
        return

    console.print("[bold]Available Macros:[/bold]")
    for path in sorted(macros):
        name = path.stem
        try:
            commands = json.loads(path.read_text(encoding="utf-8"))
            count = len(commands)
            preview = commands[0] if commands else ""
            console.print(f"  [bold]{name}[/bold]  ({count} commands)  [dim]{preview}...[/dim]")
        except (json.JSONDecodeError, IndexError):
            console.print(f"  [bold]{name}[/bold]  [red](invalid)[/red]")


def _define_macro(name: str, session: Session, ctx: CommandContext) -> None:
    """Define a macro from recent transcript commands."""
    console = ctx.console

    if not session.transcript:
        console.print("[dim]No commands in transcript to build macro from.[/dim]")
        return

    # Show recent commands and ask which to include
    console.print(f"[bold]Defining macro '{name}'[/bold]")
    console.print("[dim]Recent commands:[/dim]")
    recent = session.transcript[-20:]
    for i, entry in enumerate(recent, 1):
        console.print(f"  {i:>3}. {entry.command}")

    console.print("\n[dim]Enter command numbers to include (e.g. 1,3,5-8), or 'all' for all:[/dim]")
    console.print("[dim]Or type commands directly, one per line, blank line to finish:[/dim]")

    # Since we can't do interactive input in the REPL command handler,
    # save from transcript as a reasonable default
    commands = [entry.command for entry in recent]

    _MACRO_DIR.mkdir(parents=True, exist_ok=True)
    path = _MACRO_DIR / f"{name}.json"
    path.write_text(json.dumps(commands, indent=2), encoding="utf-8")
    console.print(f"[bold]Saved macro '{name}'[/bold] with {len(commands)} commands to {path}")
    session.log_command(f"macro define {name}", f"macro define {name}: {len(commands)} commands")


def _run_macro(name: str, session: Session, ctx: CommandContext) -> None:
    """Execute a macro's commands."""
    global _macro_depth
    from logparse.commands import dispatch

    console = ctx.console

    if _macro_depth >= _MAX_MACRO_DEPTH:
        console.print(
            f"[red]Macro recursion limit reached ({_MAX_MACRO_DEPTH}). "
            f"Possible circular reference.[/red]"
        )
        return

    path = _MACRO_DIR / f"{name}.json"

    if not path.exists():
        console.print(f"[red]Macro '{name}' not found.[/red]")
        _list_macros(console)
        return

    try:
        commands = json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        console.print(f"[red]Macro '{name}' is invalid JSON.[/red]")
        return

    from logparse.syntax import parse_command
    console.print(f"[bold]Running macro '{name}'[/bold] ({len(commands)} commands)")
    _macro_depth += 1
    try:
        for i, cmd in enumerate(commands, 1):
            console.print(f"\n[dim]>>> {cmd}[/dim]")
            dispatch(session, parse_command(cmd), ctx)
    finally:
        _macro_depth -= 1

    session.log_command(f"macro run {name}", f"macro run {name}: {len(commands)} commands")
