#!/usr/bin/env python3
"""sample command — random spread of events."""

from __future__ import annotations

import random
from datetime import datetime

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "sample",
    r"^sample(\s+\d+)?$",
    category="Display",
    usage="sample [N]",
    help="Display N random events (default 10), sorted by timestamp.",
)
def cmd_sample(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Display N random events (default 10), sorted by timestamp."""
    from logparse.output.table import render_table

    console = ctx.console
    try:
        n = int(parsed.args.strip()) if parsed.args.strip() else 10
    except ValueError:
        console.print("[red]Usage: sample [N][/red]")
        return
    events = session.filtered_events

    if not events:
        console.print("[dim]No events.[/dim]")
        return

    n = min(n, len(events))
    # consistent seed from session start time for reproducibility
    seed = int(session.start_time.timestamp())
    rng = random.Random(seed)
    sampled = rng.sample(events, n)

    # sort by timestamp for readability
    sampled.sort(key=lambda e: e.timestamp if e.timestamp else datetime.max)

    console.print(f"[bold]Sample of {n} events[/bold] (of {format_number(len(events))})")
    render_table(
        sampled, console,
        fields=session.display_columns,
        highlight=session.highlight,
        max_results=n,
    )
    session.log_command(parsed.raw, f"sample {n}")
