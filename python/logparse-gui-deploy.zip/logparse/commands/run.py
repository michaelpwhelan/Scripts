#!/usr/bin/env python3
"""run command — syntactic sugar for loading routines."""

from __future__ import annotations


from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "run",
    r"^run\s+.+",
    category="Playbook",
    usage="run <routine>",
    help="Execute a routine from ~/.logparse/routines/.",
)
def cmd_run(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Execute a routine from ~/."""
    from logparse.commands.config import execute_playbook, _find_playbook

    console = ctx.console
    name = parsed.args.strip()

    # search routines dir first, then fall back to playbook dirs
    from logparse.config_loader import get_config_dir
    routines_dir = get_config_dir() / "routines"
    filepath = None

    if routines_dir.exists():
        # exact match
        candidate = routines_dir / name
        if candidate.exists():
            filepath = candidate
        elif not name.endswith(".json"):
            candidate = routines_dir / f"{name}.json"
            if candidate.exists():
                filepath = candidate

    # fall back to standard playbook search
    if filepath is None:
        filepath = _find_playbook(name)

    if filepath is None:
        console.print(f"[red]Routine not found: {name}[/red]")
        console.print(f"[dim]Searched: {routines_dir}[/dim]")
        return

    execute_playbook(session, filepath, ctx)
