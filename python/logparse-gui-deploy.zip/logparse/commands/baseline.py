#!/usr/bin/env python3
"""baseline command — learn normal distribution and flag outliers."""

from __future__ import annotations

import statistics

from logparse.commands import register, CommandContext
from logparse.models import get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "baseline",
    r"^baseline(?:\s+\w+)?$",
    category="Analysis",
    usage="baseline [field]",
    help=(
        "Compute baseline distribution for a numeric field and flag "
        "events with values >2 standard deviations from the mean. "
        "Without a field, shows stored baselines."
    ),
)
def cmd_baseline(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Compute baseline distribution for a numeric field and flag events with values >2 standard deviations from the mean."""
    from rich.table import Table

    console = ctx.console
    field = (parsed.args or "").strip()

    # No field — show stored baselines
    if not field:
        baselines = session.variables.get("_baselines", {})
        if not baselines:
            console.print("[dim]No baselines set. Usage: baseline <field>[/dim]")
            return
        console.print("[bold]Stored Baselines:[/bold]")
        for f, info in baselines.items():
            console.print(
                f"  {f}: mean={info['mean']:.2f}, stddev={info['stddev']:.2f}, "
                f"threshold=\u00b1{info['threshold']:.2f}"
            )
        return

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # Collect numeric values
    values: list[float] = []
    for e in events:
        val = get_field(e, field)
        if val is None:
            continue
        try:
            values.append(float(val))
        except (ValueError, TypeError):
            continue

    if len(values) < 3:
        console.print(f"[dim]Not enough numeric values for field '{field}' (need 3+, got {len(values)}).[/dim]")
        return

    mean = statistics.mean(values)
    stddev = statistics.stdev(values)
    threshold = 2 * stddev

    # Store baseline
    if "_baselines" not in session.variables:
        session.variables["_baselines"] = {}
    session.variables["_baselines"][field] = {
        "mean": mean,
        "stddev": stddev,
        "threshold": threshold,
        "count": len(values),
    }

    # Find outliers
    from rich.panel import Panel

    outlier_events = []
    for i, e in enumerate(events):
        val = get_field(e, field)
        if val is None:
            continue
        try:
            fval = float(val)
        except (ValueError, TypeError):
            continue
        deviation = abs(fval - mean)
        if deviation > threshold:
            sigma = deviation / stddev if stddev > 0 else 0
            outlier_events.append((i, e, fval, sigma))

    # Summary
    lines = [
        f"  [bold]Field:[/bold]     {field}",
        f"  [bold]Samples:[/bold]   {format_number(len(values))}",
        f"  [bold]Mean:[/bold]      {mean:,.2f}",
        f"  [bold]Stddev:[/bold]    {stddev:,.2f}",
        f"  [bold]Range:[/bold]     {min(values):,.2f} — {max(values):,.2f}",
        f"  [bold]Outliers:[/bold]  {len(outlier_events)} (>{threshold:,.2f} from mean)",
    ]
    console.print(Panel("\n".join(lines), title=f"Baseline: {field}", border_style="cyan"))

    # Outlier table
    if outlier_events:
        outlier_events.sort(key=lambda x: x[3], reverse=True)
        table = Table(title=f"Outliers ({len(outlier_events)})", border_style="yellow")
        table.add_column("#", justify="right", style="dim")
        table.add_column("Value", justify="right", style="bold red")
        table.add_column("Sigma", justify="right", style="yellow")
        table.add_column("Source")
        table.add_column("Message")

        for idx, e, fval, sigma in outlier_events[:20]:
            msg = e.message[:50] + "..." if len(e.message) > 50 else e.message
            table.add_row(
                str(idx + 1),
                f"{fval:,.2f}",
                f"{sigma:.1f}\u03c3",
                e.source[:15] if e.source else "",
                msg,
            )
        console.print(table)

    session.log_command(parsed.raw, f"baseline {field}: {len(outlier_events)} outliers")
