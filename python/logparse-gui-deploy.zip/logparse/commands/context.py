#!/usr/bin/env python3
"""context command — time window around matches."""

from __future__ import annotations

from bisect import bisect_left, bisect_right

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number, parse_duration


@register(
    "context",
    r"^context\s+.+",
    category="Filter",
    usage="context <duration>",
    help="Expand view to events within ±duration of current matches.",
)
def cmd_context(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Expand view to events within ±duration of current matches."""
    console = ctx.console
    duration_str = parsed.args.strip()
    delta = parse_duration(duration_str)
    if delta is None:
        console.print(f"[red]Invalid duration: {duration_str}[/red]")
        return

    # collect timestamps from current filtered events
    match_times = sorted(
        e.timestamp.timestamp()
        for e in session.filtered_events
        if e.timestamp
    )
    if not match_times:
        console.print("[dim]No timestamps in current view.[/dim]")
        return

    delta_secs = delta.total_seconds()

    # build sorted list of (timestamp_epoch, event) for all_events
    timed = sorted(
        ((e.timestamp.timestamp(), e) for e in session.all_events if e.timestamp),
        key=lambda x: x[0],
    )
    all_epochs = [t[0] for t in timed]

    # for each match_time, find events within ±delta using bisect
    result_indices: set[int] = set()
    for mt in match_times:
        lo = bisect_left(all_epochs, mt - delta_secs)
        hi = bisect_right(all_epochs, mt + delta_secs)
        for i in range(lo, hi):
            result_indices.add(i)

    # also include events without timestamps that were in filtered set
    result = [timed[i][1] for i in sorted(result_indices)]
    no_ts = [e for e in session.filtered_events if e.timestamp is None]
    result.extend(no_ts)

    before = len(session.filtered_events)
    session.push_filter(f"context ±{duration_str}")
    session.filtered_events = result

    console.print(
        f"[bold]Context ±{duration_str}[/bold]: "
        f"{format_number(before)} \u2192 {format_number(len(result))} events"
    )
    session.log_command(parsed.raw, f"{len(result)} events")
