#!/usr/bin/env python3
"""user command — user activity timeline and summary."""

from __future__ import annotations

import re as _re
from datetime import datetime

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.models import SEVERITY_LEVELS, get_field
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number

_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser", "account", "samaccountname", "upn"}


@register(
    "user",
    r"^user\s+\S+",
    category="Analysis",
    usage="user <name> [timeline]",
    help=(
        "Show activity for a specific user across all sources. "
        "Without 'timeline': summary of actions, sources, and time range. "
        "With 'timeline': chronological event list."
    ),
)
def cmd_user(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Show activity for a specific user across all sources."""
    console = ctx.console
    args = (parsed.args or "").strip()

    m = _re.match(r"^(\S+)(?:\s+(timeline))?$", args, _re.IGNORECASE)
    if not m:
        console.print("[red]Usage: user <name> [timeline][/red]")
        return

    username = m.group(1).lower()
    show_timeline = m.group(2) is not None
    events = session.all_events  # Search all events, not just filtered

    # Find matching events
    user_events = []
    for e in events:
        for field in _USER_FIELDS:
            val = get_field(e, field)
            if val and val.lower() == username:
                user_events.append(e)
                break

    if not user_events:
        console.print(f"[dim]No events found for user '{username}'.[/dim]")
        return

    user_events.sort(key=lambda e: e.timestamp if e.timestamp else datetime.max)

    if show_timeline:
        _show_timeline(username, user_events, console)
    else:
        _show_summary(username, user_events, console)

    session.log_command(parsed.raw, f"user {username}: {len(user_events)} events")


def _show_summary(username: str, events: list, console: Console) -> None:
    from collections import Counter
    from rich.panel import Panel

    sources: Counter[str] = Counter()
    actions: Counter[str] = Counter()
    severities: Counter[str] = Counter()
    source_ips: set[str] = set()

    for e in events:
        sources[e.source or e.source_file or "(unknown)"] += 1
        action = get_field(e, "action") or ""
        if action:
            actions[action] += 1
        severities[e.severity] += 1
        srcip = get_field(e, "srcip") or ""
        if srcip:
            source_ips.add(srcip)

    timestamps = [e.timestamp for e in events if e.timestamp]
    first = timestamps[0].strftime("%Y-%m-%d %H:%M") if timestamps else "?"
    last = timestamps[-1].strftime("%Y-%m-%d %H:%M") if timestamps else "?"

    lines = [
        f"  [bold]User:[/bold]        {username}",
        f"  [bold]Events:[/bold]      {format_number(len(events))}",
        f"  [bold]First seen:[/bold]  {first}",
        f"  [bold]Last seen:[/bold]   {last}",
        f"  [bold]Source IPs:[/bold]  {format_number(len(source_ips))}",
    ]
    console.print(Panel("\n".join(lines), title="User Summary", border_style="cyan"))

    # Sources
    if sources:
        console.print("\n[bold]Sources:[/bold]")
        for src, count in sources.most_common(10):
            console.print(f"  {src}: {format_number(count)}")

    # Actions
    if actions:
        console.print("\n[bold]Actions:[/bold]")
        for action, count in actions.most_common(10):
            console.print(f"  {action}: {format_number(count)}")

    # Severity breakdown
    console.print("\n[bold]Severity:[/bold]")
    for sev in SEVERITY_LEVELS:
        if severities[sev]:
            console.print(f"  {sev}: {severities[sev]}")


def _show_timeline(username: str, events: list, console: Console) -> None:
    from rich.table import Table

    console.print(f"[bold]Timeline for {username}[/bold] ({format_number(len(events))} events)")

    table = Table(border_style="dim", show_lines=False)
    table.add_column("Time", style="dim", width=19)
    table.add_column("Sev", width=8)
    table.add_column("Source", width=15)
    table.add_column("Action", width=12)
    table.add_column("Message", ratio=1)

    sev_colors = {"Critical": "red", "High": "bright_red", "Medium": "yellow", "Low": "green", "Info": "cyan"}

    for e in events[:50]:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else ""
        color = sev_colors.get(e.severity, "dim")
        sev = f"[{color}]{e.severity}[/{color}]"
        source = (e.source or "")[:15]
        action = (get_field(e, "action") or "")[:12]
        msg = (e.message or "")[:60] + ("..." if len(e.message or "") > 60 else "")
        table.add_row(ts, sev, source, action, msg)

    console.print(table)

    remaining = len(events) - 50
    if remaining > 0:
        console.print(f"  [dim]... and {format_number(remaining)} more events[/dim]")
