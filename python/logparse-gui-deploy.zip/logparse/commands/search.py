#!/usr/bin/env python3
"""search command — grep-style text search."""

from __future__ import annotations


from logparse.commands import register, CommandContext
from logparse.filter_engine import grep_events
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "search",
    r"^search\s+.+",
    category="Filter",
    usage='search [-s] ["pattern"] | search once "pattern"',
    help="Grep-style text search across all fields. Use -s for case-sensitive.",
)
def cmd_search(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Search events by regex pattern across all fields."""
    from logparse.output.table import render_table

    console = ctx.console
    args = parsed.args.strip()

    # detect "once" modifier
    once = False
    if args.lower().startswith("once "):
        once = True
        args = args[5:].strip()

    # -s / --case-sensitive for case-sensitive search; -i is a silent no-op
    case_sensitive = False
    if args.startswith("-s "):
        case_sensitive = True
        args = args[3:].strip()
    elif args.startswith("--case-sensitive "):
        case_sensitive = True
        args = args[17:].strip()
    elif args.startswith("-i "):
        args = args[3:].strip()

    # strip quotes
    pattern = args.strip('"').strip("'")
    if not pattern:
        console.print("[red]No search pattern provided.[/red]")
        return

    if once:
        # search against all_events, don't push to stack
        results = grep_events(session.all_events, pattern, case_sensitive)
        console.print(
            f"[bold]{format_number(len(results))} matches[/bold] "
            f"(searched all {format_number(len(session.all_events))} events)"
        )
        if results:
            render_table(
                results, console,
                fields=session.display_columns,
                highlight=pattern,
                max_results=50,
            )
        console.print("[dim]Current session unchanged.[/dim]")
        session.log_command(parsed.raw, f"{len(results)} matches (once)")
    else:
        # push to stack like where
        if not session.filtered_events:
            console.print("[yellow]Warning: current view is empty — search has no effect. Use 'undo' or 'reset'.[/yellow]")
            return
        session.push_filter(f'search "{pattern}"')
        session.filtered_events = grep_events(
            session.filtered_events, pattern, case_sensitive
        )
        count = len(session.filtered_events)
        session.highlight = pattern
        console.print(f"[bold]{format_number(count)} matches[/bold]")
        session.log_command(parsed.raw, f"{count} matches")
