#!/usr/bin/env python3
"""export and copy commands."""

from __future__ import annotations

import re
from html import escape as _html_escape
from pathlib import Path

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "export",
    r"^export\s+.+",
    category="Export",
    usage="export <file.ext> | export summary [file] | export star <file.ext>",
    help="Export events to file (.html, .csv, .json) or export investigation summary.",
)
def cmd_export(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Export events to file (."""
    console = ctx.console
    args = (parsed.args or "").strip()

    # export ticket — markdown to clipboard
    if args.lower() == "ticket":
        from logparse.output.markdown import render_markdown
        text = render_markdown(session)
        from logparse.output.clipboard import copy_to_clipboard
        if copy_to_clipboard(text):
            console.print("Markdown report copied to clipboard.")
        else:
            console.print("[yellow]Clipboard not available. Output:[/yellow]")
            console.print(text[:1000])
        session.log_command(parsed.raw, "ticket exported")
        return

    # export summary [file]
    if args.lower().startswith("summary"):
        rest = args[7:].strip()
        from logparse.output.transcript import render_transcript
        text = render_transcript(session)
        if rest:
            Path(rest).write_text(text, encoding="utf-8")
            console.print(f"Summary exported to {rest}")
        else:
            from logparse.output.clipboard import copy_to_clipboard
            if copy_to_clipboard(text):
                console.print("Summary copied to clipboard.")
            else:
                console.print(text)
        session.log_command(parsed.raw, "summary exported")
        return

    # export playbook <file>
    m = re.match(r"^playbook\s+(.+)$", args, re.I)
    if m:
        import json
        filepath = m.group(1).strip()
        commands = [entry.command for entry in session.transcript]
        data = {"name": Path(filepath).stem, "commands": commands}
        Path(filepath).write_text(json.dumps(data, indent=2), encoding="utf-8")
        console.print(f"Saved {len(commands)} commands to {filepath}")
        session.log_command(parsed.raw, "playbook exported")
        return

    # export star <file>
    m = re.match(r"^star\s+(.+)$", args, re.I)
    if m:
        filepath = m.group(1).strip()
        events = [
            session.all_events[i]
            for i in sorted(session.starred)
            if i < len(session.all_events)
        ]
        if not events:
            console.print("[dim]No starred events to export.[/dim]")
            return
        _do_export(events, filepath, session, console)
        session.log_command(parsed.raw, f"exported {len(events)} starred")
        return

    # export profile <file.zip>
    m = re.match(r"^profile\s+(.+)$", args, re.I)
    if m:
        _export_profile(session, m.group(1).strip(), console)
        session.log_command(parsed.raw, "profile exported")
        return

    # Format-only shorthand: export html, export csv, export json, export md
    _FORMAT_SHORTHANDS = {"html", "csv", "json", "md", "markdown"}
    if args.lower() in _FORMAT_SHORTHANDS:
        ext = args.lower()
        if ext == "markdown":
            ext = "md"
        filepath = f"logparse-export.{ext}"
        _do_export(session.filtered_events, filepath, session, console)
        session.log_command(parsed.raw, f"exported to {filepath}")
        return

    # export <file> [include ...]
    include_match = re.match(r"^(.+?)\s+include\s+(.+)$", args, re.I)
    if include_match:
        filepath = include_match.group(1).strip()
        includes = [i.strip().lower() for i in include_match.group(2).split(",")]
        _do_export(session.filtered_events, filepath, session, console, includes=includes)
        session.log_command(parsed.raw, f"exported to {filepath} with includes")
        return

    # export <file>
    _do_export(session.filtered_events, args, session, console)
    session.log_command(parsed.raw, f"exported to {args}")


def _do_export(events: list, filepath: str, session: Session, console: Console, includes: list[str] | None = None) -> None:
    """Write events to file based on extension."""
    # Reject filenames with shell metacharacters
    if re.search(r"[$`()|;&]", filepath):
        console.print("[red]Export filename contains unsafe characters.[/red]")
        return
    # Restrict export to safe paths (no traversal, no absolute paths outside CWD)
    p = Path(filepath)
    try:
        resolved = p.resolve()
        cwd = Path.cwd().resolve()
        if ".." in p.parts:
            console.print("[red]Export path must not contain '..'[/red]")
            return
        if not resolved.is_relative_to(cwd):
            console.print("[red]Export path must be within current directory.[/red]")
            return
    except (OSError, ValueError):
        console.print("[red]Invalid export path.[/red]")
        return
    ext = p.suffix.lower()
    count = len(events)

    if ext == ".csv":
        from logparse.cli_render import render_csv as _render_csv
        with open(filepath, "w", encoding="utf-8", newline="") as f:
            _render_csv(events, 0, file=f)
    elif ext == ".json":
        from logparse.cli_render import render_json as _render_json
        with open(filepath, "w", encoding="utf-8") as f:
            _render_json(events, 0, file=f)
    elif ext == ".html":
        from logparse.output.html import render_html_report
        render_html_report(events, filepath)
        # append include sections for HTML
        if includes:
            _append_html_includes(filepath, session, includes)
    elif ext == ".md":
        from logparse.output.markdown import render_markdown
        text = render_markdown(session)
        Path(filepath).write_text(text, encoding="utf-8")
    else:
        console.print(f"[red]Unsupported format: {ext}[/red]")
        return

    console.print(f"Exported {format_number(count)} events to {filepath}")


def _append_html_includes(filepath: str, session, includes: list[str]) -> None:
    """Append extra sections to an HTML export."""
    extra_html = []

    if "annotate" in includes or "annotations" in includes:
        if session.annotations:
            lines = ["<h2>Annotations</h2><ul>"]
            for idx, note in sorted(session.annotations.items()):
                lines.append(f"<li><strong>Event #{idx}:</strong> {_html_escape(str(note))}</li>")
            lines.append("</ul>")
            extra_html.append("\n".join(lines))

    if "remember" in includes or "notes" in includes:
        if session.notes:
            lines = ["<h2>Investigation Notes</h2><ul>"]
            for note in session.notes:
                ts = note.timestamp.strftime("%Y-%m-%d %H:%M:%S")
                lines.append(f"<li><em>{ts}</em> — {_html_escape(note.text)}</li>")
            lines.append("</ul>")
            extra_html.append("\n".join(lines))

    if "visual" in includes:
        # Try plotly chart embedding first
        charts = getattr(session, "charts", [])
        if charts:
            from logparse.visual.html.embed import embed_charts
            # We'll handle this after writing the base extra_html
        elif session.last_output:
            from logparse.pipeline import AggResult
            agg_items = [r for r in session.last_output if isinstance(r, AggResult)]
            if agg_items:
                lines = ["<h2>Chart</h2><pre>"]
                max_count = max(r.count for r in agg_items) if agg_items else 1
                for r in agg_items[:20]:
                    bar_w = int(r.count / max(max_count, 1) * 40)
                    bar = "\u2588" * bar_w
                    lines.append(f"  {r.key:<20} {bar}  {r.count}")
                lines.append("</pre>")
                extra_html.append("\n".join(lines))

    if extra_html:
        content = Path(filepath).read_text(encoding="utf-8")
        insert = "\n".join(extra_html)
        # insert before closing body/html tags
        if "</body>" in content:
            content = content.replace("</body>", f"{insert}\n</body>")
        else:
            content += f"\n{insert}"
        Path(filepath).write_text(content, encoding="utf-8")

    # Embed plotly charts if available
    if "visual" in includes:
        charts = getattr(session, "charts", [])
        if charts:
            from logparse.visual.html.embed import embed_charts
            content = Path(filepath).read_text(encoding="utf-8")
            content = embed_charts(charts, content)
            Path(filepath).write_text(content, encoding="utf-8")


def _export_profile(session: Session, filepath: str, console: Console) -> None:
    """Export full session profile as a zip archive."""
    import json
    import zipfile

    if not filepath.endswith(".zip"):
        filepath += ".zip"

    with zipfile.ZipFile(filepath, "w", zipfile.ZIP_DEFLATED) as zf:
        # transcript
        transcript_data = [
            {
                "timestamp": e.timestamp.isoformat(),
                "command": e.command,
                "summary": e.summary,
                "event_count": e.event_count,
            }
            for e in session.transcript
        ]
        zf.writestr("transcript.json", json.dumps(transcript_data, indent=2))

        # notes
        if session.notes:
            notes_data = [
                {"text": n.text, "timestamp": n.timestamp.isoformat()}
                for n in session.notes
            ]
            zf.writestr("notes.json", json.dumps(notes_data, indent=2))

        # annotations
        if session.annotations:
            zf.writestr("annotations.json", json.dumps(
                {str(k): v for k, v in session.annotations.items()}, indent=2
            ))

        # starred events
        if session.starred:
            zf.writestr("starred.json", json.dumps(sorted(session.starred)))

        # variables
        if session.variables:
            vars_data = {}
            for k, v in session.variables.items():
                vars_data[k] = v if isinstance(v, (str, list)) else str(v)
            zf.writestr("variables.json", json.dumps(vars_data, indent=2))

        # filter state
        filter_state = {
            "active_filter": session.active_filter,
            "event_count": len(session.filtered_events),
        }
        zf.writestr("filter_state.json", json.dumps(filter_state, indent=2))

    console.print(f"Session profile exported to {filepath}")


@register(
    "copy",
    r"^copy\s+.+",
    category="Export",
    usage="copy table | copy <field>",
    help="Copy current view or field values to clipboard.",
)
def cmd_copy(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Copy current view or field values to clipboard."""
    from logparse.models import get_field
    from logparse.output.clipboard import copy_to_clipboard

    console = ctx.console
    args = (parsed.args or "").strip()

    if args.lower() == "table":
        # render as aligned text
        lines = []
        cols = session.display_columns
        lines.append("\t".join(cols))
        for e in session.filtered_events[:500]:
            row = []
            for c in cols:
                if c == "Timestamp":
                    row.append(e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "")
                elif c == "Severity":
                    row.append(e.severity)
                elif c == "Source":
                    row.append(e.source)
                elif c == "Message":
                    row.append(e.message.replace("\n", " "))
                else:
                    row.append(get_field(e, c) or "")
            lines.append("\t".join(row))
        text = "\n".join(lines)
    else:
        # copy field values
        field_name = args
        values = []
        for e in session.filtered_events:
            val = get_field(e, field_name)
            if val:
                values.append(val)
        text = "\n".join(values)

    if copy_to_clipboard(text):
        console.print(f"Copied to clipboard ({len(text)} chars).")
    else:
        console.print("[yellow]Clipboard not available. Output:[/yellow]")
        console.print(text[:500])
    session.log_command(parsed.raw, f"copied {args}")
