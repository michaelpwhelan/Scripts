#!/usr/bin/env python3
"""Behavioral baseline commands — build, check, list, delete.

These handle multi-metric behavioral baselines stored in
``~/.logparse/baselines/``.  Distinct from the existing ``baseline``
command which does single-field statistical analysis.
"""

from __future__ import annotations

from logparse.commands import register, sev_color, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand


@register(
    "baseline build",
    r"^baseline\s+build\s+\S+",
    category="Detection",
    usage="baseline build <name>",
    help="Build a behavioral baseline from current events and save it.",
)
def cmd_baseline_build(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Build a behavioral baseline from current events and save it."""
    from logparse.analyzers.behavioral_baseline import (
        build_baseline,
        save_baseline,
    )
    from logparse.config_loader import get_config_dir

    console = ctx.console
    parts = (parsed.args or "").split()
    if len(parts) < 2:
        console.print("[dim]Usage: baseline build <name>[/dim]")
        return
    name = parts[1]

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    profile = build_baseline(events, name)
    baselines_dir = get_config_dir() / "baselines"
    _path = save_baseline(profile, baselines_dir)

    console.print(f"[green]Baseline '{name}' saved[/green] ({len(profile.metrics)} metrics)")
    console.print(f"  Events: {profile.event_count}")
    console.print(f"  Time span: {profile.time_span_hours:.1f} hours")
    for mname, m in profile.metrics.items():
        console.print(f"  {mname}: mean={m.mean:.2f}, σ={m.stddev:.2f}, p95={m.p95:.2f}")
    session.log_command(ctx.raw_input, f"built baseline {name}")


@register(
    "baseline check",
    r"^baseline\s+check\s+\S+",
    category="Detection",
    usage="baseline check <name>",
    help="Compare current events against a stored behavioral baseline.",
)
def cmd_baseline_check(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Compare current events against a stored behavioral baseline."""
    from logparse.analyzers.behavioral_baseline import (
        check_baseline,
        load_baseline,
    )
    from logparse.config_loader import get_config_dir

    console = ctx.console
    parts = (parsed.args or "").split()
    if len(parts) < 2:
        console.print("[dim]Usage: baseline check <name>[/dim]")
        return
    name = parts[1]

    baselines_dir = get_config_dir() / "baselines"
    profile = load_baseline(name, baselines_dir)
    if profile is None:
        console.print(f"[red]Baseline '{name}' not found.[/red]")
        return

    events = session.filtered_events
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    deviations = check_baseline(events, profile)
    if not deviations:
        console.print(f"[green]No significant deviations from baseline '{name}'.[/green]")
        session.log_command(ctx.raw_input, f"baseline check {name}: OK")
        return

    from rich.table import Table

    table = Table(title=f"Deviations from baseline '{name}'")
    table.add_column("Metric")
    table.add_column("Severity")
    table.add_column("Current", justify="right")
    table.add_column("Expected", justify="right")
    table.add_column("σ", justify="right")

    for d in deviations:
        sev = sev_color(d.severity)
        table.add_row(
            d.metric_name,
            sev,
            f"{d.current_value:.2f}",
            f"{d.expected_mean:.2f} ± {d.stddev:.2f}",
            f"{d.sigma:.1f}σ",
        )
    console.print(table)
    session.log_command(
        ctx.raw_input, f"baseline check {name}: {len(deviations)} deviations"
    )


@register(
    "baseline list",
    r"^baseline\s+list\s*$",
    category="Detection",
    usage="baseline list",
    help="List stored behavioral baselines.",
)
def cmd_baseline_list(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """List stored behavioral baselines."""
    from logparse.analyzers.behavioral_baseline import (
        list_baselines,
        load_baseline,
    )
    from logparse.config_loader import get_config_dir

    console = ctx.console
    baselines_dir = get_config_dir() / "baselines"
    names = list_baselines(baselines_dir)

    if not names:
        console.print("[dim]No stored baselines. Use 'baseline build <name>'.[/dim]")
        return

    console.print("[bold]Stored Behavioral Baselines:[/bold]")
    for name in names:
        profile = load_baseline(name, baselines_dir)
        if profile:
            console.print(
                f"  [cyan]{name}[/cyan]: {profile.event_count} events, "
                f"{len(profile.metrics)} metrics, "
                f"{profile.time_span_hours:.1f}h span "
                f"(created {profile.created[:19]})"
            )


@register(
    "baseline delete",
    r"^baseline\s+delete\s+\S+",
    category="Detection",
    usage="baseline delete <name>",
    help="Delete a stored behavioral baseline.",
)
def cmd_baseline_delete(
    session: Session, parsed: ParsedCommand, ctx: CommandContext
) -> None:
    """Delete a stored behavioral baseline."""
    from logparse.analyzers.behavioral_baseline import delete_baseline
    from logparse.config_loader import get_config_dir

    console = ctx.console
    parts = (parsed.args or "").split()
    if len(parts) < 2:
        console.print("[dim]Usage: baseline delete <name>[/dim]")
        return
    name = parts[1]

    baselines_dir = get_config_dir() / "baselines"
    if delete_baseline(name, baselines_dir):
        console.print(f"[green]Deleted baseline '{name}'.[/green]")
        session.log_command(ctx.raw_input, f"deleted baseline {name}")
    else:
        console.print(f"[red]Baseline '{name}' not found.[/red]")



