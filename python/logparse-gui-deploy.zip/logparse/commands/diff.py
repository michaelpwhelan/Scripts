#!/usr/bin/env python3
"""diff command — file diff and time diff."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from rich.console import Console

from logparse.commands import register, CommandContext
from logparse.session import Session
from logparse.syntax import ParsedCommand
from logparse.util import format_number


@register(
    "diff",
    r"^diff\s+.+",
    category="Analysis",
    usage="diff <file1> <file2> [--section S] | diff time <t1> <d1> time <t2> <d2> | diff session <A> <B>",
    help="Compare configs, time windows, or saved filter snapshots.",
)
def cmd_diff(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Compare configs, time windows, or saved filter snapshots."""
    console = ctx.console
    args = parsed.args.strip()

    # diff session <A> <B>
    session_match = re.match(r"session\s+(\d+)\s+(\d+)$", args, re.I)
    if session_match:
        _session_diff(session, session_match, console)
        session.log_command(parsed.raw, "diff session")
        return

    # diff time <t1> <d1> time <t2> <d2>
    time_match = re.match(
        r"time\s+(\S+)\s+(\S+)\s+time\s+(\S+)\s+(\S+)",
        args, re.I,
    )
    if time_match:
        _time_diff(session, time_match, console)
        session.log_command(parsed.raw, "time diff")
        return

    # diff * — compare all loaded source files
    if args.strip() == "*":
        _diff_all(session, console)
        session.log_command(parsed.raw, "diff *")
        return

    # diff <file1> <file2> [--section <section>]
    parts = args.split()
    if len(parts) < 2:
        console.print("[red]Usage: diff <file1> <file2> | diff *[/red]")
        return

    file_a = Path(parts[0])
    file_b = Path(parts[1])
    section = None
    if "--section" in parts:
        idx = parts.index("--section")
        if idx + 1 < len(parts):
            section = " ".join(parts[idx + 1:])

    if not file_a.exists():
        console.print(f"[red]File not found: {file_a}[/red]")
        return
    if not file_b.exists():
        console.print(f"[red]File not found: {file_b}[/red]")
        return

    try:
        lines_a = file_a.read_text(encoding="utf-8", errors="replace").splitlines()
        lines_b = file_b.read_text(encoding="utf-8", errors="replace").splitlines()
    except (PermissionError, OSError) as exc:
        console.print(f"[red]Cannot read file: {exc}[/red]")
        return

    if section:
        lines_a = _extract_section(lines_a, section)
        lines_b = _extract_section(lines_b, section)
        if not lines_a and not lines_b:
            console.print(f"[dim]Section '{section}' not found in either file.[/dim]")
            return

    _config_diff(lines_a, lines_b, file_a.name, file_b.name, console)
    session.log_command(parsed.raw, f"diff {file_a.name} {file_b.name}")


def _diff_all(session: Session, console: Console) -> None:
    """Compare events across all loaded source files."""
    files = session.source_files
    if len(files) < 2:
        console.print("[dim]Need at least 2 loaded files to diff.[/dim]")
        return

    # If exactly 2 files and both exist on disk, do a text diff
    if len(files) == 2:
        a, b = Path(files[0]), Path(files[1])
        if a.exists() and b.exists():
            lines_a = a.read_text(encoding="utf-8", errors="replace").splitlines()
            lines_b = b.read_text(encoding="utf-8", errors="replace").splitlines()
            _config_diff(lines_a, lines_b, a.name, b.name, console)
            return

    # Multiple files or files no longer on disk: event-based comparison

    # bucket events by source file
    by_file: dict[str, set[str]] = {f: set() for f in files}
    for e in session.all_events:
        if e.source_file in by_file:
            by_file[e.source_file].add(e.message)

    # show per-file stats
    from logparse.util import compact_table
    table = compact_table()
    table.add_column("FILE", style="bold")
    table.add_column("EVENTS", justify="right", style="cyan")
    table.add_column("UNIQUE", justify="right", style="yellow")

    all_msgs = [msgs for msgs in by_file.values()]
    for i, (fname, msgs) in enumerate(by_file.items()):
        others = set()
        for j, other_msgs in enumerate(all_msgs):
            if j != i:
                others |= other_msgs
        unique = msgs - others
        table.add_row(
            Path(fname).name,
            format_number(len(msgs)),
            format_number(len(unique)),
        )

    console.print(table)

    # for 2 files, also show the unique events
    if len(files) == 2:
        names = [Path(f).name for f in files]
        msgs_a, msgs_b = list(by_file.values())
        only_a = msgs_a - msgs_b
        only_b = msgs_b - msgs_a
        common = msgs_a & msgs_b

        if only_a:
            console.print(f"\n[bold]Only in {names[0]}:[/bold]")
            for msg in sorted(only_a)[:20]:
                console.print(f"  [red]- {msg[:120]}[/red]")
            if len(only_a) > 20:
                console.print(f"  [dim]... and {len(only_a) - 20} more[/dim]")

        if only_b:
            console.print(f"\n[bold]Only in {names[1]}:[/bold]")
            for msg in sorted(only_b)[:20]:
                console.print(f"  [green]+ {msg[:120]}[/green]")
            if len(only_b) > 20:
                console.print(f"  [dim]... and {len(only_b) - 20} more[/dim]")

        console.print(
            f"\n[dim]Common: {format_number(len(common))} | "
            f"Only {names[0]}: {format_number(len(only_a))} | "
            f"Only {names[1]}: {format_number(len(only_b))}[/dim]"
        )


def _time_diff(session: Session, match: re.Match, console: Console) -> None:
    """Compare events in two time windows."""

    t1_str, d1_str = match.group(1), match.group(2)
    t2_str, d2_str = match.group(3), match.group(4)

    def _parse_time_date(t: str, d: str) -> datetime | None:
        """Parse time + date into datetime (locale-independent)."""
        # Handle AM/PM manually to avoid locale-dependent %p on Windows
        am_pm = re.match(r"(\d{1,2}):(\d{2})(AM|PM)$", t, re.I)
        if am_pm:
            hour, minute = int(am_pm.group(1)), int(am_pm.group(2))
            if am_pm.group(3).upper() == "PM" and hour != 12:
                hour += 12
            elif am_pm.group(3).upper() == "AM" and hour == 12:
                hour = 0
            for dfmt in ("%m-%d", "%Y-%m-%d"):
                try:
                    dt = datetime.strptime(d, dfmt)
                    if "%Y" not in dfmt:
                        dt = dt.replace(year=datetime.now().year)
                    return dt.replace(hour=hour, minute=minute)
                except ValueError:
                    continue
        # 24-hour formats — locale-independent
        for fmt in ("%H:%M %m-%d", "%H:%M %Y-%m-%d"):
            try:
                parsed_dt = datetime.strptime(f"{t} {d}", fmt)
                if "%Y" not in fmt:
                    parsed_dt = parsed_dt.replace(year=datetime.now().year)
                return parsed_dt
            except ValueError:
                continue
        return None

    start_a = _parse_time_date(t1_str, d1_str)
    start_b = _parse_time_date(t2_str, d2_str)

    if not start_a or not start_b:
        console.print("[red]Could not parse time ranges.[/red]")
        return

    # find events in each window (window = from start to next window start or +1hr)
    from datetime import timedelta
    end_a = start_b if start_b > start_a else start_a + timedelta(hours=1)
    end_b = start_a if start_a > start_b else start_b + timedelta(hours=1)

    events_a = set()
    events_b = set()

    for e in session.all_events:
        if e.timestamp is None:
            continue
        if start_a <= e.timestamp < end_a:
            events_a.add(e.message)
        if start_b <= e.timestamp < end_b:
            events_b.add(e.message)

    only_a = events_a - events_b
    only_b = events_b - events_a
    common = events_a & events_b


    console.rule(f"Only in window A ({t1_str} {d1_str})", style="red")
    for msg in sorted(only_a)[:20]:
        console.print(f"  [red]- {msg[:100]}[/red]")
    if len(only_a) > 20:
        console.print(f"  ... and {len(only_a) - 20} more")

    console.rule(f"Only in window B ({t2_str} {d2_str})", style="green")
    for msg in sorted(only_b)[:20]:
        console.print(f"  [green]+ {msg[:100]}[/green]")
    if len(only_b) > 20:
        console.print(f"  ... and {len(only_b) - 20} more")

    console.print()
    console.print(
        f"[dim]Only A: {len(only_a)} | Only B: {len(only_b)} | Common: {len(common)}[/dim]"
    )


def _session_diff(session: Session, match: re.Match, console: Console) -> None:
    """Compare two saved filter snapshots."""
    from rich.table import Table

    id_a = int(match.group(1))
    id_b = int(match.group(2))

    if id_a not in session.saved_filters:
        console.print(f"[red]Saved filter {id_a} not found. Use 'save' to create snapshots.[/red]")
        return
    if id_b not in session.saved_filters:
        console.print(f"[red]Saved filter {id_b} not found. Use 'save' to create snapshots.[/red]")
        return

    snap_a = session.saved_filters[id_a]
    snap_b = session.saved_filters[id_b]

    events_a = set(id(e) for e in snap_a.events)
    events_b = set(id(e) for e in snap_b.events)

    only_a = events_a - events_b
    only_b = events_b - events_a
    common = events_a & events_b

    console.rule(f"Session Diff: #{id_a} vs #{id_b}", style="cyan")
    console.print(f"  Filter A (#{id_a}): [bold]{snap_a.description or '(no filter)'}[/bold] — {format_number(len(snap_a.events))} events")
    console.print(f"  Filter B (#{id_b}): [bold]{snap_b.description or '(no filter)'}[/bold] — {format_number(len(snap_b.events))} events")
    console.print()

    table = Table(border_style="dim")
    table.add_column("Category", style="bold")
    table.add_column("Count", justify="right", style="cyan")
    table.add_row(f"Only in #{id_a}", format_number(len(only_a)))
    table.add_row(f"Only in #{id_b}", format_number(len(only_b)))
    table.add_row("Common", format_number(len(common)))
    console.print(table)


def _extract_section(lines: list[str], section_name: str) -> list[str]:
    """Extract a named section from FortiGate-style config."""
    result: list[str] = []
    depth = 0
    capturing = False
    target = section_name.lower()

    for line in lines:
        stripped = line.strip().lower()
        if stripped.startswith("config ") and target in stripped:
            capturing = True
            depth = 1
            result.append(line)
            continue
        if capturing:
            result.append(line)
            if stripped.startswith("config ") or stripped.startswith("edit "):
                depth += 1
            elif stripped == "end" or stripped == "next":
                depth -= 1
                if depth <= 0:
                    break
    return result


def _config_diff(lines_a: list[str], lines_b: list[str], name_a: str, name_b: str, console: Console) -> None:
    """Unified diff with color."""
    import difflib
    from rich.text import Text

    diff = list(difflib.unified_diff(
        lines_a, lines_b,
        fromfile=name_a, tofile=name_b,
        lineterm="",
    ))
    if not diff:
        console.print("[green]Files are identical.[/green]")
        return

    for line in diff:
        if line.startswith("---") or line.startswith("+++"):
            console.print(Text(line, style="bold"))
        elif line.startswith("@@"):
            console.print(Text(line, style="cyan"))
        elif line.startswith("-"):
            console.print(Text(line, style="red"))
        elif line.startswith("+"):
            console.print(Text(line, style="green"))
        else:
            console.print(line)
