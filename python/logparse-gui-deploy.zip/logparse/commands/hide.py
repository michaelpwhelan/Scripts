#!/usr/bin/env python3
"""hide / unhide commands — exclude events by field value."""

from __future__ import annotations

import re

from logparse.commands import register, CommandContext
from logparse.filter_engine import is_known_field, match_field
from logparse.models import get_field, resolve_field_alias, _CORE_FIELDS, _FIELD_ALIASES
from logparse.session import Session, HideRule
from logparse.syntax import ParsedCommand
from logparse.util import format_number

_SEV_KEYWORDS = {"critical", "high", "medium", "low", "info"}
_IP_RE = re.compile(r"^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$")


def _find_close_field(candidate: str, session: Session | None = None) -> str | None:
    """Find a close match for a possibly-typo'd field name."""
    cl = candidate.lower()
    # Check core fields and aliases
    all_known = set(_CORE_FIELDS) | set(_FIELD_ALIASES)
    if session and session.all_events:
        all_known.update(k.lower() for k in session.all_events[0].extra)

    # Simple edit distance 1: deletion, substitution, transposition
    for known in all_known:
        if len(known) < 3:
            continue
        # Same length, <=2 char difference
        if len(cl) == len(known):
            diffs = sum(1 for a, b in zip(cl, known) if a != b)
            if diffs <= 2:
                return known
        # Off by one char (insertion/deletion)
        if abs(len(cl) - len(known)) == 1:
            longer, shorter = (cl, known) if len(cl) > len(known) else (known, cl)
            diffs = 0
            i = j = 0
            while i < len(longer) and j < len(shorter):
                if longer[i] != shorter[j]:
                    diffs += 1
                    i += 1
                else:
                    i += 1
                    j += 1
            if diffs <= 1:
                return known
    return None


def _infer_field(value: str, session: Session | None = None) -> str:
    """Guess which field a bare value belongs to."""
    vl = value.lower()
    if vl in _SEV_KEYWORDS:
        return "severity"
    if _IP_RE.match(value):
        return "srcip"
    # scan first 200 events for the field with the most matches
    if session:
        events = session.filtered_events[:200]
        best_field = ""
        best_count = 0
        for e in events:
            for k, v in e.extra.items():
                if isinstance(v, str) and vl in v.lower():
                    # tally across all events for this key
                    count = sum(
                        1 for ev in events
                        if vl in (ev.extra.get(k) or "").lower()
                    )
                    if count > best_count:
                        best_count = count
                        best_field = k
                    break  # only check first matching key per event
        if best_field:
            return best_field
    return "source"


def _parse_hide_args(args: str, session: Session | None = None) -> tuple[str, list[str], bool]:
    """Parse hide arguments with smart field inference.

    Returns (field, values, contains_mode).

    1. ``field contains "value"`` — substring match mode
    2. Explicit separator (field:value or field=value) — trust as-is
    3. First word is known field — use as field, rest as values
    4. No known field — infer from data
    """
    # 1. "field contains value" syntax
    cm = re.match(r'^(\w+)\s+contains\s+["\']?(.+?)["\']?\s*$', args, re.I)
    if cm:
        field = resolve_field_alias(cm.group(1))
        return field, [cm.group(2).strip()], True

    # 2. explicit separator
    m = re.match(r"^(\w+)[:=]\s*(.+)$", args)
    if m:
        field = resolve_field_alias(m.group(1))
        raw_val = m.group(2).strip()
        # quoted value — strip quotes first, then decide mode
        if (raw_val.startswith('"') and raw_val.endswith('"')) or \
           (raw_val.startswith("'") and raw_val.endswith("'")):
            unquoted = raw_val[1:-1]
            # If the unquoted value has wildcards, use wildcard mode not contains
            if "*" in unquoted or "?" in unquoted:
                return field, [unquoted], False
            return field, [unquoted], True
        values = [v.strip().strip('"').strip("'") for v in raw_val.split(",")]
        return field, values, False
    # 3. first word is a known field name
    m = re.match(r"^(\w+)\s+(.+)$", args)
    if m:
        candidate = m.group(1)
        if is_known_field(candidate.lower(), session=session):
            field = resolve_field_alias(candidate)
            values = [v.strip().strip('"').strip("'") for v in m.group(2).split(",")]
            return field, values, False
        # Check for close typo match before falling through
        close = _find_close_field(candidate, session)
        if close:
            # Treat as the intended field with a typo
            field = resolve_field_alias(close)
            values = [v.strip().strip('"').strip("'") for v in m.group(2).split(",")]
            return field, values, False
    # 4. bare severity keywords joined by and/or/comma — combine into severity filter
    #    "info and medium", "high or critical", "info, medium"
    segments = re.split(r"\b(?:and|or)\b|,", args, flags=re.IGNORECASE)
    stripped = [s.strip().strip('"').strip("'") for s in segments if s.strip()]
    if stripped and all(s.lower() in _SEV_KEYWORDS for s in stripped):
        return "severity", stripped, False

    # 5. bare value(s) — infer field
    values = [v.strip().strip('"').strip("'") for v in args.split(",")]
    field = _infer_field(values[0], session)
    return field, values, False


def _hide_op(values: list[str], contains: bool) -> str:
    """Determine the match_field op for a set of hide values."""
    if contains:
        return "contains"
    if len(values) > 1:
        return "in"
    if len(values) == 1 and ("*" in values[0] or "?" in values[0]):
        return "wildcard"
    return "eq"


def _hide_pattern(values: list[str], op: str) -> str:
    """Build the match_field pattern from hide values."""
    if op == "in":
        return ",".join(values)
    return values[0] if values else ""


def _match_hide(field_val: str, values: list[str], contains: bool) -> bool:
    """Check if a field value matches hide criteria via filter_engine."""
    op = _hide_op(values, contains)
    pattern = _hide_pattern(values, op)
    return match_field(field_val, pattern, op)


@register(
    "hide",
    r"^hide\s+.+",
    category="Filter",
    usage="hide <field>:<val>[, val, ...] | hide <field> <val>[, val, ...]",
    help="Exclude events matching field values (inverse of where). Undoable.",
)
def cmd_hide(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Exclude events matching field values (inverse of where)."""
    console = ctx.console
    args = parsed.args.strip()

    field, values, contains = _parse_hide_args(args, session)
    if not field or not values:
        console.print("[red]Usage: hide Source:WMI-Activity, DCOM[/red]")
        return

    # Check if field was a typo correction — warn the user
    # Skip when input was bare severity keywords (not a typo, just shorthand)
    _raw_parts = args.split(":")[0].split("=")[0].split()
    raw_field = _raw_parts[0] if _raw_parts else ""
    if (raw_field and raw_field.lower() != field.lower()
            and raw_field.lower() not in _SEV_KEYWORDS):
        corrected = _find_close_field(raw_field, session)
        if corrected:
            console.print(f"[yellow]Assuming '{raw_field}' → '{field}' (typo correction)[/yellow]")

    before = len(session.filtered_events)
    mode_label = "contains " if contains else ""
    session.push_filter(f"hide {field}:{mode_label}{','.join(values)}")

    rule = HideRule(field=field, values=values, mode=_hide_op(values, contains))
    if not isinstance(session.hide_rules, list):
        session.hide_rules = []
    session.hide_rules.append(rule)

    session.filtered_events = [
        e for e in session.filtered_events
        if not _match_hide(get_field(e, field) or "", values, contains)
    ]

    after = len(session.filtered_events)
    removed = before - after
    console.print(
        f"[bold]Hidden {format_number(removed)} events[/bold] "
        f"({field}: {', '.join(values)}). "
        f"{format_number(after)} remaining."
    )
    session.log_command(parsed.raw, f"hidden {removed}, {after} remaining")


@register(
    "unhide",
    r"^unhide\s+.+",
    category="Filter",
    usage="unhide <field>:<value>",
    help="Restore a previously hidden value.",
)
def cmd_unhide(session: Session, parsed: ParsedCommand, ctx: CommandContext) -> None:
    """Restore a previously hidden value."""
    console = ctx.console
    args = parsed.args.strip()

    field, values, _contains = _parse_hide_args(args, session)
    if not field or not values:
        console.print("[red]Usage: unhide Source:DCOM[/red]")
        return

    values_lower = set(v.lower() for v in values)
    removed_rules = 0

    new_rules: list[HideRule] = []
    for rule in session.hide_rules:
        if rule.field.lower() == field.lower():
            remaining = [v for v in rule.values if v.lower() not in values_lower]
            if remaining:
                new_rules.append(HideRule(field=rule.field, values=remaining, mode=rule.mode))
            else:
                removed_rules += 1
        else:
            new_rules.append(rule)

    session.hide_rules = new_rules

    # Recompute: find the most recent non-hide snapshot in filter_history
    # and use its stored events as the base, then re-apply remaining hides.
    base_events = None
    if session.filter_history:
        # Walk backwards to find the last snapshot that isn't a hide operation
        for snap in reversed(session.filter_history):
            if not snap.description.startswith("hide "):
                base_events = list(snap.events)
                break
    if base_events is None:
        base_events = list(session.all_events)

    # Apply remaining hide rules on top of the base using proper matching
    if session.hide_rules:
        from logparse.session import _hide_rule_op_pattern
        for rule in session.hide_rules:
            op, pattern = _hide_rule_op_pattern(rule)
            base_events = [
                e for e in base_events
                if not match_field(get_field(e, rule.field) or "", pattern, op)
            ]
    session.filtered_events = base_events

    console.print(
        f"[bold]Unhidden {', '.join(values)}[/bold]. "
        f"{format_number(len(session.filtered_events))} events."
    )
    session.log_command(parsed.raw, f"unhidden {', '.join(values)}")
