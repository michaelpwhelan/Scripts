#!/usr/bin/env python3
"""Markdown export for investigation reports."""

from __future__ import annotations

from datetime import datetime

from logparse.models import SEVERITY_LEVELS
from logparse.session import Session
from logparse.util import format_number


def render_markdown(session: Session) -> str:
    """Render a full investigation report as Markdown."""
    lines: list[str] = []

    # Header
    lines.append("# Investigation Report")
    lines.append("")
    lines.append(f"**Date:** {datetime.now():%Y-%m-%d %H:%M}")
    if session.source_files:
        lines.append(f"**Sources:** {', '.join(session.source_files)}")
    ts_events = [e for e in session.all_events if e.timestamp]
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        lines.append(f"**Time range:** {first:%Y-%m-%d %H:%M:%S} — {last:%Y-%m-%d %H:%M:%S}")
    lines.append(f"**Total events:** {format_number(len(session.all_events))}")
    lines.append(f"**Filtered events:** {format_number(len(session.filtered_events))}")
    lines.append("")

    # Filters Applied
    if session.filter_history or session.active_filter:
        lines.append("## Filters Applied")
        lines.append("")
        for snap in session.filter_history:
            if snap.description:
                lines.append(f"- {snap.description}")
        if session.active_filter:
            lines.append(f"- {session.active_filter} *(active)*")
        lines.append("")

    # Key Findings (starred events)
    starred_events = [
        (i, session.all_events[i])
        for i in sorted(session.starred)
        if i < len(session.all_events)
    ]
    if starred_events:
        lines.append("## Key Findings")
        lines.append("")
        lines.append("| # | Timestamp | Severity | Source | Message |")
        lines.append("|---|-----------|----------|--------|---------|")
        for idx, ev in starred_events:
            ts = ev.timestamp.strftime("%Y-%m-%d %H:%M:%S") if ev.timestamp else ""
            msg = ev.message.replace("|", "\\|").replace("\n", " ")[:120]
            annotation = ""
            if idx in session.annotations:
                annotation = f" — *{session.annotations[idx]}*"
            sev = ev.severity.replace("|", "\\|")
            src = (ev.source or "").replace("|", "\\|")
            lines.append(f"| {idx} | {ts} | {sev} | {src} | {msg}{annotation} |")
        lines.append("")

    # Annotations
    if session.annotations:
        non_starred = {
            k: v for k, v in session.annotations.items()
            if k not in session.starred
        }
        if non_starred:
            lines.append("## Annotations")
            lines.append("")
            for idx, text in sorted(non_starred.items()):
                ev = session.all_events[idx] if idx < len(session.all_events) else None
                ts = ev.timestamp.strftime("%H:%M:%S") if ev and ev.timestamp else "?"
                lines.append(f"{idx}. **[{ts}]** {text}")
            lines.append("")

    # Investigation Notes
    if session.notes:
        lines.append("## Investigation Notes")
        lines.append("")
        for i, note in enumerate(session.notes, 1):
            ts = note.timestamp.strftime("%H:%M")
            lines.append(f"{i}. [{ts}] {note.text}")
        lines.append("")

    # Event Summary
    lines.append("## Event Summary")
    lines.append("")
    # Severity distribution
    from collections import Counter
    sev_counts: Counter[str] = Counter()
    for e in session.filtered_events:
        sev_counts[e.severity] += 1
    if sev_counts:
        lines.append("### Severity Distribution")
        lines.append("")
        for sev in SEVERITY_LEVELS:
            if sev in sev_counts:
                lines.append(f"- **{sev}:** {format_number(sev_counts[sev])}")
        lines.append("")

    # Top sources
    from logparse.models import get_field
    src_counts: Counter[str] = Counter()
    for e in session.filtered_events:
        src = get_field(e, "source") or "(unknown)"
        src_counts[src] += 1
    if src_counts:
        lines.append("### Top Sources")
        lines.append("")
        for src, cnt in src_counts.most_common(10):
            lines.append(f"- **{src}:** {format_number(cnt)}")
        lines.append("")

    # Transcript
    if session.transcript:
        lines.append("## Command Transcript")
        lines.append("")
        lines.append("```")
        for i, entry in enumerate(session.transcript, 1):
            lines.append(
                f"[{i}] {entry.timestamp:%H:%M:%S}  "
                f"{entry.command} → {entry.summary}"
            )
        lines.append("```")
        lines.append("")

    return "\n".join(lines)
