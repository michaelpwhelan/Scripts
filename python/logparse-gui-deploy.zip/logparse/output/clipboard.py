#!/usr/bin/env python3
"""Platform-aware clipboard operations."""

from __future__ import annotations

import shutil
import subprocess


def _find_clipboard_cmd() -> list[str] | None:
    """Detect available clipboard command."""
    # WSL
    if shutil.which("clip.exe"):
        return ["clip.exe"]
    # Linux — xclip
    if shutil.which("xclip"):
        return ["xclip", "-selection", "clipboard"]
    # Linux — xsel
    if shutil.which("xsel"):
        return ["xsel", "--clipboard", "--input"]
    # Linux — wl-copy (Wayland)
    if shutil.which("wl-copy"):
        return ["wl-copy"]
    # macOS
    if shutil.which("pbcopy"):
        return ["pbcopy"]
    return None


def copy_to_clipboard(text: str) -> bool:
    """Copy text to system clipboard. Returns True on success."""
    cmd = _find_clipboard_cmd()
    if cmd is None:
        return False

    try:
        proc = subprocess.run(
            cmd,
            input=text.encode("utf-8"),
            capture_output=True,
            timeout=5,
        )
        return proc.returncode == 0
    except (subprocess.TimeoutExpired, OSError):
        return False
