#!/usr/bin/env python3
"""Investigation transcript renderer."""

from __future__ import annotations

from logparse.session import Session


def render_transcript(session: Session) -> str:
    """Render session transcript as pasteable text."""
    lines = ["logparse investigation transcript", "=" * 40, ""]

    if session.source_files:
        lines.append(f"Files: {', '.join(session.source_files)}")
    lines.append(f"Total events: {len(session.all_events):,}")
    lines.append(f"Session started: {session.start_time:%Y-%m-%d %H:%M:%S}")
    lines.append("")

    # Key Findings (from remember notes)
    if session.notes:
        lines.append("Key Findings")
        lines.append("-" * 20)
        for i, note in enumerate(session.notes, 1):
            lines.append(f"  {i}. [{note.timestamp:%H:%M}] {note.text}")
        lines.append("")

    # Command transcript
    lines.append("Command History")
    lines.append("-" * 20)
    for i, entry in enumerate(session.transcript, 1):
        lines.append(
            f"[{i}] {entry.timestamp:%H:%M:%S}  "
            f"{entry.command} \u2192 {entry.summary}"
        )

    lines.append("")
    lines.append(
        f"Final view: {len(session.filtered_events):,} events"
        f" ({session.active_filter or 'no filter'})"
    )
    return "\n".join(lines)
