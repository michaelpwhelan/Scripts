#!/usr/bin/env python3
"""Self-contained HTML report generator."""

from __future__ import annotations

from html import escape
from pathlib import Path

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_SEV_COLORS = {
    "Critical": "#dc2626",
    "High": "#ef4444",
    "Medium": "#eab308",
    "Low": "#06b6d4",
    "Info": "#9ca3af",
}

_CSS = """\
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Consolas', 'Courier New', monospace; background: #1a1a2e; color: #e0e0e0; padding: 20px; }
h1 { color: #4ade80; margin-bottom: 10px; }
.meta { color: #9ca3af; margin-bottom: 20px; font-size: 0.9em; }
table { width: 100%; border-collapse: collapse; margin-top: 10px; }
th { background: #16213e; color: #4ade80; text-align: left; padding: 8px 12px;
     cursor: pointer; user-select: none; border-bottom: 2px solid #0f3460; }
th:hover { background: #0f3460; }
td { padding: 6px 12px; border-bottom: 1px solid #16213e; max-width: 400px;
     overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
tr:hover td { background: #16213e; }
.sev { font-weight: bold; padding: 2px 6px; border-radius: 3px; font-size: 0.85em; }
@media print { body { background: white; color: black; }
  th { background: #f0f0f0; color: black; } td { border-color: #ccc; } }
"""

_JS = """\
document.querySelectorAll('th').forEach((th,i) => {
  th.addEventListener('click', () => {
    const tbody = th.closest('table').querySelector('tbody');
    const rows = Array.from(tbody.querySelectorAll('tr'));
    const dir = th.dataset.dir === 'asc' ? 'desc' : 'asc';
    th.dataset.dir = dir;
    rows.sort((a,b) => {
      const av = a.children[i]?.textContent || '';
      const bv = b.children[i]?.textContent || '';
      return dir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av);
    });
    rows.forEach(r => tbody.appendChild(r));
  });
});
"""


def render_html_report(
    events: list[LogEvent],
    output_path: str,
    title: str = "logparse Report",
    fields: list[str] | None = None,
) -> None:
    """Write a self-contained HTML report to disk."""
    if fields is None:
        fields = ["Timestamp", "Severity", "Source", "Message"]
        # discover extra fields
        extra_keys: set[str] = set()
        for e in events[:200]:
            extra_keys.update(e.extra.keys())
        if extra_keys:
            fields.extend(sorted(extra_keys))

    # header stats
    ts_events = [e for e in events if e.timestamp]
    time_range = ""
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        if first is not None and last is not None:
            time_range = f"{first:%Y-%m-%d %H:%M:%S} &mdash; {last:%Y-%m-%d %H:%M:%S}"

    source_files = sorted(set(e.source_file for e in events if e.source_file))

    html_parts = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        f"<title>{escape(title)}</title>",
        f"<style>{_CSS}</style>",
        "</head><body>",
        f"<h1>{escape(title)}</h1>",
        '<div class="meta">',
        f"  <div>Events: {format_number(len(events))}</div>",
    ]
    if time_range:
        html_parts.append(f"  <div>Time range: {time_range}</div>")
    if source_files:
        html_parts.append(f"  <div>Sources: {escape(', '.join(source_files))}</div>")
    from datetime import datetime
    html_parts.append(f"  <div>Generated: {datetime.now():%Y-%m-%d %H:%M:%S}</div>")
    html_parts.append("</div>")

    # table
    html_parts.append("<table><thead><tr>")
    for f in fields:
        html_parts.append(f"<th>{escape(f)}</th>")
    html_parts.append("</tr></thead><tbody>")

    for event in events:
        html_parts.append("<tr>")
        for f in fields:
            val = ""
            if f == "Timestamp":
                val = event.timestamp.strftime("%Y-%m-%d %H:%M:%S") if event.timestamp else ""
            elif f == "Severity":
                color = _SEV_COLORS.get(event.severity, "#9ca3af")
                val = f'<span class="sev" style="color:{color}">{escape(event.severity)}</span>'
                html_parts.append(f"<td>{val}</td>")
                continue
            elif f == "Source":
                val = event.source or ""
            elif f == "Message":
                val = (event.message or "").replace("\n", " ")
            else:
                val = get_field(event, f) or ""
            html_parts.append(f"<td>{escape(val)}</td>")
        html_parts.append("</tr>")

    html_parts.append("</tbody></table>")
    html_parts.append(f"<script>{_JS}</script>")
    html_parts.append("</body></html>")

    Path(output_path).write_text("\n".join(html_parts), encoding="utf-8")


# ---------------------------------------------------------------------------
# Evidence HTML report — print-ready, self-contained
# ---------------------------------------------------------------------------

_EVIDENCE_CSS = """\
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', Arial, sans-serif; color: #1a1a2e; padding: 40px; max-width: 900px; margin: 0 auto; }
h1 { color: #0f3460; margin-bottom: 4px; font-size: 1.6em; }
h2 { color: #16213e; margin: 24px 0 8px 0; font-size: 1.2em; border-bottom: 2px solid #0f3460; padding-bottom: 4px; }
h3 { color: #333; margin: 12px 0 4px 0; font-size: 1em; }
.meta { color: #666; margin-bottom: 24px; font-size: 0.9em; line-height: 1.6; }
table { width: 100%; border-collapse: collapse; margin: 8px 0 16px 0; font-size: 0.85em; }
th { background: #0f3460; color: white; text-align: left; padding: 6px 10px; }
td { padding: 5px 10px; border-bottom: 1px solid #ddd; }
tr:nth-child(even) td { background: #f8f9fa; }
.sufficient { color: #16a34a; font-weight: bold; }
.partial { color: #ca8a04; font-weight: bold; }
.gap { color: #dc2626; font-weight: bold; }
.alert { background: #fef2f2; border-left: 4px solid #dc2626; padding: 8px 12px; margin: 8px 0; }
.ok { background: #f0fdf4; border-left: 4px solid #16a34a; padding: 8px 12px; margin: 8px 0; }
.finding { margin: 4px 0; padding: 4px 0; }
.finding-sev { font-weight: bold; }
.sig-block { margin-top: 32px; border-top: 1px solid #ccc; padding-top: 16px; }
@media print { body { padding: 20px; } h2 { page-break-before: auto; } }
@page { margin: 1in; }
"""


def render_evidence_html(
    events: list[LogEvent],
    output_path: str,
    organization: str = "",
    analyst: str = "",
) -> None:
    """Write a print-ready HTML evidence report."""
    from collections import Counter
    from datetime import datetime

    from logparse.compliance_data import (
        CONTROLS, DOMAINS, evidence_status, get_domain_controls, matches_control,
    )

    now = datetime.now()
    ts_events = [e for e in events if e.timestamp]
    t_min = min((e.timestamp for e in ts_events), default=None)
    t_max = max((e.timestamp for e in ts_events), default=None)

    # Compute source inventory
    source_info: dict[str, dict] = {}
    for e in events:
        sf = e.source_file or e.source or "(unknown)"
        if sf not in source_info:
            source_info[sf] = {"format": e.source_format or "unknown", "count": 0}
        source_info[sf]["count"] += 1

    # Compute control scores
    ctrl_counts: Counter[str] = Counter()
    for e in events:
        for ctrl_id, ctrl in CONTROLS.items():
            if matches_control(e.extra, e.message, ctrl):
                ctrl_counts[ctrl_id] += 1

    formats = set(i["format"] for i in source_info.values())
    al3_id = "IS.WP.AL-3"
    if al3_id in CONTROLS:
        ctrl_counts[al3_id] = len(formats)

    h = [
        "<!DOCTYPE html>",
        '<html lang="en"><head><meta charset="utf-8">',
        "<title>Log Review Evidence Report</title>",
        f"<style>{_EVIDENCE_CSS}</style>",
        "</head><body>",
        "<h1>Log Review Evidence Report</h1>",
    ]

    # Meta
    h.append('<div class="meta">')
    if organization:
        h.append(f"<div><strong>Organization:</strong> {escape(organization)}</div>")
    if analyst:
        h.append(f"<div><strong>Analyst:</strong> {escape(analyst)}</div>")
    h.append(f"<div><strong>Generated:</strong> {now:%Y-%m-%d %H:%M:%S}</div>")
    h.append(f"<div><strong>Events analyzed:</strong> {format_number(len(events))}</div>")
    if t_min is not None and t_max is not None:
        h.append(f"<div><strong>Review period:</strong> "
                 f"{t_min:%Y-%m-%d %H:%M} &mdash; {t_max:%Y-%m-%d %H:%M}</div>")
    h.append("</div>")

    # TOC
    h.append("<h2>Contents</h2><ol>")
    for label in ["Log Sources Inventory", "FFIEC Control Evidence",
                   "Log Retention", "Audit Trail Integrity", "Review Certification"]:
        anchor = label.lower().replace(" ", "-")
        h.append(f'<li><a href="#{anchor}">{escape(label)}</a></li>')
    h.append("</ol>")

    # Section 1 — Sources
    h.append('<h2 id="log-sources-inventory">1. Log Sources Inventory</h2>')
    h.append("<p><em>Demonstrates multi-source log aggregation per FFIEC "
             "Information Security Booklet &sect;II.C.22</em></p>")
    h.append("<table><thead><tr><th>Source</th><th>Format</th>"
             "<th>Events</th></tr></thead><tbody>")
    for sf, info in sorted(source_info.items(), key=lambda x: -x[1]["count"]):
        h.append(f"<tr><td>{escape(sf)}</td><td>{escape(info['format'])}</td>"
                 f"<td>{format_number(info['count'])}</td></tr>")
    h.append("</tbody></table>")
    h.append(f"<p>{len(source_info)} source(s), {len(formats)} format(s)</p>")

    # Section 2 — FFIEC controls
    h.append('<h2 id="ffiec-control-evidence">2. FFIEC Control Evidence</h2>')
    h.append("<table><thead><tr><th>Domain</th><th>Name</th>"
             "<th>Coverage</th><th>Status</th></tr></thead><tbody>")

    domains_sufficient = 0
    for domain_id, domain_name in DOMAINS.items():
        controls = get_domain_controls(domain_id)
        if not controls:
            continue
        suf = sum(1 for c in controls
                  if evidence_status(ctrl_counts.get(c.control_id, 0), c) == "Sufficient")
        if suf == len(controls):
            status_cls, status_txt = "sufficient", "SUFFICIENT"
            domains_sufficient += 1
        elif suf > 0 or any(
            evidence_status(ctrl_counts.get(c.control_id, 0), c) == "Partial"
            for c in controls
        ):
            status_cls, status_txt = "partial", "PARTIAL"
        else:
            status_cls, status_txt = "gap", "GAP"
        h.append(f"<tr><td>{escape(domain_id)}</td><td>{escape(domain_name)}</td>"
                 f"<td>{suf}/{len(controls)}</td>"
                 f'<td class="{status_cls}">{status_txt}</td></tr>')
    h.append("</tbody></table>")

    coverage = (domains_sufficient / len(DOMAINS) * 100) if DOMAINS else 0
    h.append(f"<p><strong>Overall domain coverage: {coverage:.0f}%</strong> "
             f"({domains_sufficient}/{len(DOMAINS)} domains)</p>")

    # Section 3 — Retention
    h.append('<h2 id="log-retention">3. Log Retention</h2>')
    if t_min is not None and t_max is not None:
        days = (t_max - t_min).days
        cls = "ok" if days >= 90 else "alert"
        label = "meets" if days >= 90 else "below"
        h.append(f'<div class="{cls}">Log span: <strong>{days} days</strong>'
                 f" &mdash; {label} FFIEC 90-day minimum recommendation</div>")
    else:
        h.append('<div class="alert">No timestamped events available.</div>')

    # Section 4 — Integrity
    h.append('<h2 id="audit-trail-integrity">4. Audit Trail Integrity</h2>')
    log_clears = sum(1 for e in events if e.extra.get("EventID") == "1102")
    policy_changes = sum(1 for e in events if e.extra.get("EventID") == "4719")
    if log_clears:
        h.append(f'<div class="alert">ALERT: {log_clears} audit log clear event(s) '
                 f"detected (EID 1102)</div>")
    else:
        h.append('<div class="ok">No audit log clear events detected (EID 1102)</div>')
    if policy_changes:
        h.append(f"<p>{policy_changes} audit policy change(s) detected (EID 4719)</p>")

    # Section 5 — Signature
    h.append('<h2 id="review-certification">5. Review Certification</h2>')
    h.append('<div class="sig-block">')
    h.append("<p>This report documents automated log review. Evidence demonstrates "
             "ongoing monitoring per FFIEC Information Security Booklet &sect;II.C.22 "
             "and NCUA Part 748 Appendix A &sect;III.C.2.</p>")
    h.append("<br><p>Reviewed by: ___________________________&nbsp;&nbsp;&nbsp;"
             "Date: ______________</p>")
    h.append("</div>")

    h.append("</body></html>")
    Path(output_path).write_text("\n".join(h), encoding="utf-8")
