#!/usr/bin/env python3
"""Table and grid output formatters using rich."""

from __future__ import annotations

import re

from rich.console import Console
from rich.style import Style
from rich.table import Table
from rich.text import Text

from logparse.models import LogEvent, get_field
from logparse.pipeline import AggResult, StatsResult
from logparse.util import format_number

_SEV_STYLE: dict[str, Style] = {
    "Critical": Style(color="red", bold=True),
    "High": Style(color="red"),
    "Medium": Style(color="yellow"),
    "Low": Style(color="cyan"),
    "Info": Style(color="bright_black"),
}

_DEFAULT_FIELDS = ("Timestamp", "Severity", "Source", "Message")


def _format_ts(event: LogEvent) -> str:
    if event.timestamp is not None:
        return event.timestamp.strftime("%Y-%m-%d %H:%M:%S")
    return ""


def _cell_value(event: LogEvent, field: str) -> str:
    match field:
        case "Timestamp":
            return _format_ts(event)
        case "Severity":
            return event.severity
        case "Source":
            return event.source
        case "Message":
            return event.message.replace("\n", " ")
        case _:
            return get_field(event, field) or ""


def _apply_highlight(text: Text, pattern: str) -> Text:
    """Highlight matches in a rich Text object."""
    if not pattern:
        return text
    try:
        text.highlight_regex(pattern, style="on yellow bold")
    except re.error:
        pass
    return text


def _severity_text(sev: str) -> Text:
    style = _SEV_STYLE.get(sev, Style())
    return Text(sev, style=style)


def render_stats(
    result: StatsResult,
    console: Console,
) -> None:
    """Render numeric statistics as key-value display."""
    if result.count == 0:
        console.print(f"[dim]No numeric values found for field '{result.field}'.[/dim]")
        return
    console.print()
    console.print(f"  [bold]Field[/bold]    : {result.field}")
    console.print(f"  [bold]Count[/bold]    : {format_number(result.count)}")
    console.print(f"  [bold]Min[/bold]      : {result.min_val:,.2f}")
    console.print(f"  [bold]Max[/bold]      : {result.max_val:,.2f}")
    console.print(f"  [bold]Avg[/bold]      : {result.avg_val:,.2f}")
    console.print(f"  [bold]Sum[/bold]      : {result.sum_val:,.2f}")
    console.print()


def render_agg(
    results: list[AggResult],
    console: Console,
    max_results: int = 0,
) -> None:
    """Render aggregation results (count by, timeline, stats)."""
    try:
        max_results = int(max_results)
    except (TypeError, ValueError):
        max_results = 0
    display = results[:max_results] if max_results > 0 else results
    if not display:
        console.print("[dim]No results.[/dim]")
        return

    # Handle StatsResult objects
    if isinstance(display[0], StatsResult):
        table = Table(show_header=True, show_footer=False, box=None, pad_edge=False)
        table.add_column("FIELD", style="bold")
        table.add_column("COUNT", justify="right", style="cyan")
        table.add_column("MIN", justify="right")
        table.add_column("MAX", justify="right")
        table.add_column("AVG", justify="right")
        table.add_column("SUM", justify="right")
        for r in display:
            table.add_row(
                r.field, format_number(r.count),
                f"{r.min_val:,.0f}", f"{r.max_val:,.0f}",
                f"{r.avg_val:,.1f}", f"{r.sum_val:,.0f}",
            )
        console.print(table)
        return

    field_label = display[0].field.upper() if hasattr(display[0], 'field') and display[0].field else "KEY"
    table = Table(show_header=True, show_footer=False, box=None, pad_edge=False)
    table.add_column(field_label, style="bold")
    table.add_column("COUNT", justify="right", style="cyan")

    for r in display:
        table.add_row(r.key, format_number(r.count))

    console.print(table)
    console.print(f"[dim]{format_number(len(display))} results[/dim]")


def render_table(
    events: list[LogEvent],
    console: Console,
    fields: tuple[str, ...] | list[str] = _DEFAULT_FIELDS,
    highlight: str = "",
    max_results: int = 0,
    annotations: dict[int, str] | None = None,
) -> None:
    """Render events as a bordered table."""
    if not events:
        console.print("[dim]No events to display.[/dim]")
        return
    # Guard: if pipeline produced non-LogEvent results, delegate to render_agg
    if not isinstance(events[0], LogEvent):
        if isinstance(events[0], (AggResult, StatsResult)):
            render_agg(events, console, max_results=max_results)
            return
        console.print("[dim]No events to display.[/dim]")
        return

    _RENDER_CAP = 500
    display = events[:max_results] if max_results > 0 else events
    overflow = len(display) - _RENDER_CAP if len(display) > _RENDER_CAP else 0
    display = display[:_RENDER_CAP]

    # Auto-prune empty columns and cap to terminal width (e.g. show *)
    if len(fields) > len(_DEFAULT_FIELDS):
        # Phase 1: remove completely empty fields
        extras_pop: list[tuple[str, int]] = []
        for f in fields:
            if f in _DEFAULT_FIELDS:
                continue
            pop = sum(1 for e in display if _cell_value(e, f))
            if pop > 0:
                extras_pop.append((f, pop))

        # Phase 2: cap extras to what fits in the terminal
        # Core fields need ~80 chars; each extra needs ~12 to be readable
        term_width = console.width or 120
        max_extras = max((term_width - 80) // 12, 2)
        extras_pop.sort(key=lambda x: x[1], reverse=True)
        shown_extras = {f for f, _ in extras_pop[:max_extras]}

        new_fields = [f for f in fields if f in _DEFAULT_FIELDS or f in shown_extras]
        total_hidden = len(fields) - len(new_fields)
        if total_hidden > 0:
            fields = new_fields
            console.print(f"[dim]({total_hidden} fields hidden — use show <field> to view)[/dim]")

    table = Table(
        show_header=True,
        show_footer=True,
        expand=True,
        highlight=False,
    )

    # add columns — Message gets priority sizing
    term_width = console.width or 120
    msg_min_ratio = 0.40
    msg_min = int(term_width * msg_min_ratio)

    # row number column
    table.add_column("#", footer="#", width=4, justify="right",
                     style="dim", no_wrap=True)

    for f in fields:
        footer_label = f
        if f == "Message":
            table.add_column(f, footer=footer_label, min_width=msg_min, ratio=3, no_wrap=True, overflow="ellipsis")
        elif f == "Timestamp":
            table.add_column(f, footer=footer_label, width=19, no_wrap=True)
        elif f == "Severity":
            sev_w = 12 if annotations else 8
            table.add_column(f, footer=footer_label, width=sev_w, no_wrap=True)
        elif f == "Source":
            table.add_column(f, footer=footer_label, max_width=20, no_wrap=True, overflow="ellipsis")
        else:
            table.add_column(f, footer=footer_label, max_width=20, no_wrap=True, overflow="ellipsis")

    for row_idx, event in enumerate(display, 1):
        row: list[Text | str] = [Text(str(row_idx), style="dim")]
        for f in fields:
            val = _cell_value(event, f)
            if f == "Severity":
                sev_text = _severity_text(val)
                # Check global event index for annotations (annotations are
                # keyed by position in session.all_events)
                if annotations and (row_idx + (offset if 'offset' in dir() else 0)) in annotations:
                    sev_text = Text(f"{val} [A]", style=_SEV_STYLE.get(val, Style()))
                row.append(sev_text)
            else:
                t = Text(val)
                if highlight:
                    _apply_highlight(t, highlight)
                row.append(t)
        table.add_row(*row)

    console.print(table)
    total = len(events)
    shown = len(display)
    footer = f"{format_number(shown)} events"
    if overflow:
        footer += f" (… and {format_number(overflow)} more, use --export for full output)"
    elif max_results > 0 and total > max_results:
        footer += f" (of {format_number(total)})"
    console.print(f"[dim]{footer}[/dim]")


def render_grid(
    events: list[LogEvent],
    console: Console,
    fields: tuple[str, ...] | list[str] = _DEFAULT_FIELDS,
    highlight: str = "",
    max_results: int = 0,
) -> None:
    """Render events as a compact borderless grid."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    _RENDER_CAP = 500
    display = events[:max_results] if max_results > 0 else events
    overflow2 = len(display) - _RENDER_CAP if len(display) > _RENDER_CAP else 0
    display = display[:_RENDER_CAP]

    table = Table(
        show_header=True,
        show_footer=True,
        box=None,
        pad_edge=False,
        expand=True,
        highlight=False,
    )

    term_width = console.width or 120
    msg_min = int(term_width * 0.40)

    for f in fields:
        header = "SEV" if f == "Severity" else f.upper()
        if f == "Message":
            table.add_column(header, footer=header, min_width=msg_min, ratio=3, no_wrap=True, overflow="ellipsis")
        elif f == "Timestamp":
            table.add_column(header, footer=header, width=19, no_wrap=True)
        elif f == "Severity":
            table.add_column(header, footer=header, width=6, no_wrap=True)
        elif f == "Source":
            table.add_column(header, footer=header, max_width=20, no_wrap=True, overflow="ellipsis")
        else:
            table.add_column(header, footer=header, max_width=20, no_wrap=True, overflow="ellipsis")

    for event in display:
        row: list[Text | str] = []
        for f in fields:
            val = _cell_value(event, f)
            if f == "Severity":
                # abbreviated — get style from full name before abbreviating
                style = _SEV_STYLE.get(val, Style())
                abbrev = {"Critical": "CRIT", "High": "HIGH", "Medium": "MED", "Low": "LOW", "Info": "INFO"}.get(val, val)
                row.append(Text(abbrev, style=style))
            else:
                t = Text(val)
                if highlight:
                    _apply_highlight(t, highlight)
                row.append(t)
        table.add_row(*row)

    console.print(table)
    total = len(events)
    shown = len(display)
    footer = f"{format_number(shown)} events"
    if overflow2:
        footer += f" (… and {format_number(overflow2)} more, use --export for full output)"
    elif max_results > 0 and total > max_results:
        footer += f" (of {format_number(total)})"
    console.print(f"[dim]{footer}[/dim]")
