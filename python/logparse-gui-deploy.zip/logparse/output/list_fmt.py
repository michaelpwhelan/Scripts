#!/usr/bin/env python3
"""Vertical detail view formatter."""

from __future__ import annotations

from rich.console import Console
from rich.text import Text

from logparse.models import LogEvent
from logparse.output.table import _SEV_STYLE, _apply_highlight
from logparse.util import format_number


def render_list(
    events: list[LogEvent],
    console: Console,
    highlight: str = "",
    max_results: int = 0,
) -> None:
    """Render events in vertical list format with all fields."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    display = events[:max_results] if max_results > 0 else events

    for idx, event in enumerate(display, 1):
        console.rule(f"Event {idx} of {format_number(len(display))}", style="dim")

        fields: dict[str, str] = {}
        fields["Timestamp"] = (
            event.timestamp.strftime("%Y-%m-%d %H:%M:%S") if event.timestamp else ""
        )
        fields["Severity"] = event.severity
        fields["Source"] = event.source

        # extra fields
        for k, v in sorted(event.extra.items()):
            fields[k] = v

        fields["Message"] = event.message.replace("\n", "\n" + " " * 16)

        # truncated raw
        raw = event.raw
        if len(raw) > 500:
            raw = raw[:500] + "\u2026"
        fields["Raw"] = raw.replace("\n", "\n" + " " * 16)

        max_label = max(len(k) for k in fields) if fields else 10

        for label, val in fields.items():
            label_str = label.rjust(max_label)
            if label == "Severity":
                style = _SEV_STYLE.get(val)
                val_text = Text(val, style=style) if style else Text(val)
            else:
                val_text = Text(val)
                if highlight:
                    _apply_highlight(val_text, highlight)

            console.print(f"  [cyan]{label_str}[/cyan] : ", end="")
            console.print(val_text)
