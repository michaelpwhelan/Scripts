#!/usr/bin/env python3
"""Session state for interactive mode."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime

from logparse.models import LogEvent


@dataclass
class FilterSnapshot:
    """A saved filter state."""

    description: str
    events: list[LogEvent]
    hide_rules: list["HideRule"] = field(default_factory=list)


@dataclass
class TranscriptEntry:
    """Record of a single REPL command."""

    timestamp: datetime
    command: str
    summary: str
    event_count: int


@dataclass
class Note:
    """Investigation note."""

    text: str
    nid: int = 0
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class HideRule:
    """Active hide rule."""

    field: str
    values: list[str]
    mode: str = ""  # "eq", "wildcard", "contains", "in"; inferred if empty


def _hide_rule_op_pattern(rule: HideRule) -> tuple[str, str]:
    """Derive (op, pattern) from a HideRule, using stored mode or inferring."""
    if rule.mode:
        op = rule.mode
    elif len(rule.values) > 1:
        op = "in"
    elif rule.values and ("*" in rule.values[0] or "?" in rule.values[0]):
        op = "wildcard"
    else:
        op = "eq"
    if op == "in":
        pattern = ",".join(rule.values)
    else:
        pattern = rule.values[0] if rule.values else ""
    return op, pattern


@dataclass
class Session:
    """Interactive session state."""

    all_events: list[LogEvent]
    filtered_events: list[LogEvent]
    active_filter: str = ""
    filter_history: list[FilterSnapshot] = field(default_factory=list)
    saved_filters: dict[int, FilterSnapshot] = field(default_factory=dict)
    transcript: list[TranscriptEntry] = field(default_factory=list)
    source_files: list[str] = field(default_factory=list)
    skipped_files: list[str] = field(default_factory=list)
    loaded_formats: list[str] = field(default_factory=list)
    display_columns: list[str] = field(
        default_factory=lambda: ["Timestamp", "Severity", "Source", "Message"]
    )
    highlight: str = ""
    time_window: tuple[datetime, datetime] | None = None
    ip_scope: str | None = None
    start_time: datetime = field(default_factory=datetime.now)
    variables: dict[str, str | list[str]] = field(default_factory=dict)
    starred: set[int] = field(default_factory=set)
    notes: list[Note] = field(default_factory=list)
    hide_rules: list[HideRule] = field(default_factory=list)
    last_output: list = field(default_factory=list)
    sort_field: str = ""
    sort_descending: bool = True
    timestamp_format: str = "datetime"  # datetime, time, relative
    config: dict = field(default_factory=dict)
    annotations: dict[int, str] = field(default_factory=dict)
    charts: list = field(default_factory=list)
    tags: dict[int, set[str]] = field(default_factory=dict)
    _shown_hints: set[str] = field(default_factory=set)
    _next_filter_id: int = 1
    _next_note_id: int = 1
    _last_resolved: str | None = None
    _pipeline_warnings: list[str] = field(default_factory=list)
    _field_name_cache: set[str] | None = None
    _value_index: dict[str, dict[str, int]] | None = None

    _MAX_FILTER_HISTORY = 50

    def push_filter(self, description: str) -> None:
        """Save current state and prepare for new filter."""
        self.filter_history.append(
            FilterSnapshot(self.active_filter, list(self.filtered_events),
                           list(self.hide_rules))
        )
        # Cap history to prevent unbounded memory growth
        if len(self.filter_history) > self._MAX_FILTER_HISTORY:
            self.filter_history = self.filter_history[-self._MAX_FILTER_HISTORY:]
        self.active_filter = description

    def undo(self) -> bool:
        """Pop filter history. Returns False if nothing to undo."""
        if not self.filter_history:
            return False
        snap = self.filter_history.pop()
        self.filtered_events = list(snap.events)
        self.active_filter = snap.description
        self.hide_rules = list(snap.hide_rules)
        return True

    def reset(self) -> None:
        """Clear all filters, ip scope, time window, hides."""
        self.filtered_events = list(self.all_events)
        self.active_filter = ""
        self.filter_history.clear()
        self.ip_scope = None
        self.time_window = None
        self.highlight = ""
        self.hide_rules.clear()

    def save_filter(self) -> int:
        """Snapshot current filter state, return its ID."""
        fid = self._next_filter_id
        self._next_filter_id += 1
        self.saved_filters[fid] = FilterSnapshot(
            self.active_filter, list(self.filtered_events),
            list(self.hide_rules),
        )
        return fid

    def restore_filter(self, fid: int) -> bool:
        """Restore a saved filter by ID."""
        snap = self.saved_filters.get(fid)
        if snap is None:
            return False
        self.push_filter(f"restored #{fid}")
        self.filtered_events = list(snap.events)
        self.active_filter = snap.description
        self.hide_rules = list(snap.hide_rules)
        return True

    def log_command(self, command: str, summary: str) -> None:
        """Add entry to transcript."""
        self.transcript.append(TranscriptEntry(
            timestamp=datetime.now(),
            command=command,
            summary=summary,
            event_count=len(self.filtered_events),
        ))

    def all_field_names(self) -> list[str]:
        """Collect all field names across all events."""
        names: set[str] = {"Timestamp", "Severity", "Source", "Message"}
        for e in self.all_events:
            names.update(e.extra.keys())
        return sorted(names)

    def invalidate_caches(self) -> None:
        """Invalidate field name and value index caches after event changes."""
        self._field_name_cache = None
        self._value_index = None

    def field_names_lower(self) -> set[str]:
        """Cached set of lowercased field names for resolver lookups."""
        if self._field_name_cache is None:
            self._field_name_cache = {n.lower() for n in self.all_field_names()}
        return self._field_name_cache

    def build_value_index(self) -> dict[str, dict[str, int]]:
        """Build {field_lower: {value_lower: count}} for categorical fields.

        Only indexes fields with < 100 unique values.  Built lazily on
        first call and cached for the session lifetime.
        """
        if self._value_index is not None:
            return self._value_index

        from collections import Counter
        raw: dict[str, Counter[str]] = {}
        for e in self.all_events:
            for k, v in e.extra.items():
                if v:
                    raw.setdefault(k.lower(), Counter())[v.lower()] += 1
            # core categorical fields
            if e.severity:
                raw.setdefault("severity", Counter())[e.severity.lower()] += 1
            if e.source:
                raw.setdefault("source", Counter())[e.source.lower()] += 1

        self._value_index = {
            field: dict(counts)
            for field, counts in raw.items()
            if len(counts) < 100
        }
        return self._value_index

    def add_note(self, text: str) -> int:
        """Add an investigation note, return its ID."""
        nid = self._next_note_id
        self._next_note_id += 1
        self.notes.append(Note(text=text, nid=nid))
        return nid

    def delete_note(self, nid: int) -> bool:
        """Delete note by ID."""
        for i, note in enumerate(self.notes):
            if note.nid == nid:
                self.notes.pop(i)
                return True
        return False

    def apply_hide_rules(self) -> None:
        """Re-filter events based on active hide rules."""
        from logparse.filter_engine import match_field
        from logparse.models import get_field
        if not self.hide_rules:
            return
        result = list(self.filtered_events)
        for rule in self.hide_rules:
            op, pattern = _hide_rule_op_pattern(rule)
            result = [
                e for e in result
                if not match_field(get_field(e, rule.field) or "", pattern, op)
            ]
        self.filtered_events = result
