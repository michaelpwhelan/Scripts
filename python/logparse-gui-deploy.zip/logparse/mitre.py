#!/usr/bin/env python3
"""MITRE ATT&CK technique library and scan engine.

Bundled offline technique signatures for Windows Security, FortiGate,
and FortiClient log sources. No external data fetching.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime

from logparse.models import LogEvent, get_field, timestamp_range


@dataclass(frozen=True)
class TechniqueSignature:
    """A single MITRE ATT&CK technique detection signature."""

    technique_id: str
    name: str
    tactic: str
    event_ids: frozenset[str] = field(default_factory=frozenset)
    field_patterns: tuple[tuple[str, str], ...] = ()
    message_patterns: tuple[str, ...] = ()
    severity: str = "Medium"
    min_count: int = 1


@dataclass
class TechniqueMatch:
    """Result of scanning events against a technique signature."""

    technique: TechniqueSignature
    events: list[LogEvent]
    count: int
    first_seen: datetime | None = None
    last_seen: datetime | None = None
    score: float = 0.0


@dataclass
class KillChain:
    """Known attack sequence composed of technique stages."""

    name: str
    stages: list[str]
    description: str


_SEV_WEIGHT = {"Critical": 4.0, "High": 3.0, "Medium": 2.0, "Low": 1.0, "Info": 0.5}

TECHNIQUES: dict[str, TechniqueSignature] = {}


def _t(
    tid: str, name: str, tactic: str, *,
    event_ids: frozenset[str] | None = None,
    field_patterns: tuple[tuple[str, str], ...] = (),
    message_patterns: tuple[str, ...] = (),
    severity: str = "Medium",
    min_count: int = 1,
) -> None:
    sig = TechniqueSignature(
        technique_id=tid, name=name, tactic=tactic,
        event_ids=event_ids or frozenset(),
        field_patterns=field_patterns,
        message_patterns=message_patterns,
        severity=severity, min_count=min_count,
    )
    TECHNIQUES[tid] = sig


# --- Credential Access ---
_t("T1110", "Brute Force", "Credential Access",
   event_ids=frozenset({"4625"}),
   field_patterns=(("action", "ssl-login-fail"),),
   severity="High", min_count=10)

_t("T1110.003", "Password Spraying", "Credential Access",
   event_ids=frozenset({"4625"}),
   message_patterns=(r"different\s+user|multiple.*account",),
   severity="High", min_count=5)

_t("T1558", "Kerberos Ticket Theft", "Credential Access",
   event_ids=frozenset({"4768", "4769"}),
   message_patterns=(r"0x17|RC4",),
   severity="High", min_count=1)

# --- Initial Access ---
_t("T1078", "Valid Accounts", "Initial Access",
   event_ids=frozenset({"4624"}),
   message_patterns=(r"LogonType.*10|logon type.*10",),
   severity="Medium", min_count=1)

_t("T1133", "External Remote Services", "Initial Access",
   field_patterns=(("subtype", "vpn"), ("action", "ssl-login")),
   severity="Medium", min_count=1)

_t("T1190", "Exploit Public-Facing App", "Initial Access",
   field_patterns=(("subtype", "ips"),),
   message_patterns=(r"critical|severity.*critical",),
   severity="Critical", min_count=1)

# --- Persistence ---
_t("T1136", "Create Account", "Persistence",
   event_ids=frozenset({"4720"}),
   severity="High", min_count=1)

_t("T1098", "Account Manipulation", "Persistence",
   event_ids=frozenset({"4738", "4728", "4732"}),
   severity="Medium", min_count=1)

_t("T1053", "Scheduled Task/Job", "Execution",
   event_ids=frozenset({"4698", "4699", "4702"}),
   severity="Medium", min_count=1)

_t("T1543", "Create or Modify System Process", "Persistence",
   event_ids=frozenset({"7045", "4697"}),
   severity="High", min_count=1)

# --- Defense Evasion ---
_t("T1070.001", "Clear Event Logs", "Defense Evasion",
   event_ids=frozenset({"1102"}),
   severity="Critical", min_count=1)

# --- Discovery ---
_t("T1046", "Network Service Scanning", "Discovery",
   field_patterns=(("action", "deny"),),
   message_patterns=(r"scan|port\s*scan",),
   severity="Medium", min_count=10)

# --- Exfiltration ---
_t("T1048", "Exfiltration Over Alternative Protocol", "Exfiltration",
   field_patterns=(("dstport", "53"),),
   message_patterns=(r"dns|sentbyte",),
   severity="High", min_count=1)

# --- Lateral Movement ---
_t("T1021", "Remote Services", "Lateral Movement",
   field_patterns=(("action", "accept"), ("dstport", "3389")),
   severity="Medium", min_count=1)

_t("T1021.001", "Remote Desktop Protocol", "Lateral Movement",
   event_ids=frozenset({"4624"}),
   message_patterns=(r"LogonType.*10|type.*10",),
   field_patterns=(("dstport", "3389"),),
   severity="Medium", min_count=1)

# --- Privilege Escalation ---
_t("T1068", "Exploitation for Privilege Escalation", "Privilege Escalation",
   event_ids=frozenset({"4672", "4673"}),
   severity="Medium", min_count=1)

# --- Impact ---
_t("T1486", "Data Encrypted for Impact", "Impact",
   message_patterns=(r"ransom|encrypt|locked",),
   severity="Critical", min_count=1)

# --- Additional Windows ---
_t("T1059.001", "PowerShell", "Execution",
   event_ids=frozenset({"4103", "4104", "800"}),
   severity="Low", min_count=1)

_t("T1547.001", "Registry Run Keys", "Persistence",
   event_ids=frozenset({"4657"}),
   message_patterns=(r"Run|RunOnce",),
   severity="Medium", min_count=1)

_t("T1003", "OS Credential Dumping", "Credential Access",
   event_ids=frozenset({"4656", "4663"}),
   message_patterns=(r"lsass|sam|ntds|security",),
   severity="Critical", min_count=1)

_t("T1562.001", "Disable or Modify Tools", "Defense Evasion",
   event_ids=frozenset({"5001"}),
   message_patterns=(r"disabled|real-time.*protection",),
   severity="High", min_count=1)

_t("T1071", "Application Layer Protocol", "Command and Control",
   field_patterns=(("dstport", "443"), ("action", "accept")),
   message_patterns=(r"beacon|c2|callback",),
   severity="Medium", min_count=5)

_t("T1027", "Obfuscated Files or Information", "Defense Evasion",
   event_ids=frozenset({"4104"}),
   message_patterns=(r"base64|encodedcommand|frombase64",),
   severity="High", min_count=1)

# --- Financial Sector Techniques ---
_t("T1566", "Phishing", "Initial Access",
   message_patterns=(r"phish|spear.*phish|malicious.*link|suspicious.*email",),
   severity="High", min_count=1)

_t("T1566.001", "Spearphishing Attachment", "Initial Access",
   message_patterns=(r"attachment.*malicious|malware.*email|infected.*document",),
   severity="High", min_count=1)

_t("T1195", "Supply Chain Compromise", "Initial Access",
   message_patterns=(r"supply.?chain|third.?party.*compromise|vendor.*breach",),
   severity="Critical", min_count=1)

_t("T1657", "Financial Theft", "Impact",
   message_patterns=(r"wire.*transfer|ach.*fraud|unauthorized.*transaction|financial.*theft",),
   severity="Critical", min_count=1)

_t("T1558.003", "Kerberoasting", "Credential Access",
   event_ids=frozenset({"4769"}),
   message_patterns=(r"kerberoast|0x17|RC4.*TGS|ticket.*encryption.*type.*0x17",),
   severity="High", min_count=3)

_t("T1556", "Modify Authentication Process", "Credential Access",
   message_patterns=(r"mfa.*bypass|authentication.*modified|conditional.*access.*changed",),
   severity="Critical", min_count=1)

# --- M365 / Cloud Techniques ---
_t("T1078.004", "Cloud Accounts", "Initial Access",
   message_patterns=(r"cloud.*login|azure.*ad.*sign|entra.*sign|m365.*auth",),
   field_patterns=(("source", "m365"),),
   severity="Medium", min_count=1)

_t("T1098.003", "Additional Cloud Roles", "Persistence",
   message_patterns=(r"role.*assignment|global.*admin|privileged.*role",),
   field_patterns=(("source", "m365"),),
   severity="High", min_count=1)

KILL_CHAINS = [
    KillChain(
        "Brute Force to Access",
        ["T1110", "T1078"],
        "Credential brute-force followed by valid logon — possible account compromise.",
    ),
    KillChain(
        "Account Compromise",
        ["T1110", "T1078", "T1136"],
        "Brute force → valid logon → new account created — persistence established.",
    ),
    KillChain(
        "External Compromise",
        ["T1133", "T1078", "T1021"],
        "External VPN access → valid credentials → lateral movement.",
    ),
    KillChain(
        "Ransomware Preparation",
        ["T1078", "T1003", "T1486"],
        "Valid account → credential dump → data encryption.",
    ),
    KillChain(
        "Defense Evasion Chain",
        ["T1562.001", "T1070.001", "T1059.001"],
        "Disable security tools → clear logs → PowerShell execution.",
    ),
    KillChain(
        "Business Email Compromise",
        ["T1566", "T1078", "T1657"],
        "Phishing → valid account access → financial theft.",
    ),
    KillChain(
        "Cloud Account Takeover",
        ["T1078.004", "T1556", "T1098.003"],
        "Cloud login → MFA bypass → privilege escalation in cloud.",
    ),
]

# ATT&CK tactic ordering for visual layout
TACTIC_ORDER = [
    "Reconnaissance", "Resource Development", "Initial Access",
    "Execution", "Persistence", "Privilege Escalation",
    "Defense Evasion", "Credential Access", "Discovery",
    "Lateral Movement", "Collection", "Command and Control",
    "Exfiltration", "Impact",
]


def _matches_technique(event: LogEvent, sig: TechniqueSignature) -> bool:
    """Check if a single event matches any criteria in the signature."""
    # Check event IDs
    if sig.event_ids:
        eid = get_field(event, "EventID") or get_field(event, "eventid") or ""
        if str(eid) in sig.event_ids:
            return True

    # Check field patterns — all patterns in a tuple must match
    if sig.field_patterns:
        all_match = True
        for field_name, expected in sig.field_patterns:
            actual = (get_field(event, field_name) or "").lower()
            if expected.lower() not in actual:
                all_match = False
                break
        if all_match:
            return True

    # Check message patterns
    if sig.message_patterns:
        # Use cached search string if available (set by scan_events)
        msg = getattr(event, "_search_text", None)
        if msg is None:
            msg = event.message.lower() + " " + " ".join(
                str(v) for v in event.extra.values()
            ).lower()
        for pattern in sig.message_patterns:
            if re.search(pattern, msg, re.IGNORECASE):
                return True

    return False


def scan_events(events: list[LogEvent]) -> list[TechniqueMatch]:
    """Scan events against all technique signatures.

    Returns matches sorted by score descending.
    """
    matches: list[TechniqueMatch] = []

    # Pre-build per-event search text so _matches_technique doesn't
    # rebuild it for each of the ~50 technique signatures.
    for e in events:
        e._search_text = e.message.lower() + " " + " ".join(
            str(v) for v in e.extra.values()
        ).lower()

    for sig in TECHNIQUES.values():
        matched_events = [e for e in events if _matches_technique(e, sig)]
        if len(matched_events) < sig.min_count:
            continue

        first, last = timestamp_range(matched_events)

        weight = _SEV_WEIGHT.get(sig.severity, 2.0)
        ratio = min(len(matched_events) / max(sig.min_count, 1), 3.0)
        score = min(weight * ratio, 10.0)

        matches.append(TechniqueMatch(
            technique=sig,
            events=matched_events,
            count=len(matched_events),
            first_seen=first,
            last_seen=last,
            score=score,
        ))

    matches.sort(key=lambda m: m.score, reverse=True)
    return matches


def detect_kill_chains(
    matches: list[TechniqueMatch],
) -> list[tuple[KillChain, list[TechniqueMatch]]]:
    """Check if detected techniques form known attack sequences."""
    detected_ids = {m.technique.technique_id for m in matches}
    match_map = {m.technique.technique_id: m for m in matches}
    results = []

    for chain in KILL_CHAINS:
        if all(tid in detected_ids for tid in chain.stages):
            chain_matches = [match_map[tid] for tid in chain.stages if tid in match_map]
            results.append((chain, chain_matches))

    return results
