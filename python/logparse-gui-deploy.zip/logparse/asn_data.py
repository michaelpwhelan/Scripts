#!/usr/bin/env python3
"""Bundled ASN lookup data.

Static curated table of major ASN allocations — last updated 2025-03.
No external API calls. Uses ipaddress module for CIDR matching.
"""

from __future__ import annotations

import ipaddress
from functools import lru_cache

# (network_cidr, asn_number, org_name, country_code)
_ASN_TABLE: list[tuple[str, int, str, str]] = [
    # Major cloud / hyperscaler
    ("8.8.4.0/24", 15169, "Google LLC", "US"),
    ("8.8.8.0/24", 15169, "Google LLC", "US"),
    ("1.1.1.0/24", 13335, "Cloudflare Inc.", "US"),
    ("1.0.0.0/24", 13335, "Cloudflare Inc.", "US"),
    ("104.16.0.0/12", 13335, "Cloudflare Inc.", "US"),
    ("172.64.0.0/13", 13335, "Cloudflare Inc.", "US"),
    ("35.184.0.0/13", 15169, "Google LLC", "US"),
    ("35.192.0.0/12", 15169, "Google LLC", "US"),
    ("35.208.0.0/12", 15169, "Google LLC", "US"),
    ("35.224.0.0/12", 15169, "Google LLC", "US"),
    ("35.240.0.0/13", 15169, "Google LLC", "US"),
    ("34.64.0.0/10", 15169, "Google LLC", "US"),
    ("34.128.0.0/10", 15169, "Google LLC", "US"),
    ("3.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("13.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("15.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("18.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("44.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("50.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("52.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("54.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("99.0.0.0/8", 16509, "Amazon.com (AWS)", "US"),
    ("20.0.0.0/8", 8075, "Microsoft Azure", "US"),
    ("13.64.0.0/11", 8075, "Microsoft Azure", "US"),
    ("40.64.0.0/10", 8075, "Microsoft Azure", "US"),
    ("51.104.0.0/14", 8075, "Microsoft Azure", "US"),
    ("52.224.0.0/11", 8075, "Microsoft Azure", "US"),
    ("104.208.0.0/13", 8075, "Microsoft Azure", "US"),
    ("134.209.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("138.197.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("139.59.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("142.93.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("157.230.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("159.65.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("159.89.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("161.35.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("164.90.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("167.172.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("167.71.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("174.138.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("178.128.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("206.189.0.0/16", 14061, "DigitalOcean LLC", "US"),
    ("209.97.0.0/16", 14061, "DigitalOcean LLC", "US"),
    # CDN / hosting
    ("151.101.0.0/16", 54113, "Fastly Inc.", "US"),
    ("199.232.0.0/16", 54113, "Fastly Inc.", "US"),
    ("23.0.0.0/8", 16625, "Akamai Technologies", "US"),
    ("2.16.0.0/13", 20940, "Akamai International", "NL"),
    ("96.16.0.0/12", 20940, "Akamai International", "US"),
    ("184.24.0.0/13", 20940, "Akamai International", "US"),
    ("198.41.128.0/17", 13335, "Cloudflare Inc.", "US"),
    # ISPs / transit
    ("4.0.0.0/8", 3356, "Lumen Technologies", "US"),
    ("12.0.0.0/8", 7018, "AT&T Services", "US"),
    ("63.0.0.0/8", 3356, "Lumen Technologies", "US"),
    ("64.0.0.0/8", 3356, "Lumen Technologies", "US"),
    ("65.0.0.0/8", 209, "CenturyLink", "US"),
    ("66.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("67.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("68.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("69.0.0.0/8", 6167, "Verizon Business", "US"),
    ("71.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("72.0.0.0/8", 7018, "AT&T Services", "US"),
    ("73.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("74.0.0.0/8", 7018, "AT&T Services", "US"),
    ("75.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("76.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("96.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("97.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("98.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("107.0.0.0/8", 3356, "Lumen Technologies", "US"),
    ("108.0.0.0/8", 7018, "AT&T Services", "US"),
    ("128.0.0.0/8", 7018, "AT&T Services", "US"),
    ("168.0.0.0/8", 7018, "AT&T Services", "US"),
    ("173.0.0.0/8", 7922, "Comcast Cable", "US"),
    ("216.0.0.0/8", 3356, "Lumen Technologies", "US"),
    # European providers
    ("2.0.0.0/8", 3215, "Orange S.A.", "FR"),
    ("5.0.0.0/8", 12322, "Free SAS", "FR"),
    ("31.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("37.0.0.0/8", 12389, "Rostelecom", "RU"),
    ("46.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("62.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("77.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("78.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("79.0.0.0/8", 2856, "BT Group", "GB"),
    ("80.0.0.0/8", 2856, "BT Group", "GB"),
    ("81.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("82.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("83.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("84.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("85.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("86.0.0.0/8", 12322, "Free SAS", "FR"),
    ("87.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("88.0.0.0/8", 3215, "Orange S.A.", "FR"),
    ("89.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("90.0.0.0/8", 3215, "Orange S.A.", "FR"),
    ("91.0.0.0/8", 12389, "Rostelecom", "RU"),
    ("92.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("93.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("94.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("95.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("109.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("141.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("145.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("151.0.0.0/8", 3269, "Telecom Italia", "IT"),
    ("176.0.0.0/8", 12389, "Rostelecom", "RU"),
    ("178.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("185.0.0.0/8", 9009, "M247 Ltd", "RO"),
    ("188.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("193.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("194.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("195.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("212.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("213.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    ("217.0.0.0/8", 3320, "Deutsche Telekom", "DE"),
    # Asia Pacific
    ("1.0.0.0/8", 13335, "Cloudflare Inc.", "US"),
    ("14.0.0.0/8", 4766, "Korea Telecom", "KR"),
    ("27.0.0.0/8", 4134, "China Telecom", "CN"),
    ("36.0.0.0/8", 4134, "China Telecom", "CN"),
    ("39.0.0.0/8", 4766, "Korea Telecom", "KR"),
    ("42.0.0.0/8", 4766, "Korea Telecom", "KR"),
    ("43.0.0.0/8", 4766, "Korea Telecom", "KR"),
    ("49.0.0.0/8", 4134, "China Telecom", "CN"),
    ("58.0.0.0/8", 4134, "China Telecom", "CN"),
    ("59.0.0.0/8", 4134, "China Telecom", "CN"),
    ("60.0.0.0/8", 4134, "China Telecom", "CN"),
    ("61.0.0.0/8", 4134, "China Telecom", "CN"),
    ("101.0.0.0/8", 4134, "China Telecom", "CN"),
    ("103.0.0.0/8", 4134, "China Telecom", "CN"),
    ("106.0.0.0/8", 4134, "China Telecom", "CN"),
    ("110.0.0.0/8", 4134, "China Telecom", "CN"),
    ("111.0.0.0/8", 4134, "China Telecom", "CN"),
    ("112.0.0.0/8", 4134, "China Telecom", "CN"),
    ("113.0.0.0/8", 4134, "China Telecom", "CN"),
    ("114.0.0.0/8", 4134, "China Telecom", "CN"),
    ("115.0.0.0/8", 4134, "China Telecom", "CN"),
    ("116.0.0.0/8", 4134, "China Telecom", "CN"),
    ("117.0.0.0/8", 4134, "China Telecom", "CN"),
    ("118.0.0.0/8", 4134, "China Telecom", "CN"),
    ("119.0.0.0/8", 4134, "China Telecom", "CN"),
    ("120.0.0.0/8", 4134, "China Telecom", "CN"),
    ("121.0.0.0/8", 4134, "China Telecom", "CN"),
    ("122.0.0.0/8", 4134, "China Telecom", "CN"),
    ("123.0.0.0/8", 4134, "China Telecom", "CN"),
    ("124.0.0.0/8", 4134, "China Telecom", "CN"),
    ("125.0.0.0/8", 4134, "China Telecom", "CN"),
    ("126.0.0.0/8", 2514, "NTT Communications", "JP"),
    ("133.0.0.0/8", 2514, "NTT Communications", "JP"),
    ("150.0.0.0/8", 2514, "NTT Communications", "JP"),
    ("153.0.0.0/8", 2514, "NTT Communications", "JP"),
    ("163.0.0.0/8", 4134, "China Telecom", "CN"),
    ("171.0.0.0/8", 4134, "China Telecom", "CN"),
    ("175.0.0.0/8", 4134, "China Telecom", "CN"),
    ("180.0.0.0/8", 4134, "China Telecom", "CN"),
    ("182.0.0.0/8", 4134, "China Telecom", "CN"),
    ("183.0.0.0/8", 4134, "China Telecom", "CN"),
    ("202.0.0.0/8", 4134, "China Telecom", "CN"),
    ("203.0.0.0/8", 4134, "China Telecom", "CN"),
    ("210.0.0.0/8", 4134, "China Telecom", "CN"),
    ("211.0.0.0/8", 4134, "China Telecom", "CN"),
    ("218.0.0.0/8", 4134, "China Telecom", "CN"),
    ("219.0.0.0/8", 4134, "China Telecom", "CN"),
    ("220.0.0.0/8", 4134, "China Telecom", "CN"),
    ("221.0.0.0/8", 4134, "China Telecom", "CN"),
    ("222.0.0.0/8", 4134, "China Telecom", "CN"),
    ("223.0.0.0/8", 4134, "China Telecom", "CN"),
    # Africa / South America
    ("41.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("102.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("105.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("154.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("196.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("197.0.0.0/8", 36874, "Internet Solutions", "ZA"),
    ("170.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("177.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("179.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("181.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("186.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("187.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("189.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("190.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("191.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("200.0.0.0/8", 28573, "Claro S.A.", "BR"),
    ("201.0.0.0/8", 28573, "Claro S.A.", "BR"),
    # Scanners / research
    ("66.240.192.0/18", 20473, "Shodan (The Shadowserver Foundation)", "US"),
    ("71.6.128.0/17", 20473, "Shodan (The Shadowserver Foundation)", "US"),
    ("162.142.125.0/24", 398324, "Censys Inc.", "US"),
    ("167.94.138.0/24", 398324, "Censys Inc.", "US"),
    ("167.94.145.0/24", 398324, "Censys Inc.", "US"),
    ("167.94.146.0/24", 398324, "Censys Inc.", "US"),
    ("167.248.133.0/24", 398324, "Censys Inc.", "US"),
]

class _ASNLookup:
    """Lazy-initialized ASN lookup table."""

    def __init__(self) -> None:
        self._parsed: list[tuple[ipaddress.IPv4Network, int, str, str]] = []
        self._initialized = False

    def _init(self) -> None:
        if self._initialized:
            return
        for cidr, asn, org, cc in _ASN_TABLE:
            try:
                self._parsed.append((ipaddress.IPv4Network(cidr, strict=False), asn, org, cc))
            except ValueError:
                continue
        # Sort by prefix length descending (most specific first)
        self._parsed.sort(key=lambda t: t[0].prefixlen, reverse=True)
        self._initialized = True

    @property
    def entries(self) -> list[tuple[ipaddress.IPv4Network, int, str, str]]:
        self._init()
        return self._parsed


_asn_lookup = _ASNLookup()


@lru_cache(maxsize=4096)
def lookup_asn(ip: str) -> dict[str, str | int]:
    """Look up ASN info for an IP address.

    Returns dict with keys: asn, org, country_code.
    Returns empty values if no match found.
    """
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return {"asn": 0, "org": "Invalid", "country_code": "??"}

    if addr.is_private or addr.is_loopback or addr.is_reserved:
        return {"asn": 0, "org": "Private/Reserved", "country_code": "--"}

    if isinstance(addr, ipaddress.IPv4Address):
        for net, asn, org, cc in _asn_lookup.entries:
            if addr in net:
                return {"asn": asn, "org": org, "country_code": cc}

    return {"asn": 0, "org": "Unknown", "country_code": "??"}
