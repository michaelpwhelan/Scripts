#!/usr/bin/env python3
"""IOC (Indicator of Compromise) data structures and matching engine.

Supports CSV/text import and STIX bundle loading.  Matching uses
case-insensitive substring search across event fields, mirroring
the PowerShell ``ioc match`` implementation.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

from logparse.models import LogEvent

log = logging.getLogger(__name__)


# -- data structures ---------------------------------------------------------


@dataclass
class IOCSet:
    """A loaded set of indicators of compromise."""

    name: str
    indicators: dict[str, str]  # {value: type}
    source: str  # "csv", "stix", "text"
    loaded_at: datetime = field(default_factory=datetime.now)


@dataclass
class IOCMatch:
    """Result of matching events against a single IOC."""

    ioc_value: str
    ioc_type: str
    matched_events: list[LogEvent] = field(default_factory=list)
    match_count: int = 0


# -- loading -----------------------------------------------------------------


def load_ioc_csv(path: Path) -> IOCSet:
    """Load IOCs from CSV/text file.

    Format: one IOC per line.  Optionally ``value,type``.
    Lines starting with ``#`` are comments.  Empty lines are skipped.
    """
    indicators: dict[str, str] = {}
    text = path.read_text(encoding="utf-8", errors="replace")
    for line in text.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split(",", 1)
        value = parts[0].strip()
        ioc_type = parts[1].strip() if len(parts) > 1 else "unknown"
        if value:
            indicators[value] = ioc_type

    log.debug("Loaded %d IOCs from %s", len(indicators), path.name)
    return IOCSet(
        name=path.stem,
        indicators=indicators,
        source="csv",
    )


def load_ioc_stix(bundle: dict, feed_name: str = "") -> IOCSet:
    """Load IOCs from a parsed STIX 2.1 bundle dict."""
    from logparse.stix_client import parse_stix_bundle, extract_ioc_values

    indicators_raw = parse_stix_bundle(bundle)
    indicators = extract_ioc_values(indicators_raw)
    name = feed_name or "stix"
    log.debug("Loaded %d IOCs from STIX bundle %s", len(indicators), name)
    return IOCSet(
        name=name,
        indicators=indicators,
        source="stix",
    )


# -- matching ----------------------------------------------------------------


def match_events(
    events: list[LogEvent],
    ioc_sets: list[IOCSet],
) -> list[IOCMatch]:
    """Scan events against all loaded IOC sets.

    Returns matches sorted by match count descending.
    """
    # Merge all IOC sets into a single lookup
    all_iocs: dict[str, str] = {}
    for s in ioc_sets:
        all_iocs.update(s.indicators)

    if not all_iocs:
        return []

    # Pre-lowercase IOCs for matching
    ioc_lookup: list[tuple[str, str, str]] = [
        (val, val.lower(), typ) for val, typ in all_iocs.items()
    ]

    matches: dict[str, IOCMatch] = {}
    for event in events:
        search_text = (
            f"{event.source} {event.message} {event.raw}"
        ).lower()
        for ioc_val, ioc_lower, ioc_type in ioc_lookup:
            if ioc_lower in search_text:
                m = matches.get(ioc_val)
                if m is None:
                    m = IOCMatch(ioc_value=ioc_val, ioc_type=ioc_type)
                    matches[ioc_val] = m
                m.matched_events.append(event)
                m.match_count += 1

    return sorted(matches.values(), key=lambda m: m.match_count, reverse=True)


def matched_event_set(
    events: list[LogEvent],
    ioc_sets: list[IOCSet],
) -> list[LogEvent]:
    """Return the subset of events that match any IOC."""
    results = match_events(events, ioc_sets)
    seen: set[int] = set()
    out: list[LogEvent] = []
    for m in results:
        for e in m.matched_events:
            eid = id(e)
            if eid not in seen:
                seen.add(eid)
                out.append(e)
    return out
