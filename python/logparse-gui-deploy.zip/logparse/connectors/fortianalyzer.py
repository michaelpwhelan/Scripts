#!/usr/bin/env python3
"""FortiAnalyzer JSON-RPC connector.

Connects to FortiAnalyzer via JSON-RPC 2.0 to fetch historical logs.
Output: JSONL files suitable for ``parse_jsonl()`` / ``parse_fortigate_kv()``.
"""

from __future__ import annotations

import json
import logging
import ssl
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from pathlib import Path

from logparse.connectors import Connector, FetchResult
from logparse.util import parse_duration

log = logging.getLogger(__name__)


class FortiAnalyzerConnector(Connector):
    """FortiAnalyzer JSON-RPC connector."""

    name = "fortianalyzer"

    ENDPOINTS: dict[str, tuple[str, str]] = {
        "traffic": ("traffic", "FortiGate traffic logs"),
        "event": ("event", "FortiGate event logs"),
        "utm": ("utm", "UTM security logs"),
    }

    def __init__(self) -> None:
        self._host = ""
        self._username = ""
        self._password = ""
        self._verify_ssl = True
        self._session_token = ""
        self._ssl_ctx: ssl.SSLContext | None = None

    def __repr__(self) -> str:
        return f"FortiAnalyzerConnector(host={self._host!r})"

    def configure(self, config: dict) -> None:
        """Load FortiAnalyzer connection settings from config."""
        self._host = config.get("host", "")
        self._username = config.get("username", "")
        self._password = config.get("password", "")
        self._verify_ssl = config.get("verify_ssl", True)
        if not self._host:
            raise ValueError(
                "FortiAnalyzer connector requires 'host' in config.  "
                "Add it under connectors.fortianalyzer in "
                "~/.logparse/config.yaml"
            )
        if self._verify_ssl:
            self._ssl_ctx = ssl.create_default_context()
        else:
            log.warning(
                "SSL verification disabled for %s — connections are "
                "vulnerable to MITM attacks",
                self._host,
            )
            self._ssl_ctx = ssl.create_default_context()
            self._ssl_ctx.check_hostname = False
            self._ssl_ctx.verify_mode = ssl.CERT_NONE

    def authenticate(self) -> None:
        """Authenticate to FortiAnalyzer via JSON-RPC."""
        resp = self._jsonrpc(
            "sys/login/user",
            {"user": self._username, "passwd": self._password},
        )
        self._session_token = resp.get("session", "")
        if not self._session_token:
            raise ConnectionError(
                f"FortiAnalyzer login failed: {resp}"
            )
        log.info("Authenticated to FortiAnalyzer at %s", self._host)

    def fetch(
        self,
        endpoint: str,
        *,
        time_range: str = "24h",
        output_dir: Path | None = None,
        max_records: int = 10_000,
    ) -> FetchResult:
        """Fetch logs from a FortiAnalyzer endpoint."""
        self._validate_endpoint(endpoint)

        logtype, desc = self.ENDPOINTS[endpoint]
        out_dir = self._prepare_output_dir(output_dir)

        date_str = self._date_str()
        out_path = out_dir / f"faz-{endpoint}-{date_str}.jsonl"

        delta = parse_duration(time_range) or timedelta(hours=24)
        now = datetime.now(timezone.utc)
        since = (now - delta).strftime("%Y-%m-%d %H:%M:%S")
        until = now.strftime("%Y-%m-%d %H:%M:%S")

        errors: list[str] = []
        event_count = 0

        # Start log query
        try:
            query_resp = self._jsonrpc(
                "log/query/data",
                {
                    "logtype": logtype,
                    "time-range": {"start": since, "end": until},
                    "limit": max_records,
                },
            )
        except (ConnectionError, OSError, TimeoutError, ValueError, KeyError) as exc:
            errors.append(str(exc))
            return FetchResult(
                output_path=out_path,
                event_count=0,
                endpoint=endpoint,
                errors=errors,
            )

        # Write results as JSONL
        records = query_resp.get("data", [])
        if isinstance(records, list):
            with open(out_path, "w", encoding="utf-8") as f:
                for record in records:
                    if isinstance(record, dict):
                        f.write(json.dumps(record, default=str) + "\n")
                        event_count += 1

        log.info(
            "Fetched %d records from %s → %s", event_count, desc, out_path
        )
        return FetchResult(
            output_path=out_path,
            event_count=event_count,
            endpoint=endpoint,
            errors=errors,
        )

    def _jsonrpc(self, method: str, params: dict) -> dict:
        """Send a JSON-RPC request to FortiAnalyzer."""
        url = f"https://{self._host}/jsonrpc"
        payload = {
            "id": 1,
            "method": method,
            "params": [params],
        }
        if self._session_token:
            payload["session"] = self._session_token

        data = json.dumps(payload).encode()
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )

        try:
            with urllib.request.urlopen(
                req, timeout=60, context=self._ssl_ctx
            ) as resp:
                body = resp.read()
                result = json.loads(body) if body else {}
                if not isinstance(result, dict):
                    return {}
                result_list = result.get("result")
                if isinstance(result_list, list) and result_list:
                    return result_list[0] if isinstance(result_list[0], dict) else {}
                return {}
        except urllib.error.HTTPError as exc:
            raise ConnectionError(
                f"FortiAnalyzer HTTP {exc.code}: {exc.reason}"
            ) from exc
        except urllib.error.URLError as exc:
            raise ConnectionError(
                f"FortiAnalyzer connection failed: {exc.reason}"
            ) from exc

    def logout(self) -> None:
        """End the FortiAnalyzer session."""
        if self._session_token:
            try:
                self._jsonrpc("sys/logout", {})
            except (ConnectionError, OSError, TimeoutError):
                pass
            self._session_token = ""
