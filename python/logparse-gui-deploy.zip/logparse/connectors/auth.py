#!/usr/bin/env python3
"""OAuth2 client credentials flow and HTTP helpers using only urllib."""

from __future__ import annotations

import json
import logging
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass

log = logging.getLogger(__name__)


@dataclass
class _TokenCache:
    """Module-level token cache."""

    access_token: str = ""
    expires_at: float = 0.0


_cache = _TokenCache()
_cache_lock = threading.Lock()


def oauth2_client_credentials(
    tenant_id: str,
    client_id: str,
    client_secret: str,
    scope: str = "https://graph.microsoft.com/.default",
) -> str:
    """Acquire an OAuth2 access token via client credentials grant.

    Returns a cached token if still valid (with 60s safety margin).
    Thread-safe via module-level lock.
    """
    with _cache_lock:
        now = time.time()
        if _cache.access_token and now < _cache.expires_at - 60:
            return _cache.access_token

    url = (
        f"https://login.microsoftonline.com/{tenant_id}/oauth2/v2.0/token"
    )
    data = urllib.parse.urlencode(
        {
            "grant_type": "client_credentials",
            "client_id": client_id,
            "client_secret": client_secret,
            "scope": scope,
        }
    ).encode()

    resp = http_post(url, data=data, headers={"Content-Type": "application/x-www-form-urlencoded"})
    token = resp["access_token"]
    expires_in = int(resp.get("expires_in", 3600))
    with _cache_lock:
        _cache.access_token = token
        _cache.expires_at = time.time() + expires_in
    log.debug("OAuth2 token acquired, expires in %ds", expires_in)
    return token


def clear_token_cache() -> None:
    """Reset the cached token (for re-authentication)."""
    with _cache_lock:
        _cache.access_token = ""
        _cache.expires_at = 0.0


# -- HTTP helpers (urllib only) ----------------------------------------------


def http_post(
    url: str,
    *,
    data: bytes | None = None,
    json_body: dict | None = None,
    headers: dict[str, str] | None = None,
) -> dict:
    """POST request returning parsed JSON response."""
    hdrs = dict(headers or {})
    body = data
    if json_body is not None:
        body = json.dumps(json_body).encode()
        hdrs.setdefault("Content-Type", "application/json")

    req = urllib.request.Request(url, data=body, headers=hdrs, method="POST")
    return _do_request(req)


def http_get(
    url: str,
    *,
    headers: dict[str, str] | None = None,
    params: dict[str, str] | None = None,
) -> dict:
    """GET request returning parsed JSON response."""
    if params:
        url = f"{url}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers=dict(headers or {}), method="GET")
    return _do_request(req)


def _do_request(req: urllib.request.Request, *, max_retries: int = 3) -> dict:
    """Execute request with retry on HTTP 429."""
    for attempt in range(max_retries):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                body = resp.read()
                return json.loads(body) if body else {}
        except urllib.error.HTTPError as exc:
            if exc.code == 429 and attempt < max_retries - 1:
                try:
                    retry_after = int(exc.headers.get("Retry-After", "5"))
                except (ValueError, TypeError):
                    retry_after = 5
                log.warning(
                    "Rate limited (429), retrying in %ds (attempt %d/%d)",
                    retry_after,
                    attempt + 1,
                    max_retries,
                )
                time.sleep(retry_after)
                continue
            raise ConnectorHTTPError(exc.code, exc.reason, url=req.full_url) from exc
        except urllib.error.URLError as exc:
            raise ConnectorHTTPError(0, str(exc.reason), url=req.full_url) from exc
    # unreachable, but satisfy type checkers
    raise ConnectorHTTPError(429, "Max retries exceeded", url=req.full_url)


class ConnectorHTTPError(Exception):
    """HTTP error from a connector request."""

    def __init__(self, status: int, reason: str, *, url: str = "") -> None:
        self.status = status
        self.reason = reason
        self.url = url
        super().__init__(f"HTTP {status}: {reason} ({url})")
