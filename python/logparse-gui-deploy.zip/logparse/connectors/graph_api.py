#!/usr/bin/env python3
"""Microsoft Graph API connector.

Fetches security alerts, sign-in logs, directory audits, and risk
detections from Microsoft 365 E5 via the Graph REST API.  All HTTP
via urllib — zero external dependencies.

Output: JSONL files suitable for ``parse_jsonl()``.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta, timezone
from pathlib import Path

from logparse.connectors import Connector, FetchResult
from logparse.connectors.auth import (
    http_get,
    oauth2_client_credentials,
)
from logparse.util import parse_duration

log = logging.getLogger(__name__)

_GRAPH_BASE = "https://graph.microsoft.com/v1.0"


class GraphAPIConnector(Connector):
    """Microsoft Graph API connector for M365 E5 security data."""

    name = "graph"

    ENDPOINTS: dict[str, tuple[str, str, str]] = {
        # name: (path, description, time_filter_field)
        "alerts": (
            "/security/alerts_v2",
            "Microsoft Defender security alerts",
            "createdDateTime",
        ),
        "signins": (
            "/auditLogs/signIns",
            "Entra ID sign-in logs",
            "createdDateTime",
        ),
        "directory": (
            "/auditLogs/directoryAudits",
            "Entra directory audit events",
            "activityDateTime",
        ),
        "risk": (
            "/identityProtection/riskDetections",
            "Identity risk detections",
            "activityDateTime",
        ),
    }

    def __init__(self) -> None:
        self._tenant_id = ""
        self._client_id = ""
        self._client_secret = ""
        self._token = ""

    def __repr__(self) -> str:
        return f"GraphAPIConnector(tenant={self._tenant_id!r})"

    def configure(self, config: dict) -> None:
        """Load Microsoft Graph API credentials from config."""
        self._tenant_id = config.get("tenant_id", "")
        self._client_id = config.get("client_id", "")
        self._client_secret = config.get("client_secret", "")
        if not all([self._tenant_id, self._client_id, self._client_secret]):
            raise ValueError(
                "Graph connector requires tenant_id, client_id, and "
                "client_secret in config.  Add them under "
                "connectors.graph in ~/.logparse/config.yaml"
            )

    def authenticate(self) -> None:
        """Authenticate via OAuth2 client credentials flow."""
        self._token = oauth2_client_credentials(
            self._tenant_id, self._client_id, self._client_secret
        )
        log.info("Authenticated to Microsoft Graph (tenant %s)", self._tenant_id)

    def fetch(
        self,
        endpoint: str,
        *,
        time_range: str = "24h",
        output_dir: Path | None = None,
        max_records: int = 10_000,
    ) -> FetchResult:
        """Fetch data from a Graph API endpoint."""
        self._validate_endpoint(endpoint)

        path, desc, time_field = self.ENDPOINTS[endpoint]
        out_dir = self._prepare_output_dir(output_dir)

        date_str = self._date_str()
        out_path = out_dir / f"m365-{endpoint}-{date_str}.jsonl"

        # Build OData time filter
        delta = parse_duration(time_range) or timedelta(hours=24)
        since = (datetime.now(timezone.utc) - delta).strftime(
            "%Y-%m-%dT%H:%M:%SZ"
        )
        odata_filter = f"{time_field} ge {since}"

        # Ensure token is fresh
        self._ensure_token()

        headers = {
            "Authorization": f"Bearer {self._token}",
            "Accept": "application/json",
        }

        url = f"{_GRAPH_BASE}{path}"
        params = {"$filter": odata_filter, "$top": str(min(max_records, 999))}

        event_count = 0
        errors: list[str] = []

        with open(out_path, "w", encoding="utf-8") as f:
            while url and event_count < max_records:
                try:
                    data = http_get(url, headers=headers, params=params)
                except (ConnectionError, OSError, TimeoutError, ValueError, KeyError) as exc:
                    errors.append(str(exc))
                    log.error("Graph API error on %s: %s", endpoint, exc)
                    break

                records = data.get("value", [])
                for record in records:
                    f.write(json.dumps(record, default=str) + "\n")
                    event_count += 1
                    if event_count >= max_records:
                        break

                # Pagination — @odata.nextLink contains the full URL
                url = data.get("@odata.nextLink", "")
                params = {}  # nextLink already includes query params

        log.info(
            "Fetched %d records from %s → %s", event_count, desc, out_path
        )
        return FetchResult(
            output_path=out_path,
            event_count=event_count,
            endpoint=endpoint,
            errors=errors,
        )

    def _ensure_token(self) -> None:
        """Re-authenticate if token might be expired."""
        # oauth2_client_credentials() handles caching + expiry internally
        self._token = oauth2_client_credentials(
            self._tenant_id, self._client_id, self._client_secret
        )
