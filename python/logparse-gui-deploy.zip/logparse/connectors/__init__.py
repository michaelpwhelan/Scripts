#!/usr/bin/env python3
"""Connector base class, result model, and registry.

Connectors fetch data from remote sources and write JSONL files to disk.
The existing ``parse_jsonl()`` handles conversion to ``LogEvent``.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path


@dataclass
class FetchResult:
    """Result of a single connector fetch operation."""

    output_path: Path
    event_count: int
    endpoint: str
    time_range: tuple[datetime, datetime] | None = None
    errors: list[str] = field(default_factory=list)


class Connector(ABC):
    """Base class for remote data connectors.

    Lifecycle: ``configure()`` → ``authenticate()`` → ``fetch()`` / ``fetch_all()``.
    """

    name: str = ""
    ENDPOINTS: dict = {}

    @abstractmethod
    def configure(self, config: dict) -> None:
        """Load connector-specific settings from config dict."""

    @abstractmethod
    def authenticate(self) -> None:
        """Perform authentication (OAuth2, API key, session token, etc.)."""

    @abstractmethod
    def fetch(
        self,
        endpoint: str,
        *,
        time_range: str = "24h",
        output_dir: Path | None = None,
        max_records: int = 10_000,
    ) -> FetchResult:
        """Fetch data from one endpoint, save as JSONL."""

    def list_endpoints(self) -> list[tuple[str, str]]:
        """Return ``[(endpoint_name, description), ...]`` from ENDPOINTS."""
        return [(name, info[1]) for name, info in self.ENDPOINTS.items()]

    def _validate_endpoint(self, endpoint: str) -> None:
        """Raise ValueError if endpoint is not in ENDPOINTS."""
        if endpoint not in self.ENDPOINTS:
            available = ", ".join(sorted(self.ENDPOINTS))
            raise ValueError(
                f"Unknown endpoint {endpoint!r}. Available: {available}"
            )

    def _prepare_output_dir(self, output_dir: Path | None) -> Path:
        """Ensure output directory exists, default to cwd."""
        out_dir = output_dir or Path(".")
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir

    def _date_str(self) -> str:
        """Current date as YYYY-MM-DD for output filenames."""
        return datetime.now().strftime("%Y-%m-%d")

    def fetch_all(
        self,
        *,
        time_range: str = "24h",
        output_dir: Path | None = None,
        max_records: int = 10_000,
    ) -> list[FetchResult]:
        """Fetch all configured endpoints."""
        results: list[FetchResult] = []
        for ep_name, _ in self.list_endpoints():
            results.append(
                self.fetch(
                    ep_name,
                    time_range=time_range,
                    output_dir=output_dir,
                    max_records=max_records,
                )
            )
        return results


# -- connector registry (lazy imports, mirrors parsers/__init__.py) ----------

_CONNECTORS: dict[str, type[Connector]] = {}


def _load_connectors() -> dict[str, type[Connector]]:
    if not _CONNECTORS:
        from logparse.connectors.graph_api import GraphAPIConnector
        from logparse.connectors.fortianalyzer import FortiAnalyzerConnector

        _CONNECTORS.update(
            {
                "graph": GraphAPIConnector,
                "fortianalyzer": FortiAnalyzerConnector,
            }
        )
    return _CONNECTORS


def get_connector(name: str) -> Connector:
    """Instantiate a connector by name."""
    registry = _load_connectors()
    cls = registry.get(name)
    if cls is None:
        available = ", ".join(sorted(registry))
        raise ValueError(f"Unknown connector {name!r}. Available: {available}")
    return cls()


def list_connectors() -> list[tuple[str, str]]:
    """Return ``[(name, description), ...]`` for all registered connectors."""
    registry = _load_connectors()
    result = []
    for name, cls in sorted(registry.items()):
        inst = cls()
        endpoints = inst.list_endpoints()
        ep_summary = ", ".join(n for n, _ in endpoints)
        result.append((name, ep_summary))
    return result
