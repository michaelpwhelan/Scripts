#!/usr/bin/env python3
"""Unified verbose output — per-file progress and dashboard summary."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from pathlib import Path

from rich import box
from rich.console import Console
from rich.style import Style
from rich.table import Table
from rich.tree import Tree


# ---------------------------------------------------------------------------
# Color palette — hex values for Rich markup
# ---------------------------------------------------------------------------

COLORS = {
    "critical": "#ff5555",
    "high": "#ff8c42",
    "medium": "#ffd166",
    "low": "#06d6a0",
    "info": "#118ab2",
    "accent": "#58a6ff",
    "green": "#3fb950",
    "cyan": "#79c0ff",
    "dim": "#8b949e",
    "text": "#c9d1d9",
    "border": "#30363d",
}

# Known noise sources (auto-detected, no profile needed)
KNOWN_NOISE_SOURCES = {
    "Microsoft-Windows-WMI-Activity",
    "WMI-Activity",
    "Microsoft-Windows-DistributedCOM",
    "DistributedCOM",
    "DCOM",
    "ESENT",
    "Microsoft-Windows-Perflib",
    "Perflib",
    "Microsoft-Windows-Winlogon",
}

# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class ParsedFileInfo:
    """Metadata for one parsed (or skipped) file."""

    filename: str
    format_name: str = ""
    event_count: int = 0
    parse_time: float = 0.0
    severity_counts: dict[str, int] = field(
        default_factory=lambda: {
            "Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0,
        }
    )
    skipped: bool = False
    skip_reason: str = ""
    archive_name: str = ""
    directory: str = ""
    index: int = 0
    total: int = 0


@dataclass
class LoadSummary:
    """Aggregate loading result for the dashboard."""

    total_events: int
    files: list[ParsedFileInfo]
    skipped: list[ParsedFileInfo]
    elapsed: float
    time_range: tuple[datetime | None, datetime | None]
    severity_counts: dict[str, int]
    source_counts: list[tuple[str, int]]
    noise_sources: list[tuple[str, int]] = field(default_factory=list)
    noise_removed: int = 0
    noise_profile: str = ""


class InputMode(Enum):
    """Input mode for verbose output rendering."""

    SINGLE = "single"
    MULTI = "multi"
    ARCHIVE = "archive"


def detect_input_mode(paths: list[str]) -> InputMode:
    """Determine rendering mode from input paths."""
    if len(paths) == 1:
        p = Path(paths[0])
        if p.suffix.lower() == ".zip" or p.is_dir():
            return InputMode.ARCHIVE
        return InputMode.SINGLE
    return InputMode.MULTI


# ---------------------------------------------------------------------------
# VerboseOutput — renders per-file lines and dashboard
# ---------------------------------------------------------------------------

_C = COLORS  # shorthand


class VerboseOutput:
    """Rich-formatted loading progress and dashboard."""

    def __init__(self, console: Console, mode: InputMode) -> None:
        self.console = console
        self.mode = mode
        self.parsed_files: list[ParsedFileInfo] = []
        self.skipped_files: list[ParsedFileInfo] = []

    # -- Phase 1: per-file output ------------------------------------------

    def file_parsed(self, info: ParsedFileInfo) -> None:
        """Handle a file that was just parsed (or skipped)."""
        if info.skipped:
            self.skipped_files.append(info)
            if self.mode != InputMode.ARCHIVE:
                self._print_skipped_line(info)
        else:
            self.parsed_files.append(info)
            if self.mode != InputMode.ARCHIVE:
                self._print_file_line(info)

    def render_archive_tree(self, archive_name: str) -> None:
        """Render a rich.tree.Tree for all files in an archive."""
        tree = Tree(
            f"[{_C['accent']}]{archive_name}[/]",
            guide_style=Style(color=_C["border"]),
        )

        # Group by directory
        dirs: dict[str, list[ParsedFileInfo]] = defaultdict(list)
        no_dir: list[ParsedFileInfo] = []
        for info in self.parsed_files + self.skipped_files:
            if info.archive_name != archive_name:
                continue
            if info.directory:
                dirs[info.directory].append(info)
            else:
                no_dir.append(info)

        # Render directory branches
        for dir_name in sorted(dirs):
            branch = tree.add(f"[{_C['cyan']}]{dir_name}/[/]")
            for info in dirs[dir_name]:
                if info.skipped:
                    branch.add(self._format_skipped_line(info))
                else:
                    branch.add(self._format_file_line(info))

        # Render root-level files
        for info in no_dir:
            if info.skipped:
                tree.add(self._format_skipped_line(info))
            else:
                tree.add(self._format_file_line(info))

        self.console.print(tree)

    def _print_file_line(self, info: ParsedFileInfo) -> None:
        self.console.print(self._format_file_line(info))

    def _print_skipped_line(self, info: ParsedFileInfo) -> None:
        self.console.print(self._format_skipped_line(info))

    def _format_file_line(self, info: ParsedFileInfo) -> str:
        """Build one per-file Rich markup string."""
        counter = f"[{_C['dim']}][{info.index}/{info.total}][/]"
        name = info.filename[:36].ljust(36)
        count_str = f"[{_C['text']}]{info.event_count:>6,}[/]"
        sparkline = self._severity_sparkline(info.severity_counts)
        fmt_name = info.format_name.replace("_", " ").title()
        timing = f"[{_C['dim']}]{fmt_name} \u00b7 {info.parse_time:.1f}s[/]"
        alert = self._severity_alert(info.severity_counts)
        alert_str = f"  {alert}" if alert else ""

        return (
            f"  [{_C['green']}]\u2713[/] {counter} {name}"
            f"{count_str}  {sparkline}  {timing}{alert_str}"
        )

    def _format_skipped_line(self, info: ParsedFileInfo) -> str:
        reason = info.skip_reason or "unknown"
        name = info.filename[:36].ljust(36)
        return (
            f"  [{_C['dim']}]\u00b7       {name}"
            f"{'':>6}  {'':18}  (skipped \u2014 {reason})[/]"
        )

    # -- Severity helpers --------------------------------------------------

    def _severity_sparkline(self, counts: dict[str, int], width: int = 18) -> str:
        """Build a proportional severity mini-bar with Rich markup."""
        crit = counts.get("Critical", 0)
        high = counts.get("High", 0)
        med = counts.get("Medium", 0)
        low = counts.get("Low", 0)
        total = crit + high + med + low

        if total == 0:
            dot = "\u00b7"
            return f"[{_C['dim']}]{dot * width}[/]"

        c_w = max(round(crit / total * width), 1) if crit else 0
        h_w = max(round(high / total * width), 1) if high else 0
        m_w = max(round(med / total * width), 1) if med else 0
        l_w = width - c_w - h_w - m_w
        if l_w < 0:
            # Proportionally trim non-zero segments to fit within width
            excess = -l_w
            segments = [("c", c_w), ("h", h_w), ("m", m_w)]
            segments.sort(key=lambda x: -x[1])  # trim largest first
            for i, (name, val) in enumerate(segments):
                trim = min(excess, val - (1 if val > 0 else 0))
                if trim > 0:
                    segments[i] = (name, val - trim)
                    excess -= trim
                if excess <= 0:
                    break
            for name, val in segments:
                if name == "c":
                    c_w = val
                elif name == "h":
                    h_w = val
                else:
                    m_w = val
            l_w = max(width - c_w - h_w - m_w, 0)

        full = "\u2588"
        med_shade = "\u2593"
        light = "\u2591"
        bar = ""
        if c_w:
            bar += f"[{_C['critical']}]{full * c_w}[/]"
        if h_w:
            bar += f"[{_C['high']}]{full * h_w}[/]"
        if m_w:
            bar += f"[{_C['medium']}]{med_shade * m_w}[/]"
        if l_w > 0:
            bar += f"[{_C['low']}]{light * l_w}[/]"

        return bar

    def _severity_bar(self, counts: dict[str, int], width: int = 60) -> str:
        """Build a wider severity bar for the dashboard."""
        return self._severity_sparkline(counts, width=width)

    def _severity_alert(self, counts: dict[str, int]) -> str:
        """Inline alert for critical/high events."""
        crit = counts.get("Critical", 0)
        high = counts.get("High", 0)
        if crit > 0:
            return f"[{_C['critical']}]\u25b2 {crit} critical[/]"
        if high > 0:
            return f"[{_C['high']}]\u25b3 {high} high[/]"
        return ""

    # -- Phase 2: dashboard ------------------------------------------------

    def render_dashboard(self, summary: LoadSummary) -> None:
        """Render the boxed summary dashboard."""
        c = _C
        dash = Table(
            box=box.ROUNDED,
            border_style=Style(color=c["border"]),
            show_header=False,
            padding=(0, 2),
            width=min(self.console.width, 100),
        )
        dash.add_column(width=16, style=c["dim"])
        dash.add_column(style=c["text"])

        # Row: events
        file_count = len(summary.files)
        skip_count = len(summary.skipped)
        skip_part = f"{skip_count} skipped \u00b7 " if skip_count else ""
        dash.add_row(
            "events",
            f"[bold]{summary.total_events:,}[/]  from {file_count} files"
            f"  [{c['dim']}]({skip_part}{summary.elapsed:.1f}s total)[/]",
        )

        # Row: time range
        first, last = summary.time_range
        if first and last:
            span = last - first
            dash.add_row(
                "time range",
                f"{first:%Y-%m-%d %H:%M} \u2192 {last:%Y-%m-%d %H:%M}"
                f"  [{c['dim']}]({span.days} days)[/]",
            )

        # Row: severity bar + legend
        sev = summary.severity_counts
        dash.add_row("severity", self._severity_bar(sev))

        legend_parts = []
        for label, key, color in [
            ("critical", "Critical", c["critical"]),
            ("high", "High", c["high"]),
            ("medium", "Medium", c["medium"]),
            ("low", "Low", c["low"]),
        ]:
            count = sev.get(key, 0)
            if count:
                legend_parts.append(f"[{color}]\u25a0 {count:,} {label}[/]")
        if legend_parts:
            dash.add_row("", "  ".join(legend_parts))

        # Separator
        dash.add_row("", "")

        # Row: top sources (two rows of 3)
        if summary.source_counts:
            row1 = "  ".join(
                f"[{c['cyan']}]{name}[/] {count:,}"
                for name, count in summary.source_counts[:3]
            )
            dash.add_row("top sources", row1)
            if len(summary.source_counts) > 3:
                row2 = "  ".join(
                    f"[{c['cyan']}]{name}[/] {count:,}"
                    for name, count in summary.source_counts[3:6]
                )
                dash.add_row("", row2)

        # Separator
        dash.add_row("", "")

        # Row: alerts
        crit_total = sev.get("Critical", 0)
        high_total = sev.get("High", 0)

        if crit_total > 0:
            crit_files = [
                f.filename for f in summary.files
                if f.severity_counts.get("Critical", 0) > 0
            ]
            dash.add_row(
                f"[{c['critical']}]alerts[/]",
                f"[{c['critical']}]\u25b2 {crit_total} critical events"
                f" in {', '.join(crit_files)}[/]",
            )

        if high_total > 0:
            high_file_count = sum(
                1 for f in summary.files
                if f.severity_counts.get("High", 0) > 0
            )
            breakdown = self._alert_breakdown(summary)
            breakdown_str = f" ({breakdown})" if breakdown else ""
            dash.add_row(
                f"[{c['high']}]alerts[/]" if not crit_total else "",
                f"[{c['high']}]\u25b2 {high_total:,} high severity events"
                f" across {high_file_count} files{breakdown_str}[/]",
            )

        # Row: noise
        noise_callout = self._noise_callout(summary)
        if noise_callout:
            dash.add_row(
                f"[{c['medium']}]noise[/]",
                noise_callout[0],
            )
            if noise_callout[1]:
                dash.add_row("", noise_callout[1])

        self.console.print(dash)
        self.console.print()

    def _alert_breakdown(self, summary: LoadSummary) -> str:
        """Categorize high/critical events by action/subtype."""
        categories: dict[str, int] = {}

        # We need events to categorize — rebuild from file-level data
        # Since we don't store events in ParsedFileInfo, we just provide
        # the breakdown from source_counts heuristics
        # This is a best-effort categorization from the file metadata
        for f in summary.files:
            high_count = (
                f.severity_counts.get("Critical", 0)
                + f.severity_counts.get("High", 0)
            )
            if high_count == 0:
                continue
            # Heuristic: FortiGate files likely have deny/vpn events
            fmt = f.format_name.lower()
            if "forti" in fmt:
                categories["deny/vpn"] = categories.get("deny/vpn", 0) + high_count
            elif "windows" in fmt or "xml" in fmt or "evtx" in fmt:
                categories["security"] = categories.get("security", 0) + high_count
            else:
                categories["other"] = categories.get("other", 0) + high_count

        if not categories:
            return ""
        return ", ".join(
            f"{count} {cat}"
            for cat, count in sorted(categories.items(), key=lambda x: -x[1])
        )

    def _noise_callout(
        self, summary: LoadSummary,
    ) -> tuple[str, str] | None:
        """Generate noise callout if known noise sources >20% of total."""
        if not summary.noise_sources or summary.total_events == 0:
            return None

        noise_total = sum(count for _, count in summary.noise_sources)
        pct = noise_total / summary.total_events * 100

        if pct < 20:
            return None

        c = _C
        noise_names = [name for name, _ in summary.noise_sources]
        names_str = " + ".join(noise_names[:3])

        line1 = (
            f"[{c['medium']}]\u25b3 {noise_total:,} events from "
            f"{names_str} ({pct:.0f}% of total)[/]"
        )
        short_names = [n.split("-")[-1] if "-" in n else n for n in noise_names[:2]]
        line2 = (
            f"[{c['dim']}]  tip: use [bold]hide Source:"
            f"{', '.join(short_names)}[/bold]"
            f" or [bold]--profile windows-workstation[/bold][/{c['dim']}]"
        )
        return line1, line2
