#!/usr/bin/env python3
"""Canonical severity constants, normalization, and classification.

All severity-related logic lives here.  Other modules import from this
module rather than maintaining their own copies.
"""

from __future__ import annotations

import re

# -- ordered severity levels -------------------------------------------------

SEVERITY_LEVELS: tuple[str, ...] = ("Critical", "High", "Medium", "Low", "Info")

SEV_ORDER: dict[str, int] = {sev: i for i, sev in enumerate(SEVERITY_LEVELS)}

# -- abbreviation / alias normalization --------------------------------------

SEV_KEYWORDS: frozenset[str] = frozenset({
    "critical", "crit", "high", "hi", "medium", "med", "low", "lo", "info",
})

SEV_NORMALIZE: dict[str, str] = {
    "critical": "Critical", "crit": "Critical",
    "high": "High", "hi": "High",
    "medium": "Medium", "med": "Medium",
    "low": "Low", "lo": "Low",
    "info": "Info",
}

# -- text-based severity classification --------------------------------------

_SEV_CRITICAL_RE = re.compile(r"critical|emergency|fatal", re.IGNORECASE)
_SEV_HIGH_RE = re.compile(
    r"\berror\b|\bfail(?:ed|ure|ing)?\b|\bdenied\b|\bblock(?:ed)?\b|\bdrop(?:ped)?\b",
    re.IGNORECASE,
)
_SEV_MEDIUM_RE = re.compile(r"\bwarn|timeout|expire|\bdown\b", re.IGNORECASE)
_SEV_INFO_RE = re.compile(r"\bdebug\b|\btrace\b|\bverbose\b", re.IGNORECASE)


def severity_from_forti_level(
    level: str = "",
    action: str = "",
    type_: str = "",
    raw: str = "",
) -> str:
    """Derive severity from FortiGate log fields."""
    if level:
        match level.lower():
            case "emergency" | "alert" | "critical":
                return "Critical"
            case "error":
                return "High"
            case "warning":
                return "Medium"
            case "notice" | "information":
                return "Low"
            case "debug":
                return "Info"
    if action:
        a = action.lower()
        if a in ("deny", "block", "drop", "dropped"):
            return "High"
        if a == "timeout":
            return "Medium"
        if a == "accept" and type_ == "utm":
            return "Medium"
        if a == "accept":
            return "Low"
    return severity_from_text(raw)


def severity_from_text(text: str) -> str:
    """Derive severity from free-text content."""
    if not text:
        return "Low"
    if _SEV_CRITICAL_RE.search(text):
        return "Critical"
    if _SEV_HIGH_RE.search(text):
        return "High"
    if _SEV_MEDIUM_RE.search(text):
        return "Medium"
    if _SEV_INFO_RE.search(text):
        return "Info"
    return "Low"
