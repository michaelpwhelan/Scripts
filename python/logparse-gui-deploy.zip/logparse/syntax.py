#!/usr/bin/env python3
"""Command parser for REPL input."""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass
class ParsedCommand:
    """Structured REPL command."""

    verb: str
    args: str
    pipe_ops: list[str] = field(default_factory=list)
    raw: str = ""


def _split_pipes(text: str) -> list[str]:
    """Split on | but not inside quotes."""
    parts: list[str] = []
    current: list[str] = []
    in_quote: str | None = None

    for ch in text:
        if ch in ('"', "'") and in_quote is None:
            in_quote = ch
            current.append(ch)
        elif ch == in_quote:
            in_quote = None
            current.append(ch)
        elif ch == "|" and in_quote is None:
            parts.append("".join(current).strip())
            current = []
        else:
            current.append(ch)

    parts.append("".join(current).strip())
    return parts


def _strip_delimiter_quotes(text: str) -> str:
    """Strip user-delimiter quotes from field:value patterns.

    Users write quotes as emphasis/delimiters, not to change semantics:
      field:"value"  → field:value
      field:"val*"   → field:val*
      regex:"^\\d+"  → regex:^\\d+
      "bare value"   → left alone (no field: prefix)

    This runs once at parse time so no downstream command needs to
    handle quote stripping individually.
    """
    def _replace(m: re.Match) -> str:
        prefix = m.group(1)  # field: or field= or regex: etc.
        _quote = m.group(2)   # opening quote
        value = m.group(3)   # content between quotes
        return f"{prefix}{value}"

    # Match: word followed by : or = followed by "..." or '...'
    return re.sub(
        r"""(\w+[:=])(["'])((?:(?!\2).)*)\2""",
        _replace,
        text,
    )


def parse_command(text: str) -> ParsedCommand:
    """Parse raw REPL input into a structured command."""
    text = text.strip()
    if not text:
        return ParsedCommand(verb="", args="", raw=text)

    segments = _split_pipes(text)
    first = segments[0]
    pipe_ops = segments[1:] if len(segments) > 1 else []

    # extract verb (first word)
    parts = first.split(None, 1)
    verb = parts[0].lower() if parts else ""
    raw_args = parts[1] if len(parts) > 1 else ""

    # Normalize: strip delimiter quotes from field:"value" patterns
    # so downstream commands never need to handle this individually
    args = _strip_delimiter_quotes(raw_args)

    return ParsedCommand(verb=verb, args=args, pipe_ops=pipe_ops, raw=text)


def split_commands(text: str) -> list[str]:
    """Split input on && and ; for command chaining."""
    commands: list[str] = []
    current: list[str] = []
    in_quote: str | None = None
    i = 0

    while i < len(text):
        ch = text[i]
        if ch in ('"', "'") and in_quote is None:
            in_quote = ch
            current.append(ch)
        elif ch == in_quote:
            in_quote = None
            current.append(ch)
        elif ch == ";" and in_quote is None:
            cmd = "".join(current).strip()
            if cmd:
                commands.append(cmd)
            current = []
        elif ch == "&" and in_quote is None and i + 1 < len(text) and text[i + 1] == "&":
            cmd = "".join(current).strip()
            if cmd:
                commands.append(cmd)
            current = []
            i += 1  # skip second & in &&
        else:
            current.append(ch)
        i += 1

    cmd = "".join(current).strip()
    if cmd:
        commands.append(cmd)
    return commands


class ExpandedStr(str):
    """String subclass that carries unresolved variable names."""

    def __new__(cls, value="") -> ExpandedStr:
        instance = super().__new__(cls, value)
        instance.unresolved_vars = []
        return instance


def expand_variables(text: str, variables: dict[str, str | list[str]]) -> ExpandedStr:
    """Replace $name tokens with stored variable values.

    Returns an :class:`ExpandedStr` with ``unresolved_vars`` listing any
    ``$name`` tokens that had no matching variable.
    """
    unresolved: list[str] = []

    def _replace(m: re.Match) -> str:
        name = m.group(1)
        if name.startswith("_"):
            return m.group(0)  # skip internal variables
        val = variables.get(name)
        if val is None:
            unresolved.append(name)
            return m.group(0)  # leave unresolved
        if isinstance(val, (dict, set, tuple)):
            return m.group(0)  # skip non-expandable types
        if isinstance(val, list):
            return ",".join(str(v) for v in val)
        return str(val)

    raw = re.sub(r"\$(\w+)", _replace, text)
    result = ExpandedStr(raw)
    result.unresolved_vars = unresolved
    return result
