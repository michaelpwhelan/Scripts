#!/usr/bin/env python3
"""STIX/TAXII 2.1 client using only urllib.

Fetches STIX bundles from TAXII servers and parses indicators.
Only handles simple ``[type:field = 'value']`` STIX patterns —
complex compound patterns are logged as warnings and skipped.
"""

from __future__ import annotations

import base64
import json
import logging
import re
import urllib.error
import urllib.request
from dataclasses import dataclass

log = logging.getLogger(__name__)

_TAXII_ACCEPT = "application/taxii+json;version=2.1"
_STIX_ACCEPT = "application/stix+json;version=2.1"

# Matches simple STIX patterns like: [ipv4-addr:value = '1.2.3.4']
# or [file:hashes.'SHA-256' = 'abc123']
_SIMPLE_PATTERN_RE = re.compile(
    r"\[(\w[\w-]*):(\w[\w.'\-]*)\s*=\s*'([^']+)'\]"
)


@dataclass(frozen=True)
class STIXIndicator:
    """Parsed STIX 2.1 indicator."""

    id: str
    name: str
    pattern: str
    pattern_type: str
    valid_from: str
    labels: tuple[str, ...]
    source: str = ""


# -- TAXII 2.1 client -------------------------------------------------------


def fetch_taxii_collection(
    discovery_url: str,
    collection_id: str,
    *,
    api_root: str = "",
    username: str = "",
    password: str = "",
) -> list[dict]:
    """Fetch STIX objects from a TAXII 2.1 collection.

    Returns the raw list of STIX objects (dicts).
    """
    headers: dict[str, str] = {"Accept": _TAXII_ACCEPT}
    if username and password:
        cred = base64.b64encode(f"{username}:{password}".encode()).decode()
        headers["Authorization"] = f"Basic {cred}"

    # Discover API root if not provided
    if not api_root:
        discovery = _taxii_get(discovery_url, headers)
        roots = discovery.get("api_roots", [])
        if not roots:
            raise ValueError(f"No API roots found at {discovery_url}")
        api_root = roots[0]
        if not api_root.endswith("/"):
            api_root += "/"

    # Fetch collection objects
    url = f"{api_root}collections/{collection_id}/objects/"
    headers["Accept"] = _STIX_ACCEPT
    all_objects: list[dict] = []

    while url:
        data = _taxii_get(url, headers)
        objects = data.get("objects", [])
        all_objects.extend(objects)
        # TAXII pagination via "next"
        url = data.get("next", "")

    log.debug(
        "Fetched %d objects from collection %s", len(all_objects), collection_id
    )
    return all_objects


def _taxii_get(url: str, headers: dict[str, str]) -> dict:
    """GET request to a TAXII endpoint."""
    req = urllib.request.Request(url, headers=headers, method="GET")
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            body = resp.read()
            return json.loads(body) if body else {}
    except urllib.error.HTTPError as exc:
        log.error("TAXII request failed: %s %s", exc.code, exc.reason)
        raise
    except urllib.error.URLError as exc:
        log.error("TAXII connection error: %s", exc.reason)
        raise


# -- STIX bundle parsing -----------------------------------------------------


def parse_stix_bundle(bundle: dict | list) -> list[STIXIndicator]:
    """Extract indicators from a STIX 2.1 bundle or object list.

    Accepts either a full bundle ``{"type": "bundle", "objects": [...]}``
    or a raw list of STIX objects.
    """
    if isinstance(bundle, list):
        objects = bundle
    else:
        objects = bundle.get("objects", [])

    indicators: list[STIXIndicator] = []
    for obj in objects:
        if not isinstance(obj, dict):
            continue
        if obj.get("type") != "indicator":
            continue

        pattern = obj.get("pattern", "")
        if not pattern:
            continue

        # Only handle simple patterns
        if not _SIMPLE_PATTERN_RE.search(pattern):
            log.debug("Skipping complex STIX pattern: %s", pattern[:100])
            continue

        indicators.append(
            STIXIndicator(
                id=obj.get("id", ""),
                name=obj.get("name", ""),
                pattern=pattern,
                pattern_type=obj.get("pattern_type", "stix"),
                valid_from=obj.get("valid_from", ""),
                labels=tuple(obj.get("labels", [])),
                source=obj.get("created_by_ref", ""),
            )
        )

    return indicators


def extract_ioc_values(
    indicators: list[STIXIndicator],
) -> dict[str, str]:
    """Extract raw IOC values from STIX indicators for matching.

    Parses simple ``[type:field = 'value']`` patterns.
    Returns ``{ioc_value: ioc_type}``.
    """
    iocs: dict[str, str] = {}
    for ind in indicators:
        for m in _SIMPLE_PATTERN_RE.finditer(ind.pattern):
            obj_type = m.group(1)  # e.g. "ipv4-addr", "domain-name"
            value = m.group(3)
            # Map STIX object types to simpler IOC types
            ioc_type = _STIX_TYPE_MAP.get(obj_type, obj_type)
            iocs[value] = ioc_type
    return iocs


_STIX_TYPE_MAP: dict[str, str] = {
    "ipv4-addr": "ipv4",
    "ipv6-addr": "ipv6",
    "domain-name": "domain",
    "url": "url",
    "file": "hash",
    "email-addr": "email",
    "mac-addr": "mac",
    "user-account": "user",
    "autonomous-system": "asn",
}


def load_stix_file(path: str) -> list[STIXIndicator]:
    """Load and parse a STIX 2.1 JSON file from disk."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    return parse_stix_bundle(data)
