#!/usr/bin/env python3
"""File loading, zip extraction, and verbose progress."""

from __future__ import annotations

import gc
import logging
import sys
import tempfile
import zipfile
from datetime import datetime
from pathlib import Path
from time import perf_counter
from typing import Callable

from logparse.models import LogEvent
from logparse.cache import load_cached, save_cache
from logparse.parsers import detect_format, parse_file

log = logging.getLogger(__name__)

_MAX_FILE_SIZE = 500 * 1024 * 1024  # 500 MB

_SKIP_EXTS = frozenset({
    ".exe", ".dll", ".png", ".jpg", ".jpeg", ".gif",
    ".pdf", ".msi", ".iso", ".cab", ".bmp", ".ico",
})
_TRY_EXTS = frozenset({
    ".log", ".txt", ".csv", ".xml", ".json", ".conf", ".evtx", ".evt", "",
})

# Filename patterns that indicate logparse export artifacts (skip when loading dirs)
_EXPORT_PREFIXES = ("logparse-export", "logparse_export")
_EXPORT_SUFFIXES = (".csv", ".json", ".html", ".md")


def _stderr(msg: str) -> None:
    print(msg, file=sys.stderr, flush=True)


def _count_severity(events: list[LogEvent]) -> dict[str, int]:
    """Count severity levels in an event list."""
    sev = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    for e in events:
        sev[e.severity] = sev.get(e.severity, 0) + 1
    return sev


def _extract_zip(
    zip_path: Path,
    quiet: bool,
    on_file: Callable | None = None,
    archive_name: str = "",
) -> list[tuple[Path, str, str, float, dict[str, int]]]:
    """Extract a zip archive and detect formats inside.

    Returns list of (extracted_path, format_name, display_name, parse_time, sev_counts).
    """
    results: list[tuple[Path, str, str, float, dict[str, int]]] = []
    tmpdir = Path(tempfile.mkdtemp(prefix="logparse-"))

    try:
        with zipfile.ZipFile(zip_path) as zf:
            # Validate member paths against zip-slip (path traversal)
            safe_members = []
            resolved_tmpdir = tmpdir.resolve()
            for member in zf.namelist():
                target = (tmpdir / member).resolve()
                if not target.is_relative_to(resolved_tmpdir):
                    log.warning(
                        "Skipping zip member with path traversal: %s", member
                    )
                    continue
                safe_members.append(member)
            for member in safe_members:
                zf.extract(member, tmpdir)
    except (zipfile.BadZipFile, OSError) as exc:
        log.warning("Failed to extract %s: %s", zip_path.name, exc)
        return results

    all_files = sorted(tmpdir.rglob("*"))
    parseable = []
    skip_list = []

    for f in all_files:
        if not f.is_file():
            continue
        ext = f.suffix.lower()
        if ext in _SKIP_EXTS:
            skip_list.append((f, "binary"))
            continue

        # nested zip — one level
        if ext == ".zip":
            results.extend(_extract_zip(f, quiet, on_file, archive_name))
            continue

        fmt = detect_format(f)
        if fmt:
            parseable.append((f, fmt))
        else:
            skip_list.append((f, "unknown format"))

    total = len(parseable) + len(skip_list)
    idx = 0

    # Emit skipped files
    for f, reason in skip_list:
        idx += 1
        rel_dir = str(f.parent.relative_to(tmpdir)) if f.parent != tmpdir else ""
        if rel_dir == ".":
            rel_dir = ""

        if on_file:
            from logparse.verbose import ParsedFileInfo
            info = ParsedFileInfo(
                filename=f.name,
                skipped=True,
                skip_reason=reason,
                archive_name=archive_name,
                directory=rel_dir,
                index=idx,
                total=total,
            )
            on_file(info)
        elif not quiet:
            _stderr(f"  {f.name:<40} (skipped)")

    # Parse files
    for f, fmt in parseable:
        idx += 1
        rel_dir = str(f.parent.relative_to(tmpdir)) if f.parent != tmpdir else ""
        if rel_dir == ".":
            rel_dir = ""

        if on_file:
            from logparse.verbose import ParsedFileInfo

        if not quiet and on_file is None:
            _stderr(f"  {f.name:<40} {fmt}")

        t_file = perf_counter()
        file_events = parse_file(f, fmt, f.name)
        file_elapsed = perf_counter() - t_file
        sev = _count_severity(file_events) if file_events else {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}

        if on_file:
            info = ParsedFileInfo(
                filename=f.name,
                format_name=fmt,
                event_count=len(file_events),
                parse_time=file_elapsed,
                severity_counts=sev,
                archive_name=archive_name,
                directory=rel_dir,
                index=idx,
                total=total,
            )
            on_file(info)

        results.append((f, fmt, f.name, file_events, sev))

    return results


def load_files(
    paths: list[str],
    format_override: str | None = None,
    quiet: bool = False,
    *,
    on_file: Callable | None = None,
    use_cache: bool = True,
) -> tuple[list[LogEvent], list[str], list[str]]:
    """Load and parse files, returning (events, loaded_files, loaded_formats).

    Prints verbose per-file progress to stderr unless *quiet*.
    When *on_file* is provided, calls it with a ParsedFileInfo for each file
    instead of printing plain-text stderr output.
    When *use_cache* is True, attempts to load previously parsed results and
    saves new parse results for future runs.
    """
    all_events: list[LogEvent] = []
    loaded_files: list[str] = []
    loaded_formats: list[str] = []
    skipped: list[str] = []
    t0 = perf_counter()

    resolved: list[Path] = []
    for p in paths:
        pp = Path(p)
        if "*" in p or "?" in p:
            parent = pp.parent if pp.parent != pp else Path(".")
            resolved.extend(sorted(parent.glob(pp.name)))
        elif pp.is_dir():
            # recurse into directory
            resolved.extend(sorted(f for f in pp.rglob("*") if f.is_file()))
        else:
            resolved.append(pp)

    total_files = len(resolved)
    use_callback = on_file is not None

    # Disable GC during batch parsing — 5-10% speedup, avoids random pauses.
    gc.disable()
    try:
        for file_idx, file_path in enumerate(resolved, 1):
            if not file_path.exists():
                log.warning("File not found: %s", file_path)
                continue

            try:
                fsize = file_path.stat().st_size
                if fsize > _MAX_FILE_SIZE:
                    log.warning(
                        "Skipping %s: file too large (%d MB, max %d MB)",
                        file_path.name, fsize // (1024 * 1024),
                        _MAX_FILE_SIZE // (1024 * 1024),
                    )
                    skipped.append(str(file_path))
                    continue
            except OSError as exc:
                log.debug("Could not stat %s: %s", file_path.name, exc)

            # Skip logparse export artifacts when loading directories
            name_lower = file_path.name.lower()
            if any(name_lower.startswith(p) for p in _EXPORT_PREFIXES):
                if use_callback:
                    from logparse.verbose import ParsedFileInfo
                    on_file(ParsedFileInfo(
                        filename=file_path.name,
                        skipped=True,
                        skip_reason="logparse export",
                        index=file_idx,
                        total=total_files,
                    ))
                elif not quiet:
                    _stderr(f"  [{file_idx}/{total_files}] {file_path.name} (skipped: logparse export)")
                skipped.append(str(file_path))
                continue

            if file_path.suffix.lower() == ".zip":
                if not quiet and not use_callback:
                    _stderr(f"Extracting {file_path.name}...")
                archive_files = _extract_zip(
                    file_path, quiet,
                    on_file=on_file,
                    archive_name=file_path.name,
                )
                for extracted_path, fmt, display_name, events, _ in archive_files:
                    if events:
                        all_events.extend(events)
                        loaded_files.append(display_name)
                        if fmt not in loaded_formats:
                            loaded_formats.append(fmt)
                        if not quiet and not use_callback:
                            _stderr(
                                f"  [{file_idx}/{total_files}] {display_name}"
                                f" \u2014 {len(events):,} events ({fmt})"
                            )

                # Render archive tree after all files processed
                if use_callback:
                    # The VerboseOutput instance handles tree rendering via
                    # the archive_name grouping — the cli.py caller will
                    # trigger render_archive_tree after load_files returns.
                    pass
                continue

            fmt = format_override or detect_format(file_path)
            if not fmt:
                log.warning("Could not detect format: %s", file_path)
                if use_callback:
                    from logparse.verbose import ParsedFileInfo
                    on_file(ParsedFileInfo(
                        filename=file_path.name,
                        skipped=True,
                        skip_reason="unknown format",
                        index=file_idx,
                        total=total_files,
                    ))
                skipped.append(str(file_path))
                continue

            if not quiet and not use_callback:
                _stderr(
                    f"  [{file_idx}/{total_files}] {file_path.name} ({fmt})..."
                )

            t_file = perf_counter()

            # Try cache first
            events = None
            if use_cache:
                events = load_cached(file_path)
                if events:
                    log.debug("Cache hit: %s (%d events)", file_path.name, len(events))

            if events is None:
                events = parse_file(file_path, fmt, str(file_path))
                if use_cache and events:
                    save_cache(file_path, events)

            file_elapsed = perf_counter() - t_file

            if events:
                sev = _count_severity(events)
                all_events.extend(events)
                loaded_files.append(file_path.name)
                if fmt not in loaded_formats:
                    loaded_formats.append(fmt)

                if use_callback:
                    from logparse.verbose import ParsedFileInfo
                    on_file(ParsedFileInfo(
                        filename=file_path.name,
                        format_name=fmt,
                        event_count=len(events),
                        parse_time=file_elapsed,
                        severity_counts=sev,
                        index=file_idx,
                        total=total_files,
                    ))
                elif not quiet:
                    _stderr(f"    {len(events):,} events")
            else:
                if use_callback:
                    from logparse.verbose import ParsedFileInfo
                    on_file(ParsedFileInfo(
                        filename=file_path.name,
                        format_name=fmt,
                        event_count=0,
                        parse_time=file_elapsed,
                        index=file_idx,
                        total=total_files,
                    ))
                elif not quiet:
                    _stderr("    0 events")
    except KeyboardInterrupt:
        _stderr(
            f"\nParse interrupted. Loaded {len(all_events):,} events"
            f" from {len(loaded_files)} file(s)."
        )
    finally:
        gc.enable()
        gc.collect()

    # sort by timestamp
    all_events.sort(
        key=lambda e: e.timestamp if e.timestamp is not None else datetime_max()
    )

    elapsed = perf_counter() - t0

    # Plain-text summary fallback (when no callback)
    if not use_callback and not quiet and all_events:
        _stderr("")
        _stderr(
            f"Loaded {len(all_events):,} events"
            f" from {len(loaded_files)} file(s)"
            f" in {elapsed:.1f}s"
        )
        # time range
        ts_events = [e for e in all_events if e.timestamp is not None]
        if ts_events:
            first = ts_events[0].timestamp
            last = ts_events[-1].timestamp
            if first is not None and last is not None:
                _stderr(
                    f"Time range: {first:%Y-%m-%d %H:%M:%S}"
                    f" \u2014 {last:%Y-%m-%d %H:%M:%S}"
                )
        # top sources
        source_counts: dict[str, int] = {}
        for e in all_events:
            if e.source:
                source_counts[e.source] = source_counts.get(e.source, 0) + 1
        if source_counts:
            top = sorted(source_counts.items(), key=lambda x: x[1], reverse=True)[:5]
            parts = [f"{name} ({count:,})" for name, count in top]
            _stderr(f"Top sources: {' | '.join(parts)}")

    if skipped and not quiet and not use_callback:
        _stderr(f"Skipped {len(skipped)} file(s)")

    return all_events, loaded_files, loaded_formats


def datetime_max() -> datetime:
    """Sentinel for sorting events without timestamps to the end."""
    from datetime import datetime
    return datetime.max
