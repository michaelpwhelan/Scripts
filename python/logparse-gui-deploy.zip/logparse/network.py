#!/usr/bin/env python3
"""Network awareness — RFC 1918 classification and site lookup."""

from __future__ import annotations

from ipaddress import ip_address, ip_network, IPv4Address, IPv6Address

_RFC1918 = [
    ip_network("10.0.0.0/8"),
    ip_network("172.16.0.0/12"),
    ip_network("192.168.0.0/16"),
]

class _NetworkConfig:
    """Lazy-loaded network configuration from ~/.logparse/network.yaml."""

    def __init__(self) -> None:
        self._config: dict | None = None

    def load(self) -> dict:
        """Load and cache ~/.logparse/network.yaml if it exists."""
        if self._config is not None:
            return self._config

        from logparse.config_loader import get_config_dir
        path = get_config_dir() / "network.yaml"
        if not path.exists():
            self._config = {}
            return self._config

        text = path.read_text(encoding="utf-8")
        try:
            import yaml
            self._config = yaml.safe_load(text) or {}
        except ImportError:
            import json
            try:
                self._config = json.loads(text)
            except (json.JSONDecodeError, ValueError):
                self._config = {}

        return self._config

    def reset(self) -> None:
        """Clear cached config (useful for testing)."""
        self._config = None


_network_cfg = _NetworkConfig()


def load_network_config() -> dict:
    """Load ~/.logparse/network.yaml if it exists."""
    return _network_cfg.load()


def _parse_ip(ip: str) -> IPv4Address | IPv6Address | None:
    """Try to parse a string as an IP address."""
    try:
        return ip_address(ip.strip())
    except (ValueError, AttributeError):
        return None


def is_internal(ip: str) -> bool:
    """Check if IP is in RFC 1918 ranges (or network.yaml overrides)."""
    addr = _parse_ip(ip)
    if addr is None:
        return False

    config = load_network_config()
    internal_nets = config.get("internal")
    if internal_nets:
        for net_str in internal_nets:
            try:
                if addr in ip_network(net_str, strict=False):
                    return True
            except ValueError:
                continue
        return False

    # default RFC 1918
    return any(addr in net for net in _RFC1918)


def is_external(ip: str) -> bool:
    """Check if IP is globally routable (respects network.yaml overrides)."""
    if is_internal(ip):
        return False
    addr = _parse_ip(ip)
    if addr is None:
        return False
    return addr.is_global


def get_site(ip: str) -> str | None:
    """Look up site name from network.yaml sites mapping."""
    addr = _parse_ip(ip)
    if addr is None:
        return None

    config = load_network_config()
    sites = config.get("sites", {})
    for site_name, net_str in sites.items():
        try:
            if addr in ip_network(net_str, strict=False):
                return site_name
        except ValueError:
            continue
    return None
