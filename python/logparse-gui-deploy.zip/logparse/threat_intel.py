#!/usr/bin/env python3
"""Bundled IP threat classification data.

Static curated lists — last updated 2025-01. No external API calls.
Uses ipaddress module for CIDR matching.
"""

from __future__ import annotations

import ipaddress
from functools import lru_cache

# Well-known Tor exit node ranges (representative /24s)
TOR_RANGES: list[str] = [
    "185.220.100.0/24", "185.220.101.0/24", "185.220.102.0/24",
    "185.220.103.0/24", "199.249.230.0/24", "204.85.191.0/24",
    "171.25.193.0/24", "62.210.105.0/24", "195.176.3.0/24",
    "176.10.99.0/24", "77.247.181.0/24", "109.70.100.0/24",
    "198.98.48.0/24", "23.129.64.0/24", "185.107.47.0/24",
    "51.15.0.0/16", "193.218.118.0/24", "178.17.170.0/24",
    "178.17.174.0/24", "91.219.237.0/24", "162.247.74.0/24",
    "5.2.72.0/24", "45.33.32.0/24", "92.223.105.0/24",
    "185.100.87.0/24", "185.100.86.0/24", "82.94.251.0/24",
    "193.189.100.0/24", "144.172.73.0/24", "198.96.155.0/24",
]

# Major cloud provider ranges (top prefixes only)
CLOUD_RANGES: dict[str, list[str]] = {
    "AWS": [
        "3.0.0.0/8", "13.0.0.0/8", "15.0.0.0/8", "18.0.0.0/8",
        "35.0.0.0/8", "44.0.0.0/8", "50.0.0.0/8", "52.0.0.0/8",
        "54.0.0.0/8", "99.0.0.0/8",
    ],
    "Azure": [
        "13.64.0.0/11", "20.0.0.0/8", "40.64.0.0/10",
        "51.104.0.0/14", "52.224.0.0/11", "104.208.0.0/13",
    ],
    "GCP": [
        "34.0.0.0/8", "35.184.0.0/13", "35.192.0.0/12",
        "35.208.0.0/12", "35.224.0.0/12", "35.240.0.0/13",
    ],
    "DigitalOcean": [
        "134.209.0.0/16", "138.197.0.0/16", "139.59.0.0/16",
        "142.93.0.0/16", "157.230.0.0/16", "159.65.0.0/16",
        "159.89.0.0/16", "161.35.0.0/16", "164.90.0.0/16",
        "167.172.0.0/16", "167.71.0.0/16", "174.138.0.0/16",
        "178.128.0.0/16", "206.189.0.0/16", "209.97.0.0/16",
    ],
}

# Known scanner/research ranges
SCANNER_RANGES: dict[str, list[str]] = {
    "Shodan": ["66.240.192.0/18", "71.6.128.0/17", "82.221.105.0/24"],
    "Censys": ["162.142.125.0/24", "167.94.138.0/24", "167.94.145.0/24",
               "167.94.146.0/24", "167.248.133.0/24"],
    "BinaryEdge": ["37.139.128.0/17"],
    "Shadowserver": ["74.82.47.0/24", "184.105.139.0/24", "184.105.247.0/24"],
    "Rapid7": ["71.6.233.0/24", "5.63.151.0/24"],
    "Stretchoid": ["198.235.24.0/24"],
}

class _ThreatNetworks:
    """Lazy-initialized pre-parsed network tables for threat classification."""

    def __init__(self) -> None:
        self._tor_nets: list[ipaddress.IPv4Network] = []
        self._cloud_nets: list[tuple[str, ipaddress.IPv4Network]] = []
        self._scanner_nets: list[tuple[str, ipaddress.IPv4Network]] = []
        self._initialized = False

    def _init(self) -> None:
        if self._initialized:
            return
        for cidr in TOR_RANGES:
            try:
                self._tor_nets.append(ipaddress.IPv4Network(cidr, strict=False))
            except ValueError:
                continue
        for provider, cidrs in CLOUD_RANGES.items():
            for cidr in cidrs:
                try:
                    self._cloud_nets.append((provider, ipaddress.IPv4Network(cidr, strict=False)))
                except ValueError:
                    continue
        for org, cidrs in SCANNER_RANGES.items():
            for cidr in cidrs:
                try:
                    self._scanner_nets.append((org, ipaddress.IPv4Network(cidr, strict=False)))
                except ValueError:
                    continue
        self._initialized = True

    @property
    def tor_nets(self) -> list[ipaddress.IPv4Network]:
        self._init()
        return self._tor_nets

    @property
    def cloud_nets(self) -> list[tuple[str, ipaddress.IPv4Network]]:
        self._init()
        return self._cloud_nets

    @property
    def scanner_nets(self) -> list[tuple[str, ipaddress.IPv4Network]]:
        self._init()
        return self._scanner_nets


_networks = _ThreatNetworks()


@lru_cache(maxsize=4096)
def classify_ip(ip: str) -> dict[str, str]:
    """Classify an IP address against bundled threat intelligence.

    Returns dict with keys: category, provider, risk.
    """
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return {"category": "invalid", "provider": "", "risk": "unknown"}

    if addr.is_private or addr.is_loopback or addr.is_reserved:
        return {"category": "internal", "provider": "", "risk": "low"}

    if isinstance(addr, ipaddress.IPv4Address):
        # Check Tor
        for net in _networks.tor_nets:
            if addr in net:
                return {"category": "tor", "provider": "Tor Network", "risk": "high"}

        # Check scanners
        for org, net in _networks.scanner_nets:
            if addr in net:
                return {"category": "scanner", "provider": org, "risk": "medium"}

        # Check cloud
        for provider, net in _networks.cloud_nets:
            if addr in net:
                return {"category": "cloud", "provider": provider, "risk": "low"}

    return {"category": "public", "provider": "", "risk": "unknown"}
