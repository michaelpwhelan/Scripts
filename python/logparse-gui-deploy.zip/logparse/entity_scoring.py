#!/usr/bin/env python3
"""Entity scoring engine.

Accumulates risk scores for entities (IPs, users, hosts) across log events.
Ports the implicit PowerShell scoring model (count thresholds → severity
colors) into explicit weighted scoring with multi-source bonuses.
"""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from datetime import datetime

from logparse.models import LogEvent, get_field


# -- scoring tables ----------------------------------------------------------


@dataclass(frozen=True)
class EventScore:
    """Weight for a specific event pattern."""

    event_type: str
    field: str
    value: str  # substring match (case-insensitive)
    weight: float


EVENT_SCORES: list[EventScore] = [
    # FortiGate actions
    EventScore("failed_login", "action", "ssl-login-fail", 3.0),
    EventScore("denied", "action", "deny", 2.0),
    EventScore("blocked", "action", "block", 2.5),
    EventScore("dropped", "action", "dropped", 2.0),
    EventScore("vpn_login", "action", "ssl-login", 1.0),
    EventScore("timeout", "action", "timeout", 1.5),
    # Windows Security event IDs
    EventScore("admin_change", "EventID", "4728", 4.0),
    EventScore("admin_change", "EventID", "4732", 4.0),
    EventScore("account_created", "EventID", "4720", 5.0),
    EventScore("account_deleted", "EventID", "4726", 3.0),
    EventScore("password_reset", "EventID", "4724", 3.0),
    EventScore("log_cleared", "EventID", "1102", 8.0),
    EventScore("logon_failure", "EventID", "4625", 2.0),
    EventScore("privilege_use", "EventID", "4672", 1.5),
    EventScore("kerberos_fail", "EventID", "4771", 2.5),
    # M365 sources
    EventScore("m365_alert", "source", "m365-defender", 5.0),
    EventScore("risky_signin", "source", "m365-risk", 4.0),
    EventScore("directory_change", "source", "m365-directory", 2.0),
    # FortiGate UTM
    EventScore("ips_detected", "subtype", "ips", 4.0),
    EventScore("av_detected", "subtype", "virus", 5.0),
    EventScore("webfilter_block", "subtype", "webfilter", 1.5),
    # Severity-based catch-all
    EventScore("critical_event", "severity", "Critical", 6.0),
    EventScore("high_event", "severity", "High", 3.0),
]

MULTI_SOURCE_BONUS: float = 1.5
"""Score multiplier per additional source file (compounds)."""

RISK_TIERS: dict[str, float] = {
    "Critical": 50.0,
    "High": 25.0,
    "Medium": 10.0,
    "Low": 0.0,
}


# -- data structures ---------------------------------------------------------


@dataclass
class EntityProfile:
    """Accumulated risk profile for an entity."""

    entity_type: str  # "ip", "user", "host"
    entity_value: str
    score: float = 0.0
    source_files: set[str] = field(default_factory=set)
    event_types: Counter = field(default_factory=Counter)
    event_count: int = 0
    first_seen: datetime | None = None
    last_seen: datetime | None = None
    risk_tier: str = "Low"


# -- scoring logic -----------------------------------------------------------


def _extract_entities(event: LogEvent) -> list[tuple[str, str, str]]:
    """Extract entities from event fields.

    Returns ``[(key, entity_type, entity_value), ...]``.
    """
    entities: list[tuple[str, str, str]] = []
    for field_name, entity_type in (
        ("srcip", "ip"),
        ("dstip", "ip"),
        ("user", "user"),
        ("devname", "host"),
    ):
        val = get_field(event, field_name)
        if val and val.strip() and val != "-":
            clean = val.strip()
            key = f"{entity_type}:{clean.lower()}"
            entities.append((key, entity_type, clean))
    # M365 user principal name
    upn = event.extra.get("userPrincipalName") or event.extra.get("userId") or ""
    if upn and "@" in upn:
        key = f"user:{upn.lower()}"
        entities.append((key, "user", upn))
    return entities


def _score_event(event: LogEvent) -> tuple[float, str]:
    """Score a single event against EVENT_SCORES.

    Returns ``(max_weight, event_type)`` across all matching rules,
    or ``(0.0, "")`` if no rule matches.
    """
    best_weight = 0.0
    best_type = ""
    for es in EVENT_SCORES:
        field_val = get_field(event, es.field) or ""
        if es.value.lower() in field_val.lower():
            if es.weight > best_weight:
                best_weight = es.weight
                best_type = es.event_type
    return best_weight, best_type


def score_entities(events: list[LogEvent]) -> list[EntityProfile]:
    """Score all entities across events, return sorted by score descending."""
    profiles: dict[str, EntityProfile] = {}

    for event in events:
        weight, event_type = _score_event(event)
        if weight == 0.0:
            continue

        for key, etype, evalue in _extract_entities(event):
            profile = profiles.get(key)
            if profile is None:
                profile = EntityProfile(entity_type=etype, entity_value=evalue)
                profiles[key] = profile

            profile.score += weight
            profile.event_count += 1
            if event_type:
                profile.event_types[event_type] += 1
            profile.source_files.add(event.source_file or event.source or "")

            ts = event.timestamp
            if ts is not None:
                if profile.first_seen is None or ts < profile.first_seen:
                    profile.first_seen = ts
                if profile.last_seen is None or ts > profile.last_seen:
                    profile.last_seen = ts

    # Apply multi-source bonus and assign risk tiers
    for profile in profiles.values():
        n_sources = len(profile.source_files - {""})
        if n_sources > 1:
            profile.score *= MULTI_SOURCE_BONUS ** (n_sources - 1)

        for tier, threshold in sorted(
            RISK_TIERS.items(), key=lambda x: x[1], reverse=True
        ):
            if profile.score >= threshold:
                profile.risk_tier = tier
                break

    return sorted(profiles.values(), key=lambda p: p.score, reverse=True)


def score_entity(
    entity_value: str, events: list[LogEvent]
) -> EntityProfile | None:
    """Score a single specific entity across events."""
    target = entity_value.lower()
    profiles = score_entities(events)
    for p in profiles:
        if p.entity_value.lower() == target:
            return p
    return None
