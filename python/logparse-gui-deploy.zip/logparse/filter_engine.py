#!/usr/bin/env python3
"""Filter parsing, evaluation, and pipeline dispatch.

This is the single authoritative parser for all filter conditions.
Commands like ``where``, ``hide``, ``show``, and ``not`` delegate here
rather than maintaining their own regex-based parsers.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from fnmatch import fnmatch

from logparse.models import LogEvent, get_field, resolve_field_alias
from logparse.severity import SEV_KEYWORDS, SEV_NORMALIZE

_CONDITION_RE = re.compile(
    r'(NOT\s+|!)?(\w[\w.-]*)([:=]|>=|<=|!=|>|<)("(?:[^"\\]|\\.)*"|[^\s]+)|AND|OR'
)

_STATIC_FIELDS: frozenset[str] = frozenset({
    # Core attrs
    "severity", "source", "message", "sourcefile", "sourceformat", "timestamp",
    # Alias canonical names (not already above)
    "dstip", "policyid", "protocol", "action", "devname", "catdesc", "service",
    # Common FortiGate extra fields
    "srcip", "srcport", "dstport", "vd", "logid", "subtype", "type",
    "user", "group", "app", "hostname", "url", "srcintf", "dstintf",
    "sentbyte", "rcvdbyte", "duration", "level", "date", "time",
})

_TIME_UNIT_SECONDS: dict[str, int] = {
    "s": 1, "m": 60, "min": 60, "minutes": 60,
    "h": 3600, "hr": 3600, "hour": 3600, "hours": 3600,
    "d": 86400, "day": 86400, "days": 86400,
}


def is_known_field(
    name_lower: str,
    extra_fields: set[str] | None = None,
    *,
    session=None,
) -> bool:
    """Check whether a lowercased name is a recognized log field.

    Pass *extra_fields* directly, or pass *session* and the extra fields
    will be extracted automatically.
    """
    if name_lower in _STATIC_FIELDS:
        return True
    if extra_fields and name_lower in extra_fields:
        return True
    if session is not None:
        return name_lower in session.field_names_lower()
    return False


def _time_in_range(ts, sh: int, sm: int, eh: int, em: int) -> bool:
    """Check if a timestamp's time-of-day is within [start, end] range.

    Handles midnight wrap: ``between 22:00 and 06:00`` works correctly.
    """
    t = ts.hour * 60 + ts.minute
    start = sh * 60 + sm
    end = eh * 60 + em
    if start <= end:
        return start <= t <= end
    return t >= start or t <= end


def _parse_bare_field_values(
    text: str,
    extra_fields: set[str] | None = None,
) -> list["Condition"]:
    """Try to interpret text as space-separated field value conditions.

    Only called when the primary regex found zero conditions.
    If any segment cannot be recognized, returns [] to let the caller
    fall back to grep or error handling.
    """
    segments = re.split(r"\b(AND|OR)\b", text, flags=re.IGNORECASE)

    # If ALL non-connector segments are bare severity keywords, combine
    # into a single "severity in X,Y" condition.  This makes
    # "hide info and medium" and "where high or critical" work naturally.
    value_segments = [
        s.strip() for s in segments
        if s.strip() and s.strip().upper() not in ("AND", "OR")
    ]
    if value_segments and all(s.lower() in SEV_KEYWORDS for s in value_segments):
        combined = ",".join(SEV_NORMALIZE.get(s.lower(), s) for s in value_segments)
        return [Condition("severity", combined, "in", False, "AND")]

    conditions: list[Condition] = []
    logic = "AND"

    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        if seg.upper() == "AND":
            logic = "AND"
            continue
        if seg.upper() == "OR":
            logic = "OR"
            continue

        # handle negation prefix
        negate = False
        if seg.startswith("!"):
            negate = True
            seg = seg[1:].strip()
        elif seg.upper().startswith("NOT "):
            negate = True
            seg = seg[4:].strip()

        parts = seg.split(None, 1)
        if len(parts) == 0:
            continue  # empty after stripping negation prefix
        if len(parts) == 1:
            # single word — only severity keywords are meaningful
            if parts[0].lower() in SEV_KEYWORDS:
                conditions.append(Condition(
                    "severity", SEV_NORMALIZE.get(parts[0].lower(), parts[0]),
                    "eq", negate, logic,
                ))
                logic = "AND"
                continue
            return []  # unrecognized single word — bail

        field_candidate, value = parts
        resolved = resolve_field_alias(field_candidate)
        if not is_known_field(resolved.lower(), extra_fields):
            return []  # unrecognized field — bail

        # Reject when the value looks like a mis-typed command rather than
        # a filter value.  "srcip trend" or "action by count" should NOT
        # become srcip=trend.  Also reject "rcvdbyte sentbyte" where the
        # value is another field name.
        value_parts = value.split()
        value_first = value_parts[0].lower() if value_parts else ""
        from logparse.commands import get_registry
        _command_verbs = {cmd.name.lower() for cmd in get_registry()}
        _pipeline_keywords = {"by", "from", "flip", "asc", "desc", "stacked"}
        if (value_first in _command_verbs
                or value_first in _pipeline_keywords
                or is_known_field(value_first, extra_fields)):
            return []

        # detect "is" keyword → strip to bare value (equality)
        is_m = re.match(r"^is\s+(.+)$", value, re.I)
        if is_m:
            value = is_m.group(1).strip().strip('"').strip("'")

        # detect "contains"/"contain" keyword → wildcard *value*
        contains_m = re.match(r"^contains?\s+(.+)$", value, re.I)
        if contains_m:
            value = f"*{contains_m.group(1).strip().strip(chr(34)).strip(chr(39))}*"

        # date expressions for timestamp/date fields → date-prefix wildcard
        if resolved.lower() in ("timestamp", "date"):
            from logparse.util import parse_date_expr
            d = parse_date_expr(value)
            if d is not None:
                value = f"{d.isoformat()}*"

        # normalize severity abbreviations for severity field
        if resolved.lower() == "severity":
            value = SEV_NORMALIZE.get(value.lower(), value)

        # detect operator from value
        value = value.strip('"').strip("'")
        # !value negation: source !Microsoft* → negate match
        if value.startswith("!") and len(value) > 1:
            negate = not negate
            value = value[1:]
        op = "eq"
        if value.startswith(">"):
            op = "gt"
            value = value[1:]
        elif value.startswith("<"):
            op = "lt"
            value = value[1:]
        elif "*" in value or "?" in value:
            op = "wildcard"

        conditions.append(Condition(resolved, value, op, negate, logic))
        logic = "AND"

    return conditions


@dataclass
class Condition:
    """Single filter condition."""

    field: str
    pattern: str
    op: str  # eq, wildcard, gt, lt
    negate: bool
    logic: str  # AND, OR


def parse_conditions(
    text: str,
    extra_fields: set[str] | None = None,
) -> list[Condition]:
    """Parse a filter string into a list of conditions.

    Recognises (in order):
    - ``has:field`` — field existence
    - ``last N<unit>`` — relative time window
    - ``between HH:MM and HH:MM`` — time-of-day range
    - ``field in val1,val2`` — multi-value membership
    - ``field contains value`` — substring match
    - ``field internal`` / ``field external`` — network classification
    - ``field:value`` / ``field=value`` — standard conditions (via regex)
    - ``field:val1,val2`` — comma multi-value (detected after regex)
    - Space-separated fallback: ``field value`` (when regex finds nothing)

    Pass *extra_fields* (lowercased) for session-aware field recognition.
    """
    conditions: list[Condition] = []
    logic = "AND"

    # --- Pre-regex: special syntaxes stripped from text before main parse ---

    # 1. has:field existence checks
    has_fields = set()
    for has_m in re.finditer(r'(NOT\s+|!)?has:(\w+)', text):
        negate = bool(has_m.group(1))
        field = has_m.group(2)
        conditions.append(Condition(field, "*", "exists", negate, logic))
        has_fields.add(f"has:{field}")
        logic = "AND"

    remaining = re.sub(r'(?:NOT\s+|!)?has:\w+', '', text).strip() if has_fields else text

    # 2. "last N<unit>" time window
    time_m = re.match(
        r'^last\s+(\d+)\s*(s|m|h|d|hr|min|hour|hours|minutes|day|days)\b(.*)$',
        remaining, re.I,
    )
    if time_m:
        amount = int(time_m.group(1))
        unit = time_m.group(2).lower()
        seconds = amount * _TIME_UNIT_SECONDS.get(unit, 3600)
        conditions.append(Condition("timestamp", str(seconds), "time_window", False, logic))
        logic = "AND"
        remaining = time_m.group(3).strip()

    # 3. "between HH:MM and HH:MM" time-of-day range
    between_m = re.match(
        r'^between\s+(\d{1,2}:\d{2})\s+and\s+(\d{1,2}:\d{2})\b(.*)$',
        remaining, re.I,
    )
    if between_m:
        time_range = f"{between_m.group(1)}-{between_m.group(2)}"
        conditions.append(Condition("timestamp", time_range, "time_range", False, logic))
        logic = "AND"
        remaining = between_m.group(3).strip()

    # 4. "field in val1,val2,..." multi-value membership
    in_m = re.match(r'^(\w+)\s+in\s+(.+?)(?:\s+(?:AND|OR)\s+|$)', remaining, re.I)
    if in_m:
        field = in_m.group(1)
        resolved = resolve_field_alias(field)
        if is_known_field(resolved.lower(), extra_fields):
            values_str = in_m.group(2).strip()
            # Normalise: strip quotes from individual values
            vals = ",".join(
                v.strip().strip('"').strip("'") for v in values_str.split(",")
            )
            conditions.append(Condition(resolved, vals, "in", False, logic))
            logic = "AND"
            # Remove the matched portion from remaining text
            remaining = remaining[in_m.end():].strip()
            # Strip leading AND/OR that was part of the lookahead
            remaining = re.sub(r'^(?:AND|OR)\s+', '', remaining, flags=re.I).strip()

    # 5. "field contains value" substring match
    # Use alternation to stop at AND/OR boundaries (unquoted) or consume to end.
    # Quoted values ("...") are taken as-is, unquoted values stop at connectors.
    contains_m = re.match(
        r'^(\w+)\s+contains?\s+'
        r'(?:"([^"]+)"|\'([^\']+)\'|(.+?))'  # quoted or unquoted (lazy)
        r'(?:\s+(AND|OR)\s+(.*)|$)',           # connector + rest, or end
        remaining, re.I,
    )
    if contains_m:
        field = contains_m.group(1)
        resolved = resolve_field_alias(field)
        if is_known_field(resolved.lower(), extra_fields):
            value = (contains_m.group(2) or contains_m.group(3)
                     or contains_m.group(4) or "").strip()
            conditions.append(Condition(resolved, value, "contains", False, logic))
            connector = contains_m.group(5)
            rest = (contains_m.group(6) or "").strip()
            if connector:
                logic = connector.upper()
                remaining = rest
            else:
                logic = "AND"
                remaining = ""

    # 6. "field internal" / "field external" network classification
    net_m = re.match(r'^(\w+)\s+(internal|external)\s*$', remaining, re.I)
    if net_m:
        field = net_m.group(1)
        resolved = resolve_field_alias(field)
        if is_known_field(resolved.lower(), extra_fields):
            direction = net_m.group(2).lower()
            conditions.append(Condition(resolved, "", direction, False, logic))
            logic = "AND"
            remaining = ""

    # --- Main regex parse on whatever text remains ---
    regex_found = False
    if remaining:
        # Normalize connectors to uppercase so the case-sensitive regex matches
        remaining = re.sub(r'\bnot\s+', 'NOT ', remaining, flags=re.IGNORECASE)
        remaining = re.sub(r'\bor\b', 'OR', remaining, flags=re.IGNORECASE)
        remaining = re.sub(r'\band\b', 'AND', remaining, flags=re.IGNORECASE)
        for tok in _CONDITION_RE.finditer(remaining):
            val = tok.group(0)
            if val == "AND":
                logic = "AND"
                continue
            if val == "OR":
                logic = "OR"
                continue
            regex_found = True

            negate = bool(tok.group(1))
            field = tok.group(2)
            separator = tok.group(3)
            pattern = (tok.group(4) or "").strip('"').strip("'")

            if not field:
                continue

            # Map separator to operator
            if separator == ">=":
                op = "gte"
            elif separator == "<=":
                op = "lte"
            elif separator == "!=":
                op = "eq"
                negate = not negate
            elif separator == ">":
                op = "gt"
            elif separator == "<":
                op = "lt"
            else:
                # : or = separator — check pattern for embedded operators
                op = "eq"
                # !value negation: source:!Microsoft* → negate match
                if pattern.startswith("!") and len(pattern) > 1:
                    negate = not negate
                    pattern = pattern[1:]
                if pattern.startswith(">="):
                    op = "gte"
                    pattern = pattern[2:]
                elif pattern.startswith("<="):
                    op = "lte"
                    pattern = pattern[2:]
                elif pattern.startswith(">"):
                    op = "gt"
                    pattern = pattern[1:]
                elif pattern.startswith("<"):
                    op = "lt"
                    pattern = pattern[1:]
                elif "," in pattern and "*" not in pattern and "?" not in pattern:
                    # field:val1,val2 — multi-value shorthand
                    vals = ",".join(
                        v.strip().strip('"').strip("'") for v in pattern.split(",")
                    )
                    conditions.append(Condition(field, vals, "in", negate, logic))
                    logic = "AND"
                    continue
                elif "*" in pattern or "?" in pattern:
                    op = "wildcard"

            conditions.append(Condition(field, pattern, op, negate, logic))
            logic = "AND"

    # If the main regex didn't match remaining text, try bare-field parsing
    # on it.  This handles e.g. "severity is medium" left over after a
    # contains clause consumed the first part of a compound condition.
    if remaining and not regex_found:
        extra_conds = _parse_bare_field_values(remaining, extra_fields)
        if extra_conds:
            extra_conds[0].logic = logic  # connect first to pre-existing conditions
            conditions.extend(extra_conds)  # preserve internal logic for rest
            logic = "AND"

    if not conditions:
        conditions = _parse_bare_field_values(text, extra_fields)

    # Normalize severity abbreviations in all severity conditions
    for cond in conditions:
        if resolve_field_alias(cond.field).lower() == "severity":
            if cond.op == "in":
                cond.pattern = ",".join(
                    SEV_NORMALIZE.get(v.strip().lower(), v.strip())
                    for v in cond.pattern.split(",")
                )
            else:
                cond.pattern = SEV_NORMALIZE.get(cond.pattern.lower(), cond.pattern)

    return conditions


def match_field(value: str | None, pattern: str, op: str) -> bool:
    """Test a single field value against a pattern.

    Handles ops: eq, wildcard, gt, lt, gte, lte, exists, in, contains.
    The ``internal``, ``external``, ``time_window``, and ``time_range``
    ops are handled directly in :func:`match_event` because they need
    the full event rather than a single field value.
    """
    if op == "exists":
        return value is not None and value != ""
    if value is None:
        return False
    match op:
        case "eq":
            return value.lower() == pattern.lower() or fnmatch(value.lower(), pattern.lower())
        case "wildcard":
            return fnmatch(value.lower(), pattern.lower())
        case "in":
            vals = {v.strip().lower() for v in pattern.split(",")}
            return value.lower() in vals
        case "contains":
            # Strip leading/trailing * wildcards — users carry over glob habits
            clean = pattern.strip("*").lower()
            return clean in value.lower() if clean else bool(value)
        case "gt":
            try:
                return float(value) > float(pattern)
            except (ValueError, TypeError):
                return False
        case "lt":
            try:
                return float(value) < float(pattern)
            except (ValueError, TypeError):
                return False
        case "gte":
            try:
                return float(value) >= float(pattern)
            except (ValueError, TypeError):
                return False
        case "lte":
            try:
                return float(value) <= float(pattern)
            except (ValueError, TypeError):
                return False
    return False


def _match_event_condition(event: LogEvent, cond: Condition) -> bool:
    """Evaluate a single condition against an event.

    Most ops delegate to :func:`match_field`.  Time and network ops
    need the full event so they are handled here.
    """
    if cond.op == "time_window":
        if event.timestamp is None:
            return False
        # pattern holds the number of seconds as a string.
        # We need the max timestamp from the dataset to compute a cutoff,
        # but that's expensive per-event.  Instead, the caller must set
        # ``cond.pattern`` to an ISO timestamp cutoff before calling
        # match_event.  parse_conditions stores raw seconds; the command
        # layer converts to a cutoff once.  As a fallback, if the pattern
        # is pure digits we treat it as a unix-epoch cutoff.
        #
        # To keep this fast, the where command pre-computes the cutoff and
        # replaces cond.pattern before the filter loop.  See _do_where().
        # If somehow we get raw seconds, just return True (accept all) to
        # avoid silent data loss.
        try:
            seconds = float(cond.pattern)
            if seconds > 1_000_000_000:
                # Looks like an epoch cutoff
                from datetime import datetime
                cutoff = datetime.fromtimestamp(seconds)
                return event.timestamp >= cutoff
        except (ValueError, TypeError, OSError):
            pass
        return True

    if cond.op == "time_range":
        if event.timestamp is None:
            return False
        try:
            start_str, end_str = cond.pattern.split("-")
            sh, sm = (int(x) for x in start_str.split(":"))
            eh, em = (int(x) for x in end_str.split(":"))
            return _time_in_range(event.timestamp, sh, sm, eh, em)
        except (ValueError, TypeError):
            return False

    if cond.op in ("internal", "external"):
        from logparse.network import is_internal, is_external
        field_val = get_field(event, cond.field) or ""
        check_fn = is_internal if cond.op == "internal" else is_external
        return check_fn(field_val)

    field_val = get_field(event, cond.field)
    return match_field(field_val, cond.pattern, cond.op)


def match_event(event: LogEvent, conditions: list[Condition]) -> bool:
    """Test whether an event matches all conditions.

    Boolean evaluation: AND binds tighter than OR.  Conditions are
    grouped into OR-separated AND-chains and evaluated as
    ``(A AND B) OR (C AND D) OR ...``.
    """
    if not conditions:
        return True

    # Split into OR-separated groups of AND-connected conditions.
    # Each new OR condition starts a new group.
    groups: list[list[Condition]] = [[]]
    for cond in conditions:
        if cond.logic == "OR" and groups[0]:
            groups.append([])
        groups[-1].append(cond)

    # A match occurs when ANY group has ALL conditions satisfied.
    for group in groups:
        all_match = True
        for cond in group:
            matched = _match_event_condition(event, cond)
            if cond.negate:
                matched = not matched
            if not matched:
                all_match = False
                break
        if all_match:
            return True
    return False


_NESTED_QUANTIFIER_RE = re.compile(
    r"[+*]\)?[+*?]"     # a+*, a*+, (a+)*, (a+)+, etc.
    r"|[+*]\)\{",        # (a+){2,}
)


def grep_events(
    events: list[LogEvent],
    pattern: str,
    case_sensitive: bool = False,
) -> list[LogEvent]:
    """Grep-style text search across all fields."""
    flags = 0 if case_sensitive else re.IGNORECASE

    # Guard against catastrophic backtracking (ReDoS) from nested quantifiers
    if _NESTED_QUANTIFIER_RE.search(pattern):
        pattern = re.escape(pattern)

    try:
        rx = re.compile(pattern, flags)
    except re.error:
        # Pattern is invalid regex — strip glob wildcards and retry as literal
        cleaned = re.escape(pattern.strip("*"))
        if not cleaned:
            return []
        try:
            rx = re.compile(cleaned, flags)
        except re.error:
            return []

    results: list[LogEvent] = []
    for e in events:
        searchable = [e.severity, e.source, e.message, e.raw]
        searchable.extend(e.extra.values())
        if any(rx.search(s) for s in searchable if s):
            results.append(e)
    return results


def filter_events(
    events: list[LogEvent],
    query: str,
) -> list[LogEvent] | list:
    """Filter events by query string, then apply pipeline operators.

    The query may contain ``|`` to chain pipeline operators
    (e.g. ``action:deny | count by dstport | head 10``).
    """
    from logparse.pipeline import apply_pipeline

    if not events or not query or not query.strip():
        return events

    parts = [p.strip() for p in query.split("|")]
    filter_part = parts[0]
    pipeline_ops = parts[1:] if len(parts) > 1 else []

    # strip "| show ..." from end and return field override
    show_fields: list[str] | None = None
    if pipeline_ops and pipeline_ops[-1].strip().lower().startswith("show "):
        show_fields = [
            f.strip() for f in pipeline_ops[-1].strip()[5:].split(",")
        ]
        pipeline_ops = pipeline_ops[:-1]

    # handle search verb in filter part
    if filter_part.lower().startswith("search "):
        search_text = filter_part[7:].strip()
        # strip -i flag (default is already case-insensitive)
        case_sensitive = False
        if search_text.startswith("-i "):
            search_text = search_text[3:].strip()
        # strip "once" modifier — caller handles session semantics
        search_text = re.sub(r"^once\s+", "", search_text, flags=re.I).strip()
        search_text = search_text.strip('"').strip("'")
        filtered = grep_events(events, search_text, case_sensitive)
    elif filter_part:
        conditions = parse_conditions(filter_part)
        filtered = [e for e in events if match_event(e, conditions)]
    else:
        filtered = list(events)

    # apply pipeline operators
    if pipeline_ops:
        result = apply_pipeline(filtered, pipeline_ops)
        if show_fields is not None:
            return result, show_fields
        return result

    if show_fields is not None:
        return filtered, show_fields
    return filtered
