#!/usr/bin/env python3
"""Entry point for ``python -m logparse``."""

from __future__ import annotations

from logparse.cli import main

main()
