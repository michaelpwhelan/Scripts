#!/usr/bin/env python3
"""CLI output rendering helpers — JSON, CSV, raw, stats, and HTML export."""

from __future__ import annotations

import json
import sys

from rich.console import Console

from logparse.models import LogEvent
from logparse.severity import SEVERITY_LEVELS
from logparse.util import format_number


def render_stats(stats: dict, console: Console) -> None:
    """Render parse statistics to console."""
    console.rule("Parse Summary", style="bold")
    console.print(f"  Total      : {format_number(stats['total'])} events")
    min_ts, max_ts = stats["time_range"]
    if min_ts:
        console.print(
            f"  Time Range : {min_ts:%Y-%m-%d %H:%M:%S}"
            f" \u2192 {max_ts:%Y-%m-%d %H:%M:%S}"
        )

    console.print()
    console.rule("Severity", style="bold")
    sev_colors = {
        "Critical": "bold red", "High": "red", "Medium": "yellow",
        "Low": "cyan", "Info": "dim",
    }
    total = max(stats["total"], 1)
    for sev in SEVERITY_LEVELS:
        count = stats["severity"].get(sev, 0)
        pct = count / total * 100
        bar_width = int(count / max(stats["severity"].values() or [1]) * 40)
        bar = "\u2588" * bar_width
        style = sev_colors.get(sev, "")
        console.print(
            f"  [{style}]{sev.upper():<10}[/{style}]"
            f" [cyan]{bar}[/cyan]  {format_number(count)}  ({pct:.1f}%)"
        )

    for label, data in [
        ("Top Source IPs", stats["top_src_ips"]),
        ("Top Sources", stats["top_sources"]),
    ]:
        if not data:
            continue
        console.print()
        console.rule(label, style="bold")
        max_val = data[0][1] if data else 1
        for name, count in data[:5]:
            bar_width = int(count / max_val * 40)
            bar = "\u2588" * bar_width
            console.print(f"  {name:<20} [cyan]{bar}[/cyan]  {format_number(count)}")


def render_json(events: list[LogEvent], max_results: int,
                file=None) -> None:
    display = events[:max_results] if max_results > 0 else events
    out = file or sys.stdout
    objects = []
    for e in display:
        obj = {
            "timestamp": e.timestamp.isoformat() if e.timestamp else None,
            "severity": e.severity,
            "source": e.source,
            "message": e.message,
        }
        obj.update(e.extra)
        objects.append(obj)
    print(json.dumps(objects, ensure_ascii=False, indent=2), file=out)


def render_csv(events: list[LogEvent], max_results: int,
               file=None) -> None:
    import csv as _csv
    display = events[:max_results] if max_results > 0 else events
    out = file or sys.stdout
    # discover extra keys
    all_keys: set[str] = set()
    for e in display:
        all_keys.update(e.extra.keys())
    sorted_keys = sorted(all_keys)
    headers = ["Timestamp", "Severity", "Source", "Message"] + sorted_keys
    writer = _csv.writer(out)
    writer.writerow(headers)
    for e in display:
        ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else ""
        row = [ts, e.severity, e.source, e.message.replace("\n", " ")]
        for k in sorted_keys:
            row.append(e.extra.get(k, ""))
        writer.writerow(row)


def render_raw(events: list[LogEvent], max_results: int) -> None:
    display = events[:max_results] if max_results > 0 else events
    for e in display:
        parts = []
        if e.timestamp:
            parts.append(e.timestamp.strftime("%Y-%m-%d %H:%M:%S"))
        parts.extend([e.severity, e.source, e.message])
        print("  ".join(parts))


def export_html(events: list[LogEvent], path: str) -> None:
    """Write a basic self-contained HTML report."""
    from logparse.output.html import render_html_report
    render_html_report(events, path)
