#!/usr/bin/env python3
"""JSON-declarative correlation rules engine.

Rules are loaded from ``~/.logparse/rules/*.json``.  Each rule defines
multi-stage conditions that link events by shared field values within
time windows.
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from datetime import datetime
from fnmatch import fnmatch
from pathlib import Path

from logparse.models import SEV_ORDER, LogEvent, get_field, timestamp_range
from logparse.util import parse_duration

log = logging.getLogger(__name__)


# -- data structures ---------------------------------------------------------


@dataclass(frozen=True)
class RuleCondition:
    """One stage in a multi-stage correlation rule."""

    stage: int
    label: str
    field: str
    operator: str  # eq, in, contains, regex
    values: tuple[str, ...]
    min_count: int = 1
    group_by: str = ""
    link_field: str = ""
    within: str = ""  # duration string, e.g. "1h"


@dataclass(frozen=True)
class CorrelationRule:
    """A complete multi-stage correlation rule."""

    rule_id: str
    name: str
    description: str
    severity: str
    mitre_techniques: tuple[str, ...]
    conditions: tuple[RuleCondition, ...]
    alert_message: str = ""


@dataclass
class RuleMatch:
    """Result of a rule matching against events."""

    rule: CorrelationRule
    linked_value: str
    stage_events: dict[int, list[LogEvent]] = field(default_factory=dict)
    total_events: int = 0
    first_seen: datetime | None = None
    last_seen: datetime | None = None


# -- rule loading ------------------------------------------------------------


def _parse_condition(raw: dict) -> RuleCondition:
    match = raw.get("match", {})
    return RuleCondition(
        stage=raw.get("stage", 1),
        label=raw.get("label", ""),
        field=match.get("field", ""),
        operator=match.get("operator", "eq"),
        values=tuple(match.get("values", [])),
        min_count=raw.get("min_count", 1),
        group_by=raw.get("group_by", ""),
        link_field=raw.get("link_field", ""),
        within=raw.get("within", ""),
    )


def _parse_rule(data: dict) -> CorrelationRule:
    conditions = tuple(
        _parse_condition(c) for c in data.get("conditions", [])
    )
    return CorrelationRule(
        rule_id=data.get("rule_id", ""),
        name=data.get("name", ""),
        description=data.get("description", ""),
        severity=data.get("severity", "Medium"),
        mitre_techniques=tuple(data.get("mitre_techniques", [])),
        conditions=conditions,
        alert_message=data.get("alert_message", ""),
    )


def load_rules(rules_dir: Path) -> list[CorrelationRule]:
    """Load all ``*.json`` rule files from a directory."""
    rules: list[CorrelationRule] = []
    if not rules_dir.is_dir():
        return rules
    for path in sorted(rules_dir.glob("*.json")):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            rules.append(_parse_rule(data))
            log.debug("Loaded rule %s from %s", data.get("rule_id"), path.name)
        except (json.JSONDecodeError, KeyError, TypeError) as exc:
            log.warning("Skipping malformed rule file %s: %s", path.name, exc)
    return rules


# -- condition matching ------------------------------------------------------


def _matches_condition(event: LogEvent, cond: RuleCondition) -> bool:
    """Check if a single event matches a rule condition."""
    val = get_field(event, cond.field) or ""
    val_lower = val.lower()
    op = cond.operator.lower()

    if op == "eq":
        return any(v.lower() == val_lower for v in cond.values)
    if op == "in":
        return any(v.lower() == val_lower for v in cond.values)
    if op == "contains":
        return any(v.lower() in val_lower for v in cond.values)
    if op == "regex":
        return any(re.search(v, val, re.IGNORECASE) for v in cond.values)
    if op == "wildcard":
        return any(fnmatch(val_lower, v.lower()) for v in cond.values)
    return False


# -- multi-stage evaluation --------------------------------------------------


def evaluate_rule(
    rule: CorrelationRule, events: list[LogEvent]
) -> list[RuleMatch]:
    """Evaluate a multi-stage correlation rule against events.

    Stage 1 events are grouped by ``group_by`` field and filtered by
    ``min_count``.  Subsequent stages link to previous stage groups
    via ``link_field`` within the ``within`` time window.
    """
    if not rule.conditions:
        return []

    sorted_conditions = sorted(rule.conditions, key=lambda c: c.stage)
    stages = {}
    for cond in sorted_conditions:
        stages.setdefault(cond.stage, []).append(cond)

    stage_numbers = sorted(stages)
    if not stage_numbers:
        return []

    # Stage 1: filter, group, count
    first_stage = stages[stage_numbers[0]]
    cond1 = first_stage[0]
    stage1_hits: list[LogEvent] = [
        e for e in events if _matches_condition(e, cond1)
    ]

    # Group by field
    groups: dict[str, list[LogEvent]] = {}
    group_field = cond1.group_by or cond1.field
    for e in stage1_hits:
        key = (get_field(e, group_field) or "").lower()
        if key:
            groups.setdefault(key, []).append(e)

    # Apply min_count
    groups = {k: v for k, v in groups.items() if len(v) >= cond1.min_count}

    if not groups:
        return []

    # Single-stage rules: return matches
    if len(stage_numbers) == 1:
        matches = []
        for linked_val, evts in groups.items():
            m = RuleMatch(
                rule=rule,
                linked_value=linked_val,
                stage_events={stage_numbers[0]: evts},
                total_events=len(evts),
            )
            m.first_seen, m.last_seen = timestamp_range(evts)
            matches.append(m)
        return matches

    # Multi-stage: link subsequent stages
    matches: list[RuleMatch] = []
    for linked_val, stage1_evts in groups.items():
        stage_events: dict[int, list[LogEvent]] = {stage_numbers[0]: stage1_evts}
        all_matched = True

        for stage_num in stage_numbers[1:]:
            stage_conds = stages[stage_num]
            cond = stage_conds[0]
            link_field = cond.link_field or group_field
            window = parse_duration(cond.within) if cond.within else None

            # Time bounds from previous stage events
            prev_evts = []
            for sevts in stage_events.values():
                prev_evts.extend(sevts)
            ts_bounds = [
                e.timestamp for e in prev_evts if e.timestamp is not None
            ]

            stage_hits: list[LogEvent] = []
            for e in events:
                # Must match condition
                if not _matches_condition(e, cond):
                    continue
                # Must link to the same entity
                link_val = (get_field(e, link_field) or "").lower()
                if link_val != linked_val:
                    continue
                # Must be within time window (if specified)
                if window and e.timestamp and ts_bounds:
                    earliest = min(ts_bounds)
                    latest = max(ts_bounds)
                    if e.timestamp < earliest - window or e.timestamp > latest + window:
                        continue
                stage_hits.append(e)

            if len(stage_hits) < cond.min_count:
                all_matched = False
                break
            stage_events[stage_num] = stage_hits

        if all_matched:
            total = sum(len(v) for v in stage_events.values())
            m = RuleMatch(
                rule=rule,
                linked_value=linked_val,
                stage_events=stage_events,
                total_events=total,
            )
            all_evts = [e for evts in stage_events.values() for e in evts]
            m.first_seen, m.last_seen = timestamp_range(all_evts)
            matches.append(m)

    return matches


def evaluate_all_rules(
    rules: list[CorrelationRule], events: list[LogEvent]
) -> list[RuleMatch]:
    """Evaluate all rules, return matches sorted by severity then count."""
    all_matches: list[RuleMatch] = []
    for rule in rules:
        all_matches.extend(evaluate_rule(rule, events))
    return sorted(
        all_matches,
        key=lambda m: (SEV_ORDER.get(m.rule.severity, 9), -m.total_events),
    )
