#!/usr/bin/env python3
"""Fuzzy command resolution engine.

Sits between raw user input and the command parser.  When input doesn't
parse cleanly, this engine finds the closest valid interpretation and
returns it for read-only execution.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from logparse.session import Session

# ---------------------------------------------------------------------------
# Public data
# ---------------------------------------------------------------------------

@dataclass
class Resolution:
    """Result of a successful resolution attempt."""

    original: str
    resolved: str
    confidence: float
    description: str


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

FILE_EXTENSIONS: tuple[str, ...] = (
    ".log", ".evtx", ".xml", ".conf", ".zip", ".csv", ".json", ".jsonl",
)

_STRIP_WORDS: set[str] = {"the", "all", "with"}
# 'from', 'in', 'for' need context-sensitive handling — see _strip_non_keywords

_DESTRUCTIVE_VERBS: set[str] = {"reset", "unset", "unhide", "unstar"}

class _ResolverState:
    """Lazily-initialized caches for the resolver module."""

    _CACHE_MAX = 512

    def __init__(self) -> None:
        self._command_verbs: set[str] | None = None
        self._cache: dict[str, Resolution] = {}

    @property
    def command_verbs(self) -> set[str]:
        if self._command_verbs is None:
            from logparse.commands import get_registry
            self._command_verbs = {cmd.name.lower() for cmd in get_registry()}
        return self._command_verbs

    def cache_get(self, key: str) -> Resolution | None:
        return self._cache.get(key)

    def cache_put(self, key: str, value: Resolution) -> None:
        if len(self._cache) >= self._CACHE_MAX:
            keys = list(self._cache)[:self._CACHE_MAX // 4]
            for k in keys:
                del self._cache[k]
        self._cache[key] = value

    def clear_cache(self) -> None:
        self._cache.clear()


_state = _ResolverState()


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_command_verbs() -> set[str]:
    """Return the set of registered command verb names."""
    return _state.command_verbs


def _looks_like_filename(token: str, session: Session) -> bool:
    """Does *token* look like a filename (by extension or loaded source)?"""
    lower = token.lower()
    if any(lower.endswith(ext) for ext in FILE_EXTENSIONS):
        return True
    # match against basenames of loaded sources
    for src in session.source_files:
        if os.path.basename(src).lower() == lower:
            return True
    return False


def _is_known_field(token: str, session: Session) -> bool:
    from logparse.filter_engine import is_known_field
    return is_known_field(token.lower(), session=session)


def _tokenize_respecting_quotes(text: str) -> list[str]:
    """Split text on whitespace, keeping quoted segments intact."""
    tokens: list[str] = []
    current: list[str] = []
    in_quote: str | None = None
    for ch in text:
        if ch in ('"', "'") and in_quote is None:
            in_quote = ch
            current.append(ch)
        elif ch == in_quote:
            in_quote = None
            current.append(ch)
        elif ch.isspace() and in_quote is None:
            if current:
                tokens.append("".join(current))
                current = []
        else:
            current.append(ch)
    if current:
        tokens.append("".join(current))
    return tokens


def _is_inside_quotes(text: str, pos: int) -> bool:
    """Check if position *pos* in *text* is inside a quoted string."""
    in_quote: str | None = None
    for i, ch in enumerate(text):
        if i == pos:
            return in_quote is not None
        if ch in ('"', "'") and in_quote is None:
            in_quote = ch
        elif ch == in_quote:
            in_quote = None
    return False


# ---------------------------------------------------------------------------
# Layer 1 transforms
# ---------------------------------------------------------------------------

def _strip_non_keywords(text: str, session: Session) -> str:
    """Remove natural-English filler words that aren't part of the grammar."""
    tokens = _tokenize_respecting_quotes(text)
    if len(tokens) < 2:
        return text

    verbs = _get_command_verbs()
    result: list[str] = []

    i = 0
    while i < len(tokens):
        tok_lower = tokens[i].lower()

        # never strip inside quotes
        if tokens[i].startswith('"') or tokens[i].startswith("'"):
            result.append(tokens[i])
            i += 1
            continue

        # 'from': strip when between a command/filter and a filename-like token
        if tok_lower == "from" and i > 0 and i + 1 < len(tokens):
            if _looks_like_filename(tokens[i + 1], session):
                i += 1
                continue

        # 'in': strip only when between a verb and a filename-like token
        if tok_lower == "in" and i > 0 and i + 1 < len(tokens):
            _prev_lower = tokens[i - 1].lower() if result else ""
            # don't strip 'in' when it's the set-membership operator
            # (field in $list) — only strip between verb and filename
            if (result and result[0].lower() in verbs
                    and _looks_like_filename(tokens[i + 1], session)):
                i += 1
                continue

        # 'for': strip only before time expressions (last, a digit+unit)
        if tok_lower == "for" and i + 1 < len(tokens):
            next_lower = tokens[i + 1].lower()
            if next_lower == "last" or re.match(r"^\d+\s*(hr|min|sec|day|d|h|m|s)$", next_lower):
                i += 1
                continue

        # generic strip words (the, all, with)
        if tok_lower in _STRIP_WORDS and i > 0:
            i += 1
            continue

        result.append(tokens[i])
        i += 1

    return " ".join(result)


def _rewrite_separators(text: str, session: Session) -> str:
    """Normalise filter separators to field:value syntax."""
    # == → :
    text = re.sub(r"(\w+)\s*==\s*", r"\1:", text)

    # != → !field:
    text = re.sub(r"(\w+)\s*!=\s*", r"!\1:", text)

    # 'is' between field and value  (field is value → field:value)
    def _rewrite_is(m: re.Match) -> str:
        field_name = m.group(1)
        value = m.group(2)
        if _is_known_field(field_name, session):
            return f"{field_name}:{value}"
        return m.group(0)
    text = re.sub(r"\b(\w+)\s+is\s+(\S+)", _rewrite_is, text, flags=re.I)

    # 'not' between field and value  (field not value → !field:value)
    def _rewrite_not(m: re.Match) -> str:
        field_name = m.group(1)
        value = m.group(2)
        if _is_known_field(field_name, session):
            return f"!{field_name}:{value}"
        return m.group(0)
    text = re.sub(r"\b(\w+)\s+not\s+(\S+)", _rewrite_not, text, flags=re.I)

    # bare 'where field value' (no separator) — insert :
    # match 'where <word> <word>' where <word1> is a known field and no : between
    def _insert_colon(m: re.Match) -> str:
        prefix = m.group(1)  # 'where' or '| where'
        field_name = m.group(2)
        value = m.group(3)
        if _is_known_field(field_name, session):
            return f"{prefix} {field_name}:{value}"
        return m.group(0)
    text = re.sub(
        r"((?:^|\|)\s*where)\s+(\w+)\s+(?!:)(\S+)",
        _insert_colon, text, flags=re.I,
    )

    return text


def _rewrite_operators(text: str, session: Session) -> str:
    """Rewrite boolean operators to logparse pipe syntax."""
    # 'not where' → 'where !'
    text = re.sub(r"\bnot\s+where\s+", "where !", text, flags=re.I)

    # 'and' between filter expressions → pipe + where
    # match: <condition> and <condition>
    text = re.sub(
        r"(\S+:\S+)\s+and\s+",
        r"\1 | where ",
        text, flags=re.I,
    )

    # 'or' between filter expressions — rewrite to logparse OR syntax
    # field:val or field:val → field:val OR field:val (preserve both sides)
    text = re.sub(
        r"(\S+:\S+)\s+or\s+(?=\S+:\S+)",
        r"\1 OR ",
        text, flags=re.I,
    )

    return text


def _insert_implicit_pipes(text: str, session: Session) -> str:
    """Insert | between adjacent command verbs missing a pipe.

    Commands like ``set time last 1hr`` use verb-like arguments (``last``
    is both a registered command and an argument to ``set``).  To avoid
    splitting those, suppress pipe insertion while inside the argument
    span of ``set`` (up to the first explicit ``|``).
    """
    tokens = _tokenize_respecting_quotes(text)
    if len(tokens) < 2:
        return text

    verbs = _get_command_verbs()
    result: list[str] = [tokens[0]]
    prev_was_pipe = (tokens[0] == "|")
    # Suppress pipe insertion inside 'set' arguments until first explicit pipe
    _COMPOUND_CMDS = {"set", "switch"}
    in_compound = tokens[0].lower() in _COMPOUND_CMDS

    for i in range(1, len(tokens)):
        tok_lower = tokens[i].lower()
        if tokens[i] == "|":
            prev_was_pipe = True
            in_compound = False
            result.append(tokens[i])
            continue

        if not in_compound and tok_lower in verbs and not prev_was_pipe:
            result.append("|")

        result.append(tokens[i])
        prev_was_pipe = (tokens[i] == "|")

    return " ".join(result)


def _filename_as_select(text: str, session: Session) -> str:
    """Wrap bare filename tokens in 'select <file>' at pipeline head."""
    tokens = _tokenize_respecting_quotes(text)
    if not tokens:
        return text

    verbs = _get_command_verbs()

    # Case 1: first token is a filename (not a verb)
    if (tokens[0].lower() not in verbs
            and _looks_like_filename(tokens[0], session)):
        rest = " ".join(tokens[1:])
        return f"select {tokens[0]} | {rest}" if rest else f"select {tokens[0]}"

    # Case 2: 'from <filename>' was already stripped but left the filename
    # in a non-verb position after another transform — scan for stranded filenames
    # Skip entirely when the first token is a command that takes file args
    first_lower = tokens[0].lower() if tokens else ""
    _FILE_ARG_CMDS = {"select", "add", "diff", "compare", "resume"}
    if first_lower in _FILE_ARG_CMDS:
        return text

    new_tokens: list[str] = []
    filename_pulled: str | None = None
    for i, tok in enumerate(tokens):
        if (tok.lower() not in verbs
                and _looks_like_filename(tok, session)
                and i > 0):
            filename_pulled = tok
        else:
            new_tokens.append(tok)

    if filename_pulled:
        rest = " ".join(new_tokens)
        return f"select {filename_pulled} | {rest}" if rest else f"select {filename_pulled}"

    return text


def _bare_value_as_where(text: str, session: Session) -> str:
    """Wrap a bare token that matches a known field value in 'where field:value'."""
    tokens = _tokenize_respecting_quotes(text)
    # only applies when the entire input is a single bare word
    if len(tokens) != 1 or tokens[0].startswith('"') or tokens[0].startswith("'"):
        return text

    tok = tokens[0]
    tok_lower = tok.lower()

    # severity keywords are unambiguous
    if tok_lower in ("critical", "high", "medium", "low", "info"):
        return f"where severity:{tok}"

    # bare field name → count by field (common shorthand)
    if _is_known_field(tok, session):
        return f"count by {tok}"

    # check value index for a unique field match
    idx = session.build_value_index()
    matched_fields = [f for f, vals in idx.items() if tok_lower in vals]
    if len(matched_fields) == 1:
        return f"where {matched_fields[0]}:{tok}"

    return text


def _bare_quoted_string_as_search(text: str, session: Session) -> str:
    """Wrap a bare quoted string in 'search ...'."""
    stripped = text.strip()

    # "..." or '...'
    if re.match(r'^["\'].*["\']$', stripped):
        return f"search {stripped}"

    # -i "..." (case-insensitive flag before quoted string)
    if re.match(r'^-i\s+["\'].*["\']$', stripped):
        return f"search {stripped}"

    return text


# ---------------------------------------------------------------------------
# Layer 2: intent mapping
# ---------------------------------------------------------------------------

def _intent_verbless_filter_chain(text: str, session: Session) -> Resolution | None:
    """Input is all field:value pairs → where chain."""
    tokens = _tokenize_respecting_quotes(text)
    if not tokens:
        return None

    conditions: list[str] = []
    for tok in tokens:
        if re.match(r"^!?\w+:\S+$", tok):
            conditions.append(tok)
        else:
            return None  # non-condition token → bail

    if not conditions:
        return None

    pipeline = " | ".join(f"where {c}" for c in conditions)
    return Resolution(
        original=text,
        resolved=pipeline,
        confidence=0.85,
        description="verb-less filter chain",
    )


def _intent_sql_ish_select(text: str, session: Session) -> Resolution | None:
    """show/select <fields> from <source> where <filter>."""
    m = re.match(
        r"^(?:show|select)\s+(.+?)\s+from\s+(\S+)(?:\s+where\s+(.+))?$",
        text, re.I,
    )
    if not m:
        return None

    fields = m.group(1).strip()
    source = m.group(2).strip()
    filter_part = m.group(3)

    if not _looks_like_filename(source, session):
        return None

    parts = [f"select {source}"]
    if filter_part:
        parts.append(f"where {filter_part}")
    if fields != "*":
        parts.append(f"show {fields}")
    else:
        parts.append("show *")

    resolved = " | ".join(parts)
    return Resolution(
        original=text,
        resolved=resolved,
        confidence=0.9,
        description="SQL-style query reordered to pipeline",
    )


def _intent_bare_comparison(text: str, session: Session) -> Resolution | None:
    """compare/diff <file1> <file2>."""
    m = re.match(r"^compare\s+(\S+)\s+(\S+)$", text, re.I)
    if not m:
        return None
    return Resolution(
        original=text,
        resolved=f"diff {m.group(1)} {m.group(2)}",
        confidence=0.95,
        description="compare → diff",
    )


def _intent_time_scoped(text: str, session: Session) -> Resolution | None:
    """'last <N><unit>' + filter → set time + filter."""
    m = re.match(r"^last\s+(\d+\s*\w+)\s+(.+)$", text, re.I)
    if not m:
        return None
    time_expr = m.group(1).strip()
    rest = m.group(2).strip()
    return Resolution(
        original=text,
        resolved=f"set time last {time_expr} | {rest}",
        confidence=0.8,
        description="time-scoped query",
    )


_INTENT_PATTERNS = [
    _intent_sql_ish_select,
    _intent_verbless_filter_chain,
    _intent_bare_comparison,
    _intent_time_scoped,
]

# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def resolve(raw: str, session: Session) -> Resolution | None:
    """Attempt to resolve unparseable input into a valid command.

    Returns *None* if resolution fails or confidence is too low.
    """
    if not raw or not raw.strip():
        return None

    # cache hit
    cached = _state.cache_get(raw)
    if cached is not None:
        return cached

    from logparse.commands import can_dispatch

    # --- Layer 1: compose syntax fixes, then test if result dispatches ---
    fixed = raw
    transforms = [
        _bare_quoted_string_as_search,
        _bare_value_as_where,
        _strip_non_keywords,
        _rewrite_separators,
        _rewrite_operators,
        _insert_implicit_pipes,
        _filename_as_select,
    ]

    for fn in transforms:
        fixed = fn(fixed, session)

    # did transforms change anything?
    if fixed != raw and can_dispatch(fixed):
        # safety gate
        parts = fixed.split()
        verb = parts[0].lower() if parts else ""
        if verb in _DESTRUCTIVE_VERBS:
            return None
        desc = "syntax corrected"
        res = Resolution(original=raw, resolved=fixed, confidence=0.95, description=desc)
        _state.cache_put(raw, res)
        return res

    # also try against parse_conditions (the filter-engine fallback)
    if fixed != raw:
        from logparse.filter_engine import parse_conditions
        extra = session.field_names_lower()
        if parse_conditions(fixed, extra_fields=extra):
            parts = fixed.split()
            verb = parts[0].lower() if parts else ""
            if verb in _DESTRUCTIVE_VERBS:
                return None
            desc = "interpreted as filter"
            res = Resolution(original=raw, resolved=f"where {fixed}" if not fixed.lower().startswith("where") else fixed,
                             confidence=0.9, description=desc)
            _state.cache_put(raw, res)
            return res

    # --- Layer 2: intent mapping ---
    for pattern_fn in _INTENT_PATTERNS:
        result = pattern_fn(raw, session)
        if result is not None:
            # safety gate
            parts = result.resolved.split()
            verb = parts[0].lower() if parts else ""
            if verb in _DESTRUCTIVE_VERBS:
                continue
            if result.confidence >= 0.5:
                _state.cache_put(raw, result)
                return result

    return None


def clear_cache() -> None:
    """Reset the resolution cache (e.g. on session reset)."""
    _state.clear_cache()
