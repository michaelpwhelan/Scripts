#!/usr/bin/env python3
"""Shared command execution logic used by both the REPL and web GUI."""

from __future__ import annotations

import json
import logging
import re
from datetime import datetime as _dt
from pathlib import Path
from typing import Any

from logparse.commands import dispatch, dispatch_readonly, CommandContext
from logparse.filter_engine import parse_conditions, match_event
from logparse.session import Session
from logparse.syntax import parse_command, split_commands, expand_variables
from logparse.util import format_number

_log = logging.getLogger(__name__)


def preprocess_input(raw: str, session: Session, console: Any) -> str | None:
    """Handle history recall, bare variables, and variable expansion.

    Returns the preprocessed command string, or *None* if the input was
    fully consumed (e.g. a bare ``$var`` print).
    """
    # history recall: !! and !N
    if raw == "!!":
        if session._last_resolved:
            raw = session._last_resolved
            session._last_resolved = None
            console.print(f"[dim]{raw}[/dim]")
        elif session.transcript:
            raw = session.transcript[-1].command
            console.print(f"[dim]{raw}[/dim]")
        else:
            console.print("[dim]No previous command.[/dim]")
            return None
    elif raw.startswith("!") and raw[1:].isdigit():
        idx = int(raw[1:]) - 1
        if 0 <= idx < len(session.transcript):
            raw = session.transcript[idx].command
            console.print(f"[dim]{raw}[/dim]")
        else:
            console.print("[dim]Invalid history index.[/dim]")
            return None

    # bare $var — print variable value or report undefined
    bare_var = re.match(r"^\$(\w+)$", raw)
    if bare_var:
        var_name = bare_var.group(1)
        if var_name in session.variables:
            val = session.variables[var_name]
            if isinstance(val, list):
                console.print(", ".join(val))
            else:
                console.print(val)
        else:
            console.print(f"[yellow]Undefined variable: ${var_name}[/yellow]")
            if session.variables:
                defined = ", ".join(f"${k}" for k in sorted(session.variables))
                console.print(f"[dim]Defined: {defined}[/dim]")
        return None

    # variable expansion
    if session.variables and not re.match(
        r"^\$\w+\s+(properties|[+-]=)", raw
    ):
        raw = expand_variables(raw, session.variables)
        unresolved = getattr(raw, "unresolved_vars", [])
        if unresolved:
            names = ", ".join(f"${n}" for n in unresolved)
            console.print(f"[yellow]Warning: undefined variable(s): {names}[/yellow]")

    return raw


def execute_command(
    session: Session, cmd_text: str, ctx: CommandContext,
) -> str:
    """Execute a single command through the full dispatch cascade.

    Returns the outcome string: ``"ok"``, ``"recovered"``, ``"resolved"``,
    ``"suggested"``, ``"auto_where"``, or ``"failed"``.

    Raises ``SystemExit`` if the user typed quit/stop.
    """
    # context help
    if cmd_text.rstrip().endswith("?"):
        from logparse.commands.meta import context_help
        context_help(cmd_text, session, ctx)
        return "ok"

    # pipe-to-variable: capture `> $varname` at end of command
    var_capture = re.search(r'\s*>\s*\$(\w+)\s*$', cmd_text)
    var_name = None
    if var_capture:
        var_name = var_capture.group(1)
        cmd_text = cmd_text[:var_capture.start()].strip()

    ctx.raw_input = cmd_text
    parsed = parse_command(cmd_text)
    console = ctx.console
    outcome = "failed"

    try:
        handled = dispatch(session, parsed, ctx)

        if var_capture and handled:
            from logparse.pipeline import AggResult
            if (session.last_output and len(session.last_output) > 0
                    and isinstance(session.last_output[0], AggResult)):
                session.variables[var_name] = [r.key for r in session.last_output]
                console.print(f"[dim]${var_name} = {len(session.last_output)} values[/dim]")
            elif session.filtered_events:
                session.variables[var_name] = str(len(session.filtered_events))
                console.print(f"[dim]${var_name} = {session.variables[var_name]}[/dim]")

        if handled:
            session._last_resolved = None
            pw = session._pipeline_warnings
            session._pipeline_warnings = []
            log_usage(session, cmd_text, "ok", warnings=pw or None)
            outcome = "ok"
        else:
            outcome = _recovery_cascade(session, cmd_text, parsed, ctx)

    except SystemExit:
        raise
    except Exception as exc:
        _log.debug("Command error: %s", exc, exc_info=True)
        console.print(f"[red]Error: {exc}[/red]")
        outcome = "failed"

    # contextual hints
    from logparse.config_loader import HINTS
    if (session.config.get("show_hints")
            and not session.config.get("tutorial_completed")):
        verb = parsed.verb.lower() if parsed.verb else ""
        hint = HINTS.get(verb)
        if hint and verb not in session._shown_hints:
            session._shown_hints.add(verb)
            console.print(f"[dim italic]{hint}[/dim italic]")

    # track last output for N.field references
    from logparse.pipeline import AggResult
    if not session.last_output or not isinstance(session.last_output[0], AggResult):
        session.last_output = list(session.filtered_events)

    return outcome


def _recovery_cascade(
    session: Session, cmd_text: str, parsed: Any, ctx: CommandContext,
) -> str:
    """Try recovery layers when dispatch returns False."""
    console = ctx.console

    # Recovery layer 0: contextual recovery advisor
    from logparse.recovery import suggest_on_failure, learn_correction
    recovery = suggest_on_failure(cmd_text, session)
    if recovery:
        console.print(f"[dim]-> {recovery}[/dim]")
        recovery_parsed = parse_command(recovery)
        if dispatch(session, recovery_parsed, ctx):
            session._last_resolved = recovery
            log_usage(session, cmd_text, "recovered", recovery)
            console.print(
                f"[dim]-> !! to repeat · "
                f"'{recovery}' will auto-apply next time[/dim]"
            )
            learn_correction(session, cmd_text, recovery)
            return "recovered"

    # Fallback 1: treat as where query
    extra = {f.lower() for f in session.all_field_names()}
    conditions = parse_conditions(cmd_text, extra_fields=extra)
    if conditions:
        console.print(f"[dim]-> where {cmd_text}[/dim]")
        session.push_filter(cmd_text)
        session.filtered_events = [
            e for e in session.filtered_events
            if match_event(e, conditions)
        ]
        count = len(session.filtered_events)
        console.print(
            f"[bold]{format_number(count)} events[/bold] "
            f"(filter: {cmd_text})"
        )
        session.log_command(cmd_text, f"{count} events")
        log_usage(session, cmd_text, "auto_where")
        return "auto_where"

    # Fallback 2: resolver (fuzzy resolution)
    from logparse.resolver import resolve
    resolution = resolve(cmd_text, session)
    if resolution and resolution.confidence >= 0.7:
        console.print(
            f"[dim]-> interpreted as: {resolution.resolved}[/dim]"
        )
        if resolution.confidence < 0.85:
            console.print(
                "[dim]   (lower confidence -- verify "
                "this is what you meant)[/dim]"
            )
        console.print(
            "[dim]-> read-only mode -- state unchanged[/dim]"
        )
        dispatch_readonly(session, resolution.resolved, ctx)
        session._last_resolved = resolution.resolved
        session.log_command(
            resolution.resolved,
            f"resolved from: {cmd_text}",
        )
        console.print("[dim]-> !! to commit[/dim]")
        log_usage(session, cmd_text, "resolved", resolution.resolved)
        return "resolved"
    elif resolution and resolution.confidence >= 0.5:
        console.print(
            f"[yellow]Did you mean: "
            f"{resolution.resolved}?[/yellow]"
        )
        log_usage(session, cmd_text, "suggested", resolution.resolved)
        return "suggested"
    else:
        console.print(
            f"[red]Unknown command: {cmd_text}[/red]"
        )
        log_usage(session, cmd_text, "failed")
        return "failed"


def execute_input(session: Session, raw: str, ctx: CommandContext) -> list[str]:
    """Process a full input line: preprocess, split, and execute each command.

    Returns a list of outcome strings, one per sub-command.
    """
    raw = raw.strip()
    if not raw or raw.startswith("#"):
        return []

    preprocessed = preprocess_input(raw, session, ctx.console)
    if preprocessed is None:
        return []

    outcomes: list[str] = []
    for cmd_text in split_commands(preprocessed):
        outcome = execute_command(session, cmd_text, ctx)
        outcomes.append(outcome)
    return outcomes


def log_usage(
    session: Session, cmd: str, outcome: str, resolved: str = "",
    warnings: list[str] | None = None,
) -> None:
    """Append to the usage log at ~/.config/logparse/usage.jsonl."""
    try:
        log_dir = Path.home() / ".config" / "logparse"
        log_dir.mkdir(parents=True, exist_ok=True)
        log_path = log_dir / "usage.jsonl"
        entry = {
            "ts": _dt.now().isoformat(timespec="seconds"),
            "input": cmd,
            "outcome": outcome,
            "resolved": resolved,
            "events": len(session.filtered_events),
        }
        if warnings:
            entry["warnings"] = warnings
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except OSError:
        pass


def get_completions(partial: str, session: Session) -> list[str]:
    """Return tab-completion candidates for a partial input string."""
    from logparse.commands import get_registry

    commands = [cmd.name for cmd in get_registry()]
    keywords = [
        "sources", "fields", "skip", "timeline", "filter", "history",
        "star", "starred", "export",
    ]

    parts = partial.split()
    if len(parts) <= 1:
        prefix = partial.lower()
        return [c for c in commands if c.startswith(prefix)]

    verb = parts[0].lower()
    text = parts[-1].lower()
    if verb == "show":
        return [k for k in keywords if k.startswith(text)]
    elif verb in ("where", "search", "count", "sort", "select"):
        fields = session.all_field_names()
        return [f for f in fields if f.lower().startswith(text)]
    return []
