#!/usr/bin/env python3
"""Parsed dataset caching (JSON-based)."""

from __future__ import annotations

import hashlib
import json
import logging
from datetime import datetime
from pathlib import Path

from logparse.config_loader import get_cache_dir
from logparse.models import LogEvent

log = logging.getLogger(__name__)

_CACHE_DIR = get_cache_dir() / "parsed"


def _cache_key(filepath: Path) -> str:
    """Deterministic cache key from (path, mtime, size)."""
    try:
        stat = filepath.stat()
        raw = f"{filepath.resolve()}:{stat.st_mtime}:{stat.st_size}"
        return hashlib.sha256(raw.encode()).hexdigest()[:16]
    except OSError:
        return ""


def _event_to_dict(e: LogEvent) -> dict:
    return {
        "timestamp": e.timestamp.isoformat() if e.timestamp else None,
        "severity": e.severity,
        "source": e.source,
        "message": e.message,
        "extra": e.extra,
        "raw": e.raw,
        "source_file": e.source_file,
        "source_format": e.source_format,
        "line_number": e.line_number,
    }


def _dict_to_event(d: dict) -> LogEvent:
    ts = None
    if d.get("timestamp"):
        try:
            ts = datetime.fromisoformat(d["timestamp"])
        except (ValueError, TypeError):
            pass
    return LogEvent(
        timestamp=ts,
        severity=d.get("severity", "Low"),
        source=d.get("source", ""),
        message=d.get("message", ""),
        extra=d.get("extra", {}),
        raw=d.get("raw", ""),
        source_file=d.get("source_file", ""),
        source_format=d.get("source_format", ""),
        line_number=d.get("line_number", -1),
    )


def load_cached(filepath: Path) -> list[LogEvent] | None:
    """Load cached parse results if valid."""
    key = _cache_key(filepath)
    if not key:
        return None

    cache_file = _CACHE_DIR / f"{key}.json"
    if not cache_file.exists():
        # Clean up legacy pickle files
        pkl = _CACHE_DIR / f"{key}.pkl"
        if pkl.exists():
            try:
                pkl.unlink()
            except OSError:
                pass
        return None

    try:
        with open(cache_file, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, list):
            return [_dict_to_event(d) for d in data]
    except (json.JSONDecodeError, KeyError, OSError) as exc:
        log.info("Cache read failed for %s: %s", filepath, exc)
        try:
            cache_file.unlink()
        except OSError:
            pass

    return None


def save_cache(filepath: Path, events: list[LogEvent]) -> None:
    """Cache parse results for a file."""
    key = _cache_key(filepath)
    if not key:
        return

    try:
        _CACHE_DIR.mkdir(parents=True, exist_ok=True)
        cache_file = _CACHE_DIR / f"{key}.json"
        with open(cache_file, "w", encoding="utf-8") as f:
            json.dump([_event_to_dict(e) for e in events], f,
                      ensure_ascii=False)
    except OSError as exc:
        log.debug("Cache write failed for %s: %s", filepath, exc)


def clear_cache() -> int:
    """Remove all cached files. Returns count removed."""
    if not _CACHE_DIR.exists():
        return 0
    count = 0
    for pattern in ("*.json", "*.pkl"):
        for f in _CACHE_DIR.glob(pattern):
            try:
                f.unlink()
                count += 1
            except OSError:
                pass
    return count
