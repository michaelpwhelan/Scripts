#!/usr/bin/env python3
"""Lightweight GeoIP lookup — RFC-based classification with optional geoip2."""

from __future__ import annotations

import ipaddress
import logging
from functools import lru_cache

log = logging.getLogger(__name__)


class _GeoIP2Lookup:
    """Lazy-loading wrapper around the optional geoip2 MaxMind reader."""

    def __init__(self) -> None:
        self._reader = None
        self._checked = False

    def lookup(self, ip: str) -> dict | None:
        """Attempt lookup via geoip2/MaxMind if available."""
        if self._checked and self._reader is None:
            return None

        if not self._checked:
            self._checked = True
            try:
                import geoip2.database
                import os
                if os.name == "nt":
                    _default_db = os.path.join(
                        os.environ.get("ProgramData", r"C:\ProgramData"),
                        "GeoIP", "GeoLite2-Country.mmdb",
                    )
                else:
                    _default_db = "/usr/share/GeoIP/GeoLite2-Country.mmdb"
                db_path = os.environ.get("GEOIP_DB", _default_db)
                if os.path.exists(db_path):
                    self._reader = geoip2.database.Reader(db_path)
            except (ImportError, OSError) as exc:
                log.debug("geoip2 init failed: %s", exc)
                return None

        if self._reader is None:
            return None

        try:
            resp = self._reader.country(ip)
            return {
                "country": resp.country.name or "Unknown",
                "country_code": resp.country.iso_code or "??",
            }
        except (ValueError, AttributeError, TypeError):
            return None
        except OSError as exc:
            log.debug("geoip2 lookup failed for %s: %s", ip, exc)
            return None


_geoip2 = _GeoIP2Lookup()


# Top RIR allocations — simplified country classification for common ranges
_COUNTRY_PREFIXES: list[tuple[str, str, str]] = [
    # (network, country_code, country_name)
    ("1.0.0.0/8", "US", "United States"),
    ("2.0.0.0/8", "EU", "Europe"),
    ("3.0.0.0/8", "US", "United States"),
    ("4.0.0.0/8", "US", "United States"),
    ("5.0.0.0/8", "EU", "Europe"),
    ("8.0.0.0/8", "US", "United States"),
    ("9.0.0.0/8", "US", "United States"),
    ("13.0.0.0/8", "US", "United States"),
    ("14.0.0.0/8", "JP", "Japan"),
    ("17.0.0.0/8", "US", "United States"),
    ("20.0.0.0/8", "US", "United States"),
    ("23.0.0.0/8", "US", "United States"),
    ("24.0.0.0/8", "US", "United States"),
    ("31.0.0.0/8", "EU", "Europe"),
    ("34.0.0.0/8", "US", "United States"),
    ("35.0.0.0/8", "US", "United States"),
    ("36.0.0.0/8", "CN", "China"),
    ("37.0.0.0/8", "EU", "Europe"),
    ("39.0.0.0/8", "KR", "South Korea"),
    ("40.0.0.0/8", "US", "United States"),
    ("41.0.0.0/8", "AF", "Africa"),
    ("42.0.0.0/8", "JP", "Japan"),
    ("43.0.0.0/8", "JP", "Japan"),
    ("44.0.0.0/8", "US", "United States"),
    ("45.0.0.0/8", "US", "United States"),
    ("46.0.0.0/8", "EU", "Europe"),
    ("47.0.0.0/8", "CA", "Canada"),
    ("49.0.0.0/8", "AP", "Asia Pacific"),
    ("50.0.0.0/8", "US", "United States"),
    ("52.0.0.0/8", "US", "United States"),
    ("54.0.0.0/8", "US", "United States"),
    ("58.0.0.0/8", "AP", "Asia Pacific"),
    ("59.0.0.0/8", "AP", "Asia Pacific"),
    ("60.0.0.0/8", "AP", "Asia Pacific"),
    ("61.0.0.0/8", "AP", "Asia Pacific"),
    ("62.0.0.0/8", "EU", "Europe"),
    ("63.0.0.0/8", "US", "United States"),
    ("64.0.0.0/8", "US", "United States"),
    ("65.0.0.0/8", "US", "United States"),
    ("66.0.0.0/8", "US", "United States"),
    ("67.0.0.0/8", "US", "United States"),
    ("68.0.0.0/8", "US", "United States"),
    ("69.0.0.0/8", "US", "United States"),
    ("70.0.0.0/8", "US", "United States"),
    ("71.0.0.0/8", "US", "United States"),
    ("72.0.0.0/8", "US", "United States"),
    ("74.0.0.0/8", "US", "United States"),
    ("76.0.0.0/8", "US", "United States"),
    ("77.0.0.0/8", "EU", "Europe"),
    ("78.0.0.0/8", "EU", "Europe"),
    ("79.0.0.0/8", "EU", "Europe"),
    ("80.0.0.0/8", "EU", "Europe"),
    ("81.0.0.0/8", "EU", "Europe"),
    ("82.0.0.0/8", "EU", "Europe"),
    ("83.0.0.0/8", "EU", "Europe"),
    ("84.0.0.0/8", "EU", "Europe"),
    ("85.0.0.0/8", "EU", "Europe"),
    ("86.0.0.0/8", "EU", "Europe"),
    ("87.0.0.0/8", "EU", "Europe"),
    ("88.0.0.0/8", "EU", "Europe"),
    ("89.0.0.0/8", "EU", "Europe"),
    ("90.0.0.0/8", "EU", "Europe"),
    ("91.0.0.0/8", "EU", "Europe"),
    ("92.0.0.0/8", "EU", "Europe"),
    ("93.0.0.0/8", "EU", "Europe"),
    ("94.0.0.0/8", "EU", "Europe"),
    ("95.0.0.0/8", "EU", "Europe"),
    ("96.0.0.0/8", "US", "United States"),
    ("97.0.0.0/8", "US", "United States"),
    ("98.0.0.0/8", "US", "United States"),
    ("99.0.0.0/8", "US", "United States"),
    ("100.0.0.0/8", "US", "United States"),
    ("101.0.0.0/8", "AP", "Asia Pacific"),
    ("102.0.0.0/8", "AF", "Africa"),
    ("103.0.0.0/8", "AP", "Asia Pacific"),
    ("104.0.0.0/8", "US", "United States"),
    ("105.0.0.0/8", "AF", "Africa"),
    ("106.0.0.0/8", "AP", "Asia Pacific"),
    ("107.0.0.0/8", "US", "United States"),
    ("108.0.0.0/8", "US", "United States"),
    ("109.0.0.0/8", "EU", "Europe"),
    ("110.0.0.0/8", "AP", "Asia Pacific"),
    ("111.0.0.0/8", "AP", "Asia Pacific"),
    ("112.0.0.0/8", "AP", "Asia Pacific"),
    ("113.0.0.0/8", "AP", "Asia Pacific"),
    ("114.0.0.0/8", "AP", "Asia Pacific"),
    ("115.0.0.0/8", "AP", "Asia Pacific"),
    ("116.0.0.0/8", "AP", "Asia Pacific"),
    ("117.0.0.0/8", "AP", "Asia Pacific"),
    ("118.0.0.0/8", "AP", "Asia Pacific"),
    ("119.0.0.0/8", "AP", "Asia Pacific"),
    ("120.0.0.0/8", "AP", "Asia Pacific"),
    ("121.0.0.0/8", "AP", "Asia Pacific"),
    ("122.0.0.0/8", "AP", "Asia Pacific"),
    ("123.0.0.0/8", "AP", "Asia Pacific"),
    ("124.0.0.0/8", "AP", "Asia Pacific"),
    ("125.0.0.0/8", "AP", "Asia Pacific"),
    ("126.0.0.0/8", "JP", "Japan"),
    ("128.0.0.0/8", "US", "United States"),
    ("129.0.0.0/8", "US", "United States"),
    ("130.0.0.0/8", "US", "United States"),
    ("131.0.0.0/8", "US", "United States"),
    ("132.0.0.0/8", "US", "United States"),
    ("133.0.0.0/8", "JP", "Japan"),
    ("134.0.0.0/8", "US", "United States"),
    ("135.0.0.0/8", "US", "United States"),
    ("136.0.0.0/8", "US", "United States"),
    ("137.0.0.0/8", "US", "United States"),
    ("138.0.0.0/8", "US", "United States"),
    ("139.0.0.0/8", "US", "United States"),
    ("140.0.0.0/8", "US", "United States"),
    ("141.0.0.0/8", "EU", "Europe"),
    ("142.0.0.0/8", "US", "United States"),
    ("143.0.0.0/8", "US", "United States"),
    ("144.0.0.0/8", "US", "United States"),
    ("145.0.0.0/8", "EU", "Europe"),
    ("146.0.0.0/8", "US", "United States"),
    ("147.0.0.0/8", "US", "United States"),
    ("148.0.0.0/8", "US", "United States"),
    ("149.0.0.0/8", "US", "United States"),
    ("150.0.0.0/8", "JP", "Japan"),
    ("151.0.0.0/8", "EU", "Europe"),
    ("152.0.0.0/8", "US", "United States"),
    ("153.0.0.0/8", "AP", "Asia Pacific"),
    ("154.0.0.0/8", "AF", "Africa"),
    ("155.0.0.0/8", "US", "United States"),
    ("156.0.0.0/8", "US", "United States"),
    ("157.0.0.0/8", "US", "United States"),
    ("158.0.0.0/8", "US", "United States"),
    ("159.0.0.0/8", "EU", "Europe"),
    ("160.0.0.0/8", "US", "United States"),
    ("161.0.0.0/8", "US", "United States"),
    ("162.0.0.0/8", "US", "United States"),
    ("163.0.0.0/8", "US", "United States"),
    ("164.0.0.0/8", "US", "United States"),
    ("168.0.0.0/8", "US", "United States"),
    ("169.0.0.0/8", "US", "United States"),
    ("170.0.0.0/8", "SA", "South America"),
    ("171.0.0.0/8", "AP", "Asia Pacific"),
    ("175.0.0.0/8", "AP", "Asia Pacific"),
    ("176.0.0.0/8", "EU", "Europe"),
    ("177.0.0.0/8", "SA", "South America"),
    ("178.0.0.0/8", "EU", "Europe"),
    ("179.0.0.0/8", "SA", "South America"),
    ("180.0.0.0/8", "AP", "Asia Pacific"),
    ("181.0.0.0/8", "SA", "South America"),
    ("182.0.0.0/8", "AP", "Asia Pacific"),
    ("183.0.0.0/8", "AP", "Asia Pacific"),
    ("185.0.0.0/8", "EU", "Europe"),
    ("186.0.0.0/8", "SA", "South America"),
    ("187.0.0.0/8", "SA", "South America"),
    ("188.0.0.0/8", "EU", "Europe"),
    ("189.0.0.0/8", "SA", "South America"),
    ("190.0.0.0/8", "SA", "South America"),
    ("191.0.0.0/8", "SA", "South America"),
    ("192.0.0.0/8", "US", "United States"),
    ("193.0.0.0/8", "EU", "Europe"),
    ("194.0.0.0/8", "EU", "Europe"),
    ("195.0.0.0/8", "EU", "Europe"),
    ("196.0.0.0/8", "AF", "Africa"),
    ("197.0.0.0/8", "AF", "Africa"),
    ("198.0.0.0/8", "US", "United States"),
    ("199.0.0.0/8", "US", "United States"),
    ("200.0.0.0/8", "SA", "South America"),
    ("201.0.0.0/8", "SA", "South America"),
    ("202.0.0.0/8", "AP", "Asia Pacific"),
    ("203.0.0.0/8", "AP", "Asia Pacific"),
    ("204.0.0.0/8", "US", "United States"),
    ("205.0.0.0/8", "US", "United States"),
    ("206.0.0.0/8", "US", "United States"),
    ("207.0.0.0/8", "US", "United States"),
    ("208.0.0.0/8", "US", "United States"),
    ("209.0.0.0/8", "US", "United States"),
    ("210.0.0.0/8", "AP", "Asia Pacific"),
    ("211.0.0.0/8", "AP", "Asia Pacific"),
    ("212.0.0.0/8", "EU", "Europe"),
    ("213.0.0.0/8", "EU", "Europe"),
    ("216.0.0.0/8", "US", "United States"),
    ("217.0.0.0/8", "EU", "Europe"),
    ("218.0.0.0/8", "AP", "Asia Pacific"),
    ("219.0.0.0/8", "AP", "Asia Pacific"),
    ("220.0.0.0/8", "AP", "Asia Pacific"),
    ("221.0.0.0/8", "AP", "Asia Pacific"),
    ("222.0.0.0/8", "AP", "Asia Pacific"),
    ("223.0.0.0/8", "AP", "Asia Pacific"),
]

# Build lookup networks once
_NETWORKS: list[tuple[ipaddress.IPv4Network, str, str]] = []


def _build_networks() -> None:
    if _NETWORKS:
        return
    for cidr, code, name in _COUNTRY_PREFIXES:
        _NETWORKS.append((ipaddress.IPv4Network(cidr), code, name))


def lookup(ip: str) -> dict[str, str]:
    """Look up geographic info for an IP address.

    Returns a fresh dict with keys: country, country_code, type.
    """
    cached = _lookup_cached(ip)
    return dict(cached)


@lru_cache(maxsize=4096)
def _lookup_cached(ip: str) -> dict[str, str]:
    """Cached inner lookup — callers must copy before mutating."""
    try:
        addr = ipaddress.ip_address(ip)
    except ValueError:
        return {"country": "Invalid", "country_code": "??", "type": "invalid"}

    # Private/reserved ranges
    if addr.is_private:
        return {"country": "Private", "country_code": "--", "type": "private"}
    if addr.is_loopback:
        return {"country": "Loopback", "country_code": "--", "type": "loopback"}
    if addr.is_multicast:
        return {"country": "Multicast", "country_code": "--", "type": "multicast"}
    if addr.is_reserved:
        return {"country": "Reserved", "country_code": "--", "type": "reserved"}

    # Try geoip2 first (if available)
    geo2 = _geoip2.lookup(ip)
    if geo2:
        return {**geo2, "type": "public"}

    # Fallback to RIR prefix table
    _build_networks()
    for net, code, name in _NETWORKS:
        if isinstance(addr, ipaddress.IPv4Address) and addr in net:
            return {"country": name, "country_code": code, "type": "public"}

    return {"country": "Unknown", "country_code": "??", "type": "public"}


def lookup_enriched(ip: str) -> dict[str, str]:
    """Extended lookup including threat classification.

    Returns dict with keys: country, country_code, type, category, provider, risk.
    """
    geo = lookup(ip)
    try:
        from logparse.threat_intel import classify_ip
        threat = classify_ip(ip)
        return {**geo, **threat}
    except ImportError:
        return {**geo, "category": "unknown", "provider": "", "risk": "unknown"}
