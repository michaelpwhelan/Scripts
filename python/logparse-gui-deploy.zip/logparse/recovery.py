#!/usr/bin/env python3
"""Command recovery advisor — bridges the gap between user intent and tool syntax.

Hooks into two failure points in the REPL:

1. ``suggest_on_failure(cmd, session)`` — when dispatch() returns False
2. ``suggest_on_empty(cmd, session)`` — when a command produces zero results

Uses session state (transcript, fields, variables, last_output) to infer
what the user likely meant and suggest corrections.  Learned corrections
are stored in ``session.config["learned_commands"]`` and auto-applied on
future failures.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from logparse.session import Session


# -----------------------------------------------------------------------
# Shell habit mappings — common commands users try from muscle memory
# -----------------------------------------------------------------------

_SHELL_HABITS: dict[str, str | None] = {
    "ls":    "show sources",
    "dir":   "show sources",
    "cat":   "show *",
    "less":  "show *",
    "more":  "show *",
    "wc":    "count",
    "pwd":   "show filter",
    "man":   "help",
    "info":  "help",
    "cls":   "clear",
    "grep":  None,   # needs argument transform
    "find":  None,   # needs argument transform
    "head":  "head",
    "tail":  "tail",
    "uniq":  "dedup",
    "top":   None,   # ambiguous — could mean `top <field>` or system `top`
    "diff":  None,   # needs file arguments
    "wc -l": "count",
}

# Pattern: "grep <pattern>" → "search <pattern>"
_GREP_RE = re.compile(r"^(?:grep|egrep|fgrep)\s+(.+)$", re.I)

# Pattern: "cat <file>" → "add <file>"
_CAT_RE = re.compile(r"^cat\s+(\S+.+)$", re.I)


def suggest_on_failure(cmd: str, session: Session) -> str | None:
    """Suggest a correction when dispatch() returns False.

    Returns a suggested command string, or None if no suggestion.
    The caller decides whether to auto-execute or just display it.
    """
    cmd_stripped = cmd.strip()
    cmd_lower = cmd_stripped.lower()

    # 1. Check learned corrections first (user has accepted this before)
    learned = _get_learned(session)
    if cmd_lower in learned:
        return learned[cmd_lower]

    # 2. Shell habit — argument-sensitive patterns first
    grep_m = _GREP_RE.match(cmd_stripped)
    if grep_m:
        pattern = grep_m.group(1).strip().strip('"').strip("'")
        return f'search "{pattern}"'

    cat_m = _CAT_RE.match(cmd_stripped)
    if cat_m:
        filename = cat_m.group(1).strip()
        return f"add {filename}"

    # 3. Shell habit — exact first-word match (no arguments)
    first_word = cmd_lower.split()[0] if cmd_lower else ""
    if first_word in _SHELL_HABITS:
        suggestion = _SHELL_HABITS[first_word]
        if suggestion:
            return suggestion

    # 4. Analyzer label as search — user saw "(unknown)" in analyze output
    #    and is now searching for it literally
    if "(unknown)" in cmd_lower or "unknown" in cmd_lower:
        last_cmds = [t.command for t in session.transcript[-5:]]
        if any("analyze" in c for c in last_cmds):
            return None  # handled by suggest_on_empty instead

    # 5. Bare show targets — "severity", "sources", "timeline", etc.
    _SHOW_TARGETS = {
        "severity", "sources", "fields", "timeline", "filter", "filters",
        "history", "star", "skip", "annotate",
    }
    if cmd_lower in _SHOW_TARGETS:
        return f"show {cmd_lower}"

    # 6. Field=value without 'where' prefix (not caught by filter parse)
    field_eq_m = re.match(r"^(\w+)\s*[:=]\s*(\S+)$", cmd_stripped)
    if field_eq_m:
        field = field_eq_m.group(1)
        known = {f.lower() for f in session.all_field_names()}
        if field.lower() in known:
            return f"where {field}={field_eq_m.group(2)}"

    return None


def suggest_on_empty(cmd: str, session: Session) -> str | None:
    """Suggest refinements when a command produces zero results.

    Called after a where/search/show-where returns 0 matching events.
    Returns a hint string (not a command — just guidance).
    """
    cmd_lower = cmd.lower()

    # 1. Wildcards in contains — already fixed in filter engine, but
    #    provide guidance if they're searching for an analyzer label
    if "contains" in cmd_lower and "*" in cmd:
        clean = re.sub(r"\*", "", cmd)
        return f"Tip: 'contains' does substring matching — wildcards aren't needed. Try: {clean}"

    # 2. Searching for an analyzer display label like "(unknown)"
    if "unknown" in cmd_lower:
        last_cmds = [t.command for t in session.transcript[-10:]]
        if any("analyze" in c for c in last_cmds):
            return (
                '"(unknown)" is a display label for events with missing fields. '
                "Try: where failed not user:*"
            )

    # 3. Wrong field name — check if the search value exists in a different field
    where_m = re.match(r"where\s+(\w+)\s*[:=]\s*(\S+)", cmd_lower)
    if where_m:
        field, value = where_m.group(1), where_m.group(2)
        # Check if value exists under a different field name
        from logparse.models import get_field
        sample = session.all_events[:500]
        for alt_field in session.all_field_names():
            if alt_field.lower() == field.lower():
                continue
            for e in sample:
                fval = get_field(e, alt_field)
                if fval and value.lower() in fval.lower():
                    return f"No matches in '{field}'. Found '{value}' in field '{alt_field}' instead."
        return None

    # 4. General: suggest broadening the search
    if "where" in cmd_lower or "search" in cmd_lower:
        # Extract the search term
        terms = re.findall(r'["\']([^"\']+)["\']|\b(\w{3,})\b', cmd)
        meaningful = [t[0] or t[1] for t in terms if (t[0] or t[1]).lower()
                      not in {"where", "search", "show", "contains", "field"}]
        if meaningful:
            term = meaningful[-1]
            return f'Try broader search: search "{term}"'

    return None


def learn_correction(session: Session, original: str, resolved: str) -> None:
    """Store a user-accepted correction for future auto-application."""
    learned = _get_learned(session)
    learned[original.strip().lower()] = resolved.strip()
    _set_learned(session, learned)


def _get_learned(session: Session) -> dict[str, str]:
    """Get the learned corrections dict from session config."""
    if not hasattr(session, "config") or session.config is None:
        return {}
    return session.config.get("learned_commands", {})


def _set_learned(session: Session, learned: dict[str, str]) -> None:
    """Store the learned corrections dict in session config."""
    if not hasattr(session, "config") or session.config is None:
        session.config = {}
    session.config["learned_commands"] = learned
