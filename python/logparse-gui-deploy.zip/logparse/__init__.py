"""logparse — Log investigation tool for infrastructure log files."""

__version__ = "1.0.0"
