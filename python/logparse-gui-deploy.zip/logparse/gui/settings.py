#!/usr/bin/env python3
"""Persistent GUI settings stored as JSON in the config directory."""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

_log = logging.getLogger(__name__)

_DEFAULTS: dict[str, Any] = {
    "panel_width": 40,
    "recent_files": [],
    "theme": "dark",
    "dashboard_open": False,
    "search_open": False,
    "invest_open": False,
    "chart_builder_open": False,
    "command_history": [],
}


def _settings_path() -> Path:
    from logparse.config_loader import get_config_dir
    return get_config_dir() / "gui_settings.json"


def load_gui_settings() -> dict[str, Any]:
    """Load GUI settings from disk, returning defaults for missing keys."""
    path = _settings_path()
    result = dict(_DEFAULTS)
    if path.exists():
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                result.update(data)
        except Exception as exc:
            _log.warning("Failed to load GUI settings from %s: %s", path, exc)
    return result


def save_gui_settings(data: dict[str, Any]) -> None:
    """Write GUI settings to disk."""
    path = _settings_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    try:
        path.write_text(json.dumps(data, indent=2), encoding="utf-8")
    except Exception as exc:
        _log.error("Failed to save GUI settings to %s: %s", path, exc)
