#!/usr/bin/env python3
"""Shared application state for the logparse GUI server."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

from logparse.commands import CommandContext
from logparse.gui.web_console import WebConsole
from logparse.session import Session


@dataclass
class AppState:
    """Mutable state container stored on ``app.state.lp``.

    Replaces the bare module-level globals that were previously scattered
    across server.py.  A single typed object is easier to reason about,
    pass to helpers, and eventually extend (e.g. multi-session).
    """

    session: Session | None = None
    console: WebConsole | None = None
    ctx: CommandContext | None = None
