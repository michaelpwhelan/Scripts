#!/usr/bin/env python3
"""Web GUI for logparse - FastAPI server with modular ES module frontend."""
