const LOG_PREFIX = '[logparse-gui]';
export function log(...args) { console.log(LOG_PREFIX, ...args); }
export function logErr(...args) { console.error(LOG_PREFIX, ...args); }
export function logWarn(...args) { console.warn(LOG_PREFIX, ...args); }

export function $(id) { return document.getElementById(id); }

export function appendSystemMsg(text, isError = false) {
  const empty = $('empty-state');
  if (empty) empty.remove();
  const outputContent = $('output-content');
  const outputPanel = $('output-panel');
  const div = document.createElement('div');
  div.style.color = isError ? 'var(--red)' : 'var(--accent)';
  div.style.padding = '4px 0';
  div.textContent = text;
  outputContent.appendChild(div);
  outputPanel.scrollTop = outputPanel.scrollHeight;
}
