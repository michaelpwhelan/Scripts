// Shared mutable state for the logparse GUI.
// All modules import from here to read/write state.
export const state = {
  cmdHistory: [],
  historyIdx: -1,
  currentSort: { col: -1, dir: 'asc', field: '' },
  tableData: { columns: [], rows: [] },
  chartCounter: 0,
  currentPage: 0,
  totalPages: 1,
  rowMeta: {},
  ctxRowIdx: -1,
  ctxRowData: [],
  sessionState: {},
  modalMode: '',
  modalIdx: -1,
  searchOpen: false,
  dashboardOpen: false,
  analyzerOpen: false,
  reportOpen: false,
  investOpen: false,
  chartBuilderOpen: false,
};
