/**
 * Progress bar for long-running operations.
 * Listens for {type: 'progress', message, percent} WebSocket messages
 * and updates the #progress-bar / #progress-fill elements.
 * Auto-hides when a 'result' message arrives.
 */

import { onMessage } from './ws.js';
import { $ } from './utils.js';

let hideTimer = null;

/**
 * Show the progress bar with the given percentage and optional message.
 */
function showProgress(percent, message) {
  const bar = $('progress-bar');
  const fill = $('progress-fill');
  if (!bar || !fill) return;

  // Cancel any pending auto-hide
  if (hideTimer !== null) {
    clearTimeout(hideTimer);
    hideTimer = null;
  }

  bar.style.display = 'block';

  // Clamp to 0-100
  const pct = Math.max(0, Math.min(100, percent));
  fill.style.width = pct + '%';
  fill.style.transition = 'width 0.2s ease';

  // Update the text label if a message element exists
  const label = $('progress-label');
  if (label) {
    label.textContent = message || '';
    label.style.display = message ? 'block' : 'none';
  }

  // Store the message as a title on the bar for hover visibility
  bar.title = message || (pct + '%');
}

/**
 * Hide the progress bar with a short delay so the user sees 100%.
 */
function hideProgress() {
  const bar = $('progress-bar');
  const fill = $('progress-fill');
  if (!bar) return;

  // Snap to 100% briefly before hiding
  if (fill) fill.style.width = '100%';

  if (hideTimer !== null) clearTimeout(hideTimer);
  hideTimer = setTimeout(() => {
    bar.style.display = 'none';
    if (fill) fill.style.width = '0%';
    const label = $('progress-label');
    if (label) {
      label.textContent = '';
      label.style.display = 'none';
    }
    bar.title = '';
    hideTimer = null;
  }, 500);
}

/**
 * Initialise the progress module.
 * Registers WS handlers for 'progress' and 'result' message types.
 */
export function init() {
  onMessage('progress', (msg) => {
    const percent = msg.percent != null ? msg.percent : 0;
    showProgress(percent, msg.message || '');
  });

  // Any result message means the operation finished - hide the bar
  onMessage('result', () => hideProgress());

  // Also hide on error
  onMessage('error', () => hideProgress());
}
