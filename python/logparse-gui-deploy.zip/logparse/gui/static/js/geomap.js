/**
 * GeoIP map panel - sends the `geo` command for a selected IP field
 * and lets the existing chart rendering pipeline display the Plotly
 * scattergeo chart inside #chart-panel.
 */

import { $ } from './utils.js';
import { send, onMessage } from './ws.js';
import { sendCommand } from './commands.js';

const IP_FIELDS = ['srcip', 'dstip', 'remip', 'locip', 'src', 'dst', 'ip'];

let panelOpen = false;

/**
 * Toggle the geo-map controls inside #chart-panel.
 * Selecting a field and clicking "Generate Map" sends the `geo` command;
 * the resulting Plotly chart is rendered by the charts module.
 */
export function toggleGeoMap() {
  panelOpen = !panelOpen;
  const btn = $('btn-geo');
  if (btn) btn.classList.toggle('active', panelOpen);

  let container = $('geo-controls');

  if (!panelOpen) {
    if (container) container.remove();
    return;
  }

  const chartPanel = $('chart-panel');
  if (!chartPanel) return;
  chartPanel.style.display = 'block';

  // Build the controls bar if it does not already exist
  if (!container) {
    container = document.createElement('div');
    container.id = 'geo-controls';
    container.style.cssText =
      'display:flex;align-items:center;gap:8px;padding:6px 10px;' +
      'background:var(--surface-raised);border-bottom:1px solid var(--border);font-size:13px;';

    const label = document.createElement('span');
    label.textContent = 'IP field:';
    label.style.color = 'var(--text-secondary)';
    container.appendChild(label);

    const select = document.createElement('select');
    select.id = 'geo-field-select';
    select.style.cssText =
      'background:var(--surface-base);color:var(--text-primary);border:1px solid var(--border);' +
      'border-radius:4px;padding:3px 6px;font-size:13px;';
    IP_FIELDS.forEach(f => {
      const opt = document.createElement('option');
      opt.value = f;
      opt.textContent = f;
      select.appendChild(opt);
    });
    container.appendChild(select);

    const genBtn = document.createElement('button');
    genBtn.textContent = 'Generate Map';
    genBtn.className = 'btn btn-sm';
    genBtn.style.cssText =
      'background:var(--accent);color:#fff;border:none;border-radius:4px;' +
      'padding:4px 10px;cursor:pointer;font-size:13px;';
    genBtn.addEventListener('click', () => {
      const field = $('geo-field-select').value;
      sendCommand('geo ' + field);
    });
    container.appendChild(genBtn);

    chartPanel.prepend(container);
  }
}

/**
 * Initialise the geo-map module.
 * Binds the header button if present.
 */
export function init() {
  const btn = $('btn-geo');
  if (btn) btn.addEventListener('click', () => toggleGeoMap());
}
