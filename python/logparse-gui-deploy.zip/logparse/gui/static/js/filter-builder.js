import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';

const OPERATORS = [
  { value: ':',        label: 'equals' },
  { value: '!=',       label: 'not equals' },
  { value: '>',        label: 'greater than' },
  { value: '<',        label: 'less than' },
  { value: '>=',       label: 'greater or equal' },
  { value: '<=',       label: 'less or equal' },
  { value: 'contains', label: 'contains' },
  { value: 'in()',     label: 'in (list)' },
  { value: 'between',  label: 'between' },
  { value: '/regex/',  label: 'regex' },
];

const SEVERITIES = ['Critical', 'High', 'Medium', 'Low', 'Info'];

let rows = [];       // { id, field, op, value, logic }
let rowCounter = 0;
let fieldNames = []; // populated from server

/**
 * Build the filter builder DOM and inject it into #search-panel.
 */
function buildUI() {
  const searchPanel = $('search-panel');
  if (!searchPanel) return;

  // Container that sits below the existing search controls
  const container = document.createElement('div');
  container.id = 'filter-builder-section';
  container.style.flexBasis = '100%'; // force onto its own row in the flex-wrap parent

  container.innerHTML =
    '<div style="display:flex;align-items:center;gap:8px;margin-top:8px">' +
      '<span style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;' +
        'color:var(--text-secondary);font-weight:600">Advanced Filter</span>' +
      '<button id="btn-add-row" style="' +
        'background:var(--surface-overlay);color:var(--text-primary);border:1px solid var(--border);' +
        'padding:2px 8px;border-radius:2px;font-family:var(--font-mono);font-size:10px;cursor:pointer' +
      '">+ Row</button>' +
      '<button id="btn-apply-filter" style="' +
        'background:var(--surface-overlay);color:var(--accent);border:1px solid var(--accent);' +
        'padding:2px 8px;border-radius:2px;font-family:var(--font-mono);font-size:10px;cursor:pointer' +
      '">Apply</button>' +
      '<button id="btn-clear-builder" style="' +
        'background:var(--surface-overlay);color:var(--text-secondary);border:1px solid var(--border);' +
        'padding:2px 8px;border-radius:2px;font-family:var(--font-mono);font-size:10px;cursor:pointer' +
      '">Clear</button>' +
    '</div>' +
    '<div id="filter-builder-rows"></div>' +
    '<div id="filter-preview"></div>' +
    '<div class="sev-checks">' +
      '<span style="font-size:10px;text-transform:uppercase;letter-spacing:0.5px;' +
        'color:var(--text-secondary);font-weight:600">Severity:</span>' +
      SEVERITIES.map(s =>
        '<label><input type="checkbox" class="sev-cb" value="' + s + '"> ' + s + '</label>'
      ).join('') +
    '</div>' +
    '<div class="time-range-row">' +
      '<span style="font-weight:600">Time:</span>' +
      '<input type="datetime-local" id="time-start" title="Start time">' +
      '<span>to</span>' +
      '<input type="datetime-local" id="time-end" title="End time">' +
      '<button id="btn-apply-time" style="' +
        'background:var(--surface-overlay);color:var(--text-primary);border:1px solid var(--border);' +
        'padding:2px 8px;border-radius:2px;font-family:var(--font-mono);font-size:10px;cursor:pointer' +
      '">Apply Time</button>' +
    '</div>';

  searchPanel.appendChild(container);
}

/**
 * Add a new filter row to the builder.
 */
function addFilterRow() {
  const id = ++rowCounter;
  const row = { id, field: '', op: ':', value: '', logic: 'AND' };
  rows.push(row);
  renderRows();
}

/**
 * Remove a filter row by id.
 */
function removeFilterRow(id) {
  rows = rows.filter(r => r.id !== id);
  renderRows();
}

/**
 * Toggle the logic connector (AND/OR) for a row.
 */
function toggleLogic(id) {
  const row = rows.find(r => r.id === id);
  if (row) {
    row.logic = row.logic === 'AND' ? 'OR' : 'AND';
    renderRows();
  }
}

/**
 * Render all filter rows into the container.
 */
function renderRows() {
  const container = $('filter-builder-rows');
  if (!container) return;
  container.innerHTML = '';

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    const div = document.createElement('div');
    div.className = 'filter-row';

    // Logic toggle (show between rows, not on the first)
    if (i > 0) {
      const logicBtn = document.createElement('button');
      logicBtn.className = 'logic-toggle' + (r.logic === 'OR' ? ' active' : '');
      logicBtn.textContent = r.logic;
      logicBtn.title = 'Toggle AND/OR';
      logicBtn.addEventListener('click', () => toggleLogic(r.id));
      div.appendChild(logicBtn);
    }

    // Field dropdown
    const fieldSel = document.createElement('select');
    fieldSel.innerHTML = '<option value="">Field...</option>';
    for (const f of fieldNames) {
      const opt = document.createElement('option');
      opt.value = f;
      opt.textContent = f;
      if (f === r.field) opt.selected = true;
      fieldSel.appendChild(opt);
    }
    fieldSel.addEventListener('change', () => {
      r.field = fieldSel.value;
      updatePreview();
    });
    div.appendChild(fieldSel);

    // Operator dropdown
    const opSel = document.createElement('select');
    for (const op of OPERATORS) {
      const opt = document.createElement('option');
      opt.value = op.value;
      opt.textContent = op.label;
      if (op.value === r.op) opt.selected = true;
      opSel.appendChild(opt);
    }
    opSel.addEventListener('change', () => {
      r.op = opSel.value;
      updatePreview();
    });
    div.appendChild(opSel);

    // Value input
    const valInput = document.createElement('input');
    valInput.type = 'text';
    valInput.placeholder = 'Value...';
    valInput.value = r.value;
    valInput.addEventListener('input', () => {
      r.value = valInput.value;
      updatePreview();
    });
    valInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); applyFilterBuilder(); }
    });
    div.appendChild(valInput);

    // Remove button
    const removeBtn = document.createElement('span');
    removeBtn.className = 'remove-row';
    removeBtn.textContent = '\u00d7';
    removeBtn.title = 'Remove row';
    removeBtn.addEventListener('click', () => removeFilterRow(r.id));
    div.appendChild(removeBtn);

    container.appendChild(div);
  }

  updatePreview();
}

/**
 * Compose the `where` expression from the current rows and show it
 * in the preview element.
 */
function composeExpression() {
  const parts = [];

  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (!r.field || !r.value) continue;

    let clause;
    if (r.op === 'contains') {
      clause = r.field + ' contains ' + r.value;
    } else if (r.op === 'in()') {
      clause = r.field + ' in(' + r.value + ')';
    } else if (r.op === 'between') {
      clause = r.field + ' between ' + r.value;
    } else if (r.op === '/regex/') {
      clause = r.field + ':/' + r.value + '/';
    } else {
      clause = r.field + r.op + r.value;
    }

    if (parts.length > 0) {
      parts.push(r.logic);
    }
    parts.push(clause);
  }

  return parts.join(' ');
}

/**
 * Update the preview display.
 */
function updatePreview() {
  const el = $('filter-preview');
  if (!el) return;
  const expr = composeExpression();
  el.textContent = expr ? 'where ' + expr : '';
}

/**
 * Send the composed filter expression as a `where` command.
 */
function applyFilterBuilder() {
  const expr = composeExpression();
  if (!expr) return;
  sendCommand('where ' + expr);
}

/**
 * Apply the severity quick-filter based on checked checkboxes.
 */
function applySeverityFilter() {
  const checked = [];
  document.querySelectorAll('.sev-cb:checked').forEach(cb => {
    checked.push(cb.value);
  });
  if (checked.length === 0) return;
  if (checked.length === 1) {
    sendCommand('where severity:' + checked[0]);
  } else {
    sendCommand('where severity in(' + checked.join(',') + ')');
  }
}

/**
 * Apply the time range filter.
 */
function applyTimeRange() {
  const start = $('time-start')?.value;
  const end = $('time-end')?.value;
  if (!start && !end) return;

  if (start && end) {
    // Convert datetime-local to the format the backend expects
    const s = start.replace('T', ' ');
    const e = end.replace('T', ' ');
    sendCommand('where timestamp between ' + s + ' ' + e);
  } else if (start) {
    sendCommand('where timestamp>=' + start.replace('T', ' '));
  } else if (end) {
    sendCommand('where timestamp<=' + end.replace('T', ' '));
  }
}

/**
 * Clear all filter rows and reset the builder.
 */
function clearBuilder() {
  rows = [];
  rowCounter = 0;
  renderRows();
  document.querySelectorAll('.sev-cb').forEach(cb => { cb.checked = false; });
  const ts = $('time-start');
  const te = $('time-end');
  if (ts) ts.value = '';
  if (te) te.value = '';
}

/**
 * Cache field names when they arrive from the server so the
 * filter-row dropdowns can be populated.
 */
function handleFieldNames(msg) {
  fieldNames = msg.fields || [];
  // Re-render rows so dropdowns pick up the new fields
  if (rows.length > 0) renderRows();
}

/**
 * Initialise the filter builder: build the DOM, bind events, register
 * the field_names handler.
 */
export function init() {
  buildUI();

  const btnAdd = $('btn-add-row');
  if (btnAdd) btnAdd.addEventListener('click', () => addFilterRow());

  const btnApply = $('btn-apply-filter');
  if (btnApply) btnApply.addEventListener('click', () => applyFilterBuilder());

  const btnClear = $('btn-clear-builder');
  if (btnClear) btnClear.addEventListener('click', () => clearBuilder());

  const btnTime = $('btn-apply-time');
  if (btnTime) btnTime.addEventListener('click', () => applyTimeRange());

  // Severity checkboxes - apply on change
  document.querySelectorAll('.sev-cb').forEach(cb => {
    cb.addEventListener('change', () => applySeverityFilter());
  });

  // Listen for field names to populate dropdowns
  onMessage('field_names', handleFieldNames);
}
