/**
 * Export modal - lets the user choose a format and scope, then sends
 * the appropriate `export` command through the REPL interface.
 */

import { $ } from './utils.js';
import { sendCommand } from './commands.js';

const FORMATS = [
  { label: 'HTML',     value: 'html' },
  { label: 'CSV',      value: 'csv'  },
  { label: 'JSON',     value: 'json' },
  { label: 'Markdown', value: 'md'   },
];

const SCOPES = [
  { label: 'All events',      prefix: ''             },
  { label: 'Filtered events', prefix: ''             },
  { label: 'Starred events',  prefix: 'show starred | ' },
];

let modalOpen = false;

/**
 * Toggle the export modal overlay.
 */
export function toggleExport() {
  modalOpen = !modalOpen;
  let overlay = $('export-overlay');

  if (!modalOpen) {
    if (overlay) {
      overlay.classList.remove('open');
      overlay.style.display = 'none';
    }
    return;
  }

  // Create overlay on first open
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'export-overlay';
    overlay.style.cssText =
      'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:100;' +
      'display:flex;align-items:center;justify-content:center;';

    const modal = document.createElement('div');
    modal.id = 'export-modal';
    modal.style.cssText =
      'background:var(--surface-raised);border:1px solid var(--border);border-radius:8px;' +
      'width:360px;box-shadow:0 8px 32px rgba(0,0,0,0.5);';

    // Header
    const header = document.createElement('div');
    header.style.cssText =
      'display:flex;align-items:center;justify-content:space-between;' +
      'padding:12px 16px;border-bottom:1px solid var(--border);';
    const title = document.createElement('h3');
    title.textContent = 'Export';
    title.style.cssText = 'margin:0;font-size:14px;color:var(--text-primary);';
    const closeBtn = document.createElement('button');
    closeBtn.id = 'export-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.style.cssText =
      'background:none;border:none;color:var(--text-secondary);cursor:pointer;font-size:18px;';
    closeBtn.addEventListener('click', () => toggleExport());
    header.appendChild(title);
    header.appendChild(closeBtn);
    modal.appendChild(header);

    // Body
    const body = document.createElement('div');
    body.style.cssText = 'padding:16px;';

    // Format selector
    body.appendChild(makeLabel('Format'));
    const formatGroup = document.createElement('div');
    formatGroup.id = 'export-format-group';
    formatGroup.style.cssText = 'display:flex;gap:4px;margin-bottom:14px;';
    FORMATS.forEach((f, i) => {
      const pill = document.createElement('button');
      pill.textContent = f.label;
      pill.dataset.value = f.value;
      pill.className = 'exp-pill';
      pill.style.cssText = pillStyle(i === 0);
      if (i === 0) pill.classList.add('active');
      pill.addEventListener('click', () => selectPill(formatGroup, pill));
      formatGroup.appendChild(pill);
    });
    body.appendChild(formatGroup);

    // Scope selector
    body.appendChild(makeLabel('Scope'));
    const scopeGroup = document.createElement('div');
    scopeGroup.id = 'export-scope-group';
    scopeGroup.style.cssText = 'display:flex;flex-direction:column;gap:4px;margin-bottom:16px;';
    SCOPES.forEach((s, i) => {
      const radio = document.createElement('label');
      radio.style.cssText =
        'display:flex;align-items:center;gap:6px;font-size:13px;color:var(--text-primary);cursor:pointer;';
      const input = document.createElement('input');
      input.type = 'radio';
      input.name = 'export-scope';
      input.value = s.prefix;
      input.style.accentColor = 'var(--accent)';
      if (i === 0) input.checked = true;
      radio.appendChild(input);
      radio.appendChild(document.createTextNode(s.label));
      scopeGroup.appendChild(radio);
    });
    body.appendChild(scopeGroup);

    // Action buttons
    const actions = document.createElement('div');
    actions.style.cssText = 'display:flex;gap:8px;';

    const exportBtn = document.createElement('button');
    exportBtn.id = 'export-run-btn';
    exportBtn.textContent = 'Export';
    exportBtn.style.cssText =
      'flex:1;background:var(--accent);color:#fff;border:none;border-radius:4px;' +
      'padding:7px 0;cursor:pointer;font-size:13px;font-weight:600;';
    exportBtn.addEventListener('click', () => runExport());
    actions.appendChild(exportBtn);

    const clipBtn = document.createElement('button');
    clipBtn.id = 'export-clip-btn';
    clipBtn.textContent = 'Copy to Clipboard';
    clipBtn.style.cssText =
      'flex:1;background:var(--surface-base);color:var(--text-primary);border:1px solid var(--border);' +
      'border-radius:4px;padding:7px 0;cursor:pointer;font-size:13px;';
    clipBtn.addEventListener('click', () => {
      sendCommand('export clipboard');
      toggleExport();
    });
    actions.appendChild(clipBtn);

    body.appendChild(actions);
    modal.appendChild(body);
    overlay.appendChild(modal);

    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) toggleExport();
    });

    document.body.appendChild(overlay);
  }

  overlay.classList.add('open');
  overlay.style.display = 'flex';
}

function makeLabel(text) {
  const lbl = document.createElement('div');
  lbl.textContent = text;
  lbl.style.cssText =
    'font-size:12px;color:var(--text-secondary);margin-bottom:4px;font-weight:600;';
  return lbl;
}

function pillStyle(active) {
  if (active) {
    return 'background:var(--accent);color:#fff;border:1px solid var(--accent);' +
      'border-radius:4px;padding:4px 12px;cursor:pointer;font-size:13px;';
  }
  return 'background:var(--surface-base);color:var(--text-secondary);border:1px solid var(--border);' +
    'border-radius:4px;padding:4px 12px;cursor:pointer;font-size:13px;';
}

function selectPill(group, selected) {
  group.querySelectorAll('.exp-pill').forEach(p => {
    p.style.cssText = pillStyle(false);
    p.classList.remove('active');
  });
  selected.style.cssText = pillStyle(true);
  selected.classList.add('active');
}

/**
 * Build and send the export command from the current modal selections.
 */
function runExport() {
  const formatGroup = $('export-format-group');
  const activeFmt = formatGroup ? formatGroup.querySelector('.exp-pill.active') : null;
  const format = activeFmt ? activeFmt.dataset.value : 'html';

  const scopeGroup = $('export-scope-group');
  const checkedRadio = scopeGroup ? scopeGroup.querySelector('input[name="export-scope"]:checked') : null;
  const prefix = checkedRadio ? checkedRadio.value : '';

  sendCommand(prefix + 'export ' + format);
  toggleExport();
}

/**
 * Initialise the export module.
 * Binds the header Export button.
 */
export function init() {
  const btn = $('btn-export');
  if (btn) {
    // Replace the simple handler from app.js with the modal version
    btn.replaceWith(btn.cloneNode(true));
    const freshBtn = $('btn-export');
    if (freshBtn) freshBtn.addEventListener('click', () => toggleExport());
  }
}
