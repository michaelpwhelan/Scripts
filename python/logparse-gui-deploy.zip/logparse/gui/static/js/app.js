/**
 * logparse GUI - Application entry point.
 *
 * Imports all modules, registers cross-cutting message handlers,
 * wires up keyboard shortcuts, and starts the WebSocket connection.
 */

import { state } from './state.js';
import { connect, send, onMessage } from './ws.js';
import { $, appendSystemMsg } from './utils.js';
import { sendCommand, init as initCommands } from './commands.js';
import { updateTable, init as initTable } from './table.js';
import { init as initDetail } from './detail.js';
import { renderCharts } from './charts.js';
import { init as initDashboard } from './dashboard.js';
import { init as initSearch } from './search.js';
import { init as initUpload } from './upload.js';
import { init as initLayout } from './layout.js';
import { init as initInvestigation } from './investigation.js';
import { init as initContextMenu } from './context-menu.js';
import { init as initChartBuilder } from './chart-builder.js';
import { init as initPalette, togglePalette } from './palette.js';
import { init as initAnalyzers } from './analyzers.js';
import { init as initReports } from './reports.js';
import { init as initFilterBuilder } from './filter-builder.js';
import { init as initGeoMap } from './geomap.js';
import { init as initMitre } from './mitre.js';
import { init as initTimeline } from './timeline.js';
import { init as initSessions } from './sessions.js';
import { init as initExport } from './export.js';
import { init as initProgress } from './progress.js';
import { init as initConfig } from './config.js';

// ---------------------------------------------------------------------------
// Cross-cutting message handlers
// ---------------------------------------------------------------------------

onMessage('result', (msg) => {
  // Append command output to the output panel
  const empty = $('empty-state');
  if (empty) empty.remove();

  const outputContent = $('output-content');
  const outputPanel = $('output-panel');
  const wrapper = document.createElement('div');

  if (msg.command) {
    const echo = document.createElement('div');
    echo.className = 'cmd-echo';
    echo.textContent = '> ' + msg.command;
    wrapper.appendChild(echo);
  }
  if (msg.html) {
    const out = document.createElement('div');
    out.className = 'cmd-output';
    out.innerHTML = msg.html;
    wrapper.appendChild(out);
  }
  outputContent.appendChild(wrapper);
  outputPanel.scrollTop = outputPanel.scrollHeight;

  if (msg.events) updateTable(msg.events);
  if (msg.charts && msg.charts.length) renderCharts(msg.charts);
  if (msg.session) updateStatus(msg.session);
});

onMessage('loaded', (msg) => {
  appendSystemMsg(`Loaded ${msg.total} events from ${msg.files.length} file(s)`);
  if (msg.events) updateTable(msg.events);
  if (msg.session) updateStatus(msg.session);
  const empty = $('empty-state');
  if (empty) empty.remove();
});

onMessage('session_state', (msg) => {
  if (msg.session) updateStatus(msg.session);
});

onMessage('error', (msg) => {
  appendSystemMsg(msg.message, true);
});

onMessage('exit', () => {
  appendSystemMsg('Session ended.');
});

// ---------------------------------------------------------------------------
// Status bar + prompt
// ---------------------------------------------------------------------------

function updateStatus(s) {
  state.sessionState = s;
  $('stat-total').textContent = s.total || 0;
  $('stat-filtered').textContent = s.filtered || 0;
  $('stat-filter').textContent = s.active_filter || 'none';
  $('stat-depth').textContent = s.filter_depth || 0;
  $('stat-starred').textContent = s.starred || 0;
  $('stat-charts').textContent = s.charts_count || 0;

  // Update prompt
  const label = $('prompt-label');
  if (s.active_filter) {
    label.textContent = `logparse (${s.active_filter}) [${s.filtered}]>`;
  } else {
    label.textContent = `logparse [${s.filtered || s.total || 0}]>`;
  }
  // refreshInvestPanel is handled by investigation.js session_state handler
}

// ---------------------------------------------------------------------------
// Keyboard shortcuts
// ---------------------------------------------------------------------------

document.addEventListener('keydown', (e) => {
  const tag = e.target.tagName;

  // Escape: close panels and menus
  if (e.key === 'Escape') {
    $('ctx-menu').style.display = 'none';
    const modal = $('tag-modal');
    if (modal) modal.classList.remove('open');
    const palette = $('palette-overlay');
    if (palette) palette.classList.remove('open');
    const detail = $('detail-panel');
    if (detail) detail.style.display = 'none';
    return;
  }

  // Ctrl+Z: undo (not in input fields)
  if (e.ctrlKey && e.key === 'z' && tag !== 'INPUT') {
    e.preventDefault();
    sendCommand('undo');
    return;
  }

  // Ctrl+K: command palette
  if (e.ctrlKey && e.key === 'k') {
    e.preventDefault();
    togglePalette();
    return;
  }

  // Ctrl+S: save session
  if (e.ctrlKey && e.key === 's') {
    e.preventDefault();
    sendCommand('save_session auto');
    return;
  }

  // Ctrl+F: toggle search
  if (e.ctrlKey && e.key === 'f') {
    e.preventDefault();
    const btn = $('btn-search');
    if (btn) btn.click();
    return;
  }

  // Ctrl+D: toggle dashboard
  if (e.ctrlKey && e.key === 'd') {
    e.preventDefault();
    const btn = $('btn-dashboard');
    if (btn) btn.click();
    return;
  }

  // Ctrl+I: toggle investigation sidebar
  if (e.ctrlKey && e.key === 'i') {
    e.preventDefault();
    const btn = $('btn-invest');
    if (btn) btn.click();
    return;
  }

  // F5: refresh session state
  if (e.key === 'F5') {
    e.preventDefault();
    send({ type: 'session_state' });
    return;
  }

  // / : focus command input (not in input fields)
  if (e.key === '/' && tag !== 'INPUT' && tag !== 'SELECT') {
    e.preventDefault();
    $('cmd-input').focus();
    return;
  }

  // Focus command input on printable keys outside inputs
  if (tag !== 'INPUT' && tag !== 'SELECT' && !e.ctrlKey && !e.altKey && !e.metaKey) {
    $('cmd-input').focus();
  }
});

// ---------------------------------------------------------------------------
// Initialise all modules and connect
// ---------------------------------------------------------------------------

initCommands();
initTable();
initDetail();
initDashboard();
initSearch();
initUpload();
initLayout();
initInvestigation();
initContextMenu();
initChartBuilder();
initPalette();
initAnalyzers();
initReports();
initFilterBuilder();
initGeoMap();
initMitre();
initTimeline();
initSessions();
initExport();
initProgress();
initConfig();

// Bind header buttons not owned by specific modules
const btnLoad = $('btn-load');
if (btnLoad) btnLoad.addEventListener('click', () => $('file-input').click());

$('cmd-input').focus();
connect();
