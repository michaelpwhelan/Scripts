import { state } from './state.js';
import { log, logErr, $ } from './utils.js';

/**
 * Render an array of Plotly chart objects into the chart panel.
 * Each chart is expected to have {data, layout} properties.
 */
export function renderCharts(charts) {
  log('renderCharts:', charts.length, 'chart(s)');
  const panel = $('chart-panel');
  panel.style.display = 'block';
  panel.innerHTML = '';

  charts.forEach((chart, idx) => {
    log('  chart', idx, '-- data traces:', (chart.data || []).length,
        'layout keys:', Object.keys(chart.layout || {}).join(','));

    const div = document.createElement('div');
    div.className = 'chart-wrap';
    div.id = 'chart-' + (state.chartCounter++);
    panel.appendChild(div);

    try {
      Plotly.react(div.id, chart.data, chart.layout, { responsive: true });
      log('  chart', idx, 'rendered OK');
    } catch (e) {
      logErr('  chart', idx, 'Plotly render error:', e);
    }
  });
}

export function init() {
  // Charts module is passive - renderCharts is called by the main
  // response router when a result includes charts.  No WS handlers
  // to register here.
}
