import { state } from './state.js';
import { $ } from './utils.js';
import { send, onMessage } from './ws.js';
import { sendCommand } from './commands.js';

let analyzerCache = null;

/**
 * Toggle the analyzer panel.  When opening, hides the table area and
 * fetches the analyzer list from the REST endpoint.  Closes any other
 * overlay panel (dashboard, reports) first.
 */
export function toggleAnalyzers() {
  state.analyzerOpen = !state.analyzerOpen;
  const panel = $('analyzer-panel');
  const btn = $('btn-analyzers');
  const tableContainer = $('table-container');
  const tableStatus = $('table-status');
  const detailPanel = $('detail-panel');

  // Close sibling overlay panels and reset their state flags
  closePanel('dashboard-panel', 'btn-dashboard');
  state.dashboardOpen = false;
  closePanel('report-panel', 'btn-reports');
  state.reportOpen = false;

  if (state.analyzerOpen) {
    btn.classList.add('active');
    panel.classList.add('open');
    tableContainer.style.display = 'none';
    tableStatus.style.display = 'none';
    detailPanel.style.display = 'none';
    fetchAnalyzers();
  } else {
    btn.classList.remove('active');
    panel.classList.remove('open');
    tableContainer.style.display = '';
    tableStatus.style.display = '';
  }
}

function closePanel(panelId, btnId) {
  const p = $(panelId);
  const b = $(btnId);
  if (p) p.classList.remove('open');
  if (b) b.classList.remove('active');
}

/**
 * Fetch the analyzer list from the REST API.  Falls back to the
 * cached list if the request fails (e.g. endpoint not yet wired).
 */
async function fetchAnalyzers() {
  if (analyzerCache) {
    renderAnalyzers(analyzerCache);
    return;
  }
  try {
    const resp = await fetch('/api/analyzers');
    if (!resp.ok) throw new Error(resp.statusText);
    analyzerCache = await resp.json();
    renderAnalyzers(analyzerCache);
  } catch {
    // Fallback: use a sensible static list so the panel is never empty.
    analyzerCache = fallbackAnalyzers();
    renderAnalyzers(analyzerCache);
  }
}

/**
 * Static fallback when the /api/analyzers endpoint is unavailable.
 */
function fallbackAnalyzers() {
  return [
    { name: 'anomaly',       category: 'Detection',  help: 'Detect statistical anomalies and outliers' },
    { name: 'dns',           category: 'Network',    help: 'Analyze DNS query patterns and tunneling' },
    { name: 'failed_logins', category: 'Auth',       help: 'Detect brute-force and credential attacks' },
    { name: 'incident',      category: 'Detection',  help: 'Reconstruct incident timelines with MITRE mapping' },
    { name: 'ipsec_tunnel',  category: 'VPN',        help: 'Monitor IPsec tunnel health and failures' },
    { name: 'sdwan',         category: 'Network',    help: 'SD-WAN path quality and failover analysis' },
    { name: 'sla',           category: 'Network',    help: 'SLA compliance and latency metrics' },
    { name: 'vpn_sessions',  category: 'VPN',        help: 'Track VPN session lifecycle and anomalies' },
    { name: 'auth',          category: 'Auth',       help: 'Authentication pattern analysis' },
    { name: 'behavioral_baseline', category: 'Detection', help: 'Behavioral baseline deviation detection' },
    { name: 'entity_risk',   category: 'Detection',  help: 'Entity risk scoring across sources' },
    { name: 'firewall',      category: 'Network',    help: 'Firewall policy and deny analysis' },
    { name: 'traffic',       category: 'Network',    help: 'Traffic volume and protocol analysis' },
    { name: 'windows',       category: 'Endpoint',   help: 'Windows event log analysis' },
    { name: 'correlation',   category: 'Detection',  help: 'Cross-source event correlation' },
    { name: 'summary',       category: 'General',    help: 'Quick summary statistics' },
  ];
}

/**
 * Render the analyzer list as a grid of cards grouped by category.
 */
function renderAnalyzers(analyzers) {
  const panel = $('analyzer-panel');
  if (!panel) return;

  // Group by category
  const groups = {};
  for (const a of analyzers) {
    const cat = a.category || 'General';
    (groups[cat] ||= []).push(a);
  }

  let html =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">' +
      '<h3 style="font-size:13px;font-weight:600;color:var(--text-primary)">Analyzers</h3>' +
      '<button id="btn-run-all-analyzers" style="' +
        'background:var(--surface-overlay);color:var(--accent);border:1px solid var(--accent);' +
        'padding:4px 12px;border-radius:2px;font-family:var(--font-mono);font-size:11px;cursor:pointer' +
      '">Run All</button>' +
    '</div>';

  for (const [cat, items] of Object.entries(groups).sort(([a], [b]) => a.localeCompare(b))) {
    html +=
      '<div style="margin-bottom:16px">' +
        '<div style="font-size:10px;text-transform:uppercase;letter-spacing:0.8px;' +
          'color:var(--text-secondary);margin-bottom:6px;font-weight:600">' + escHtml(cat) + '</div>' +
        '<div class="card-grid">';

    for (const a of items) {
      html +=
        '<div class="feature-card">' +
          '<h4>' + escHtml(a.name) + '</h4>' +
          '<div class="card-desc">' + escHtml(a.help || '') + '</div>' +
          '<span class="card-cat">' + escHtml(cat) + '</span>' +
          '<div class="card-actions">' +
            '<button data-analyzer="' + escAttr(a.name) + '">Run</button>' +
          '</div>' +
        '</div>';
    }

    html += '</div></div>';
  }

  panel.innerHTML = html;

  // Bind "Run" buttons
  panel.querySelectorAll('[data-analyzer]').forEach(btn => {
    btn.addEventListener('click', () => {
      sendCommand('analyze ' + btn.dataset.analyzer);
    });
  });

  // Bind "Run All"
  const runAll = $('btn-run-all-analyzers');
  if (runAll) {
    runAll.addEventListener('click', () => sendCommand('analyze'));
  }
}

function escHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escAttr(s) {
  return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
}

/**
 * Initialise: bind the header button.
 */
export function init() {
  const btn = $('btn-analyzers');
  if (btn) btn.addEventListener('click', () => toggleAnalyzers());
}
