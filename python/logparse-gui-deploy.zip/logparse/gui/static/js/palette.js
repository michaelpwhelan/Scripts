/**
 * Command palette (Ctrl+K) - VS Code style searchable command list.
 */

import { $ } from './utils.js';
import { sendCommand } from './commands.js';

let commands = [];
let activeIdx = -1;
let visible = false;

/**
 * Toggle the command palette overlay.
 */
export function togglePalette() {
  const overlay = $('palette-overlay');
  visible = !visible;
  if (visible) {
    overlay.classList.add('open');
    const input = $('palette-input');
    input.value = '';
    input.focus();
    fetchCommands();
  } else {
    overlay.classList.remove('open');
    $('cmd-input').focus();
  }
}

export function closePalette() {
  visible = false;
  $('palette-overlay').classList.remove('open');
  $('cmd-input').focus();
}

/**
 * Fetch the command registry from the REST API.
 */
async function fetchCommands() {
  if (commands.length > 0) {
    renderResults('');
    return;
  }
  try {
    const resp = await fetch('/api/commands');
    if (resp.ok) {
      commands = await resp.json();
      renderResults('');
    }
  } catch (e) {
    // Commands will be empty; palette still works with typed input
  }
}

/**
 * Render filtered results in the palette results list.
 */
function renderResults(query) {
  const container = $('palette-results');
  container.innerHTML = '';
  activeIdx = -1;

  const q = query.toLowerCase().trim();
  const filtered = q
    ? commands.filter(c =>
        c.name.toLowerCase().includes(q) ||
        (c.help && c.help.toLowerCase().includes(q)) ||
        (c.category && c.category.toLowerCase().includes(q))
      )
    : commands;

  filtered.slice(0, 30).forEach((cmd, i) => {
    const div = document.createElement('div');
    div.className = 'pal-item';
    div.dataset.index = i;

    const name = document.createElement('span');
    name.className = 'pal-name';
    name.textContent = cmd.usage || cmd.name;
    div.appendChild(name);

    const cat = document.createElement('span');
    cat.className = 'pal-cat';
    cat.textContent = cmd.category || '';
    div.appendChild(cat);

    div.addEventListener('click', () => {
      executeFromPalette(cmd);
    });

    container.appendChild(div);
  });
}

function executeFromPalette(cmd) {
  closePalette();
  // If the command has a simple name, send it directly
  sendCommand(cmd.name);
}

function setActive(idx) {
  const items = document.querySelectorAll('#palette-results .pal-item');
  items.forEach(el => el.classList.remove('active'));
  if (idx >= 0 && idx < items.length) {
    items[idx].classList.add('active');
    items[idx].scrollIntoView({ block: 'nearest' });
  }
  activeIdx = idx;
}

/**
 * Initialise palette: bind input handlers.
 */
export function init() {
  const input = $('palette-input');
  if (!input) return;

  input.addEventListener('input', () => {
    renderResults(input.value);
  });

  input.addEventListener('keydown', (e) => {
    const items = document.querySelectorAll('#palette-results .pal-item');
    const count = items.length;

    if (e.key === 'Escape') {
      e.preventDefault();
      closePalette();
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      setActive(activeIdx < count - 1 ? activeIdx + 1 : 0);
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      setActive(activeIdx > 0 ? activeIdx - 1 : count - 1);
    } else if (e.key === 'Enter') {
      e.preventDefault();
      if (activeIdx >= 0 && activeIdx < count) {
        // Find the command from the rendered list
        const idx = parseInt(items[activeIdx].dataset.index, 10);
        const q = input.value.toLowerCase().trim();
        const filtered = q
          ? commands.filter(c =>
              c.name.toLowerCase().includes(q) ||
              (c.help && c.help.toLowerCase().includes(q)) ||
              (c.category && c.category.toLowerCase().includes(q))
            )
          : commands;
        if (filtered[idx]) executeFromPalette(filtered[idx]);
      } else if (input.value.trim()) {
        // Send raw input as command
        closePalette();
        sendCommand(input.value.trim());
      }
    }
  });

  // Click outside the palette box closes it
  const overlay = $('palette-overlay');
  if (overlay) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closePalette();
    });
  }
}
