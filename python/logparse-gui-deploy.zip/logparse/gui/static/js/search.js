import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $, log } from './utils.js';
import { sendCommand } from './commands.js';

/**
 * Toggle the search/filter panel.  When opening, requests field names
 * from the server to populate the filter-field dropdown.
 */
export function toggleSearch() {
  state.searchOpen = !state.searchOpen;
  const panel = $('search-panel');
  const btn = $('btn-search');

  if (state.searchOpen) {
    panel.classList.add('open');
    btn.classList.add('active');
    send({ type: 'field_names' });
    $('search-text').focus();
  } else {
    panel.classList.remove('open');
    btn.classList.remove('active');
  }
}

/**
 * Send a text search command to the server.
 */
export function applySearch() {
  const input = $('search-text');
  const text = input.value.trim();
  if (!text) return;
  sendCommand('search "' + text.replace(/"/g, '\\"') + '"');
  input.value = '';
}

/**
 * Build a `where` command from the field/operator/value dropdowns,
 * send it, and add a filter pill to the active-filters bar.
 */
export function addFilter() {
  const field = $('filter-field').value;
  const op = $('filter-op').value;
  const value = $('filter-value').value.trim();
  if (!field || !value) return;

  let cmd;
  if (op === 'contains') {
    cmd = 'where ' + field + ' contains ' + value;
  } else {
    cmd = 'where ' + field + op + value;
  }
  sendCommand(cmd);
  $('filter-value').value = '';

  // Add a visual pill representing the active filter
  const pill = document.createElement('span');
  pill.className = 'filter-pill';

  const label = document.createElement('span');
  label.textContent = field + ' ' + op + ' ' + value;
  pill.appendChild(label);

  const closeBtn = document.createElement('span');
  closeBtn.className = 'pill-x';
  closeBtn.textContent = '\u00d7';
  closeBtn.addEventListener('click', () => {
    pill.remove();
    sendCommand('undo');
  });
  pill.appendChild(closeBtn);

  $('active-filters').appendChild(pill);
}

/**
 * Populate the filter-field dropdown (and chart-builder field selects)
 * with the given list of field names.
 */
export function populateFieldDropdown(fields) {
  const sel = $('filter-field');
  const current = sel.value;
  sel.innerHTML = '<option value="">Field...</option>';
  fields.forEach(f => {
    const opt = document.createElement('option');
    opt.value = f;
    opt.textContent = f;
    sel.appendChild(opt);
  });
  if (current) sel.value = current;

  // Also populate chart builder field selects if they exist
  ['chart-field1', 'chart-field2'].forEach(id => {
    const cSel = $(id);
    if (!cSel) return;
    const cCurrent = cSel.value;
    const placeholder = cSel.options[0]?.textContent || 'Field...';
    cSel.innerHTML = '<option value="">' + placeholder + '</option>';
    fields.forEach(f => {
      const opt = document.createElement('option');
      opt.value = f;
      opt.textContent = f;
      cSel.appendChild(opt);
    });
    if (cCurrent) cSel.value = cCurrent;
  });
}

/**
 * Initialise search module: register WS handler, bind keyboard shortcuts
 * and header button.
 */
export function init() {
  onMessage('field_names', (msg) => populateFieldDropdown(msg.fields || []));

  // Enter key in search-text triggers search
  const searchText = $('search-text');
  if (searchText) {
    searchText.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); applySearch(); }
    });
  }

  // Enter key in filter-value triggers addFilter
  const filterValue = $('filter-value');
  if (filterValue) {
    filterValue.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); addFilter(); }
    });
  }

  // Bind header toggle button
  const btn = $('btn-search');
  if (btn) btn.addEventListener('click', () => toggleSearch());

  // Bind search panel buttons by ID
  const btnApply = $('btn-search-apply');
  if (btnApply) btnApply.addEventListener('click', () => applySearch());
  const btnAdd = $('btn-add-filter');
  if (btnAdd) btnAdd.addEventListener('click', () => addFilter());
  const btnUndo = $('btn-undo');
  if (btnUndo) btnUndo.addEventListener('click', () => sendCommand('undo'));
  const btnReset = $('btn-reset');
  if (btnReset) btnReset.addEventListener('click', () => sendCommand('reset'));
}
