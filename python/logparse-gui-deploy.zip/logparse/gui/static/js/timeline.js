/**
 * Timeline visualization panel - sends `timeline <interval> | visual line`
 * through the command interface and lets the existing Plotly chart
 * rendering pipeline display the result in #chart-panel.
 */

import { state } from './state.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';

const INTERVALS = [
  { label: '1 min',  value: '1m'  },
  { label: '5 min',  value: '5m'  },
  { label: '15 min', value: '15m' },
  { label: '30 min', value: '30m' },
  { label: '1 hour', value: '1h'  },
  { label: '1 day',  value: '1d'  },
];
const DEFAULT_INTERVAL = '1h';

let panelOpen = false;

/**
 * Toggle the timeline controls inside #chart-panel.
 * Selecting an interval and clicking "Generate" sends the appropriate
 * timeline + visual command.
 */
export function toggleTimeline() {
  panelOpen = !panelOpen;
  const btn = $('btn-timeline');
  if (btn) btn.classList.toggle('active', panelOpen);

  let container = $('timeline-controls');

  if (!panelOpen) {
    if (container) container.remove();
    return;
  }

  const chartPanel = $('chart-panel');
  if (!chartPanel) return;
  chartPanel.style.display = 'block';

  // Build the controls bar if it does not already exist
  if (!container) {
    container = document.createElement('div');
    container.id = 'timeline-controls';
    container.style.cssText =
      'display:flex;align-items:center;gap:8px;padding:6px 10px;' +
      'background:var(--surface-raised);border-bottom:1px solid var(--border);font-size:13px;';

    const label = document.createElement('span');
    label.textContent = 'Interval:';
    label.style.color = 'var(--text-secondary)';
    container.appendChild(label);

    // Interval selector - pill-style toggle buttons
    const group = document.createElement('div');
    group.id = 'timeline-interval-group';
    group.style.cssText = 'display:flex;gap:2px;';
    INTERVALS.forEach(iv => {
      const pill = document.createElement('button');
      pill.textContent = iv.label;
      pill.dataset.value = iv.value;
      pill.className = 'tl-pill';
      pill.style.cssText =
        'background:var(--surface-base);color:var(--text-secondary);border:1px solid var(--border);' +
        'border-radius:4px;padding:3px 8px;cursor:pointer;font-size:12px;transition:all 0.1s;';
      if (iv.value === DEFAULT_INTERVAL) {
        pill.style.background = 'var(--accent)';
        pill.style.color = '#fff';
        pill.style.borderColor = 'var(--accent)';
        pill.classList.add('active');
      }
      pill.addEventListener('click', () => selectInterval(pill));
      group.appendChild(pill);
    });
    container.appendChild(group);

    const genBtn = document.createElement('button');
    genBtn.textContent = 'Generate';
    genBtn.className = 'btn btn-sm';
    genBtn.style.cssText =
      'background:var(--accent);color:#fff;border:none;border-radius:4px;' +
      'padding:4px 10px;cursor:pointer;font-size:13px;';
    genBtn.addEventListener('click', () => generateTimeline());
    container.appendChild(genBtn);

    chartPanel.prepend(container);
  }
}

/**
 * Highlight the selected interval pill and deselect others.
 */
function selectInterval(pill) {
  const group = $('timeline-interval-group');
  if (!group) return;
  group.querySelectorAll('.tl-pill').forEach(p => {
    p.style.background = 'var(--surface-base)';
    p.style.color = 'var(--text-secondary)';
    p.style.borderColor = 'var(--border)';
    p.classList.remove('active');
  });
  pill.style.background = 'var(--accent)';
  pill.style.color = '#fff';
  pill.style.borderColor = 'var(--accent)';
  pill.classList.add('active');
}

/**
 * Read the currently selected interval and send the timeline command.
 */
function generateTimeline() {
  const group = $('timeline-interval-group');
  const active = group ? group.querySelector('.tl-pill.active') : null;
  const interval = active ? active.dataset.value : DEFAULT_INTERVAL;
  sendCommand('timeline ' + interval + ' | visual line');
}

/**
 * Initialise the timeline module.
 * Binds the header button if present.
 */
export function init() {
  const btn = $('btn-timeline');
  if (btn) btn.addEventListener('click', () => toggleTimeline());
}
