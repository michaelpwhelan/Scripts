import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { log, $ } from './utils.js';
import { showContextMenu } from './context-menu.js';

/**
 * Render the event table from server-provided page data.
 * Data shape: {columns, rows, total, page, page_size}
 * Row index (the # column) is row[0].
 */
export function updateTable(data) {
  log('updateTable: columns=' + (data.columns || []).length,
      'rows=' + (data.rows || []).length, 'total=' + data.total);
  state.tableData = data;
  state.currentPage = data.page || 0;
  const pageSize = data.page_size || 200;
  const total = data.total || 0;
  state.totalPages = Math.max(1, Math.ceil(total / pageSize));
  updatePagination();

  const head = $('table-head');
  const body = $('table-body');

  // Build header - indicator column + data columns
  head.innerHTML = '';
  const thInd = document.createElement('th');
  thInd.textContent = '';
  thInd.style.width = '36px';
  thInd.style.cursor = 'default';
  head.appendChild(thInd);

  (data.columns || []).forEach((col, i) => {
    const th = document.createElement('th');
    th.textContent = col;
    if (state.currentSort.col === i) {
      const arrow = document.createElement('span');
      arrow.className = 'sort-arrow';
      arrow.textContent = state.currentSort.dir === 'asc' ? ' \u25b2' : ' \u25bc';
      th.appendChild(arrow);
    }
    th.addEventListener('click', () => sortTable(i, col));
    head.appendChild(th);
  });

  // Build body rows
  body.innerHTML = '';
  (data.rows || []).forEach(row => {
    const tr = document.createElement('tr');
    const idx = parseInt(row[0], 10);

    // Indicators cell (star icon, tags, annotation marker)
    const tdInd = document.createElement('td');
    tdInd.style.padding = '4px';
    tdInd.style.textAlign = 'center';
    const meta = state.rowMeta[String(idx)] || {};

    const star = document.createElement('span');
    star.className = 'row-star';
    star.textContent = meta.starred ? '\u2605' : '\u2606';
    star.title = meta.starred ? 'Unstar' : 'Star';
    star.addEventListener('click', (e) => {
      e.stopPropagation();
      send({ type: 'star_toggle', index: idx });
    });
    tdInd.appendChild(star);

    if (meta.tags && meta.tags.length) {
      meta.tags.forEach(t => {
        const tag = document.createElement('span');
        tag.className = 'row-tag';
        tag.textContent = t;
        tdInd.appendChild(tag);
      });
    }
    if (meta.annotation) {
      const ann = document.createElement('span');
      ann.className = 'row-annot';
      ann.textContent = '\u270e';
      ann.title = meta.annotation;
      tdInd.appendChild(ann);
    }
    tr.appendChild(tdInd);

    // Data cells
    row.forEach((cell, i) => {
      const td = document.createElement('td');
      td.textContent = cell;
      if (data.columns[i] === 'Severity') td.className = 'sev-' + cell;
      tr.appendChild(td);
    });

    // Single click selects row
    tr.addEventListener('click', () => {
      document.querySelectorAll('#event-table tr.selected').forEach(r => r.classList.remove('selected'));
      tr.classList.add('selected');
    });

    // Double click opens detail
    tr.addEventListener('dblclick', () => {
      if (!isNaN(idx)) send({ type: 'event_detail', index: idx });
    });

    // Right click context menu
    tr.addEventListener('contextmenu', (e) => {
      e.preventDefault();
      state.ctxRowIdx = idx;
      state.ctxRowData = row;
      showContextMenu(e.clientX, e.clientY, meta);
    });

    body.appendChild(tr);
  });

  // Update table status text
  const status = $('table-status');
  const showing = (data.rows || []).length;
  status.textContent = `Showing ${showing} of ${total} events` +
    (state.currentPage > 0 ? ` (page ${state.currentPage + 1} of ${state.totalPages})` : '');

  // Request row metadata from server
  refreshRowMeta();
}

/**
 * Send a server-side sort request. The server re-sorts and returns a fresh page.
 */
function sortTable(colIdx, field) {
  if (state.currentSort.col === colIdx) {
    state.currentSort.dir = state.currentSort.dir === 'asc' ? 'desc' : 'asc';
  } else {
    state.currentSort = { col: colIdx, dir: 'asc', field: field || '' };
  }
  send({
    type: 'events_sorted',
    field: field || state.tableData.columns[colIdx] || '',
    direction: state.currentSort.dir,
    page: 0,
  });
}

/**
 * Request row metadata (starred, tags, annotations) for the current page.
 */
export function refreshRowMeta() {
  send({ type: 'row_meta', page: state.currentPage });
}

/**
 * Re-apply star/tag/annotation indicators to already-rendered rows.
 * Called after row_meta arrives or after a star toggle.
 */
export function applyRowIndicators() {
  const rows = document.querySelectorAll('#table-body tr');
  rows.forEach(tr => {
    const indCell = tr.firstElementChild;
    if (!indCell) return;
    // # column is the second cell (after the indicator cell)
    const idx = tr.children[1]?.textContent;
    if (!idx) return;
    const meta = state.rowMeta[idx] || {};
    const starEl = indCell.querySelector('.row-star');
    if (starEl) {
      starEl.textContent = meta.starred ? '\u2605' : '\u2606';
      starEl.title = meta.starred ? 'Unstar' : 'Star';
    }
  });
}

/**
 * Update the pagination button states and page info label.
 */
function updatePagination() {
  const info = $('page-info');
  info.textContent = `Page ${state.currentPage + 1} of ${state.totalPages}`;
  const btns = document.querySelectorAll('#pagination button');
  if (btns.length >= 4) {
    btns[0].disabled = btns[1].disabled = (state.currentPage <= 0);
    btns[2].disabled = btns[3].disabled = (state.currentPage >= state.totalPages - 1);
  }
}

/**
 * Navigate to a specific page by sending a request to the server.
 */
export function goPage(page) {
  if (page < 0 || page >= state.totalPages) return;
  send({ type: 'events_page', page });
}

/**
 * Initialise table module: register WS handlers and bind pagination buttons.
 */
export function init() {
  onMessage('events_page', (msg) => updateTable(msg));

  onMessage('row_meta', (msg) => {
    state.rowMeta = msg.meta || {};
    applyRowIndicators();
  });

  // Bind pagination buttons (they reference goPage via onclick in HTML,
  // but we also wire them here so modules work without inline handlers)
  const paginationBtns = document.querySelectorAll('#pagination button');
  if (paginationBtns.length >= 4) {
    paginationBtns[0].addEventListener('click', () => goPage(0));
    paginationBtns[1].addEventListener('click', () => goPage(state.currentPage - 1));
    paginationBtns[2].addEventListener('click', () => goPage(state.currentPage + 1));
    paginationBtns[3].addEventListener('click', () => goPage(state.totalPages - 1));
  }
}
