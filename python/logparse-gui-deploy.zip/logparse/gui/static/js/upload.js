import { log, logErr, $, appendSystemMsg } from './utils.js';
import { dispatch } from './ws.js';

let dragCounter = 0;

/**
 * Upload a single file to the server via multipart POST.
 * On success the JSON response is dispatched through the WS handler
 * system so all modules react as if it came over the socket.
 */
export async function uploadFile(file) {
  log('uploadFile:', file.name, file.size, 'bytes');
  appendSystemMsg(`Uploading ${file.name}...`);

  const form = new FormData();
  form.append('file', file);

  try {
    const resp = await fetch('/upload', { method: 'POST', body: form });
    log('upload response status:', resp.status);

    if (!resp.ok) {
      const text = await resp.text();
      logErr('upload HTTP error:', resp.status, text.substring(0, 200));
      appendSystemMsg(`Upload failed: HTTP ${resp.status}`, true);
      return;
    }

    let data;
    try {
      data = await resp.json();
    } catch (err) {
      logErr('upload response not JSON:', err);
      appendSystemMsg('Upload failed: bad response from server', true);
      return;
    }

    log('upload response:', data.type, 'total=' + data.total);
    // Route the response through the standard message dispatch so every
    // module (table, status bar, etc.) picks it up.
    dispatch(data);
  } catch (err) {
    logErr('uploadFile error:', err);
    appendSystemMsg(`Upload failed: ${err}`, true);
  }
}

/**
 * Initialise upload module: set up drag-and-drop handlers on the
 * document and the file-input change handler.
 */
export function init() {
  const overlay = $('drop-overlay');

  document.addEventListener('dragenter', (e) => {
    e.preventDefault();
    dragCounter++;
    overlay.classList.add('active');
  });

  document.addEventListener('dragleave', (e) => {
    e.preventDefault();
    dragCounter--;
    if (dragCounter <= 0) {
      dragCounter = 0;
      overlay.classList.remove('active');
    }
  });

  document.addEventListener('dragover', (e) => e.preventDefault());

  document.addEventListener('drop', async (e) => {
    e.preventDefault();
    dragCounter = 0;
    overlay.classList.remove('active');
    const files = e.dataTransfer.files;
    for (const file of files) {
      await uploadFile(file);
    }
  });

  // File dialog input
  const fileInput = $('file-input');
  if (fileInput) {
    fileInput.addEventListener('change', async (e) => {
      for (const file of e.target.files) {
        await uploadFile(file);
      }
      e.target.value = '';
    });
  }

  // "Load Files" button is bound in app.js via btn-load ID
}
