/**
 * MITRE ATT&CK matrix panel - sends the `mitre` command and displays
 * an interactive tactic/technique heatmap grid alongside the command
 * output in the output panel.
 */

import { $ } from './utils.js';
import { sendCommand } from './commands.js';

const TACTICS = [
  'Initial Access',
  'Execution',
  'Persistence',
  'Privilege Escalation',
  'Defense Evasion',
  'Credential Access',
  'Discovery',
  'Lateral Movement',
  'Collection',
  'Command and Control',
  'Exfiltration',
  'Impact',
];

let panelOpen = false;

/**
 * Toggle the MITRE ATT&CK overlay panel on the right side.
 * On open, sends the `mitre` command so the output panel receives the
 * full textual mapping, and renders a lightweight tactic header grid.
 */
export function toggleMitre() {
  panelOpen = !panelOpen;
  const btn = $('btn-mitre');
  if (btn) btn.classList.toggle('active', panelOpen);

  let panel = $('mitre-panel');

  if (!panelOpen) {
    if (panel) {
      panel.classList.remove('open');
      panel.style.display = 'none';
    }
    return;
  }

  // Create the panel element on first open
  if (!panel) {
    panel = document.createElement('div');
    panel.id = 'mitre-panel';
    panel.style.cssText =
      'position:fixed;top:40px;right:0;bottom:24px;width:420px;' +
      'background:var(--surface-raised);border-left:1px solid var(--border);' +
      'overflow-y:auto;z-index:50;padding:12px;display:none;' +
      'transition:transform 0.15s ease;box-shadow:-2px 0 8px rgba(0,0,0,0.3);';
    document.body.appendChild(panel);
  }

  panel.classList.add('open');
  panel.style.display = 'block';

  // Send the command - results appear in the output panel via the
  // normal result handler; we also build a visual matrix here.
  sendCommand('mitre');
  renderMatrix(panel);
}

/**
 * Render a static MITRE ATT&CK tactic grid inside the given container.
 * Technique cells are intentionally left empty - the real data is shown
 * by the command output.  The grid serves as a visual reference that
 * highlights which tactic columns exist.
 */
function renderMatrix(panel) {
  let html =
    '<div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px">' +
      '<h3 style="margin:0;font-size:14px;color:var(--text-primary)">MITRE ATT&CK Matrix</h3>' +
      '<button id="mitre-close" style="background:none;border:none;color:var(--text-secondary);' +
        'cursor:pointer;font-size:16px" title="Close">&times;</button>' +
    '</div>' +
    '<p style="font-size:12px;color:var(--text-secondary);margin:0 0 10px">' +
      'Command output shows detected techniques. Grid below maps the 12 ATT&CK tactics.' +
    '</p>' +
    '<div style="display:flex;gap:2px;flex-wrap:wrap">';

  TACTICS.forEach(t => {
    const abbr = t.split(' ').map(w => w[0]).join('');
    html +=
      '<div class="mitre-cell" title="' + t + '" style="' +
        'flex:1 0 calc(25% - 4px);min-width:90px;max-width:120px;' +
        'background:var(--surface-base);border:1px solid var(--border);border-radius:4px;' +
        'padding:6px 4px;text-align:center;font-size:11px;color:var(--text-secondary);' +
        'cursor:default;transition:background 0.15s">' +
        '<div style="font-weight:600;color:var(--accent);font-size:13px">' + abbr + '</div>' +
        '<div style="margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' + t + '</div>' +
      '</div>';
  });

  html += '</div>';

  // Quick-action buttons
  html +=
    '<div style="margin-top:14px;display:flex;gap:6px;flex-wrap:wrap">' +
      '<button class="mitre-action btn btn-sm" data-cmd="mitre" style="' + btnStyle() + '">Refresh</button>' +
      '<button class="mitre-action btn btn-sm" data-cmd="mitre | export html" style="' + btnStyle() + '">Export HTML</button>' +
      '<button class="mitre-action btn btn-sm" data-cmd="mitre | export json" style="' + btnStyle() + '">Export JSON</button>' +
    '</div>';

  panel.innerHTML = html;

  // Bind close button
  const closeBtn = $('mitre-close');
  if (closeBtn) closeBtn.addEventListener('click', () => toggleMitre());

  // Bind quick-action buttons
  panel.querySelectorAll('.mitre-action').forEach(b => {
    b.addEventListener('click', () => {
      const cmd = b.dataset.cmd;
      if (cmd) sendCommand(cmd);
    });
  });
}

function btnStyle() {
  return 'background:var(--surface-base);color:var(--text-primary);border:1px solid var(--border);' +
    'border-radius:4px;padding:4px 10px;cursor:pointer;font-size:12px;';
}

/**
 * Initialise the MITRE module.
 * Binds the header button if present.
 */
export function init() {
  const btn = $('btn-mitre');
  if (btn) btn.addEventListener('click', () => toggleMitre());
}
