import { log, logErr, logWarn, $ } from './utils.js';

const handlers = {};  // type -> [fn, ...]
let ws = null;
let reconnectDelay = 2000;
const MAX_DELAY = 30000;
let queue = [];
let heartbeatTimer = null;
let pongTimeout = null;

/**
 * Register a handler for a specific message type.
 * Use type '*' to receive all messages.
 */
export function onMessage(type, fn) {
  (handlers[type] ||= []).push(fn);
}

/**
 * Send an object as JSON over the WebSocket.
 * If the socket is not open, the message is queued and flushed on reconnect.
 */
export function send(obj) {
  if (ws && ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify(obj));
  } else {
    queue.push(obj);
  }
}

function setStatus(status) {
  const el = $('conn-status');
  if (!el) return;
  el.textContent = status.charAt(0).toUpperCase() + status.slice(1);
  el.className = status;
  const cmdBar = $('cmd-bar');
  if (cmdBar) {
    cmdBar.classList.toggle('disconnected', status !== 'connected');
  }
}

function startHeartbeat() {
  stopHeartbeat();
  heartbeatTimer = setInterval(() => {
    if (!ws || ws.readyState !== WebSocket.OPEN) return;
    ws.send(JSON.stringify({ type: 'ping' }));
    pongTimeout = setTimeout(() => {
      logWarn('Pong timeout, forcing reconnect');
      if (ws) ws.close();
    }, 5000);
  }, 30000);
}

function stopHeartbeat() {
  if (heartbeatTimer !== null) {
    clearInterval(heartbeatTimer);
    heartbeatTimer = null;
  }
  if (pongTimeout !== null) {
    clearTimeout(pongTimeout);
    pongTimeout = null;
  }
}

export function dispatch(msg) {
  const fns = handlers[msg.type] || [];
  for (const fn of fns) {
    try { fn(msg); } catch (err) { logErr('handler error:', err); }
  }
  const wildcards = handlers['*'] || [];
  for (const fn of wildcards) {
    try { fn(msg); } catch (err) { logErr('handler error:', err); }
  }
}

/**
 * Open the WebSocket connection with automatic reconnection.
 */
export function connect() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const url = `${proto}://${location.host}/ws`;
  log('WebSocket connecting to', url);
  setStatus('reconnecting');

  ws = new WebSocket(url);

  ws.onopen = () => {
    log('WebSocket connected');
    reconnectDelay = 2000;
    setStatus('connected');
    // Flush queued messages
    while (queue.length) {
      ws.send(JSON.stringify(queue.shift()));
    }
    // Resync session state after reconnect
    send({ type: 'session_state' });
    startHeartbeat();
  };

  ws.onmessage = (e) => {
    let msg;
    try { msg = JSON.parse(e.data); } catch { return; }
    // Handle pong for heartbeat
    if (msg.type === 'pong') {
      clearTimeout(pongTimeout);
      pongTimeout = null;
      return;
    }
    dispatch(msg);
  };

  ws.onerror = (e) => logErr('WebSocket error:', e);

  ws.onclose = (e) => {
    logWarn('WebSocket closed:', e.code, e.reason);
    stopHeartbeat();
    setStatus('disconnected');
    setTimeout(() => {
      reconnectDelay = Math.min(reconnectDelay * 2, MAX_DELAY);
      connect();
    }, reconnectDelay);
  };
}
