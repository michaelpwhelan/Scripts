import { $ } from './utils.js';

export function init() {
  const resizeHandle = $('resize-handle');
  const outputPanel = $('output-panel');
  let isResizing = false;

  resizeHandle.addEventListener('mousedown', (e) => {
    isResizing = true;
    e.preventDefault();
    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
  });

  document.addEventListener('mousemove', (e) => {
    if (!isResizing) return;
    const mainEl = $('main');
    const mainRect = mainEl.getBoundingClientRect();
    const newWidth = e.clientX - mainRect.left;
    const pct = (newWidth / mainRect.width) * 100;
    if (pct > 15 && pct < 75) {
      outputPanel.style.width = pct + '%';
    }
  });

  document.addEventListener('mouseup', () => {
    if (!isResizing) return;
    isResizing = false;
    document.body.style.cursor = '';
    document.body.style.userSelect = '';
  });
}
