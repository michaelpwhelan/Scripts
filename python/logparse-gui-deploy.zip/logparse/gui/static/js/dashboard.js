import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $ } from './utils.js';

const SEV_COLORS = {
  Critical: '#ff5555',
  High:     '#ff8c42',
  Medium:   '#ffd166',
  Low:      '#06d6a0',
  Info:     '#118ab2',
};

/**
 * Toggle the dashboard panel.  When opening, hides the table and
 * requests fresh dashboard data from the server.
 */
export function toggleDashboard() {
  state.dashboardOpen = !state.dashboardOpen;
  const panel = $('dashboard-panel');
  const btn = $('btn-dashboard');
  const tableContainer = $('table-container');
  const tableStatus = $('table-status');
  const detailPanel = $('detail-panel');

  if (state.dashboardOpen) {
    // Close sibling overlay panels and reset their state flags
    const ap = $('analyzer-panel');
    const rp = $('report-panel');
    if (ap) ap.classList.remove('open');
    if (rp) rp.classList.remove('open');
    const ab = $('btn-analyzers');
    const rb = $('btn-reports');
    if (ab) ab.classList.remove('active');
    if (rb) rb.classList.remove('active');
    state.analyzerOpen = false;
    state.reportOpen = false;

    btn.classList.add('active');
    panel.classList.add('open');
    tableContainer.style.display = 'none';
    tableStatus.style.display = 'none';
    detailPanel.style.display = 'none';
    send({ type: 'dashboard' });
  } else {
    btn.classList.remove('active');
    panel.classList.remove('open');
    tableContainer.style.display = '';
    tableStatus.style.display = '';
  }
}

/**
 * Build the dashboard HTML from the server-provided data object.
 * Expected keys: total, severity, top_sources, top_ips, hourly,
 *                recent_alerts, time_range.
 */
export function renderDashboard(data) {
  const panel = $('dashboard-panel');
  const total = data.total || 0;
  const sev = data.severity || {};
  const maxSev = Math.max(...Object.values(sev), 1);

  // Severity distribution rows
  let sevRows = '';
  for (const s of ['Critical', 'High', 'Medium', 'Low', 'Info']) {
    const c = sev[s] || 0;
    const pct = total ? ((c / total) * 100).toFixed(1) : '0.0';
    const barW = ((c / maxSev) * 100).toFixed(0);
    sevRows +=
      '<div class="dash-row">' +
        '<span class="label" style="color:' + SEV_COLORS[s] + '">' + s + '</span>' +
        '<div class="dash-bar-track"><div class="dash-bar-fill" style="width:' + barW + '%;background:' + SEV_COLORS[s] + '"></div></div>' +
        '<span class="count">' + c + ' (' + pct + '%)</span>' +
      '</div>';
  }

  // Top sources
  const sources = data.top_sources || [];
  const maxSrc = sources.length ? sources[0][1] : 1;
  let srcRows = '';
  sources.forEach(([name, count]) => {
    const barW = ((count / maxSrc) * 100).toFixed(0);
    srcRows +=
      '<div class="dash-row"><span class="label">' + esc(name) + '</span>' +
        '<div class="dash-bar-track"><div class="dash-bar-fill" style="width:' + barW + '%;background:var(--accent)"></div></div>' +
        '<span class="count">' + count + '</span>' +
      '</div>';
  });

  // Top IPs
  const ips = data.top_ips || [];
  const maxIp = ips.length ? ips[0][1] : 1;
  let ipRows = '';
  ips.forEach(([ip, count]) => {
    const barW = ((count / maxIp) * 100).toFixed(0);
    ipRows +=
      '<div class="dash-row"><span class="label">' + esc(ip) + '</span>' +
        '<div class="dash-bar-track"><div class="dash-bar-fill" style="width:' + barW + '%;background:var(--accent)"></div></div>' +
        '<span class="count">' + count + '</span>' +
      '</div>';
  });

  // Hourly activity mini-bar chart
  const hourly = data.hourly || [];
  const maxH = Math.max(...hourly, 1);
  let hourlyBars = '';
  let hourLabels = '';
  for (let h = 0; h < 24; h++) {
    const pct = ((hourly[h] || 0) / maxH * 100).toFixed(0);
    hourlyBars +=
      '<div class="dash-hourly-bar" style="height:' + Math.max(pct, 2) +
      '%" title="' + String(h).padStart(2, '0') + ':00 -- ' + (hourly[h] || 0) + ' events"></div>';
    hourLabels += (h % 6 === 0)
      ? '<span>' + String(h).padStart(2, '0') + '</span>'
      : '<span></span>';
  }

  // Recent alerts
  const alerts = data.recent_alerts || [];
  let alertRows = '';
  if (alerts.length === 0) {
    alertRows = '<div style="color:var(--text-muted);font-size:12px">No critical/high events</div>';
  }
  alerts.forEach(a => {
    const ts = a.timestamp ? a.timestamp.split(' ').pop() || '' : '';
    alertRows +=
      '<div class="dash-alert-item">' +
        '<span class="ts">' + esc(ts) + '</span>' +
        '<span style="color:' + (SEV_COLORS[a.severity] || 'var(--text-primary)') + ';font-size:11px">' + esc(a.severity) + '</span>' +
        '<span class="msg">' + esc(a.message) + '</span>' +
      '</div>';
  });

  // Time range
  const tr = data.time_range || {};
  const timeStr = tr.first && tr.last
    ? tr.first.replace('T', ' ').substring(0, 19) + '  --  ' + tr.last.replace('T', ' ').substring(0, 19)
    : 'No timestamps';

  panel.innerHTML =
    '<div class="dash-grid">' +
      '<div class="dash-card"><h3>Overview</h3>' +
        '<div class="dash-stat">' + total.toLocaleString() + '</div>' +
        '<div class="dash-stat-label">Total events</div>' +
        '<div style="margin-top:8px;font-size:12px;color:var(--text-secondary)">' + timeStr + '</div>' +
      '</div>' +
      '<div class="dash-card"><h3>Severity</h3>' + sevRows + '</div>' +
      '<div class="dash-card"><h3>Hourly Activity</h3>' +
        '<div class="dash-hourly">' + hourlyBars + '</div>' +
        '<div class="dash-hour-labels">' + hourLabels + '</div>' +
      '</div>' +
      '<div class="dash-card"><h3>Recent Alerts</h3>' + alertRows + '</div>' +
      '<div class="dash-card"><h3>Top Sources</h3>' +
        (srcRows || '<div style="color:var(--text-muted);font-size:12px">No sources</div>') +
      '</div>' +
      '<div class="dash-card"><h3>Top Source IPs</h3>' +
        (ipRows || '<div style="color:var(--text-muted);font-size:12px">No IPs</div>') +
      '</div>' +
    '</div>';
}

function esc(s) {
  return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

/**
 * Initialise dashboard module: register WS handler and bind header button.
 */
export function init() {
  onMessage('dashboard_data', (msg) => renderDashboard(msg));

  const btn = $('btn-dashboard');
  if (btn) btn.addEventListener('click', () => toggleDashboard());
}
