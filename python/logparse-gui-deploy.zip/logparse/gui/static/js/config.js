/**
 * Configuration UI - display columns, timestamp format, theme, noise profiles.
 */

import { $ } from './utils.js';
import { send, onMessage } from './ws.js';
import { sendCommand } from './commands.js';

let configOpen = false;

export function toggleConfig() {
  configOpen = !configOpen;
  let panel = $('config-panel');

  if (!panel) {
    // Create config panel dynamically
    panel = document.createElement('div');
    panel.id = 'config-panel';
    panel.style.cssText = `
      display:none; position:fixed; top:50%; left:50%; transform:translate(-50%,-50%);
      background:var(--surface-raised); border:1px solid var(--border); border-radius:4px;
      padding:20px; min-width:400px; max-height:80vh; overflow-y:auto; z-index:500;
      font-size:12px;
    `;
    document.body.appendChild(panel);

    // Backdrop
    const backdrop = document.createElement('div');
    backdrop.id = 'config-backdrop';
    backdrop.style.cssText = `
      display:none; position:fixed; inset:0; background:rgba(0,0,0,0.5); z-index:499;
    `;
    backdrop.addEventListener('click', () => toggleConfig());
    document.body.appendChild(backdrop);
  }

  const backdrop = $('config-backdrop');
  if (configOpen) {
    renderConfig(panel);
    panel.style.display = 'block';
    if (backdrop) backdrop.style.display = 'block';
  } else {
    panel.style.display = 'none';
    if (backdrop) backdrop.style.display = 'none';
  }
}

function renderConfig(panel) {
  panel.innerHTML = `
    <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
      <h3 style="font-size:15px;color:var(--text-primary);margin:0">Settings</h3>
      <span id="config-close" style="cursor:pointer;color:var(--text-secondary);font-size:18px">&times;</span>
    </div>

    <div style="margin-bottom:12px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-secondary);margin-bottom:4px">Display Columns</div>
      <div style="color:var(--text-muted);font-size:11px;margin-bottom:4px">
        Use the <code>select</code> command to change columns (e.g., <code>select Timestamp Severity Source srcip dstip Message</code>)
      </div>
      <button id="config-select-default" style="background:var(--surface-overlay);color:var(--text-primary);border:1px solid var(--border);padding:3px 10px;border-radius:2px;font-family:var(--font-mono);font-size:11px;cursor:pointer">
        Reset to Default
      </button>
    </div>

    <div style="margin-bottom:12px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-secondary);margin-bottom:4px">Timestamp Format</div>
      <div style="display:flex;gap:8px">
        <button class="ts-fmt" data-fmt="datetime">datetime</button>
        <button class="ts-fmt" data-fmt="time">time</button>
        <button class="ts-fmt" data-fmt="relative">relative</button>
      </div>
    </div>

    <div style="margin-bottom:12px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-secondary);margin-bottom:4px">Noise Profile</div>
      <div style="display:flex;gap:8px;align-items:center">
        <input type="text" id="config-noise" placeholder="Profile name..."
               style="background:var(--surface-base);color:var(--text-primary);border:1px solid var(--border);padding:3px 6px;font-family:var(--font-mono);font-size:11px;border-radius:2px;outline:none;width:160px">
        <button id="config-noise-apply" style="background:var(--surface-overlay);color:var(--text-primary);border:1px solid var(--border);padding:3px 10px;border-radius:2px;font-family:var(--font-mono);font-size:11px;cursor:pointer">Apply</button>
      </div>
    </div>

    <div style="margin-bottom:12px">
      <div style="font-size:11px;text-transform:uppercase;letter-spacing:0.8px;color:var(--text-secondary);margin-bottom:4px">Quick Commands</div>
      <div style="display:flex;gap:4px;flex-wrap:wrap">
        <button class="quick-cmd" data-cmd="help">Help</button>
        <button class="quick-cmd" data-cmd="cheatsheet">Cheatsheet</button>
        <button class="quick-cmd" data-cmd="clear">Clear Output</button>
      </div>
    </div>
  `;

  // Style the buttons
  panel.querySelectorAll('.ts-fmt, .quick-cmd, #config-select-default, #config-noise-apply').forEach(btn => {
    btn.style.cssText = 'background:var(--surface-overlay);color:var(--text-primary);border:1px solid var(--border);padding:3px 10px;border-radius:2px;font-family:var(--font-mono);font-size:11px;cursor:pointer;';
  });

  // Bind events
  $('config-close').addEventListener('click', () => toggleConfig());

  $('config-select-default').addEventListener('click', () => {
    sendCommand('select Timestamp Severity Source Message');
    toggleConfig();
  });

  panel.querySelectorAll('.ts-fmt').forEach(btn => {
    btn.addEventListener('click', () => {
      sendCommand('set timestamp_format ' + btn.dataset.fmt);
      toggleConfig();
    });
  });

  const noiseApply = $('config-noise-apply');
  if (noiseApply) {
    noiseApply.addEventListener('click', () => {
      const name = $('config-noise').value.trim();
      if (name) {
        sendCommand('config noise ' + name);
        toggleConfig();
      }
    });
  }

  panel.querySelectorAll('.quick-cmd').forEach(btn => {
    btn.addEventListener('click', () => {
      sendCommand(btn.dataset.cmd);
      toggleConfig();
    });
  });
}

export function init() {
  // No default button in header; config is accessible via command palette or Ctrl+,
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.key === ',') {
      e.preventDefault();
      toggleConfig();
    }
  });
}
