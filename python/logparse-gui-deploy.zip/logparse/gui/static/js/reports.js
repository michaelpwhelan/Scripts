import { state } from './state.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';

const REPORTS = [
  { name: 'summary',     desc: 'Overview with severity distribution and top sources' },
  { name: 'morning',     desc: 'Daily security briefing' },
  { name: 'audit',       desc: 'Detailed audit trail' },
  { name: 'compliance',  desc: 'FFIEC/NCUA compliance mapping' },
  { name: 'evidence',    desc: 'Forensic evidence documentation' },
  { name: 'timeline',    desc: 'Chronological event timeline' },
  { name: 'security',    desc: 'Security-focused narrative report' },
  { name: 'traffic',     desc: 'Network traffic analysis' },
  { name: 'incident',    desc: 'Incident reconstruction with MITRE mapping' },
  { name: 'correlation', desc: 'Cross-source correlation findings' },
  { name: 'sla',         desc: 'SLA compliance metrics' },
];

/**
 * Toggle the report panel.  Closes sibling overlay panels (dashboard,
 * analyzers) first so only one panel is visible at a time.
 */
export function toggleReports() {
  state.reportOpen = !state.reportOpen;
  const panel = $('report-panel');
  const btn = $('btn-reports');
  const tableContainer = $('table-container');
  const tableStatus = $('table-status');
  const detailPanel = $('detail-panel');

  // Close sibling overlay panels and reset their state flags
  closePanel('dashboard-panel', 'btn-dashboard');
  state.dashboardOpen = false;
  closePanel('analyzer-panel', 'btn-analyzers');
  state.analyzerOpen = false;

  if (state.reportOpen) {
    btn.classList.add('active');
    panel.classList.add('open');
    tableContainer.style.display = 'none';
    tableStatus.style.display = 'none';
    detailPanel.style.display = 'none';
    renderReports();
  } else {
    btn.classList.remove('active');
    panel.classList.remove('open');
    tableContainer.style.display = '';
    tableStatus.style.display = '';
  }
}

function closePanel(panelId, btnId) {
  const p = $(panelId);
  const b = $(btnId);
  if (p) p.classList.remove('open');
  if (b) b.classList.remove('active');
}

/**
 * Render the report list as a card grid.
 */
function renderReports() {
  const panel = $('report-panel');
  if (!panel) return;

  let html =
    '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">' +
      '<h3 style="font-size:13px;font-weight:600;color:var(--text-primary)">Reports</h3>' +
    '</div>' +
    '<div class="card-grid">';

  for (const r of REPORTS) {
    html +=
      '<div class="feature-card">' +
        '<h4>' + escHtml(r.name) + '</h4>' +
        '<div class="card-desc">' + escHtml(r.desc) + '</div>' +
        '<div class="card-actions">' +
          '<button data-report="' + escAttr(r.name) + '">Generate</button>' +
          '<button data-export="' + escAttr(r.name) + '">Export HTML</button>' +
        '</div>' +
      '</div>';
  }

  html += '</div>';
  panel.innerHTML = html;

  // Bind "Generate" buttons
  panel.querySelectorAll('[data-report]').forEach(btn => {
    btn.addEventListener('click', () => {
      sendCommand('report ' + btn.dataset.report);
    });
  });

  // Bind "Export HTML" buttons - generates then exports
  panel.querySelectorAll('[data-export]').forEach(btn => {
    btn.addEventListener('click', () => {
      sendCommand('report ' + btn.dataset.export);
      // Queue the export after a short delay so the report renders first
      setTimeout(() => sendCommand('export html'), 500);
    });
  });
}

function escHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function escAttr(s) {
  return s.replace(/&/g, '&amp;').replace(/"/g, '&quot;');
}

/**
 * Initialise: bind the header button.
 */
export function init() {
  const btn = $('btn-reports');
  if (btn) btn.addEventListener('click', () => toggleReports());
}
