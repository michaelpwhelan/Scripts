import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';

// Chart types that require a second field selector
const TWO_FIELD_TYPES = ['scatter', 'flow', 'treemap'];

/**
 * Toggle the chart builder panel.  When opening, requests field names
 * from the server and adjusts field selector visibility.
 */
export function toggleChartBuilder() {
  state.chartBuilderOpen = !state.chartBuilderOpen;
  const panel = $('chart-builder');
  const btn = $('btn-charts');

  if (state.chartBuilderOpen) {
    panel.classList.add('open');
    btn.classList.add('active');
    send({ type: 'field_names' });
    updateChartFieldVisibility();
  } else {
    panel.classList.remove('open');
    btn.classList.remove('active');
  }
}

/**
 * Show or hide the second field dropdown depending on the selected
 * chart type (scatter, flow, treemap need two fields).
 */
function updateChartFieldVisibility() {
  const type = $('chart-type').value;
  const f2 = $('chart-field2');
  f2.style.display = TWO_FIELD_TYPES.includes(type) ? '' : 'none';
}

/**
 * Build the appropriate visual/count command from the current chart
 * type and field selections, then send it.
 */
export function renderChart() {
  const type = $('chart-type').value;
  const f1 = $('chart-field1').value;
  const f2 = $('chart-field2').value;

  let cmd;
  if (type === 'severity') {
    cmd = 'visual severity';
  } else if (type === 'heatmap') {
    cmd = 'visual heatmap';
  } else if (type === 'geo') {
    cmd = 'visual geo' + (f1 ? ' ' + f1 : '');
  } else if (TWO_FIELD_TYPES.includes(type) && f1 && f2) {
    cmd = 'visual ' + type + ' ' + f1 + ' ' + f2;
  } else if (f1) {
    if (type === 'dist') cmd = 'visual dist ' + f1;
    else if (type === 'line') cmd = 'visual line';
    else cmd = 'count by ' + f1 + ' | visual ' + type;
  } else {
    cmd = 'visual ' + type;
  }

  sendCommand(cmd);
}

/**
 * Initialise chart-builder module: register change listener on
 * chart-type select, bind buttons and header toggle.
 */
export function init() {
  const chartType = $('chart-type');
  if (chartType) {
    chartType.addEventListener('change', updateChartFieldVisibility);
  }

  // Header toggle button
  const btn = $('btn-charts');
  if (btn) btn.addEventListener('click', () => toggleChartBuilder());

  // Bind chart builder buttons by ID
  const btnRender = $('btn-chart-render');
  if (btnRender) btnRender.addEventListener('click', () => renderChart());
  const btnBar = $('btn-quick-bar');
  if (btnBar) btnBar.addEventListener('click', () => sendCommand('visual bar'));
  const btnPie = $('btn-quick-pie');
  if (btnPie) btnPie.addEventListener('click', () => sendCommand('visual pie'));
}
