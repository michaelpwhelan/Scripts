import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';

/**
 * Toggle the investigation sidebar panel.
 * When opening, triggers an immediate refresh of the panel contents.
 */
export function toggleInvestPanel() {
  state.investOpen = !state.investOpen;
  const panel = $('invest-panel');
  const btn = $('btn-invest');

  if (state.investOpen) {
    panel.classList.add('open');
    btn.classList.add('active');
    refreshInvestPanel();
  } else {
    panel.classList.remove('open');
    btn.classList.remove('active');
  }
}

/**
 * Rebuild the investigation sidebar contents from state.sessionState.
 * Sections: starred events, tags, annotations, quick actions.
 */
export function refreshInvestPanel() {
  if (!state.investOpen) return;

  const panel = $('invest-panel');
  const s = state.sessionState;
  const starredIndices = s.starred_indices || [];
  const allTags = s.all_tags || [];

  let html = '';

  // -- Starred events --
  html += '<div class="inv-section">' +
    '<div class="inv-header">Starred <span class="inv-count">' + starredIndices.length + '</span></div>';
  if (starredIndices.length === 0) {
    html += '<div class="inv-empty">No starred events. Right-click a row to star.</div>';
  } else {
    starredIndices.slice(0, 20).forEach(idx => {
      html += '<div class="inv-item" data-action="detail" data-idx="' + idx + '">' +
        '<span class="inv-idx">#' + idx + '</span>' +
        '<span class="inv-msg">Event ' + idx + '</span></div>';
    });
    if (starredIndices.length > 20) {
      html += '<div class="inv-empty">... and ' + (starredIndices.length - 20) + ' more</div>';
    }
  }
  html += '</div>';

  // -- Tags --
  html += '<div class="inv-section">' +
    '<div class="inv-header">Tags <span class="inv-count">' + allTags.length + '</span></div>';
  if (allTags.length === 0) {
    html += '<div class="inv-empty">No tags. Right-click a row to tag.</div>';
  } else {
    allTags.forEach(tag => {
      html += '<div class="inv-item" data-action="filter-tag" data-tag="' + tag + '">' +
        '<span class="inv-tag">' + tag + '</span>' +
        '<span class="inv-msg">Click to filter</span></div>';
    });
  }
  html += '</div>';

  // -- Annotations --
  const annotCount = s.annotations_count || 0;
  html += '<div class="inv-section">' +
    '<div class="inv-header">Annotations <span class="inv-count">' + annotCount + '</span></div>';
  if (annotCount === 0) {
    html += '<div class="inv-empty">No annotations. Right-click a row to annotate.</div>';
  } else {
    html += '<div class="inv-empty">' + annotCount + ' annotated events</div>';
  }
  html += '</div>';

  // -- Quick actions --
  html += '<div class="inv-section"><div class="inv-header">Quick Actions</div>';
  html += '<div class="inv-item" data-action="cmd" data-cmd="show starred">' +
    '<span class="inv-icon">&#9733;</span><span class="inv-msg">Show starred events</span></div>';
  html += '<div class="inv-item" data-action="cmd" data-cmd="annotate list">' +
    '<span class="inv-icon">&#9998;</span><span class="inv-msg">List annotations</span></div>';
  html += '<div class="inv-item" data-action="cmd" data-cmd="export star">' +
    '<span class="inv-icon">&#8594;</span><span class="inv-msg">Export starred</span></div>';
  html += '<div class="inv-item" data-action="cmd" data-cmd="summary">' +
    '<span class="inv-icon">&#8801;</span><span class="inv-msg">Summary report</span></div>';
  html += '</div>';

  panel.innerHTML = html;

  // Bind click handlers via delegation — remove previous listener first
  // to prevent unbounded accumulation on repeated refreshes.
  panel.removeEventListener('click', handleInvestClick);
  panel.addEventListener('click', handleInvestClick);
}

function handleInvestClick(e) {
  const item = e.target.closest('.inv-item');
  if (!item) return;

  const action = item.dataset.action;
  if (action === 'detail') {
    const idx = parseInt(item.dataset.idx, 10);
    if (!isNaN(idx)) send({ type: 'event_detail', index: idx });
  } else if (action === 'filter-tag') {
    sendCommand('where tag=' + item.dataset.tag);
  } else if (action === 'cmd') {
    sendCommand(item.dataset.cmd);
  }
}

/**
 * Initialise investigation module: register WS handler for session_state
 * updates and bind the header button.
 */
export function init() {
  // When session state updates, refresh the investigation panel
  onMessage('session_state', (msg) => {
    if (msg.session) {
      state.sessionState = msg.session;
      refreshInvestPanel();
    }
  });

  const btn = $('btn-invest');
  if (btn) btn.addEventListener('click', () => toggleInvestPanel());
}
