import { onMessage } from './ws.js';
import { $ } from './utils.js';

/**
 * Render the event detail panel with key-value pairs.
 * msg.fields is an object of {fieldName: value}.
 */
export function showDetail(msg) {
  const panel = $('detail-panel');
  const table = $('detail-table');
  table.innerHTML = '';

  const fields = msg.fields || {};
  for (const [key, val] of Object.entries(fields)) {
    const tr = document.createElement('tr');
    const tdKey = document.createElement('td');
    tdKey.textContent = key;
    const tdVal = document.createElement('td');
    tdVal.textContent = val;
    if (key === 'Severity') tdVal.className = 'sev-' + val;
    tr.appendChild(tdKey);
    tr.appendChild(tdVal);
    table.appendChild(tr);
  }

  panel.style.display = 'block';
}

/**
 * Close the detail panel and deselect any highlighted table rows.
 */
export function closeDetail() {
  $('detail-panel').style.display = 'none';
  document.querySelectorAll('#event-table tr.selected').forEach(r => r.classList.remove('selected'));
}

/**
 * Initialise detail module: register WS handler and bind close button.
 */
export function init() {
  onMessage('detail', (msg) => showDetail(msg));

  // Bind the close button inside the detail panel
  const closeBtn = document.querySelector('#detail-panel .close-btn');
  if (closeBtn) {
    closeBtn.addEventListener('click', () => closeDetail());
  }
}
