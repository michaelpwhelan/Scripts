/**
 * Session save/resume UI - provides a modal for saving the current
 * session, listing saved sessions, and resuming a previous one.
 * Uses the existing `save_session` and `resume` REPL commands.
 */

import { $ } from './utils.js';
import { send, onMessage } from './ws.js';
import { sendCommand } from './commands.js';
import { appendSystemMsg } from './utils.js';

let modalOpen = false;

/**
 * Toggle the sessions modal overlay.
 * On open, requests the session list from the server.
 */
export function toggleSessions() {
  modalOpen = !modalOpen;

  let overlay = $('sessions-overlay');

  if (!modalOpen) {
    if (overlay) {
      overlay.classList.remove('open');
      overlay.style.display = 'none';
    }
    return;
  }

  // Create overlay on first open
  if (!overlay) {
    overlay = document.createElement('div');
    overlay.id = 'sessions-overlay';
    overlay.style.cssText =
      'position:fixed;inset:0;background:rgba(0,0,0,0.55);z-index:100;' +
      'display:flex;align-items:center;justify-content:center;';

    const modal = document.createElement('div');
    modal.id = 'sessions-modal';
    modal.style.cssText =
      'background:var(--surface-raised);border:1px solid var(--border);border-radius:8px;' +
      'width:440px;max-height:80vh;display:flex;flex-direction:column;' +
      'box-shadow:0 8px 32px rgba(0,0,0,0.5);';

    // Header
    const header = document.createElement('div');
    header.style.cssText =
      'display:flex;align-items:center;justify-content:space-between;' +
      'padding:12px 16px;border-bottom:1px solid var(--border);';
    const title = document.createElement('h3');
    title.textContent = 'Sessions';
    title.style.cssText = 'margin:0;font-size:14px;color:var(--text-primary);';
    const closeBtn = document.createElement('button');
    closeBtn.id = 'sessions-close';
    closeBtn.innerHTML = '&times;';
    closeBtn.style.cssText =
      'background:none;border:none;color:var(--text-secondary);cursor:pointer;font-size:18px;';
    closeBtn.addEventListener('click', () => toggleSessions());
    header.appendChild(title);
    header.appendChild(closeBtn);
    modal.appendChild(header);

    // Save form
    const saveForm = document.createElement('div');
    saveForm.style.cssText =
      'display:flex;gap:6px;padding:12px 16px;border-bottom:1px solid var(--border);';
    const nameInput = document.createElement('input');
    nameInput.id = 'session-name-input';
    nameInput.type = 'text';
    nameInput.placeholder = 'Session name';
    nameInput.style.cssText =
      'flex:1;background:var(--surface-base);color:var(--text-primary);border:1px solid var(--border);' +
      'border-radius:4px;padding:5px 8px;font-size:13px;outline:none;';
    nameInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') saveSession();
    });
    const saveBtn = document.createElement('button');
    saveBtn.id = 'session-save-btn';
    saveBtn.textContent = 'Save';
    saveBtn.style.cssText =
      'background:var(--accent);color:#fff;border:none;border-radius:4px;' +
      'padding:5px 14px;cursor:pointer;font-size:13px;';
    saveBtn.addEventListener('click', () => saveSession());
    saveForm.appendChild(nameInput);
    saveForm.appendChild(saveBtn);
    modal.appendChild(saveForm);

    // Session list container
    const listContainer = document.createElement('div');
    listContainer.id = 'sessions-list';
    listContainer.style.cssText =
      'flex:1;overflow-y:auto;padding:8px 16px;min-height:120px;';
    listContainer.innerHTML =
      '<div style="color:var(--text-muted);font-size:12px;padding:16px 0;text-align:center">' +
        'Loading sessions...' +
      '</div>';
    modal.appendChild(listContainer);

    overlay.appendChild(modal);

    // Close on backdrop click
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) toggleSessions();
    });

    document.body.appendChild(overlay);
  }

  overlay.classList.add('open');
  overlay.style.display = 'flex';

  // Focus the name input
  const nameInput = $('session-name-input');
  if (nameInput) {
    nameInput.value = '';
    setTimeout(() => nameInput.focus(), 50);
  }

  // Request session list
  requestSessionList();
}

/**
 * Save the current session using the name entered in the input field.
 * Falls back to 'auto' if the field is empty.
 */
function saveSession() {
  const nameInput = $('session-name-input');
  const name = (nameInput ? nameInput.value.trim() : '') || 'auto';
  sendCommand('save_session ' + name);
  appendSystemMsg('Session saved: ' + name);
  if (nameInput) nameInput.value = '';

  // Refresh the list after a short delay to let the server process
  setTimeout(requestSessionList, 400);
}

/**
 * Ask the server for the list of saved sessions.
 * Sends a command whose output will be captured by the result handler;
 * we also send a dedicated WS message so the server can respond with
 * structured data if supported.
 */
function requestSessionList() {
  send({ type: 'session_list' });
}

/**
 * Render the session list from structured data.
 * Each entry shows the session name, date, and a Resume button.
 */
function renderSessionList(sessions) {
  const container = $('sessions-list');
  if (!container) return;

  if (!sessions || sessions.length === 0) {
    container.innerHTML =
      '<div style="color:var(--text-muted);font-size:12px;padding:16px 0;text-align:center">' +
        'No saved sessions found.' +
      '</div>';
    return;
  }

  let html = '';
  sessions.forEach(s => {
    const name = typeof s === 'string' ? s : (s.name || s);
    const date = (s && s.date) ? s.date : '';
    const total = (s && s.events != null) ? s.events + ' events' : '';

    html +=
      '<div class="session-entry" style="' +
        'display:flex;align-items:center;justify-content:space-between;' +
        'padding:8px 0;border-bottom:1px solid var(--border);">' +
        '<div style="flex:1;min-width:0">' +
          '<div style="font-size:13px;color:var(--text-primary);' +
            'white-space:nowrap;overflow:hidden;text-overflow:ellipsis">' +
            escapeHtml(name) +
          '</div>' +
          '<div style="font-size:11px;color:var(--text-muted)">' +
            escapeHtml(date) + (total ? ' &middot; ' + total : '') +
          '</div>' +
        '</div>' +
        '<button class="session-resume-btn" data-name="' + escapeAttr(name) + '" style="' +
          'background:var(--surface-base);color:var(--accent);border:1px solid var(--border);' +
          'border-radius:4px;padding:3px 10px;cursor:pointer;font-size:12px;' +
          'white-space:nowrap;margin-left:8px;">Resume</button>' +
      '</div>';
  });

  container.innerHTML = html;

  // Bind resume buttons
  container.querySelectorAll('.session-resume-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const name = btn.dataset.name;
      sendCommand('resume ' + name);
      appendSystemMsg('Resuming session: ' + name);
      toggleSessions();
    });
  });
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function escapeAttr(str) {
  return str.replace(/&/g, '&amp;').replace(/"/g, '&quot;')
            .replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/**
 * Initialise the sessions module.
 * Registers WS handlers for session_list responses and binds UI triggers.
 */
export function init() {
  // Handle structured session list from server
  onMessage('session_list', (msg) => {
    renderSessionList(msg.sessions || []);
  });

  // Ctrl+S is already handled in app.js (quick-save).
  // Bind any dedicated header button for the full sessions panel.
  const btn = $('btn-sessions');
  if (btn) btn.addEventListener('click', () => toggleSessions());
}
