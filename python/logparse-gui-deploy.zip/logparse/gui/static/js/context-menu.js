import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { $ } from './utils.js';
import { sendCommand } from './commands.js';
import { refreshRowMeta, applyRowIndicators } from './table.js';
import { refreshInvestPanel } from './investigation.js';

// Fields worth showing in the filter/exclude submenu.
// Skip '#' (synthetic index) and very long fields like Message/raw.
const SKIP_FIELDS = new Set(['#', 'message', 'raw']);
const MAX_VALUE_LEN = 40;

/**
 * Build and show the right-click context menu for a table row.
 * Dynamically populates filter/exclude items from the row's actual data.
 */
export function showContextMenu(x, y, meta) {
  const menu = $('ctx-menu');

  // Update star label
  const label = $('ctx-star-label');
  label.textContent = meta.starred ? 'Unstar' : 'Star';

  // Build dynamic filter/exclude items from the row data
  buildDynamicFilters();

  menu.style.left = x + 'px';
  menu.style.top = y + 'px';
  menu.style.display = 'block';

  // Clamp to viewport edges
  const rect = menu.getBoundingClientRect();
  if (rect.right > window.innerWidth) menu.style.left = (x - rect.width) + 'px';
  if (rect.bottom > window.innerHeight) menu.style.top = (y - rect.height) + 'px';
}

/**
 * Populate #ctx-dynamic-filters with concrete field:value pairs
 * from the right-clicked row, so the user sees exactly what each
 * action will do.
 */
function buildDynamicFilters() {
  const container = $('ctx-dynamic-filters');
  if (!container) return;
  container.innerHTML = '';

  const cols = state.tableData.columns || [];
  const row = state.ctxRowData || [];
  if (!cols.length || !row.length) return;

  // Collect non-empty, non-skip field:value pairs
  const pairs = [];
  for (let i = 0; i < cols.length; i++) {
    const field = cols[i];
    const value = row[i];
    if (SKIP_FIELDS.has(field.toLowerCase()) || SKIP_FIELDS.has(field)) continue;
    if (value == null || value === '') continue;
    pairs.push({ field, value });
  }

  if (pairs.length === 0) return;

  // Show up to 4 most useful filter options, then up to 4 exclude options
  const shown = pairs.slice(0, 4);

  for (const { field, value } of shown) {
    const display = value.length > MAX_VALUE_LEN ? value.slice(0, MAX_VALUE_LEN) + '...' : value;
    const filterDiv = document.createElement('div');
    filterDiv.className = 'ctx-item';
    filterDiv.innerHTML = '<span class="ctx-icon">&#8801;</span> ' +
      '<span style="color:var(--text-secondary)">' + escHtml(field) + ' = </span>' +
      escHtml(display);
    filterDiv.addEventListener('click', (e) => {
      e.stopPropagation();
      sendCommand('where ' + field.toLowerCase() + ':' + value);
      hideContextMenu();
    });
    container.appendChild(filterDiv);
  }

  // Separator between filter and exclude
  if (shown.length > 0) {
    const sep = document.createElement('div');
    sep.className = 'ctx-sep';
    container.appendChild(sep);
  }

  for (const { field, value } of shown) {
    const display = value.length > MAX_VALUE_LEN ? value.slice(0, MAX_VALUE_LEN) + '...' : value;
    const excludeDiv = document.createElement('div');
    excludeDiv.className = 'ctx-item';
    excludeDiv.innerHTML = '<span class="ctx-icon">&#8800;</span> ' +
      '<span style="color:var(--text-secondary)">' + escHtml(field) + ' != </span>' +
      escHtml(display);
    excludeDiv.addEventListener('click', (e) => {
      e.stopPropagation();
      sendCommand('where ' + field.toLowerCase() + '!=' + value);
      hideContextMenu();
    });
    container.appendChild(excludeDiv);
  }
}

function escHtml(s) {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function hideContextMenu() {
  $('ctx-menu').style.display = 'none';
}

// -- Static context menu actions --

function ctxStar() {
  if (state.ctxRowIdx >= 0) send({ type: 'star_toggle', index: state.ctxRowIdx });
}

function ctxTag() {
  if (state.ctxRowIdx < 0) return;
  state.modalMode = 'tag';
  state.modalIdx = state.ctxRowIdx;
  $('modal-title').textContent = 'Tag Event #' + state.ctxRowIdx;
  $('modal-input').placeholder = 'Enter tag label...';
  $('modal-input').value = '';
  $('tag-modal').classList.add('open');
  $('modal-input').focus();
}

function ctxAnnotate() {
  if (state.ctxRowIdx < 0) return;
  state.modalMode = 'annotate';
  state.modalIdx = state.ctxRowIdx;
  const existing = (state.rowMeta[String(state.ctxRowIdx)] || {}).annotation || '';
  $('modal-title').textContent = 'Annotate Event #' + state.ctxRowIdx;
  $('modal-input').placeholder = 'Enter note...';
  $('modal-input').value = existing;
  $('tag-modal').classList.add('open');
  $('modal-input').focus();
}

function ctxCopy() {
  if (state.ctxRowData.length) {
    navigator.clipboard.writeText(state.ctxRowData.join('\t')).catch(() => {});
  }
}

// -- Modal (shared by tag and annotate) --

export function closeModal() {
  $('tag-modal').classList.remove('open');
  state.modalMode = '';
  state.modalIdx = -1;
}

export function submitModal() {
  const val = $('modal-input').value.trim();
  if (!val && state.modalMode === 'tag') { closeModal(); return; }
  if (state.modalMode === 'tag') {
    send({ type: 'tag_event', index: state.modalIdx, label: val });
  } else if (state.modalMode === 'annotate') {
    send({ type: 'annotate_event', index: state.modalIdx, text: val });
  }
  closeModal();
}

// -- Star result handling --

function onStarResult(msg) {
  const key = String(msg.index);
  if (!state.rowMeta[key]) state.rowMeta[key] = {};
  state.rowMeta[key].starred = msg.starred;
  applyRowIndicators();
  const statStarred = $('stat-starred');
  if (statStarred) statStarred.textContent = msg.total_starred || 0;
  refreshInvestPanel();
}

/**
 * Initialise context-menu module.
 */
export function init() {
  onMessage('star_result', (msg) => onStarResult(msg));
  onMessage('tag_result', () => { refreshRowMeta(); refreshInvestPanel(); });
  onMessage('annotate_result', () => { refreshRowMeta(); refreshInvestPanel(); });

  // Click anywhere outside the menu closes it
  document.addEventListener('click', (e) => {
    const menu = $('ctx-menu');
    if (menu && menu.contains(e.target)) return;
    hideContextMenu();
  });

  // Bind static context menu items (star, tag, annotate, copy)
  const menu = $('ctx-menu');
  const actions = { star: ctxStar, tag: ctxTag, annotate: ctxAnnotate, copy: ctxCopy };
  if (menu) {
    menu.addEventListener('click', (e) => {
      e.stopPropagation();
      const item = e.target.closest('.ctx-item');
      if (!item) { hideContextMenu(); return; }
      const action = item.dataset.action;
      // Dynamic filter/exclude items have their own click handlers,
      // so only dispatch for items with data-action attributes
      if (action && actions[action]) actions[action]();
      if (action) hideContextMenu();
    });
  }

  // Modal keyboard shortcuts
  const modalInput = $('modal-input');
  if (modalInput) {
    modalInput.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') { e.preventDefault(); submitModal(); }
      if (e.key === 'Escape') closeModal();
    });
  }

  // Modal buttons
  const modalBtns = document.querySelectorAll('#tag-modal .modal-actions button');
  if (modalBtns.length >= 2) {
    modalBtns[0].addEventListener('click', () => closeModal());
    modalBtns[1].addEventListener('click', () => submitModal());
  }
}
