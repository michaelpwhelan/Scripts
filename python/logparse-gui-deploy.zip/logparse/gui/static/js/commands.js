import { state } from './state.js';
import { send, onMessage } from './ws.js';
import { log, $ } from './utils.js';

let compIdx = -1;
let compOptions = [];

export function init() {
  const cmdInput = $('cmd-input');

  cmdInput.addEventListener('keydown', (e) => {
    // When completions are visible, arrow keys navigate them
    if (compOptions.length > 0 && (e.key === 'ArrowDown' || e.key === 'ArrowUp')) {
      e.preventDefault();
      navigateCompletions(e.key === 'ArrowDown' ? 1 : -1);
      return;
    }

    if (e.key === 'Enter') {
      if (compOptions.length > 0 && compIdx >= 0) {
        // Accept the highlighted completion
        e.preventDefault();
        applyCompletion(compOptions[compIdx]);
        return;
      }
      const text = cmdInput.value.trim();
      if (!text) return;
      state.cmdHistory.push(text);
      state.historyIdx = state.cmdHistory.length;
      sendCommand(text);
      cmdInput.value = '';
      hideCompletions();
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (state.historyIdx > 0) {
        state.historyIdx--;
        cmdInput.value = state.cmdHistory[state.historyIdx];
      }
    } else if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (state.historyIdx < state.cmdHistory.length - 1) {
        state.historyIdx++;
        cmdInput.value = state.cmdHistory[state.historyIdx];
      } else {
        state.historyIdx = state.cmdHistory.length;
        cmdInput.value = '';
      }
    } else if (e.key === 'Tab') {
      e.preventDefault();
      if (compOptions.length > 0) {
        // Cycle through visible completions
        navigateCompletions(1);
      } else {
        requestCompletions();
      }
    } else if (e.key === 'Escape') {
      hideCompletions();
    }
  });

  // Hide completions when input loses focus (slight delay so click events fire)
  cmdInput.addEventListener('blur', () => {
    setTimeout(hideCompletions, 150);
  });

  onMessage('completions', (msg) => showCompletions(msg.options || []));
}

export function sendCommand(text) {
  log('command:', text);
  send({ type: 'command', text });
}

function requestCompletions() {
  const cmdInput = $('cmd-input');
  const text = cmdInput.value;
  if (!text) return;
  send({ type: 'complete', partial: text });
}

function showCompletions(options) {
  const compBox = $('completions');
  if (!compBox) return;
  compOptions = options;
  compIdx = -1;
  compBox.innerHTML = '';

  if (options.length === 0) {
    compBox.style.display = 'none';
    return;
  }

  // If there is exactly one option, apply it immediately
  if (options.length === 1) {
    applyCompletion(options[0]);
    return;
  }

  // Position the dropdown below the command input
  const cmdInput = $('cmd-input');
  const rect = cmdInput.getBoundingClientRect();
  compBox.style.left = rect.left + 'px';
  compBox.style.top = (rect.bottom + 2) + 'px';
  compBox.style.minWidth = rect.width + 'px';
  compBox.style.display = 'block';

  for (let i = 0; i < options.length; i++) {
    const item = document.createElement('div');
    item.className = 'completion-item';
    item.textContent = options[i];
    item.addEventListener('mousedown', (e) => {
      e.preventDefault();
      applyCompletion(options[i]);
    });
    compBox.appendChild(item);
  }
}

function hideCompletions() {
  const compBox = $('completions');
  if (compBox) compBox.style.display = 'none';
  compOptions = [];
  compIdx = -1;
}

function navigateCompletions(direction) {
  if (compOptions.length === 0) return;
  const compBox = $('completions');
  if (!compBox) return;

  // Remove highlight from current item
  const items = compBox.querySelectorAll('.completion-item');
  if (compIdx >= 0 && compIdx < items.length) {
    items[compIdx].classList.remove('active');
  }

  // Move index
  compIdx += direction;
  if (compIdx >= compOptions.length) compIdx = 0;
  if (compIdx < 0) compIdx = compOptions.length - 1;

  // Highlight new item
  items[compIdx].classList.add('active');
  items[compIdx].scrollIntoView({ block: 'nearest' });
}

function applyCompletion(option) {
  const cmdInput = $('cmd-input');
  const text = cmdInput.value;
  const cursor = cmdInput.selectionStart;

  // Find the start of the last word before the cursor
  const before = text.slice(0, cursor);
  const lastSpace = before.lastIndexOf(' ');
  const prefix = lastSpace === -1 ? '' : text.slice(0, lastSpace + 1);
  const after = text.slice(cursor);

  cmdInput.value = prefix + option + (after.length > 0 ? after : ' ');
  const newCursor = (prefix + option + ' ').length;
  cmdInput.setSelectionRange(newCursor, newCursor);
  cmdInput.focus();

  hideCompletions();
}
