#!/usr/bin/env python3
"""WebConsole adapter - wraps Rich Console to capture HTML output."""

from __future__ import annotations

import io
import json
import logging
import traceback
from typing import Any

from rich.console import Console

_log = logging.getLogger(__name__)


class WebConsole(Console):
    """Rich Console subclass that records output for web delivery.

    Extends Console(record=True) so all print/rule/table calls are
    captured.  After a command executes, call ``capture_result(session)``
    to extract:
      - styled HTML fragment of the console output
      - any new Plotly charts added to the session
      - serialized event table page
    """

    def __init__(self, width: int = 120) -> None:
        super().__init__(
            file=io.StringIO(),
            record=True,
            force_terminal=True,
            color_system="truecolor",
            width=width,
            markup=True,
            highlight=False,
        )
        self._chart_cursor: int = 0  # tracks session.charts index
        _log.info("WebConsole initialized (width=%d)", width)

    def capture_result(self, session: Any) -> dict:
        """Extract accumulated output and new charts, then reset buffer."""
        # 1. Rich HTML fragment
        try:
            html = self.export_html(inline_styles=True, code_format="<pre>{code}</pre>")
            _log.info("capture_result: exported %d bytes of HTML", len(html))
        except Exception as exc:
            _log.error("capture_result: export_html failed: %s\n%s",
                       exc, traceback.format_exc())
            html = f"<pre style='color:red'>export_html error: {exc}</pre>"

        # Clear the recording buffer for the next command
        try:
            self._record_buffer.clear()
            if isinstance(self.file, io.StringIO):
                self.file.truncate(0)
                self.file.seek(0)
        except Exception as exc:
            _log.error("capture_result: buffer clear failed: %s", exc)

        # 2. New Plotly charts
        charts: list[dict] = []
        session_charts = getattr(session, "charts", [])
        new_chart_count = len(session_charts) - self._chart_cursor
        if new_chart_count > 0:
            new_charts = session_charts[self._chart_cursor:]
            self._chart_cursor = len(session_charts)
            _log.info("capture_result: %d new chart(s) to convert", new_chart_count)
            charts = _convert_charts(new_charts)
            _log.info("capture_result: converted %d chart(s) to Plotly JSON", len(charts))

        # 3. Session state snapshot
        session_state = {
            "total": len(session.all_events),
            "filtered": len(session.filtered_events),
            "active_filter": session.active_filter or "",
            "filter_depth": len(session.filter_history),
            "starred": len(session.starred),
            "charts_count": len(session_charts),
        }

        return {
            "type": "result",
            "html": html,
            "charts": charts,
            "session": session_state,
        }


def _convert_charts(chart_list: list) -> list[dict]:
    """Convert ChartData objects to Plotly JSON dicts for the browser."""
    results = []
    try:
        from logparse.visual.html.plotly_charts import chart_to_plotly
    except ImportError:
        _log.warning("_convert_charts: plotly not available")
        return results

    for i, chart_data in enumerate(chart_list):
        try:
            _log.info("  converting chart %d: type=%s title=%r",
                       i, chart_data.chart_type, chart_data.title)
            fig = chart_to_plotly(chart_data)
        except Exception as exc:
            _log.error("  chart_to_plotly failed for chart %d: %s\n%s",
                       i, exc, traceback.format_exc())
            continue
        if fig is None:
            _log.warning("  chart_to_plotly returned None for chart %d", i)
            continue
        try:
            fig_json = json.loads(fig.to_json())
            fig_json["div_id"] = f"chart-{id(chart_data)}"
            results.append(fig_json)
            _log.info("  chart %d converted OK (%d bytes)", i, len(fig.to_json()))
        except Exception as exc:
            _log.error("  chart %d JSON conversion failed: %s\n%s",
                       i, exc, traceback.format_exc())
    return results
