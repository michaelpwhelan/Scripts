#!/usr/bin/env python3
"""TLS certificate generation for the logparse GUI server.

Uses the ``cryptography`` library (optional gui dependency) to create a
self-signed certificate + private key pair suitable for local HTTPS.
"""

from __future__ import annotations

import datetime
import ipaddress
import logging
from pathlib import Path

_log = logging.getLogger(__name__)


def ensure_cert(config_dir: Path) -> tuple[Path, Path]:
    """Return (cert_path, key_path), generating them if they don't exist.

    Certificates are stored under ``config_dir / "certs" /``.
    """
    certs_dir = config_dir / "certs"
    cert_path = certs_dir / "logparse.pem"
    key_path = certs_dir / "logparse-key.pem"

    if cert_path.exists() and key_path.exists():
        _log.info("Using existing TLS cert: %s", cert_path)
        return cert_path, key_path

    _log.info("Generating self-signed TLS certificate in %s", certs_dir)
    certs_dir.mkdir(parents=True, exist_ok=True)

    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
    except ImportError:
        raise RuntimeError(
            "TLS certificate generation requires the 'cryptography' package.\n"
            "Install it with: pip install 'logparse[gui]'"
        ) from None

    # Generate 2048-bit RSA private key
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
    )

    # Build self-signed certificate
    subject = issuer = x509.Name([
        x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME, "logparse"),
    ])

    now = datetime.datetime.now(datetime.timezone.utc)
    cert = (
        x509.CertificateBuilder()
        .subject_name(subject)
        .issuer_name(issuer)
        .public_key(private_key.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(now)
        .not_valid_after(now + datetime.timedelta(days=365))
        .add_extension(
            x509.SubjectAlternativeName([
                x509.DNSName("localhost"),
                x509.IPAddress(ipaddress.IPv4Address("127.0.0.1")),
            ]),
            critical=False,
        )
        .sign(private_key, hashes.SHA256())
    )

    # Write PEM files
    key_path.write_bytes(
        private_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption(),
        )
    )
    cert_path.write_bytes(cert.public_bytes(serialization.Encoding.PEM))

    _log.info("TLS certificate generated: %s", cert_path)
    print(f"Generated self-signed TLS certificate: {cert_path}")
    return cert_path, key_path
