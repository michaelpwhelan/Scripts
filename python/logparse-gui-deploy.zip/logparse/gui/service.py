#!/usr/bin/env python3
"""Windows Service helpers using NSSM (Non-Sucking Service Manager).

NSSM wraps any executable as a Windows Service without requiring pywin32.
These helpers generate and optionally execute the NSSM commands needed to
install, uninstall, start, and stop the logparse GUI as a service.
"""

from __future__ import annotations

import os
import shutil
import sys
from typing import Any


SERVICE_NAME = "logparse-gui"
SERVICE_DISPLAY = "logparse GUI Server"
SERVICE_DESCRIPTION = "Log investigation web GUI for infrastructure log files"


def _find_nssm() -> str | None:
    """Return the path to nssm.exe if it's on the PATH."""
    return shutil.which("nssm")


def _python_exe() -> str:
    """Return the path to the current Python interpreter."""
    return sys.executable


def _build_args(cli_args: Any) -> str:
    """Build the logparse CLI argument string from parsed args."""
    parts = ["-m", "logparse", "--gui"]
    bind = getattr(cli_args, "bind", None) or "127.0.0.1"
    parts.extend(["--bind", bind])
    if getattr(cli_args, "tls", False):
        parts.append("--tls")
    if getattr(cli_args, "cert", None):
        parts.extend(["--cert", cli_args.cert])
    if getattr(cli_args, "key", None):
        parts.extend(["--key", cli_args.key])
    return " ".join(parts)


def print_install_commands(cli_args: Any) -> None:
    """Print (and optionally execute) NSSM install commands."""
    python = _python_exe()
    app_args = _build_args(cli_args)
    nssm = _find_nssm()

    print(f"=== logparse GUI - Windows Service Install ===\n")

    if nssm:
        print(f"NSSM found at: {nssm}\n")
    else:
        print("NSSM not found on PATH.")
        print("Download from: https://nssm.cc/download")
        print("Then add nssm.exe to your PATH and re-run.\n")

    print("Run these commands in an elevated (Administrator) terminal:\n")
    print(f'  nssm install {SERVICE_NAME} "{python}" {app_args}')
    print(f'  nssm set {SERVICE_NAME} DisplayName "{SERVICE_DISPLAY}"')
    print(f'  nssm set {SERVICE_NAME} Description "{SERVICE_DESCRIPTION}"')
    print(f'  nssm set {SERVICE_NAME} AppRestartDelay 5000')
    print(f'  nssm set {SERVICE_NAME} AppStopMethodSkip 6')

    # Log file in config dir
    if os.name == "nt":
        log_dir = os.path.join(os.environ.get("APPDATA", ""), "logparse", "logs")
    else:
        log_dir = os.path.expanduser("~/.logparse/logs")
    print(f'  nssm set {SERVICE_NAME} AppStdout "{log_dir}\\gui.log"')
    print(f'  nssm set {SERVICE_NAME} AppStderr "{log_dir}\\gui.log"')
    print(f'  nssm set {SERVICE_NAME} AppRotateFiles 1')
    print(f'  nssm set {SERVICE_NAME} AppRotateBytes 10485760')
    print()
    print(f"  nssm start {SERVICE_NAME}")
    print()
    print(f"The service will auto-restart on failure (5s delay).")
    print(f"Logs written to: {log_dir}\\gui.log")


def print_uninstall_commands() -> None:
    """Print NSSM uninstall commands."""
    print(f"=== logparse GUI - Windows Service Uninstall ===\n")
    print("Run these commands in an elevated (Administrator) terminal:\n")
    print(f"  nssm stop {SERVICE_NAME}")
    print(f"  nssm remove {SERVICE_NAME} confirm")
    print()
