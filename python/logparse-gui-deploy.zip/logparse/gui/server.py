#!/usr/bin/env python3
"""FastAPI web server for the logparse GUI."""

import logging
from pathlib import Path
from typing import Any

try:
    from fastapi import FastAPI
    from fastapi.responses import HTMLResponse
    from starlette.staticfiles import StaticFiles
except ImportError:
    FastAPI = StaticFiles = HTMLResponse = None  # type: ignore[assignment,misc]

from logparse.commands import CommandContext
from logparse.gui.state import AppState
from logparse.gui.web_console import WebConsole
from logparse.session import Session

_log = logging.getLogger(__name__)

_STATIC_DIR = Path(__file__).parent / "static"


def _get_app(api_key: str | None = None) -> "FastAPI":
    """Build and return the FastAPI application."""
    from logparse.gui.routes.api import router as api_router
    from logparse.gui.routes.upload import router as upload_router
    from logparse.gui.routes.ws import router as ws_router

    app = FastAPI(title="logparse GUI")

    # Security headers and optional API key via a single ASGI wrapper that
    # skips WebSocket connections (BaseHTTPMiddleware is not WS-safe in
    # older Starlette versions).
    from starlette.types import ASGIApp, Receive, Scope, Send

    class SecurityWrapper:
        """Thin ASGI middleware that adds security headers to HTTP responses
        and enforces an optional API key.  WebSocket scopes are passed
        through untouched.
        """

        def __init__(self, app: ASGIApp) -> None:
            self.app = app

        async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
            if scope["type"] != "http":
                await self.app(scope, receive, send)
                return

            # Optional API key check
            if api_key:
                from starlette.requests import Request as _Req
                req = _Req(scope)
                path = req.url.path
                if not (path == "/" or path.startswith("/static") or path == "/docs"):
                    key = req.headers.get("x-api-key") or req.query_params.get("api_key")
                    if key != api_key:
                        await send({"type": "http.response.start", "status": 401,
                                    "headers": [[b"content-type", b"text/plain"]]})
                        await send({"type": "http.response.body", "body": b"Unauthorized"})
                        return

            async def send_with_headers(message):
                if message["type"] == "http.response.start":
                    headers = list(message.get("headers", []))
                    headers.append([b"content-security-policy",
                                    b"default-src 'self'; script-src 'self' 'unsafe-inline'; "
                                    b"style-src 'self' 'unsafe-inline'; img-src 'self' data:; "
                                    b"connect-src 'self' ws: wss:"])
                    headers.append([b"x-content-type-options", b"nosniff"])
                    headers.append([b"x-frame-options", b"DENY"])
                    headers.append([b"referrer-policy", b"no-referrer"])
                    message = {**message, "headers": headers}
                await send(message)

            await self.app(scope, receive, send_with_headers)

    app.add_middleware(SecurityWrapper)

    # Mount route modules
    app.include_router(ws_router)
    app.include_router(upload_router)
    app.include_router(api_router)

    # Serve static assets (JS modules, CSS, vendor libs)
    app.mount("/static", StaticFiles(directory=str(_STATIC_DIR)), name="static")

    @app.get("/", response_class=HTMLResponse)
    async def index():
        html_path = _STATIC_DIR / "index.html"
        _log.info("GET / - serving %s (%s bytes)", html_path, html_path.stat().st_size)
        return HTMLResponse(html_path.read_text(encoding="utf-8"))

    return app


def launch_gui(args: Any) -> None:
    """Entry point called from ``logparse --gui``."""
    try:
        import uvicorn
    except ImportError:
        print("GUI mode requires: pip install 'logparse[gui]'")
        print("  (fastapi, uvicorn, python-multipart)")
        return

    # Set up logging so we can see what's happening
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(name)s %(levelname)s  %(message)s",
        datefmt="%H:%M:%S",
    )
    _log.info("Initializing GUI server")

    console = WebConsole()
    ctx = CommandContext(console=console)

    # Pre-load files if given on command line
    input_paths = getattr(args, "paths", None) or []
    if input_paths:
        _log.info("Pre-loading files: %s", input_paths)
        from logparse.loader import load_files
        events, loaded_files, loaded_formats = load_files(input_paths, quiet=True)
        session = Session(
            all_events=events,
            filtered_events=list(events),
            source_files=loaded_files,
            loaded_formats=loaded_formats,
        )
        from logparse.config_loader import load_config
        session.config = load_config()
        _log.info("Loaded %d events from %d file(s)", len(events), len(loaded_files))
        print(f"Loaded {len(events)} events from {len(loaded_files)} file(s)")
    else:
        _log.info("No input files - starting with empty session")
        session = Session(
            all_events=[],
            filtered_events=[],
            source_files=[],
            loaded_formats=[],
        )
        from logparse.config_loader import load_config
        session.config = load_config()

    # Build app and attach state
    api_key = getattr(args, "api_key", None)
    app = _get_app(api_key=api_key)
    app.state.lp = AppState(session=session, console=console, ctx=ctx)

    import socket
    import webbrowser

    # Find an available port
    host = getattr(args, "bind", None) or "127.0.0.1"
    port = 8077
    for attempt_port in range(8077, 8100):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            if s.connect_ex((host, attempt_port)) != 0:
                port = attempt_port
                break

    # TLS configuration
    ssl_kwargs: dict[str, Any] = {}
    if getattr(args, "tls", False):
        from logparse.gui.tls import ensure_cert
        from logparse.config_loader import get_config_dir
        cert_path, key_path = ensure_cert(get_config_dir())
        ssl_kwargs["ssl_certfile"] = str(cert_path)
        ssl_kwargs["ssl_keyfile"] = str(key_path)
        _log.info("TLS enabled: cert=%s key=%s", cert_path, key_path)
    elif getattr(args, "cert", None) and getattr(args, "key", None):
        ssl_kwargs["ssl_certfile"] = args.cert
        ssl_kwargs["ssl_keyfile"] = args.key
        _log.info("TLS enabled (user certs): cert=%s key=%s", args.cert, args.key)

    scheme = "https" if ssl_kwargs else "http"
    url = f"{scheme}://{host}:{port}"
    print(f"logparse GUI starting at {url}")
    print("Press Ctrl+C to stop.\n")
    _log.info("Starting uvicorn on %s:%d", host, port)

    # Open browser after a short delay
    import threading
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()

    uvicorn.run(app, host=host, port=port, log_level="info", **ssl_kwargs)
