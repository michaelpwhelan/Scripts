#!/usr/bin/env python3
"""WebSocket endpoint and message dispatch for the logparse GUI."""

from __future__ import annotations

import json
import logging
import traceback
from collections import Counter
from pathlib import Path
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from logparse.dispatch import execute_input, get_completions
from logparse.gui.event_serializer import serialize_events, serialize_event_detail
from logparse.gui.state import AppState
from logparse.models import get_field
from logparse.session import Session

_log = logging.getLogger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# WebSocket endpoint
# ---------------------------------------------------------------------------

@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    _log.info("WebSocket connection request from %s", ws.client)
    await ws.accept()
    _log.info("WebSocket accepted")
    lp: AppState = ws.app.state.lp
    try:
        while True:
            data = await ws.receive_text()
            _log.info("WS recv: %s", data[:200])
            try:
                msg = json.loads(data)
            except json.JSONDecodeError as exc:
                _log.error("WS bad JSON: %s", exc)
                await ws.send_text(json.dumps({
                    "type": "error", "message": f"Bad JSON: {exc}",
                }))
                continue

            try:
                resp = handle_message(lp, msg)
            except Exception as exc:
                _log.error("WS handle_message crashed: %s\n%s",
                           exc, traceback.format_exc())
                resp = {"type": "error", "message": f"Server error: {exc}"}

            try:
                resp_text = json.dumps(resp)
            except (TypeError, ValueError) as exc:
                _log.error("WS response not JSON-serializable: %s\n%s",
                           exc, traceback.format_exc())
                bad_keys = []
                for k, v in resp.items():
                    try:
                        json.dumps({k: v})
                    except (TypeError, ValueError):
                        bad_keys.append(f"{k}={type(v).__name__}")
                _log.error("  Bad keys: %s", bad_keys)
                resp_text = json.dumps({
                    "type": "error",
                    "message": f"Response serialization failed: {exc} (keys: {bad_keys})",
                })

            _log.info("WS send: type=%s len=%d", resp.get("type"), len(resp_text))
            await ws.send_text(resp_text)

            # Clean shutdown on exit command
            if resp.get("type") == "exit":
                _log.info("Exit command - closing WebSocket")
                await ws.close(code=1000, reason="Session ended")
                break
    except WebSocketDisconnect:
        _log.info("WebSocket disconnected normally")
    except Exception as exc:
        _log.error("WebSocket handler crashed: %s\n%s", exc, traceback.format_exc())


# ---------------------------------------------------------------------------
# Message dispatch
# ---------------------------------------------------------------------------

def handle_message(lp: AppState, msg: dict) -> dict:
    """Route a single WebSocket message to its handler and return the response."""
    msg_type = msg.get("type", "")
    _log.info("handle_message: type=%s", msg_type)

    # Guard: session must exist for all types except "load" and "ping"
    if lp.session is None and msg_type not in ("load", "ping", ""):
        return {"type": "error", "message": "No session - load files first."}

    handler = _DISPATCH.get(msg_type)
    if handler is not None:
        return handler(lp, msg)

    _log.warning("  unknown message type: %s", msg_type)
    return {"type": "error", "message": f"Unknown message type: {msg_type}"}


# ---------------------------------------------------------------------------
# Individual message handlers
# ---------------------------------------------------------------------------

def _on_command(lp: AppState, msg: dict) -> dict:
    text = msg.get("text", "")
    if not isinstance(text, str):
        return {"type": "error", "message": "Invalid command text."}
    text = text.strip()
    if not text:
        _log.info("  empty command, returning noop")
        return {"type": "noop"}

    _log.info("  executing: %r", text)
    try:
        execute_input(lp.session, text, lp.ctx)
        _log.info("  execute_input completed")
    except SystemExit:
        _log.info("  command triggered SystemExit (quit/stop)")
        return {"type": "exit"}
    except Exception as exc:
        _log.error("  execute_input error: %s\n%s", exc, traceback.format_exc())
        lp.console.print(f"[red]Error: {exc}[/red]")

    try:
        result = lp.console.capture_result(lp.session)
        _log.info("  capture_result: html=%d bytes, charts=%d",
                   len(result.get("html", "")), len(result.get("charts", [])))
    except Exception as exc:
        _log.error("  capture_result error: %s\n%s", exc, traceback.format_exc())
        return {"type": "error", "message": f"capture_result failed: {exc}"}

    try:
        result["events"] = serialize_events(
            lp.session.filtered_events,
            lp.session.display_columns,
            all_events=lp.session.all_events,
        )
        _log.info("  events: %d rows serialized", len(result["events"].get("rows", [])))
    except Exception as exc:
        _log.error("  serialize_events error: %s\n%s", exc, traceback.format_exc())
        result["events"] = {"total": 0, "filtered": 0, "page": 0, "columns": [], "rows": []}

    result["command"] = text
    return result


def _on_load(lp: AppState, msg: dict) -> dict:
    paths = msg.get("paths", [])
    if not isinstance(paths, list):
        return {"type": "error", "message": "paths must be a list."}
    _log.info("  loading paths: %s", paths)
    return load_files_into_session(lp, paths)


def _on_complete(lp: AppState, msg: dict) -> dict:
    partial = msg.get("partial", "")
    if not isinstance(partial, str):
        partial = str(partial)
    candidates = get_completions(partial, lp.session)
    _log.info("  completions for %r: %s", partial, candidates[:5])
    return {"type": "completions", "options": candidates[:20]}


def _on_session_state(lp: AppState, msg: dict) -> dict:
    snap = session_snapshot(lp.session)
    _log.info("  session_state: total=%s filtered=%s",
               snap["session"]["total"], snap["session"]["filtered"])
    return snap


def _on_events_page(lp: AppState, msg: dict) -> dict:
    page = msg.get("page", 0)
    if not isinstance(page, int) or isinstance(page, bool):
        return {"type": "error", "message": "page must be an integer."}
    _log.info("  events_page: page=%d", page)
    return {
        "type": "events_page",
        **serialize_events(
            lp.session.filtered_events,
            lp.session.display_columns,
            page=page,
            all_events=lp.session.all_events,
        ),
    }


def _on_events_sorted(lp: AppState, msg: dict) -> dict:
    """Server-side sort + paginate - fixes broken client-side sort."""
    field = msg.get("field", "")
    direction = msg.get("direction", "asc")
    page = msg.get("page", 0)
    if not isinstance(field, str) or not field:
        return {"type": "error", "message": "field is required."}
    if not isinstance(page, int) or isinstance(page, bool):
        page = 0

    _log.info("  events_sorted: field=%s dir=%s page=%d", field, direction, page)

    events = list(lp.session.filtered_events)
    reverse = direction == "desc"

    def sort_key(ev):
        val = get_field(ev, field)
        if val is None:
            return ("", ) if not reverse else ("\xff" * 20, )
        return (str(val), )

    events.sort(key=sort_key, reverse=reverse)

    page_size = 200
    total = len(events)
    start = page * page_size
    end = min(start + page_size, total)
    page_events = events[start:end]

    # O(1) id-based lookup instead of O(n) .index() per row
    _id_to_idx: dict[int, int] = {id(ev): i for i, ev in enumerate(lp.session.all_events)}

    columns = lp.session.display_columns
    rows = []
    for ev in page_events:
        idx = _id_to_idx.get(id(ev), -1)
        row = [str(idx)]
        for col in columns:
            val = get_field(ev, col)
            row.append(str(val) if val is not None else "")
        rows.append(row)

    return {
        "type": "events_page",
        "total": total,
        "filtered": total,
        "page": page,
        "page_size": page_size,
        "columns": ["#"] + columns,
        "rows": rows,
    }


def _on_event_detail(lp: AppState, msg: dict) -> dict:
    idx = msg.get("index", 0)
    if not isinstance(idx, int) or isinstance(idx, bool):
        return {"type": "error", "message": "index must be an integer."}
    _log.info("  event_detail: index=%d (total=%d)", idx, len(lp.session.all_events))
    if 0 <= idx < len(lp.session.all_events):
        return serialize_event_detail(lp.session.all_events[idx], idx)
    return {"type": "error", "message": f"Index {idx} out of range (0-{len(lp.session.all_events)-1})."}


def _on_field_names(lp: AppState, msg: dict) -> dict:
    return {"type": "field_names", "fields": lp.session.all_field_names()}


def _on_dashboard(lp: AppState, msg: dict) -> dict:
    return dashboard_data(lp.session)


def _on_star_toggle(lp: AppState, msg: dict) -> dict:
    idx = msg.get("index", -1)
    if not isinstance(idx, int) or isinstance(idx, bool):
        return {"type": "error", "message": "index must be an integer."}
    if not (0 <= idx < len(lp.session.all_events)):
        return {"type": "error", "message": f"Index {idx} out of range."}
    if idx in lp.session.starred:
        lp.session.starred.discard(idx)
        starred = False
    else:
        lp.session.starred.add(idx)
        starred = True
    return {"type": "star_result", "index": idx, "starred": starred,
            "total_starred": len(lp.session.starred)}


def _on_tag_event(lp: AppState, msg: dict) -> dict:
    idx = msg.get("index", -1)
    label = msg.get("label", "")
    if not isinstance(idx, int) or isinstance(idx, bool):
        return {"type": "error", "message": "index must be an integer."}
    if not isinstance(label, str) or not label.strip():
        return {"type": "error", "message": "label must be a non-empty string."}
    label = label.strip()
    tags = lp.session.tags
    if idx not in tags:
        tags[idx] = set()
    tags[idx].add(label)
    return {"type": "tag_result", "index": idx, "tags": sorted(tags[idx])}


def _on_untag_event(lp: AppState, msg: dict) -> dict:
    idx = msg.get("index", -1)
    label = msg.get("label", "")
    if isinstance(idx, int) and not isinstance(idx, bool) and isinstance(label, str):
        tags = lp.session.tags
        if idx in tags:
            tags[idx].discard(label)
            if not tags[idx]:
                del tags[idx]
    return {"type": "tag_result", "index": idx,
            "tags": sorted(lp.session.tags.get(idx, set()))}


def _on_annotate_event(lp: AppState, msg: dict) -> dict:
    idx = msg.get("index", -1)
    text = msg.get("text", "")
    if not isinstance(idx, int) or isinstance(idx, bool):
        return {"type": "error", "message": "index must be an integer."}
    if not isinstance(text, str):
        return {"type": "error", "message": "text must be a string."}
    text = text.strip()
    if text:
        lp.session.annotations[idx] = text
    elif idx in lp.session.annotations:
        del lp.session.annotations[idx]
    return {"type": "annotate_result", "index": idx,
            "annotation": lp.session.annotations.get(idx, "")}


def _on_row_meta(lp: AppState, msg: dict) -> dict:
    page = msg.get("page", 0)
    if not isinstance(page, int) or isinstance(page, bool):
        page = 0
    page_size = 200
    start = page * page_size
    end = min(start + page_size, len(lp.session.filtered_events))
    page_events = lp.session.filtered_events[start:end]

    # Map filtered page events to their all_events indices so meta
    # lookups (starred/tags/annotations) use the correct keys.
    _id_to_idx: dict[int, int] = {id(ev): i for i, ev in enumerate(lp.session.all_events)}

    meta: dict[str, dict] = {}
    for ev in page_events:
        idx = _id_to_idx.get(id(ev))
        if idx is None:
            continue
        entry: dict[str, Any] = {}
        if idx in lp.session.starred:
            entry["starred"] = True
        if idx in lp.session.tags:
            entry["tags"] = sorted(lp.session.tags[idx])
        if idx in lp.session.annotations:
            entry["annotation"] = lp.session.annotations[idx]
        if entry:
            meta[str(idx)] = entry
    return {"type": "row_meta", "meta": meta}


def _on_ping(lp: AppState, msg: dict) -> dict:
    return {"type": "pong"}


def _on_session_list(lp: AppState, msg: dict) -> dict:
    """List saved sessions from the sessions directory."""
    from logparse.config_loader import get_config_dir
    sessions_dir = get_config_dir() / "sessions"
    sessions = []
    if sessions_dir.exists():
        for f in sorted(sessions_dir.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True):
            import json as _json
            try:
                data = _json.loads(f.read_text(encoding="utf-8"))
                sessions.append({
                    "name": f.stem,
                    "file": str(f),
                    "date": data.get("saved_at", ""),
                    "events": data.get("event_count", 0),
                })
            except Exception:
                sessions.append({"name": f.stem, "file": str(f), "date": "", "events": 0})
    return {"type": "session_list", "sessions": sessions}


# ---------------------------------------------------------------------------
# Dispatch table
# ---------------------------------------------------------------------------

_DISPATCH: dict[str, Any] = {
    "command": _on_command,
    "load": _on_load,
    "complete": _on_complete,
    "session_state": _on_session_state,
    "events_page": _on_events_page,
    "events_sorted": _on_events_sorted,
    "event_detail": _on_event_detail,
    "field_names": _on_field_names,
    "dashboard": _on_dashboard,
    "star_toggle": _on_star_toggle,
    "tag_event": _on_tag_event,
    "untag_event": _on_untag_event,
    "annotate_event": _on_annotate_event,
    "row_meta": _on_row_meta,
    "ping": _on_ping,
    "session_list": _on_session_list,
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def load_files_into_session(lp: AppState, paths: list[str]) -> dict:
    """Load log files into the session."""
    from logparse.loader import load_files

    _log.info("load_files_into_session: paths=%s", paths)

    # Validate paths exist before loading
    missing = [p for p in paths if not Path(p).exists()]
    if missing:
        _log.warning("  missing paths: %s", missing)
        return {"type": "error", "message": f"File(s) not found: {', '.join(missing)}"}

    try:
        events, loaded_files, loaded_formats = load_files(paths, quiet=True)
        _log.info("  parsed %d events from %d files (formats: %s)",
                   len(events), len(loaded_files), loaded_formats)
    except Exception as exc:
        _log.error("  load_files error: %s\n%s", exc, traceback.format_exc())
        return {"type": "error", "message": f"Load failed: {exc}"}

    if lp.session is None:
        _log.info("  creating new session")
        lp.session = Session(
            all_events=events,
            filtered_events=list(events),
            source_files=loaded_files,
            loaded_formats=loaded_formats,
        )
        from logparse.config_loader import load_config
        lp.session.config = load_config()
    else:
        _log.info("  extending existing session (was %d events)", len(lp.session.all_events))
        lp.session.all_events.extend(events)
        lp.session.filtered_events = list(lp.session.all_events)
        lp.session.source_files.extend(loaded_files)
        lp.session.loaded_formats.extend(loaded_formats)
        lp.session.active_filter = ""
        # Reset state that references event indices - they're now invalid
        lp.session.filter_history.clear()
        lp.session.starred.clear()
        lp.session.annotations.clear()
        lp.session.tags.clear()

    _log.info("  session now has %d events total", len(lp.session.all_events))

    result: dict[str, Any] = {
        "type": "loaded",
        "total": len(lp.session.all_events),
        "files": loaded_files,
        "formats": loaded_formats,
    }
    result["events"] = serialize_events(
        lp.session.filtered_events,
        lp.session.display_columns,
        all_events=lp.session.all_events,
    )
    result["session"] = session_snapshot(lp.session).get("session", {})
    return result


def session_snapshot(session: Session) -> dict:
    """Return current session state as a JSON-serializable dict."""
    all_tags: set[str] = set()
    for tag_set in session.tags.values():
        all_tags.update(tag_set)
    return {
        "type": "session_state",
        "session": {
            "total": len(session.all_events),
            "filtered": len(session.filtered_events),
            "active_filter": session.active_filter or "",
            "filter_depth": len(session.filter_history),
            "starred": len(session.starred),
            "starred_indices": sorted(session.starred),
            "charts_count": len(getattr(session, "charts", [])),
            "source_files": session.source_files,
            "loaded_formats": session.loaded_formats,
            "annotations_count": len(session.annotations),
            "tags_count": sum(len(v) for v in session.tags.values()),
            "all_tags": sorted(all_tags),
        },
    }


def dashboard_data(session: Session) -> dict:
    """Compute dashboard metrics from the current session."""
    events = session.all_events
    total = len(events)

    sev_counts = Counter(e.severity for e in events)
    severity = {s: sev_counts.get(s, 0) for s in
                ("Critical", "High", "Medium", "Low", "Info")}

    source_counts = Counter(e.source for e in events if e.source)
    ip_counts = Counter(get_field(e, "srcip") for e in events
                        if get_field(e, "srcip"))

    ts_events = [e for e in events if e.timestamp]
    hourly = [0] * 24
    for e in ts_events:
        hourly[e.timestamp.hour] += 1

    first_ts = min(e.timestamp for e in ts_events) if ts_events else None
    last_ts = max(e.timestamp for e in ts_events) if ts_events else None

    crit_high = [e for e in events if e.severity in ("Critical", "High")]
    recent = crit_high[-5:]

    return {
        "type": "dashboard_data",
        "total": total,
        "severity": severity,
        "top_sources": [[s, c] for s, c in source_counts.most_common(5)],
        "top_ips": [[ip, c] for ip, c in ip_counts.most_common(5)],
        "time_range": {
            "first": first_ts.isoformat() if first_ts else None,
            "last": last_ts.isoformat() if last_ts else None,
        },
        "hourly": hourly,
        "recent_alerts": [
            {"severity": e.severity,
             "message": e.message[:80],
             "timestamp": str(e.timestamp) if e.timestamp else ""}
            for e in recent
        ],
    }
