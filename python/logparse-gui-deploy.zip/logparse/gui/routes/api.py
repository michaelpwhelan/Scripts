#!/usr/bin/env python3
"""REST API endpoints for the logparse GUI."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from logparse.gui.settings import load_gui_settings, save_gui_settings
from logparse.gui.state import AppState

_log = logging.getLogger(__name__)

router = APIRouter(prefix="/api")


@router.get("/health")
async def health():
    """Health check endpoint for monitoring and reconnection probes."""
    return {"status": "ok"}


@router.get("/settings")
async def get_settings():
    """Return persisted GUI settings."""
    return load_gui_settings()


@router.put("/settings")
async def put_settings(request: Request):
    """Merge and persist GUI settings."""
    body = await request.json()
    current = load_gui_settings()
    current.update(body)
    save_gui_settings(current)
    return current


@router.get("/commands")
async def list_commands(request: Request):
    """Return the command registry for the command palette."""
    from logparse.commands import get_registry
    registry = get_registry()
    result = []
    for cmd in registry:
        result.append({
            "name": cmd.name,
            "category": cmd.category,
            "usage": cmd.usage,
            "help": cmd.help,
        })
    return result


@router.get("/analyzers")
async def list_analyzers():
    """Return available analyzers with metadata."""
    from logparse.analyzers import ANALYZER_INFO
    return [
        {"name": name, "category": cat, "help": desc}
        for name, (cat, desc) in ANALYZER_INFO.items()
    ]


@router.get("/reports")
async def list_reports():
    """Return available report types with descriptions."""
    return [
        {"name": n, "description": d}
        for n, d in [
            ("summary", "Overview with severity distribution and top sources"),
            ("morning", "Daily security briefing"),
            ("audit", "Detailed audit trail"),
            ("compliance", "FFIEC/NCUA compliance mapping"),
            ("evidence", "Forensic evidence documentation"),
            ("timeline", "Chronological event timeline"),
            ("security", "Security-focused narrative report"),
            ("traffic", "Network traffic analysis"),
            ("incident", "Incident reconstruction with MITRE mapping"),
            ("correlation", "Cross-source correlation findings"),
            ("sla", "SLA compliance metrics"),
        ]
    ]
