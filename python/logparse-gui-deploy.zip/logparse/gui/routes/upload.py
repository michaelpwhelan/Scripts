#!/usr/bin/env python3
"""File upload endpoint for the logparse GUI."""

from __future__ import annotations

import logging
import tempfile
import traceback
from pathlib import Path

from fastapi import APIRouter, Request, UploadFile

from logparse.gui.routes.ws import load_files_into_session
from logparse.gui.state import AppState

_log = logging.getLogger(__name__)

router = APIRouter()


@router.post("/upload")
async def upload(file: UploadFile, request: Request):
    """Handle drag-and-drop or file-dialog uploads."""
    _log.info("POST /upload - filename=%s size=%s", file.filename, file.size)
    lp: AppState = request.app.state.lp

    import shutil

    tmp = Path(tempfile.mkdtemp(prefix="logparse_"))
    dest = tmp / (file.filename or "upload.log")
    content = await file.read()
    dest.write_bytes(content)
    _log.info("  Saved to %s (%d bytes)", dest, len(content))

    try:
        resp = load_files_into_session(lp, [str(dest)])
        _log.info("  Load result: type=%s total=%s", resp.get("type"), resp.get("total"))
    except Exception as exc:
        _log.error("  Upload handler crashed: %s\n%s", exc, traceback.format_exc())
        resp = {"type": "error", "message": f"Upload processing failed: {exc}"}
    finally:
        # Clean up temp directory after loading (events are already in memory)
        try:
            shutil.rmtree(tmp)
            _log.info("  Cleaned up temp dir: %s", tmp)
        except OSError as exc:
            _log.warning("  Failed to clean temp dir %s: %s", tmp, exc)
    return resp
