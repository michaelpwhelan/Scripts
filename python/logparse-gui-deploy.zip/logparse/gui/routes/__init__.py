#!/usr/bin/env python3
"""GUI route modules - WebSocket, REST API, file upload."""
