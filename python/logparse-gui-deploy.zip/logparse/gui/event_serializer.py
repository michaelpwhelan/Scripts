#!/usr/bin/env python3
"""Serialize LogEvent lists to JSON-friendly dicts for the web GUI."""

from __future__ import annotations

from typing import Any

from logparse.models import LogEvent, get_field


def serialize_events(
    events: list[LogEvent],
    columns: list[str],
    page: int = 0,
    page_size: int = 200,
    all_events: list[LogEvent] | None = None,
) -> dict[str, Any]:
    """Return a page of events as a JSON-serializable dict.

    When *all_events* is provided, the ``#`` column contains the index
    into ``all_events`` so that detail lookups always reference the
    correct event regardless of active filters.
    """
    total = len(events)
    start = page * page_size
    end = min(start + page_size, total)
    page_events = events[start:end]

    # Build id→index lookup for O(1) mapping to all_events index
    if all_events is not None:
        _id_to_idx: dict[int, int] = {id(ev): i for i, ev in enumerate(all_events)}
    else:
        _id_to_idx = {}

    rows: list[list[str]] = []
    for filtered_idx, ev in enumerate(page_events, start=start):
        # Use all_events index when available, fall back to filtered index
        if _id_to_idx:
            row_idx = _id_to_idx.get(id(ev), filtered_idx)
        else:
            row_idx = filtered_idx
        row = [str(row_idx)]
        for col in columns:
            val = get_field(ev, col)
            row.append(str(val) if val is not None else "")
        rows.append(row)

    return {
        "total": total,
        "filtered": total,
        "page": page,
        "page_size": page_size,
        "columns": ["#"] + columns,
        "rows": rows,
    }


def serialize_event_detail(event: LogEvent, idx: int) -> dict[str, Any]:
    """Return all fields of a single event for detail view."""
    fields: dict[str, str] = {
        "Index": str(idx),
        "Timestamp": str(event.timestamp) if event.timestamp else "",
        "Severity": event.severity,
        "Source": event.source,
        "Message": event.message,
        "Source File": event.source_file,
        "Format": event.source_format,
        "Line": str(event.line_number),
    }
    for k, v in sorted(event.extra.items()):
        fields[k] = str(v)
    return {"type": "detail", "index": idx, "fields": fields}
