#!/usr/bin/env python3
"""CLI argument parsing and main execution."""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

from logparse import __version__
from logparse.cli_render import (
    export_html,
    render_csv,
    render_json,
    render_raw,
    render_stats,
)
from logparse.cli_subcommands import handle_diff, handle_fetch
from logparse.models import LogEvent
from logparse.parsers import PARSER_DESCRIPTIONS
from logparse.severity import SEV_ORDER
from logparse.util import format_number, parse_duration


def _build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="logparse",
        description="Log investigation tool for infrastructure log files.",
    )
    p.add_argument(
        "paths",
        nargs="*",
        metavar="PATH",
        help="Log file(s) to parse. Supports globs and .zip archives.",
    )
    p.add_argument(
        "-f", "--format",
        dest="format_",
        metavar="FMT",
        help="Explicit log format (overrides auto-detection).",
    )
    p.add_argument(
        "-w", "--filter",
        dest="filter_",
        metavar="QUERY",
        help='Filter query (e.g. "action:deny | count by dstport").',
    )
    p.add_argument(
        "-g", "--grep",
        metavar="PATTERN",
        help="Grep-style text search (case-insensitive, regex OR).",
    )
    p.add_argument(
        "--case-sensitive",
        action="store_true",
        help="Make --grep case-sensitive.",
    )
    p.add_argument(
        "--time",
        metavar="RANGE",
        help='Time window filter (e.g. "last 24hr", "last 1h").',
    )
    p.add_argument(
        "-o", "--output",
        default="table",
        choices=("table", "grid", "list", "raw", "json", "csv"),
        help="Output format (default: table).",
    )
    p.add_argument(
        "--fields",
        metavar="F1,F2,...",
        help="Comma-separated fields to display.",
    )
    p.add_argument(
        "-n", "--max",
        type=int,
        default=0,
        metavar="N",
        help="Maximum number of events to display.",
    )
    p.add_argument(
        "-s", "--stats-only",
        action="store_true",
        help="Show parse statistics only, no events.",
    )
    p.add_argument(
        "-r", "--regex",
        metavar="PATTERN",
        help="Filter events by regex on raw log line.",
    )
    p.add_argument(
        "--highlight",
        metavar="PATTERN",
        help="Highlight matching text without filtering.",
    )
    p.add_argument(
        "--preview",
        action="store_true",
        help="Show top 10 events by severity (opinionated triage).",
    )
    p.add_argument(
        "--export",
        metavar="FILE",
        help="Export to file (format from extension: .html, .csv, .json).",
    )
    p.add_argument(
        "--no-pager",
        action="store_true",
        help="Disable automatic pager for long output.",
    )
    p.add_argument(
        "--no-color",
        action="store_true",
        help="Disable colored output.",
    )
    p.add_argument(
        "--no-cache",
        action="store_true",
        help="Bypass parsed dataset cache.",
    )
    p.add_argument(
        "--profile",
        metavar="NAME",
        help="Apply noise profile to filter known-noisy sources.",
    )
    p.add_argument(
        "-q", "--quiet",
        action="store_true",
        help="Minimal output.",
    )
    p.add_argument(
        "-i", "--interactive",
        action="store_true",
        help="Launch interactive query mode (REPL).",
    )
    p.add_argument(
        "-S", "--script",
        metavar="FILE",
        help="Run commands from a script file (one per line, # comments).",
    )
    p.add_argument(
        "-c", "--command",
        metavar="CMDS",
        help='Run inline commands (semicolon-separated), then exit.',
    )
    p.add_argument(
        "--list-parsers",
        action="store_true",
        help="List available log format parsers.",
    )
    p.add_argument(
        "--gui",
        action="store_true",
        help="Launch web GUI (requires pip install 'logparse[gui]').",
    )
    p.add_argument(
        "--tls",
        action="store_true",
        help="Enable HTTPS with auto-generated self-signed certificate.",
    )
    p.add_argument(
        "--cert",
        metavar="FILE",
        help="TLS certificate file (PEM) for HTTPS.",
    )
    p.add_argument(
        "--key",
        metavar="FILE",
        help="TLS private key file (PEM) for HTTPS.",
    )
    p.add_argument(
        "--bind",
        default="127.0.0.1",
        metavar="ADDR",
        help="Address to bind the GUI server to (default: 127.0.0.1).",
    )
    p.add_argument(
        "--api-key",
        metavar="KEY",
        help="Require API key for GUI server access (header: X-API-Key).",
    )
    p.add_argument(
        "--install-service",
        action="store_true",
        help="Generate Windows Service install commands (NSSM) and exit.",
    )
    p.add_argument(
        "--uninstall-service",
        action="store_true",
        help="Generate Windows Service uninstall commands and exit.",
    )
    p.add_argument(
        "--version",
        action="version",
        version=f"logparse {__version__}",
    )
    return p


def _get_log_statistics(events: list[LogEvent]) -> dict:
    """Compute statistics over parsed events."""
    sev_counts = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
    sources: dict[str, int] = {}
    event_ids: dict[str, int] = {}
    src_ips: dict[str, int] = {}
    dst_ips: dict[str, int] = {}
    per_file: dict[str, dict] = {}
    min_ts = None
    max_ts = None

    for e in events:
        sev_counts[e.severity] = sev_counts.get(e.severity, 0) + 1
        if e.source:
            sources[e.source] = sources.get(e.source, 0) + 1
        if eid := e.extra.get("EventID"):
            event_ids[eid] = event_ids.get(eid, 0) + 1
        if sip := e.extra.get("srcip"):
            src_ips[sip] = src_ips.get(sip, 0) + 1
        if dip := e.extra.get("dstip"):
            dst_ips[dip] = dst_ips.get(dip, 0) + 1
        if e.timestamp is not None:
            if min_ts is None or e.timestamp < min_ts:
                min_ts = e.timestamp
            if max_ts is None or e.timestamp > max_ts:
                max_ts = e.timestamp
        sf = e.source_file or "(single file)"
        if sf not in per_file:
            per_file[sf] = {
                "total": 0, "format": "", "Critical": 0,
                "High": 0, "Medium": 0, "Low": 0, "Info": 0,
            }
        per_file[sf]["total"] += 1
        per_file[sf][e.severity] = per_file[sf].get(e.severity, 0) + 1
        if not per_file[sf]["format"] and e.source_format:
            per_file[sf]["format"] = e.source_format

    return {
        "total": len(events),
        "severity": sev_counts,
        "time_range": (min_ts, max_ts),
        "top_sources": sorted(sources.items(), key=lambda x: x[1], reverse=True)[:10],
        "top_event_ids": sorted(event_ids.items(), key=lambda x: x[1], reverse=True)[:10],
        "top_src_ips": sorted(src_ips.items(), key=lambda x: x[1], reverse=True)[:10],
        "top_dst_ips": sorted(dst_ips.items(), key=lambda x: x[1], reverse=True)[:10],
        "per_file": per_file,
    }


def _preview_events(events: list[LogEvent]) -> list[LogEvent]:
    """Return top 10 events by severity, then recency."""
    ranked = sorted(
        events,
        key=lambda e: (
            SEV_ORDER.get(e.severity, 5),
            -(e.timestamp.timestamp() if e.timestamp else 0),
        ),
    )
    return ranked[:10]


def _terminal_height() -> int:
    try:
        return os.get_terminal_size().lines
    except (ValueError, OSError):
        return 40


def run_script(
    events: list[LogEvent],
    loaded_files: list[str],
    loaded_formats: list[str],
    args,
    console,
) -> None:
    """Execute a script (file or inline commands) non-interactively."""
    import json as _json
    import logging

    from logparse.commands import dispatch, CommandContext
    from logparse.filter_engine import parse_conditions, match_event
    from logparse.session import Session
    from logparse.syntax import parse_command, split_commands

    session = Session(
        all_events=events,
        filtered_events=list(events),
        source_files=loaded_files,
        loaded_formats=loaded_formats,
    )
    ctx = CommandContext(console=console)

    # Collect commands from file or inline string
    commands: list[str] = []
    if args.script:
        script_path = Path(args.script)
        if not script_path.exists():
            print(f"Script not found: {args.script}", file=sys.stderr)
            sys.exit(1)
        text = script_path.read_text(encoding="utf-8")

        # Detect JSON playbook format
        stripped = text.lstrip()
        if stripped and stripped[0] in ("{", "["):
            try:
                data = _json.loads(text)
                commands = data.get("commands", data) if isinstance(data, dict) else data
            except _json.JSONDecodeError:
                pass

        # Plain text: one command per line, # comments
        if not commands:
            for line in text.splitlines():
                line = line.strip()
                if line and not line.startswith("#"):
                    commands.append(line)
    else:
        # Inline -c commands: split on ; and &&
        for cmd in split_commands(args.command):
            cmd = cmd.strip()
            if cmd:
                commands.append(cmd)

    if not commands:
        print("No commands to execute.", file=sys.stderr)
        sys.exit(1)

    errors = 0
    for cmd_text in commands:
        # Expand command chains (a single line may contain ; or &&)
        for sub_cmd in split_commands(cmd_text):
            sub_cmd = sub_cmd.strip()
            if not sub_cmd or sub_cmd.startswith("#"):
                continue

            if not args.quiet:
                console.print(f"[dim]> {sub_cmd}[/dim]")

            parsed = parse_command(sub_cmd)
            try:
                handled = dispatch(session, parsed, ctx)
                if not handled:
                    # Fallback: try as filter (same as REPL)
                    extra = {f.lower() for f in session.all_field_names()}
                    conditions = parse_conditions(sub_cmd, extra_fields=extra)
                    if conditions:
                        session.push_filter(sub_cmd)
                        session.filtered_events = [
                            e for e in session.filtered_events
                            if match_event(e, conditions)
                        ]
                        count = len(session.filtered_events)
                        console.print(
                            f"[bold]{format_number(count)} events[/bold] "
                            f"(filter: {sub_cmd})"
                        )
                    else:
                        console.print(f"[red]Unknown command: {sub_cmd}[/red]")
                        errors += 1
            except SystemExit:
                return
            except (ValueError, KeyError, TypeError, OSError, RuntimeError) as exc:
                logging.getLogger(__name__).debug(
                    "Script command error: %s", exc, exc_info=True)
                console.print(f"[red]Error: {exc}[/red]")
                errors += 1

    if errors:
        sys.exit(1)


def main(argv: list[str] | None = None) -> None:
    """CLI entry point."""
    raw = argv if argv is not None else sys.argv[1:]

    # diff subcommand — intercept before argparse
    if raw and raw[0] == "diff":
        return handle_diff(raw[1:])

    # fetch subcommand — intercept before argparse
    if raw and raw[0] == "fetch":
        return handle_fetch(raw[1:])

    parser = _build_parser()
    args = parser.parse_args(raw)

    # list parsers
    if args.list_parsers:
        print("Available log format parsers:")
        for name, desc in PARSER_DESCRIPTIONS.items():
            print(f"  {name:<20} {desc}")
        return

    # Windows Service management
    if getattr(args, "install_service", False):
        from logparse.gui.service import print_install_commands
        print_install_commands(args)
        return
    if getattr(args, "uninstall_service", False):
        from logparse.gui.service import print_uninstall_commands
        print_uninstall_commands()
        return

    # GUI mode — launch web server
    if args.gui:
        from logparse.gui.server import launch_gui
        launch_gui(args)
        return

    # validate input
    if not args.paths:
        if sys.stdin.isatty():
            parser.print_help()
            return
        parser.error("No input files specified.")

    # set up console
    from rich.console import Console
    from time import perf_counter

    force_terminal = not args.no_color
    console = Console(
        force_terminal=force_terminal,
        no_color=args.no_color,
        stderr=False,
    )

    # auto-detect piped output
    if not sys.stdout.isatty() and args.output == "table":
        args.output = "raw"
        args.no_color = True

    # set up verbose output
    from logparse.verbose import (
        VerboseOutput, LoadSummary, detect_input_mode, KNOWN_NOISE_SOURCES,
    )

    verbose = None
    if not args.quiet:
        err_console = Console(
            force_terminal=force_terminal,
            no_color=args.no_color,
            stderr=True,
        )
        mode = detect_input_mode(args.paths)
        verbose = VerboseOutput(err_console, mode)

    # load files
    from logparse.loader import load_files

    t0 = perf_counter()
    all_events, loaded_files, loaded_formats = load_files(
        args.paths,
        format_override=args.format_,
        quiet=args.quiet,
        on_file=verbose.file_parsed if verbose else None,
        use_cache=not args.no_cache,
    )
    load_elapsed = perf_counter() - t0

    if not all_events:
        print("No events parsed.", file=sys.stderr)
        return

    # Render archive tree if needed
    if verbose:
        from logparse.verbose import InputMode
        if verbose.mode == InputMode.ARCHIVE and verbose.parsed_files:
            archive_name = verbose.parsed_files[0].archive_name
            if archive_name:
                verbose.render_archive_tree(archive_name)

    # apply noise profile
    noise_removed = 0
    if args.profile:
        from logparse.noise import find_profile, load_profile, apply_noise_filter
        prof_path = find_profile(args.profile)
        if prof_path is None:
            print(f"Noise profile not found: {args.profile}", file=sys.stderr)
            return
        profile = load_profile(prof_path)
        all_events, noise_removed = apply_noise_filter(all_events, profile)
        if not args.quiet and not verbose:
            print(
                f"Noise profile '{args.profile}': removed {noise_removed:,} events, "
                f"{len(all_events):,} remaining",
                file=sys.stderr,
            )

    # Build LoadSummary and render dashboard
    load_summary = None
    if verbose:
        # Compute aggregate severity counts
        sev_totals = {"Critical": 0, "High": 0, "Medium": 0, "Low": 0, "Info": 0}
        source_counts: dict[str, int] = {}
        for e in all_events:
            sev_totals[e.severity] = sev_totals.get(e.severity, 0) + 1
            if e.source:
                source_counts[e.source] = source_counts.get(e.source, 0) + 1

        sorted_sources = sorted(
            source_counts.items(), key=lambda x: x[1], reverse=True
        )

        # Detect noise sources
        noise_sources = [
            (name, count) for name, count in sorted_sources
            if name in KNOWN_NOISE_SOURCES
        ]

        # Time range
        ts_events = [e for e in all_events if e.timestamp is not None]
        first_ts = ts_events[0].timestamp if ts_events else None
        last_ts = ts_events[-1].timestamp if ts_events else None

        load_summary = LoadSummary(
            total_events=len(all_events),
            files=verbose.parsed_files,
            skipped=verbose.skipped_files,
            elapsed=load_elapsed,
            time_range=(first_ts, last_ts),
            severity_counts=sev_totals,
            source_counts=sorted_sources[:10],
            noise_sources=noise_sources,
            noise_removed=noise_removed,
            noise_profile=args.profile or "",
        )
        # Skip rendering here when entering interactive mode — the REPL
        # renders its own dashboard on startup.
        if not args.interactive:
            verbose.console.print()
            verbose.render_dashboard(load_summary)

    # stats only
    if args.stats_only:
        stats = _get_log_statistics(all_events)
        render_stats(stats, console)
        return

    # script mode
    if args.script or args.command:
        run_script(all_events, loaded_files, loaded_formats, args, console)
        return

    # interactive mode
    if args.interactive:
        from logparse.repl import run_repl
        run_repl(all_events, loaded_files, loaded_formats, load_summary=load_summary)
        return

    # apply filters
    filtered = all_events
    show_fields: list[str] | None = None

    if args.filter_:
        from logparse.filter_engine import filter_events

        result = filter_events(all_events, args.filter_)
        # filter_events may return (events, show_fields) tuple
        if isinstance(result, tuple):
            filtered, show_fields = result
        else:
            filtered = result

    # --grep flag
    if args.grep:
        from logparse.filter_engine import grep_events
        filtered = grep_events(
            filtered, args.grep,
            case_sensitive=args.case_sensitive,
        )

    # --regex flag (legacy, still supported)
    if args.regex:
        from logparse.filter_engine import _NESTED_QUANTIFIER_RE
        pattern = args.regex
        if _NESTED_QUANTIFIER_RE.search(pattern):
            pattern = re.escape(pattern)
        try:
            regex_obj = re.compile(pattern, re.IGNORECASE)
        except re.error as exc:
            print(f"Invalid regex: {exc}", file=sys.stderr)
            return
        filtered = [e for e in filtered if regex_obj.search(e.raw)]

    # --time flag
    if args.time:
        delta = parse_duration(args.time)
        if delta is None:
            print(f"Invalid time range: {args.time}", file=sys.stderr)
            return
        # compute cutoff from max timestamp in dataset
        ts_events = [e for e in filtered if e.timestamp is not None]
        if ts_events:
            max_ts = max(e.timestamp for e in ts_events)
            cutoff = max_ts - delta
            filtered = [
                e for e in filtered
                if e.timestamp is not None and e.timestamp >= cutoff
            ]

    # --preview flag
    if args.preview:
        filtered = _preview_events(filtered)

    # --export flag
    if args.export:
        ext = Path(args.export).suffix.lower()
        if ext == ".csv":
            with open(args.export, "w", encoding="utf-8", newline="") as f:
                render_csv(filtered, args.max, file=f)
        elif ext == ".json":
            with open(args.export, "w", encoding="utf-8") as f:
                render_json(filtered, args.max, file=f)
        elif ext == ".html":
            export_html(filtered, args.export)
        else:
            print(f"Unsupported export format: {ext}", file=sys.stderr)
            return
        count = min(len(filtered), args.max) if args.max > 0 else len(filtered)
        print(f"Exported {format_number(count)} events to {args.export}",
              file=sys.stderr)
        return

    # check for aggregation results
    from logparse.pipeline import AggResult

    if filtered and isinstance(filtered[0], AggResult):
        from logparse.output.table import render_agg

        render_agg(filtered, console, max_results=args.max)
        return

    # field list — show_fields from pipe override, or --fields, or default
    fields = None
    if show_fields:
        fields = show_fields
    elif args.fields:
        fields = [f.strip() for f in args.fields.split(",")]

    # determine pager usage
    use_pager = (
        not args.no_pager
        and sys.stdout.isatty()
        and not args.no_color
        and isinstance(filtered, list)
        and len(filtered) > _terminal_height()
    )

    def _render() -> None:
        match args.output:
            case "table":
                from logparse.output.table import render_table
                render_table(
                    filtered, console,
                    fields=fields or ("Timestamp", "Severity", "Source", "Message"),
                    highlight=args.highlight or "",
                    max_results=args.max,
                )
            case "grid":
                from logparse.output.table import render_grid
                render_grid(
                    filtered, console,
                    fields=fields or ("Timestamp", "Severity", "Source", "Message"),
                    highlight=args.highlight or "",
                    max_results=args.max,
                )
            case "list":
                from logparse.output.list_fmt import render_list
                render_list(
                    filtered, console,
                    highlight=args.highlight or "",
                    max_results=args.max,
                )
            case "json":
                render_json(filtered, args.max)
            case "csv":
                render_csv(filtered, args.max)
            case "raw":
                render_raw(filtered, args.max)

    if use_pager:
        with console.pager(styles=True):
            _render()
    else:
        _render()
