#!/usr/bin/env python3
"""FFIEC Information Security work program control mapping.

Maps log event patterns to FFIEC IS.WP.* control domains for credit union
examination evidence generation.  Each control defines event ID patterns,
field-value matchers, and message keywords that constitute evidence of the
control operating effectively.

Reference: FFIEC IT Examination Handbook — Information Security Booklet
           NCUA Part 748, Appendix A, Section III
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field


@dataclass(frozen=True)
class FFIECControl:
    """Single FFIEC control with detection criteria."""

    domain: str                          # e.g. "IS.WP.AL"
    control_id: str                      # e.g. "IS.WP.AL-1"
    name: str
    description: str
    handbook_ref: str                    # e.g. "Info Security §II.C.22"
    nist_mapping: tuple[str, ...]        # NIST 800-53 crosswalk
    event_ids: frozenset[str] = field(default_factory=frozenset)
    field_patterns: tuple[tuple[str, str], ...] = ()   # (field, substring)
    message_patterns: tuple[str, ...] = ()
    evidence_threshold: int = 10         # events for "Sufficient Evidence"
    partial_threshold: int = 1           # events for "Partial Evidence"


# ---------------------------------------------------------------------------
# Domain definitions
# ---------------------------------------------------------------------------

DOMAINS: dict[str, str] = {
    "IS.WP.AC": "Access Controls & User Management",
    "IS.WP.AL": "Audit and Logging",
    "IS.WP.CM": "Change Management",
    "IS.WP.ID": "Incident Detection & Response",
    "IS.WP.BC": "Business Continuity Planning",
    "IS.WP.NS": "Network Security",
    "IS.WP.AM": "Account Management & Authentication",
    "IS.WP.RM": "Remote Access Management",
    "IS.WP.PM": "Privilege Management",
    "IS.WP.MV": "Malware & Vulnerability Management",
}


# ---------------------------------------------------------------------------
# Controls
# ---------------------------------------------------------------------------

CONTROLS: dict[str, FFIECControl] = {}


def _c(
    domain: str, seq: int, name: str, description: str, handbook_ref: str,
    nist: tuple[str, ...], *,
    event_ids: frozenset[str] | None = None,
    field_patterns: tuple[tuple[str, str], ...] = (),
    message_patterns: tuple[str, ...] = (),
    evidence_threshold: int = 10,
    partial_threshold: int = 1,
) -> None:
    ctrl_id = f"{domain}-{seq}"
    CONTROLS[ctrl_id] = FFIECControl(
        domain=domain, control_id=ctrl_id, name=name,
        description=description, handbook_ref=handbook_ref,
        nist_mapping=nist, event_ids=event_ids or frozenset(),
        field_patterns=field_patterns, message_patterns=message_patterns,
        evidence_threshold=evidence_threshold,
        partial_threshold=partial_threshold,
    )


# -- IS.WP.AC  Access Controls & User Management ---------------------------

_c("IS.WP.AC", 1,
   "Logon monitoring",
   "Authentication success and failure events are logged and reviewed",
   "Info Security §II.C.10",
   ("AC-7", "IA-5"),
   event_ids=frozenset({"4624", "4625", "4648", "4771", "4776"}),
   field_patterns=(("action", "login"), ("action", "ssl-login")),
   message_patterns=("logon", "authentication"),
   evidence_threshold=50)

_c("IS.WP.AC", 2,
   "Session control",
   "User sessions are monitored for unauthorized activity",
   "Info Security §II.C.10",
   ("AC-12",),
   event_ids=frozenset({"4634", "4647"}),
   field_patterns=(("action", "timeout"),),
   message_patterns=("logoff", "session end"))


# -- IS.WP.AL  Audit and Logging -------------------------------------------

_c("IS.WP.AL", 1,
   "Log generation and retention",
   "Audit log records are generated and retained in a secure manner",
   "Info Security §II.C.22",
   ("AU-2", "AU-3", "AU-12"),
   message_patterns=("audit", "log"),
   evidence_threshold=100,
   partial_threshold=10)

_c("IS.WP.AL", 2,
   "Log integrity monitoring",
   "Logs are protected from unauthorized modification or deletion",
   "Info Security §II.C.22",
   ("AU-9", "AU-10"),
   event_ids=frozenset({"1102", "4719"}),
   message_patterns=("audit log cleared", "audit policy changed"),
   evidence_threshold=1,
   partial_threshold=1)

_c("IS.WP.AL", 3,
   "Multi-source aggregation",
   "Security event logs from multiple sources are collected centrally",
   "Info Security §II.C.22",
   ("AU-6", "SI-4"),
   evidence_threshold=2,
   partial_threshold=2)


# -- IS.WP.CM  Change Management -------------------------------------------

_c("IS.WP.CM", 1,
   "System change tracking",
   "Configuration changes to systems are logged and reviewed",
   "Info Security §II.C.15",
   ("CM-3", "CM-5"),
   event_ids=frozenset({"4697", "7045", "4657"}),
   field_patterns=(("type", "event"), ("subtype", "system")),
   message_patterns=("service installed", "config change", "policy change"))

_c("IS.WP.CM", 2,
   "Firewall rule auditing",
   "Firewall rules are audited or verified at least quarterly",
   "Info Security §II.C.9",
   ("CM-6",),
   field_patterns=(("type", "event"), ("subtype", "system")),
   message_patterns=("policy", "firewall", "rule"))


# -- IS.WP.ID  Incident Detection & Response -------------------------------

_c("IS.WP.ID", 1,
   "Intrusion detection",
   "Network and host intrusion events are detected and analyzed",
   "Info Security §II.C.9, §III.C",
   ("SI-4", "IR-4"),
   field_patterns=(("subtype", "ips"), ("action", "detected")),
   message_patterns=("intrusion", "attack", "exploit", "ips"),
   evidence_threshold=5)

_c("IS.WP.ID", 2,
   "Security event alerting",
   "Blocked and denied actions generate alerts for review",
   "Info Security §III.C",
   ("SI-4", "IR-5"),
   field_patterns=(("action", "deny"), ("action", "blocked"),
                   ("action", "dropped")),
   message_patterns=("denied", "blocked", "dropped"),
   evidence_threshold=20)

_c("IS.WP.ID", 3,
   "Incident documentation",
   "Security incidents are documented with evidence and decisions",
   "Info Security §III.D",
   ("IR-4", "IR-5", "IR-6"),
   message_patterns=("incident", "alert", "critical"),
   evidence_threshold=1)


# -- IS.WP.BC  Business Continuity Planning ---------------------------------

_c("IS.WP.BC", 1,
   "Infrastructure availability monitoring",
   "HA failover and system availability events are monitored",
   "BCM §V.F.1",
   ("CP-2", "CP-10"),
   field_patterns=(("subtype", "ha"),),
   message_patterns=("failover", "ha", "cluster", "standby", "primary"),
   evidence_threshold=1)

_c("IS.WP.BC", 2,
   "Tunnel and WAN health monitoring",
   "VPN tunnel and SD-WAN link health events are monitored",
   "BCM §V.F.1",
   ("CP-8",),
   field_patterns=(("subtype", "vpn"), ("type", "event")),
   message_patterns=("tunnel", "ipsec", "sdwan", "sla"),
   evidence_threshold=5)


# -- IS.WP.NS  Network Security --------------------------------------------

_c("IS.WP.NS", 1,
   "Perimeter traffic monitoring",
   "Network perimeter traffic is logged and analyzed",
   "Info Security §II.C.9",
   ("SC-7", "AC-4"),
   field_patterns=(("type", "traffic"), ("subtype", "forward")),
   evidence_threshold=100,
   partial_threshold=20)

_c("IS.WP.NS", 2,
   "UTM and content inspection",
   "Web filtering, antivirus, and application control events are reviewed",
   "Info Security §II.C.9",
   ("SC-7", "SI-3"),
   field_patterns=(("type", "utm"),),
   message_patterns=("virus", "webfilter", "app-ctrl", "malware"),
   evidence_threshold=10)

_c("IS.WP.NS", 3,
   "DNS monitoring",
   "DNS query patterns are monitored for anomalies",
   "Info Security §II.C.9",
   ("SC-20",),
   field_patterns=(("subtype", "dns"),),
   message_patterns=("dns", "nxdomain"),
   evidence_threshold=10)


# -- IS.WP.AM  Account Management & Authentication -------------------------

_c("IS.WP.AM", 1,
   "Account lifecycle management",
   "User account creation, modification, and deletion are logged",
   "Info Security §II.C.10",
   ("AC-2",),
   event_ids=frozenset({"4720", "4722", "4723", "4724", "4725", "4726"}),
   message_patterns=("account created", "account disabled", "account deleted",
                     "password change", "password reset"),
   evidence_threshold=3)

_c("IS.WP.AM", 2,
   "Group membership changes",
   "Security group membership changes are tracked",
   "Info Security §II.C.10",
   ("AC-2",),
   event_ids=frozenset({"4728", "4732", "4756"}),
   message_patterns=("group member", "added to"),
   evidence_threshold=1)

_c("IS.WP.AM", 3,
   "Multi-factor authentication",
   "MFA usage and bypass events are monitored",
   "Authentication Guidance",
   ("IA-2",),
   message_patterns=("mfa", "multi-factor", "two-factor", "2fa",
                     "conditional access"),
   evidence_threshold=5)


# -- IS.WP.RM  Remote Access Management ------------------------------------

_c("IS.WP.RM", 1,
   "VPN session monitoring",
   "Remote access VPN sessions are logged with user and source IP",
   "Info Security §II.C.15",
   ("AC-17",),
   field_patterns=(("subtype", "vpn"), ("action", "tunnel-up"),
                   ("action", "ssl-login")),
   message_patterns=("vpn", "remote access", "ssl-vpn"),
   evidence_threshold=5)

_c("IS.WP.RM", 2,
   "Remote desktop monitoring",
   "RDP and remote administration sessions are tracked",
   "Info Security §II.C.15",
   ("AC-17",),
   event_ids=frozenset({"4624"}),
   field_patterns=(("dstport", "3389"),),
   message_patterns=("rdp", "remote desktop", "logontype.*10"),
   evidence_threshold=3)


# -- IS.WP.PM  Privilege Management ----------------------------------------

_c("IS.WP.PM", 1,
   "Privileged activity monitoring",
   "Use of administrative and elevated privileges is logged",
   "Info Security §II.C.10",
   ("AC-6",),
   event_ids=frozenset({"4672", "4648", "4673"}),
   message_patterns=("privilege", "admin", "elevated"),
   evidence_threshold=10)

_c("IS.WP.PM", 2,
   "Administrative group changes",
   "Changes to administrator and privileged groups are alerted",
   "Info Security §II.C.10",
   ("AC-6",),
   event_ids=frozenset({"4728", "4732", "4756"}),
   message_patterns=("admin group", "domain admins", "administrators"),
   evidence_threshold=1)


# -- IS.WP.MV  Malware & Vulnerability Management --------------------------

_c("IS.WP.MV", 1,
   "Malware detection events",
   "Antivirus and anti-malware detections are logged and responded to",
   "Info Security §II.C.16",
   ("SI-3",),
   event_ids=frozenset({"1116", "1117", "5001"}),
   field_patterns=(("subtype", "virus"),),
   message_patterns=("malware", "virus", "trojan", "ransomware"),
   evidence_threshold=1)

_c("IS.WP.MV", 2,
   "IPS signature monitoring",
   "Intrusion prevention signatures trigger alerts and blocks",
   "Info Security §II.C.9",
   ("SI-4",),
   field_patterns=(("subtype", "ips"),),
   message_patterns=("ips", "signature", "cve"),
   evidence_threshold=5)

_c("IS.WP.MV", 3,
   "Vulnerability scan evidence",
   "Vulnerability assessment results are reviewed",
   "Info Security §II.C.16",
   ("RA-5",),
   message_patterns=("vulnerability", "scan", "cve", "patch"),
   evidence_threshold=1)


# ---------------------------------------------------------------------------
# Matching logic
# ---------------------------------------------------------------------------

def matches_control(event_extra: dict[str, str], message: str,
                    ctrl: FFIECControl) -> bool:
    """Check if an event matches any detection criteria for a control."""
    # Event ID match
    eid = event_extra.get("EventID", "") or event_extra.get("eventid", "")
    if eid and ctrl.event_ids and str(eid) in ctrl.event_ids:
        return True

    # Field pattern match (any pair matches)
    if ctrl.field_patterns:
        for field_name, expected in ctrl.field_patterns:
            val = event_extra.get(field_name, "")
            if not val:
                # case-insensitive fallback
                for k, v in event_extra.items():
                    if k.lower() == field_name.lower():
                        val = v
                        break
            if val and expected.lower() in val.lower():
                return True

    # Message pattern match
    if ctrl.message_patterns:
        msg_lower = message.lower()
        if any(re.search(p, msg_lower) for p in ctrl.message_patterns):
            return True

    return False


def get_domain_controls(domain: str) -> list[FFIECControl]:
    """Return all controls for a given domain."""
    return [c for c in CONTROLS.values() if c.domain == domain]


def evidence_status(count: int, ctrl: FFIECControl) -> str:
    """Return evidence status label."""
    if count >= ctrl.evidence_threshold:
        return "Sufficient"
    if count >= ctrl.partial_threshold:
        return "Partial"
    return "None"
