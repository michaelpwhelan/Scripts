#!/usr/bin/env python3
"""Pipeline operators: head, tail, sort, count, dedup, etc."""

from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass
from datetime import datetime
from math import floor

from logparse.models import SEV_ORDER, LogEvent, get_field
from logparse.severity import SEV_KEYWORDS, SEV_NORMALIZE


@dataclass
class AggResult:
    """Aggregation result from count-by, timeline, etc."""

    key: str
    count: int
    field: str = ""


@dataclass
class StatsResult:
    """Numeric statistics for a field."""

    field: str
    count: int
    min_val: float
    max_val: float
    avg_val: float
    sum_val: float
    median_val: float = 0.0
    stddev_val: float = 0.0
    p95_val: float = 0.0
    p99_val: float = 0.0


def _op_count(events: list[LogEvent]) -> list[AggResult]:
    return [AggResult(key="Count", count=len(events))]


def _op_count_by(events: list[LogEvent], field: str) -> list[AggResult]:
    if not events:
        return []
    if not isinstance(events[0], LogEvent):
        return events
    counter: Counter[str] = Counter()
    for e in events:
        val = get_field(e, field) or "(empty)"
        counter[val] += 1
    return [
        AggResult(key=k, count=c, field=field)
        for k, c in counter.most_common()
    ]


def _op_sort(
    events: list[LogEvent], field: str, direction: str | None = None
) -> list[LogEvent]:
    if not events or not isinstance(events[0], LogEvent):
        return events  # can't sort non-LogEvent results
    fl = field.lower()

    if fl == "severity":
        # SEV_ORDER: Critical=0 .. Info=4  →  Python ascending = Critical first.
        # Users expect "most severe first" as the default for severity,
        # and "asc" to mean "least severe first" (Info → Critical).
        descending = direction is not None and direction.lower() == "asc"
    else:
        descending = direction is not None and direction.lower() == "desc"

    # Separate events with null/empty values — always sort them to the end
    if fl == "severity":
        def sort_key(e: LogEvent) -> int:
            """Map severity to numeric sort order."""
            return SEV_ORDER.get(e.severity, 5)
    elif fl == "timestamp":
        def sort_key(e: LogEvent) -> str:
            """Sort by timestamp."""
            if e.timestamp is None:
                return ""
            return e.timestamp.isoformat()
    else:
        def sort_key(e: LogEvent) -> tuple:
            """Sort by field value, numeric first then lexical."""
            v = get_field(e, fl) or ""
            try:
                return (0, float(v))
            except (ValueError, TypeError):
                return (1, v.lower())

    # Partition: events with values sort normally, nulls go to the end
    has_value = []
    no_value = []
    for e in events:
        v = get_field(e, fl)
        if v is None or v == "":
            no_value.append(e)
        else:
            has_value.append(e)

    has_value.sort(key=sort_key, reverse=descending)
    return has_value + no_value


def _op_head(events: list[LogEvent], n: int) -> list[LogEvent]:
    return events[:n]


def _op_tail(events: list[LogEvent], n: int) -> list[LogEvent]:
    return events[-n:] if n < len(events) else events


def _op_dedup(events: list[LogEvent], field: str | None = None) -> list[LogEvent]:
    """Collapse duplicate events.  Dedup by field value or message content."""
    if not events or not isinstance(events[0], LogEvent):
        return events  # can't dedup non-LogEvent results
    seen: set[str] = set()
    result: list[LogEvent] = []
    for e in events:
        if field:
            key = get_field(e, field) or ""
        else:
            key = e.message
        if key not in seen:
            seen.add(key)
            result.append(e)
    return result


def _op_where(events: list[LogEvent], filter_text: str) -> list[LogEvent]:
    """Apply a filter condition within the pipeline."""
    if not events or not isinstance(events[0], LogEvent):
        return events
    from logparse.filter_engine import parse_conditions, match_event
    conditions = parse_conditions(filter_text)
    if not conditions:
        return events
    return [e for e in events if match_event(e, conditions)]


def _op_grep(events: list[LogEvent], pattern: str) -> list[LogEvent]:
    """Grep-style text search across all fields in the pipeline."""
    if not events or not isinstance(events[0], LogEvent):
        return events
    from logparse.filter_engine import grep_events
    return grep_events(events, pattern)


def _op_field(events: list[LogEvent], name: str) -> list[LogEvent]:
    """Extract a single field — passthrough for pipeline compatibility."""
    return events


def _op_stats(events: list[LogEvent], field: str) -> list[StatsResult]:
    """Compute numeric statistics for a field."""
    if not events:
        return []
    if not isinstance(events[0], LogEvent):
        return events
    values: list[float] = []
    for e in events:
        raw = get_field(e, field)
        if raw is None:
            continue
        try:
            values.append(float(raw))
        except (ValueError, TypeError):
            continue
    if not values:
        return [StatsResult(field=field, count=0, min_val=0, max_val=0, avg_val=0, sum_val=0)]
    import statistics as _stats
    sorted_vals = sorted(values)
    n = len(sorted_vals)
    return [StatsResult(
        field=field,
        count=n,
        min_val=min(values),
        max_val=max(values),
        avg_val=sum(values) / n,
        sum_val=sum(values),
        median_val=_stats.median(values),
        stddev_val=_stats.stdev(values) if n >= 2 else 0.0,
        p95_val=sorted_vals[min(int(n * 0.95), n - 1)] if n >= 20 else sorted_vals[-1],
        p99_val=sorted_vals[min(int(n * 0.99), n - 1)],
    )]


def _op_timeline(events: list[LogEvent], interval: str) -> list[AggResult]:
    if not events:
        return []
    if not isinstance(events[0], LogEvent):
        return events
    bucket_minutes = {
        "1m": 1, "5m": 5, "10m": 10, "15m": 15, "30m": 30,
        "1h": 60, "hour": 60, "1d": 1440, "day": 1440,
    }.get(interval, 60)
    bucket_secs = bucket_minutes * 60

    groups: dict[str, int] = {}
    fmt = "%Y-%m-%d %H:%M" if bucket_minutes < 1440 else "%Y-%m-%d"

    for e in events:
        if e.timestamp is None:
            continue
        ts_epoch = e.timestamp.timestamp()
        bucket_epoch = floor(ts_epoch / bucket_secs) * bucket_secs
        try:
            bucket_dt = datetime.fromtimestamp(bucket_epoch)
        except (OSError, OverflowError, ValueError):
            continue
        label = bucket_dt.strftime(fmt)
        groups[label] = groups.get(label, 0) + 1

    return [AggResult(key=k, count=v) for k, v in groups.items()]


def _op_severity(events: list[LogEvent], text: str) -> list[LogEvent]:
    """Filter events by severity keywords (e.g. 'severity Medium', 'high and critical')."""
    if not events or not isinstance(events[0], LogEvent):
        return events
    # Strip optional "severity" prefix
    clean = text.strip()
    if clean.lower().startswith("severity"):
        clean = clean[len("severity"):].strip()
    # Split on comma, and, or — extract severity tokens
    tokens = re.split(r"\s*(?:,|and|or)\s*", clean, flags=re.IGNORECASE)
    sev_values = set()
    for t in tokens:
        t = t.strip().lower()
        if t in SEV_KEYWORDS:
            sev_values.add(SEV_NORMALIZE.get(t, t.capitalize()))
    if not sev_values:
        return events
    return [e for e in events if e.severity in sev_values]


# -- dispatcher ---------------------------------------------------------------

_PATTERNS: list[tuple[re.Pattern[str], object]] = [
    (re.compile(r"^count$", re.I), lambda e, m: _op_count(e)),
    (
        re.compile(r"^count\s+by\s+(\w+)$", re.I),
        lambda e, m: _op_count_by(e, m.group(1)),
    ),
    (
        re.compile(r"^sort\s+flip$", re.I),
        lambda e, m: list(reversed(e)),
    ),
    (
        re.compile(r"^sort\s+(?:by\s+)?(\w+)\s*(asc|desc)?$", re.I),
        lambda e, m: _op_sort(e, m.group(1), m.group(2)),
    ),
    (
        re.compile(r"^head\s+(\d+)$", re.I),
        lambda e, m: _op_head(e, min(int(m.group(1)), 100_000)),
    ),
    (
        re.compile(r"^tail\s+(\d+)$", re.I),
        lambda e, m: _op_tail(e, min(int(m.group(1)), 100_000)),
    ),
    (
        re.compile(r"^top\s+(\d+)$", re.I),
        lambda e, m: _op_head(e, min(int(m.group(1)), 100_000)),
    ),
    (
        re.compile(r"^dedup(?:\s+(\w+))?$", re.I),
        lambda e, m: _op_dedup(e, m.group(1)),
    ),
    (
        re.compile(r"^timeline\s+(\w+)$", re.I),
        lambda e, m: _op_timeline(e, m.group(1)),
    ),
    (
        re.compile(r"^field\s+(\w+)$", re.I),
        lambda e, m: _op_field(e, m.group(1)),
    ),
    (
        re.compile(r"^stats\s+(\w+)$", re.I),
        lambda e, m: _op_stats(e, m.group(1)),
    ),
    # "| severity Medium" or "| Medium" or "| high and critical" — severity filter
    (
        re.compile(
            r"^(?:severity\s+)?("
            + "|".join(sorted(SEV_KEYWORDS, key=len, reverse=True))
            + r")(?:\s*(?:,|and|or)\s*(?:"
            + "|".join(sorted(SEV_KEYWORDS, key=len, reverse=True))
            + r"))*$",
            re.I,
        ),
        lambda e, m: _op_severity(e, m.group(0)),
    ),
    # "| where severity:High" or "| show where severity:High" — inline filter
    (
        re.compile(r"^(?:show\s+)?where\s+(.+)$", re.I),
        lambda e, m: _op_where(e, m.group(1)),
    ),
    # "| grep <pattern>" or "| search <pattern>" — text search across all fields
    (
        re.compile(r"^(?:grep|search)\s+(.+)$", re.I),
        lambda e, m: _op_grep(e, m.group(1).strip().strip('"').strip("'")),
    ),
    # "| show <text>" — text search (in pipeline context, bare text = grep)
    (
        re.compile(r"^show\s+(.+)$", re.I),
        lambda e, m: _op_grep(e, m.group(1).strip().strip('"').strip("'")),
    ),
    # bare "| show" — pass-through (display happens anyway)
    (re.compile(r"^show$", re.I), lambda e, m: e),
]


def extract_visual(ops: list[str]) -> tuple[list[str], str | None]:
    """Strip a trailing 'visual <type>' from pipe ops.

    Returns (remaining_ops, visual_type_or_None).
    """
    if ops and ops[-1].strip().lower().startswith("visual "):
        return ops[:-1], ops[-1].strip()[7:].strip().lower()
    return ops, None


def _op_context(
    seed: list[LogEvent],
    duration_str: str,
    all_events: list[LogEvent],
) -> list[LogEvent]:
    """Expand seed events to include all events within ±duration."""
    from bisect import bisect_left, bisect_right
    from logparse.util import parse_duration

    delta = parse_duration(duration_str)
    if delta is None:
        return seed  # invalid duration — pass through

    match_times = sorted(
        e.timestamp.timestamp() for e in seed if e.timestamp
    )
    if not match_times:
        return seed

    delta_secs = delta.total_seconds()
    timed = sorted(
        ((e.timestamp.timestamp(), e) for e in all_events if e.timestamp),
        key=lambda x: x[0],
    )
    all_epochs = [t[0] for t in timed]

    result_indices: set[int] = set()
    for mt in match_times:
        lo = bisect_left(all_epochs, mt - delta_secs)
        hi = bisect_right(all_epochs, mt + delta_secs)
        for i in range(lo, hi):
            result_indices.add(i)

    result = [timed[i][1] for i in sorted(result_indices)]
    no_ts = [e for e in seed if e.timestamp is None]
    result.extend(no_ts)
    return result


_CONTEXT_RE = re.compile(r"^context\s+(\S+)$", re.I)


def apply_pipeline(
    events: list[LogEvent],
    ops: list[str],
    warnings: list[str] | None = None,
    all_events: list[LogEvent] | None = None,
) -> list:
    """Apply a sequence of pipeline operators to events.

    Returns ``list[LogEvent]`` or ``list[AggResult]`` depending on
    the final operator.  Pass a list as *warnings* to collect messages
    about unknown operators.  Pass *all_events* to enable ``context``
    expansion in the pipeline.
    """
    result: list = events
    for op_str in ops:
        op_str = op_str.strip()
        if not op_str:
            continue
        matched = False

        # context needs all_events — handle separately
        ctx_m = _CONTEXT_RE.match(op_str)
        if ctx_m:
            if all_events is not None:
                result = _op_context(result, ctx_m.group(1), all_events)
                matched = True
            elif warnings is not None:
                warnings.append(
                    "context requires all_events — use as a standalone "
                    "command instead: context " + ctx_m.group(1)
                )
                matched = True

        if not matched:
            for pattern, handler in _PATTERNS:
                m = pattern.match(op_str)
                if m:
                    result = handler(result, m)
                    matched = True
                    break
        if not matched and warnings is not None:
            parts = op_str.split()
            op_verb = parts[0].lower() if parts else ""
            known = ["count", "sort", "head", "tail", "top", "dedup",
                      "timeline", "field", "stats", "context", "where",
                      "show", "grep", "search", "severity"]
            from logparse.commands import _levenshtein
            suggestions = [k for k in known if _levenshtein(op_verb, k) <= 2]
            if suggestions:
                warnings.append(
                    f"Unknown operator '{op_verb}'. Did you mean: {suggestions[0]}?"
                )
            else:
                warnings.append(f"Unknown operator '{op_verb}' — ignored.")
    return result
