#!/usr/bin/env python3
"""Raw text fallback parser — nothing is silently dropped."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from logparse.models import LogEvent, severity_from_text

# Locale-independent English month lookup (syslog always uses English)
_MONTH_MAP = {
    "Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
    "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12,
}

# Ordered list of timestamp patterns to try (most specific first)
_TS_PATTERNS: list[tuple[re.Pattern[str], str]] = [
    # ISO 8601: 2025-03-19T14:30:00
    (
        re.compile(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})"),
        "%Y-%m-%dT%H:%M:%S",
    ),
    # Common log: 2025-03-19 14:30:00
    (
        re.compile(r"(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})"),
        "%Y-%m-%d %H:%M:%S",
    ),
    # US date: 03/19/2025 14:30:00
    (
        re.compile(r"(\d{2}/\d{2}/\d{4} \d{2}:\d{2}:\d{2})"),
        "%m/%d/%Y %H:%M:%S",
    ),
]

# Syslog pattern handled separately (locale-independent month lookup)
_SYSLOG_RE = re.compile(
    r"(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)"
    r"\s+(\d{1,2})\s+(\d{2}):(\d{2}):(\d{2})"
)


def _parse_syslog_ts(line: str) -> datetime | None:
    """Parse syslog timestamp using locale-independent month lookup.

    Year inference: syslog timestamps lack a year field. We assume the
    current year unless the result is more than 14 days in the future
    (likely a year-wrap from old logs) — but NOT if we're near a year
    boundary (Dec/Jan) where a future date probably means the next day.
    """
    m = _SYSLOG_RE.search(line)
    if not m:
        return None
    month = _MONTH_MAP[m.group(1)]
    day, hour, minute, second = int(m.group(2)), int(m.group(3)), int(m.group(4)), int(m.group(5))
    now = datetime.now()
    year = now.year
    ts = datetime(year, month, day, hour, minute, second)
    # Only roll back a year if the timestamp is far in the future (>14 days).
    # Near year boundaries (Dec→Jan), a few days ahead is normal.
    if ts > now and (ts - now).days > 14:
        ts = ts.replace(year=year - 1)
    return ts


def _extract_timestamp(line: str) -> datetime | None:
    for pattern, fmt in _TS_PATTERNS:
        m = pattern.search(line)
        if m:
            try:
                ts = datetime.strptime(m.group(1), fmt)
                return ts
            except ValueError:
                continue
    # Syslog format — locale-independent
    return _parse_syslog_ts(line)


def parse_raw_text(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a file as plain text, one event per non-empty line."""
    events: list[LogEvent] = []
    stem = path.stem

    with open(path, encoding="utf-8", errors="replace") as f:
        for line_num, raw_line in enumerate(f, 1):
            raw_line = raw_line.rstrip("\n\r")
            if not raw_line.strip():
                continue

            ts = _extract_timestamp(raw_line)
            severity = severity_from_text(raw_line)

            events.append(
                LogEvent(
                    timestamp=ts,
                    severity=severity,
                    source=stem,
                    message=raw_line,
                    extra={},
                    raw=raw_line,
                    source_file=source_file,
                    source_format="raw_text",
                    line_number=line_num,
                )
            )

    return events
