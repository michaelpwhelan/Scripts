#!/usr/bin/env python3
"""FortiGate configuration file parser with security flag evaluation."""

from __future__ import annotations

import re
from pathlib import Path

from logparse.models import LogEvent

_SET_RE = re.compile(r"^set\s+(\S+)\s+(.+)$")


def parse_fortigate_conf(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a FortiGate .conf file into config-entry events."""
    lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    events: list[LogEvent] = []

    # header extraction
    header_extra: dict[str, str] = {}
    for line in lines:
        if m := re.match(r"^#config-version=(\w+)-([^:]+):", line):
            header_extra["Model"] = m.group(1)
            header_extra["Firmware"] = m.group(2)
        if m := re.match(r"^#buildno=(\d+)", line):
            header_extra["BuildNo"] = m.group(1)
        if not line.startswith("#"):
            break

    section_stack: list[str] = []
    current_section = ""
    edit_id = ""
    edit_settings: dict[str, str] = {}
    edit_raw_lines: list[str] = []
    in_edit = False
    nest_depth = 0
    _hostname = ""

    for i, raw in enumerate(lines, 1):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue

        if m := re.match(r"^config\s+(.+)$", line):
            if in_edit:
                nest_depth += 1
                edit_raw_lines.append(raw)
            else:
                section_stack.append(m.group(1))
                current_section = " > ".join(section_stack)
            continue

        if line == "end":
            if in_edit and nest_depth > 0:
                nest_depth -= 1
                edit_raw_lines.append(raw)
                continue
            if in_edit:
                # Emit pending edit block before closing (same as 'next')
                edit_raw_lines.append(raw)
                in_edit = False
                sec_part = current_section.split(">")[-1].strip()
                name = edit_settings.get("name", edit_id)
                extra = dict(edit_settings)
                for k, v in header_extra.items():
                    extra[f"Config_{k}"] = v
                extra["Section"] = current_section
                events.append(
                    LogEvent(
                        timestamp=None,
                        severity="Low",
                        source=sec_part,
                        message=f"[{sec_part} {edit_id}] {name}",
                        extra=extra,
                        raw="\n".join(edit_raw_lines),
                        source_file=source_file,
                        source_format="fortigate_conf",
                        line_number=i,
                    )
                )
                continue
            if section_stack:
                section_stack.pop()
                current_section = " > ".join(section_stack) if section_stack else ""
            continue

        if m := re.match(r'^edit\s+"?([^"]+)"?$', line):
            edit_id = m.group(1)
            edit_settings = {}
            edit_raw_lines = [raw]
            in_edit = True
            nest_depth = 0
            continue

        if line == "next" and in_edit:
            edit_raw_lines.append(raw)
            in_edit = False

            if "system global" in current_section and edit_settings.get("hostname"):
                _hostname = edit_settings["hostname"]

            severity = "Low"
            flags: list[str] = []

            # security flag evaluation
            if edit_settings.get("status") == "disable":
                severity = "Medium"
                flags.append("DISABLED")

            if "firewall policy" in current_section:
                sa = edit_settings.get("srcaddr", "")
                da = edit_settings.get("dstaddr", "")
                svc = edit_settings.get("service", "")
                if re.fullmatch(r'(?i)"?all"?', sa.strip()) and re.fullmatch(r'(?i)"?all"?', da.strip()) and re.fullmatch(r'(?i)"?all"?', svc.strip()):
                    severity = "Medium"
                    flags.append("PERMISSIVE")

                act = edit_settings.get("action", "deny")
                if act == "accept":
                    utm_keys = {k for k in edit_settings if re.match(
                        r"^(utm-status|av-profile|webfilter-profile|ips-sensor|application-list|ssl-ssh-profile)$", k
                    )}
                    if not utm_keys:
                        flags.append("NO-UTM")
                    if not edit_settings.get("ips-sensor"):
                        severity = "Medium"
                        flags.append("NO-IPS")

                log_traffic = edit_settings.get("logtraffic")
                if log_traffic == "disable":
                    severity = "Medium"
                    flags.append("NO-LOGGING")

                if "certificate-inspection" in edit_settings.get("ssl-ssh-profile", ""):
                    flags.append("WEAK-SSL-INSPECT")

            if "system interface" in current_section:
                if re.search(r"\b(http|telnet)\b", edit_settings.get("allowaccess", "")):
                    severity = "High"
                    flags.append("INSECURE-MGMT")

            if "system password-policy" in current_section:
                min_len_str = edit_settings.get("minimum-length", "")
                if min_len_str:
                    try:
                        if int(min_len_str) < 8:
                            severity = "Medium"
                            flags.append("WEAK-PASSWD-POLICY")
                    except ValueError:
                        pass
                if edit_settings.get("status") == "disable":
                    severity = "Medium"
                    flags.append("WEAK-PASSWD-POLICY")

            # build message
            sec_part = current_section.split(">")[-1].strip()
            name = edit_settings.get("name", edit_id)
            msg_parts = [f"[{sec_part} {edit_id}] {name}"]

            if "firewall policy" in current_section:
                si = edit_settings.get("srcintf", "?")
                di = edit_settings.get("dstintf", "?")
                msg_parts.append(f"{si}->{di}")
                for fld in ("srcaddr", "dstaddr", "action"):
                    if v := edit_settings.get(fld):
                        msg_parts.append(f"{fld}={v}")

            if flags:
                msg_parts.append(f"[{','.join(flags)}]")

            extra: dict[str, str] = dict(edit_settings)
            for k, v in header_extra.items():
                extra[f"Config_{k}"] = v
            extra["Section"] = current_section

            events.append(
                LogEvent(
                    timestamp=None,
                    severity=severity,
                    source=sec_part,
                    message=": ".join(msg_parts),
                    extra=extra,
                    raw="\n".join(edit_raw_lines),
                    source_file=source_file,
                    source_format="fortigate_conf",
                    line_number=i,
                )
            )
            continue

        if in_edit:
            edit_raw_lines.append(raw)
            if m := _SET_RE.match(line):
                edit_settings[m.group(1)] = m.group(2).strip('"')
            continue

        if not in_edit:
            if m := _SET_RE.match(line):
                if "system global" in current_section and m.group(1) == "hostname":
                    _hostname = m.group(2).strip('"')

    return events
