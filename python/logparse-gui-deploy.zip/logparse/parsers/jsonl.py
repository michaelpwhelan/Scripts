#!/usr/bin/env python3
"""JSON Lines / NDJSON parser."""

from __future__ import annotations

import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path

from logparse.models import LogEvent, severity_from_text

log = logging.getLogger(__name__)

# Common field names that map to LogEvent.timestamp
_TS_KEYS = {"timestamp", "time", "@timestamp", "ts", "date"}
# Common field names that map to LogEvent.message
_MSG_KEYS = {"message", "msg", "log"}
# Common field names that map to LogEvent.severity
_SEV_KEYS = {"level", "severity", "loglevel"}
# Common field names that map to LogEvent.source
_SRC_KEYS = {"source", "host", "hostname"}


def _intern_pairs(items: list[tuple[str, object]]) -> dict[str, object]:
    """object_pairs_hook for json.loads — interns dict keys."""
    return {sys.intern(k): v for k, v in items}


def _flatten(obj: dict, prefix: str = "") -> dict[str, str]:
    """Flatten nested dicts with dot notation, stringify non-string values."""
    result: dict[str, str] = {}
    for k, v in obj.items():
        key = sys.intern(f"{prefix}.{k}") if prefix else sys.intern(k)
        if isinstance(v, dict):
            result.update(_flatten(v, key))
        elif isinstance(v, list):
            for idx, item in enumerate(v):
                if isinstance(item, dict):
                    result.update(_flatten(item, f"{key}.{idx}"))
            # Also store a joined string for simple lookups
            simple = [str(x) for x in v if not isinstance(x, dict) and x is not None]
            if simple:
                result[key] = ", ".join(simple)
            elif not any(isinstance(x, dict) for x in v):
                result[key] = ""
        elif isinstance(v, str):
            result[key] = v
        elif v is None:
            result[key] = ""
        else:
            result[key] = str(v)
    return result


def _parse_timestamp(value: str) -> datetime | None:
    """Try common timestamp formats."""
    for fmt in (
        "%Y-%m-%dT%H:%M:%S.%fZ",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S.%f%z",
        "%Y-%m-%dT%H:%M:%S%z",
        "%Y-%m-%dT%H:%M:%S.%f",
        "%Y-%m-%dT%H:%M:%S",
        "%Y-%m-%d %H:%M:%S.%f",
        "%Y-%m-%d %H:%M:%S",
    ):
        try:
            return datetime.strptime(value, fmt)
        except ValueError:
            continue
    # epoch seconds/millis — use UTC to avoid naive/aware mixing
    try:
        epoch = float(value)
        if epoch > 1e12:
            epoch /= 1000
        return datetime.fromtimestamp(epoch, tz=timezone.utc).replace(tzinfo=None)
    except (ValueError, OSError, OverflowError):
        pass
    return None


def _match_key(keys: set[str], flat: dict[str, str]) -> str | None:
    """Find first matching key (case-insensitive) from flat dict."""
    for k, v in flat.items():
        if k.lower() in keys:
            return v
    return None


def _detect_m365(flat: dict[str, str]) -> tuple[str, str, str]:
    """Detect M365 source type and extract severity/message.

    Returns ``(source_type, severity, message)`` or ``("", "", "")``
    if the event is not from M365.
    """
    # Defender security alerts
    if "alertId" in flat and "severity" in flat:
        sev_map = {"high": "High", "medium": "Medium", "low": "Low",
                   "informational": "Info"}
        sev = sev_map.get(flat.get("severity", "").lower(), "Medium")
        msg = flat.get("title", "") or flat.get("description", "")
        return "m365-defender", sev, msg

    # Entra sign-in logs
    if "userPrincipalName" in flat and ("status.errorCode" in flat
                                         or "status.failureReason" in flat):
        error_code = flat.get("status.errorCode", "0")
        sev = "High" if error_code != "0" else "Low"
        upn = flat.get("userPrincipalName", "")
        app = flat.get("appDisplayName", "")
        msg = f"{upn} sign-in" + (f" to {app}" if app else "")
        if error_code != "0":
            reason = flat.get("status.failureReason", "")
            msg += f" FAILED ({reason})" if reason else " FAILED"
        return "m365-signin", sev, msg

    # Directory audit events
    if "activityDisplayName" in flat and "category" in flat:
        msg = flat.get("activityDisplayName", "")
        cat = flat.get("category", "")
        if cat:
            msg = f"[{cat}] {msg}"
        return "m365-directory", "Low", msg

    # Identity risk detections
    if "riskLevel" in flat and "riskEventType" in flat:
        risk_map = {"high": "High", "medium": "Medium", "low": "Low",
                    "hidden": "Info", "none": "Info"}
        sev = risk_map.get(flat.get("riskLevel", "").lower(), "Medium")
        event_type = flat.get("riskEventType", "")
        user = flat.get("userDisplayName", "") or flat.get("userPrincipalName", "")
        msg = f"{event_type}" + (f" ({user})" if user else "")
        return "m365-risk", sev, msg

    return "", "", ""


def parse_jsonl(path: Path, source_file: str) -> list[LogEvent]:
    """Parse a JSON Lines file into LogEvent objects."""
    events: list[LogEvent] = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line_num, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                obj = json.loads(line, object_pairs_hook=_intern_pairs)
            except json.JSONDecodeError:
                log.warning("jsonl: skipping invalid JSON at line %d", line_num)
                continue

            if not isinstance(obj, dict):
                log.warning("jsonl: skipping non-object at line %d", line_num)
                continue

            flat = _flatten(obj)

            # Map common fields to LogEvent core attrs
            ts_str = _match_key(_TS_KEYS, flat)
            timestamp = _parse_timestamp(ts_str) if ts_str else None

            message = _match_key(_MSG_KEYS, flat) or ""
            sev_str = _match_key(_SEV_KEYS, flat) or ""
            source = _match_key(_SRC_KEYS, flat) or ""

            # Derive severity
            if sev_str:
                severity = _level_to_severity(sev_str)
            else:
                severity = severity_from_text(message or line)

            # M365 enrichment — only activates when M365 fields are present
            m365_type, m365_sev, m365_msg = _detect_m365(flat)
            if m365_type:
                source = source or m365_type
                if not message:
                    message = m365_msg
                # M365 severity always takes priority — the "severity" field
                # in Graph API responses is the alert severity, not a log level
                if m365_sev:
                    severity = m365_sev

            # All flattened keys go to extra
            extra = flat

            events.append(LogEvent(
                timestamp=timestamp,
                severity=severity,
                source=source,
                message=message,
                extra=extra,
                raw=line,
                source_file=source_file,
                source_format="jsonl",
                line_number=line_num,
            ))

    return events


def _level_to_severity(level: str) -> str:
    """Map common log level strings to LogEvent severity."""
    lvl = level.lower().strip()
    if lvl in ("fatal", "critical", "emergency", "emerg"):
        return "Critical"
    if lvl in ("error", "err"):
        return "High"
    if lvl in ("warn", "warning"):
        return "Medium"
    if lvl in ("info", "notice", "information"):
        return "Low"
    if lvl in ("debug", "trace", "verbose"):
        return "Info"
    return severity_from_text(level)
