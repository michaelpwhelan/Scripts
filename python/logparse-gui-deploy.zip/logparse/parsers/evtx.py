#!/usr/bin/env python3
"""Windows EVTX binary parser via python-evtx."""

from __future__ import annotations

import logging
import struct
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path

from logparse.enrichment import EVENT_ID
from logparse.models import LogEvent

log = logging.getLogger(__name__)

# Namespace frequently found in EVTX XML
_NS = "{http://schemas.microsoft.com/win/2004/08/events/event}"


def _level_to_severity(level: int, event_id: int) -> str:
    match level:
        case 1:
            return "Critical"
        case 2:
            return "High"
        case 3:
            return "Medium"
        case 4:
            return "Low"
        case 5:
            return "Info"
        case 0:
            return "Medium" if event_id == 1102 else "Low"
        case _:
            return "Low"


def _parse_xml_record(xml_str: str, source_file: str, line_num: int) -> LogEvent | None:
    """Parse a single EVTX record's XML into a LogEvent."""
    try:
        root = ET.fromstring(xml_str)
    except ET.ParseError:
        return None

    # Try with and without namespace
    def find(parent: ET.Element, tag: str) -> ET.Element | None:
        """Find child element with or without XML namespace."""
        el = parent.find(f"{_NS}{tag}")
        if el is None:
            el = parent.find(tag)
        return el

    def findtext(parent: ET.Element, tag: str) -> str:
        """Return text content of a child element, or empty string."""
        el = find(parent, tag)
        if el is None:
            return ""
        return el.text or ""

    sys_el = find(root, "System")
    if sys_el is None:
        return None

    # EventID
    eid_el = find(sys_el, "EventID")
    event_id = 0
    if eid_el is not None:
        text = eid_el.text or ""
        try:
            event_id = int(text)
        except ValueError:
            pass

    # Provider
    prov_el = find(sys_el, "Provider")
    provider = prov_el.get("Name", "") if prov_el is not None else ""

    # Computer
    computer = findtext(sys_el, "Computer")

    # Channel
    channel = findtext(sys_el, "Channel")

    # Level
    level = 0
    level_text = findtext(sys_el, "Level")
    if level_text:
        try:
            level = int(level_text)
        except ValueError:
            pass

    # TimeCreated
    ts: datetime | None = None
    tc_el = find(sys_el, "TimeCreated")
    if tc_el is not None:
        time_str = tc_el.get("SystemTime", "")
        if time_str:
            # handle fractional seconds and Z suffix
            time_str = time_str.rstrip("Z")
            for fmt in ("%Y-%m-%d %H:%M:%S.%f", "%Y-%m-%d %H:%M:%S", "%Y-%m-%dT%H:%M:%S.%f", "%Y-%m-%dT%H:%M:%S"):
                try:
                    ts = datetime.strptime(time_str, fmt)
                    break
                except ValueError:
                    continue

    extra: dict[str, str] = {
        "EventID": str(event_id),
        "ProviderName": provider,
        "LogName": channel,
        "Computer": computer,
    }
    if desc := EVENT_ID.get(event_id):
        extra["EventDescription"] = desc

    # EventData
    for data_tag in ("EventData", f"{_NS}EventData"):
        ed = root.find(data_tag)
        if ed is not None:
            for data_el in ed:
                name = data_el.get("Name", "")
                text = data_el.text or ""
                if name and text:
                    extra[name] = text
            break

    # UserData
    for ud_tag in ("UserData", f"{_NS}UserData"):
        ud = root.find(ud_tag)
        if ud is not None:
            for child in ud:
                for sub in child:
                    local = sub.tag.split("}")[-1] if "}" in sub.tag else sub.tag
                    text = sub.text or ""
                    if local and text:
                        extra[local] = text
            break

    severity = _level_to_severity(level, event_id)

    msg = extra.get("EventDescription", "")
    if not msg:
        msg = f"Event {event_id}"
    if target_user := extra.get("TargetUserName"):
        msg += f" - User: {target_user}"

    return LogEvent(
        timestamp=ts,
        severity=severity,
        source=provider,
        message=msg,
        extra=extra,
        raw=xml_str,
        source_file=source_file,
        source_format="evtx",
        line_number=line_num,
    )


def parse_evtx(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a binary .evtx file using python-evtx."""
    try:
        from Evtx.Evtx import FileHeader
    except ImportError:
        log.error(
            "python-evtx not installed. Install with: pip install logparse[evtx]"
        )
        return []

    events: list[LogEvent] = []
    line_num = 0

    try:
        with open(path, "rb") as f:
            fh = FileHeader(f.read(), 0x0)
            for chunk in fh.chunks():
                for record in chunk.records():
                    line_num += 1
                    try:
                        xml_str = record.xml()
                    except (OSError, ValueError, struct.error, UnicodeDecodeError) as exc:
                        log.debug("Skipping EVTX record %d: %s", line_num, exc)
                        continue
                    evt = _parse_xml_record(xml_str, source_file, line_num)
                    if evt is not None:
                        events.append(evt)
    except (OSError, ValueError, struct.error, KeyError) as exc:
        log.warning("EVTX parse error for %s: %s", source_file, exc)

    return events
