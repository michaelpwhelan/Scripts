#!/usr/bin/env python3
"""Windows Event Log XML export parser."""

from __future__ import annotations

import logging
import re
import xml.etree.ElementTree as ET
from pathlib import Path

from logparse.models import LogEvent
from logparse.parsers.evtx import _parse_xml_record

log = logging.getLogger(__name__)


def parse_windows_xml(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse an exported Windows Event XML file."""
    events: list[LogEvent] = []

    try:
        content = path.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        log.warning("Could not read %s: %s", source_file, exc)
        return events

    if "<Event" not in content:
        log.warning("No Event elements found in XML file: %s", source_file)
        return events

    # wrap in root element if needed
    if not re.search(r"<Events[\s>]", content):
        content = f"<Events>{content}</Events>"

    # strip namespace for simpler parsing
    content = re.sub(r'xmlns="[^"]*"', "", content)

    try:
        root = ET.fromstring(content)
    except ET.ParseError as exc:
        log.warning("XML parse error for %s: %s", source_file, exc)
        return events

    for line_num, event_el in enumerate(root.iter("Event"), 1):
        xml_str = ET.tostring(event_el, encoding="unicode")
        evt = _parse_xml_record(xml_str, source_file, line_num)
        if evt is not None:
            evt.source_format = "windows_xml"
            events.append(evt)

    return events
