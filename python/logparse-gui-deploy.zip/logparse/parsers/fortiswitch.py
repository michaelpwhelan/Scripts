#!/usr/bin/env python3
"""FortiSwitch event log parser."""

from __future__ import annotations

import re
from pathlib import Path

from logparse.models import LogEvent, severity_from_forti_level, severity_from_text
from logparse.parsers import parse_forti_kv_lines


def _extract_switch_fields(extra: dict[str, str], msg: str) -> None:
    """Extract switch-specific fields into extra dict."""
    msg_lower = msg.lower()

    # port name
    port = (
        extra.get("port")
        or extra.get("interface")
        or extra.get("portname")
    )
    if not port:
        m = re.search(r"(?:port|interface)\s+([\w/.-]+)", msg)
        if m:
            port = m.group(1)
    extra["PortName"] = port or ""

    # port status
    status = extra.get("portstatus") or extra.get("linkstatus")
    if not status:
        m = re.search(r"(?:port|link)\s+(?:is\s+)?(up|down)", msg_lower)
        if m:
            status = m.group(1)
    extra["PortStatus"] = status or ""

    # MAC address
    mac = extra.get("mac") or extra.get("srcmac") or extra.get("macaddr")
    if not mac:
        m = re.search(r"([0-9a-fA-F]{2}(?:[:-][0-9a-fA-F]{2}){5})", msg)
        if m:
            mac = m.group(1)
    extra["MacAddress"] = mac or ""

    # auth result
    auth = extra.get("authresult") or extra.get("authstatus")
    if not auth:
        m = re.search(
            r"802\.1x\s+auth(?:entication)?\s+(success|fail\w*|reject\w*|timeout)",
            msg_lower,
        )
        if m:
            auth = m.group(1)
    extra["AuthResult"] = auth or ""

    # STP state
    stp = extra.get("stpstate")
    if not stp:
        m = re.search(r"stp\s+(?:state\s+)?(\w+)", msg_lower)
        if m:
            stp = m.group(1)
    extra["StpState"] = stp or ""

    # VLAN ID
    vlan = extra.get("vlan") or extra.get("vlanid")
    if not vlan:
        m = re.search(r"(?:vlan|VLAN)\s*(\d+)", msg)
        if m:
            vlan = m.group(1)
    extra["VlanId"] = vlan or ""


def _build_message_inner(extra: dict[str, str], msg_field: str, kv_line: str) -> str:
    """Build display message from switch-specific fields."""
    msg_lower = msg_field.lower()
    port = extra.get("PortName", "")
    mac = extra.get("MacAddress", "")
    auth = extra.get("AuthResult", "")
    stp = extra.get("StpState", "")
    vlan = extra.get("VlanId", "")
    status = extra.get("PortStatus", "")

    if "802.1x" in msg_lower or "dot1x" in msg_lower or auth:
        result = auth or "event"
        parts = [f"802.1X auth {result}"]
        if mac:
            parts.append(f"for {mac}")
        if port:
            parts.append(f"on {port}")
        return " ".join(parts)

    if "stp" in msg_lower or "spanning" in msg_lower:
        parts = ["STP topology change"]
        if port:
            parts.append(f"on {port}")
        if stp:
            parts.append(f"state={stp}")
        return " ".join(parts)

    if re.search(r"mac\s+(learn|age|move|flush)", msg_lower) or mac:
        m = re.search(r"(?i)mac\s+(learn\w*|age\w*|move\w*|flush\w*)", msg_field)
        action = m.group(1).lower() if m else "event"
        parts = [f"MAC {mac}" if mac else "MAC", action]
        if port:
            parts.append(f"on {port}")
        if vlan:
            parts.append(f"VLAN {vlan}")
        return " ".join(parts)

    if port and (status or "port" in msg_lower or "link" in msg_lower or "interface" in msg_lower):
        s = status or "event"
        result = f"Port {port} {s}"
        if extra.get("speed"):
            result += f" speed={extra['speed']}"
        if extra.get("duplex"):
            result += f" duplex={extra['duplex']}"
        return result

    if msg_field:
        return msg_field
    if extra.get("action"):
        return extra["action"]
    return kv_line[:200]


def _enrich(extra: dict[str, str], raw_line: str) -> None:
    msg_field = extra.get("msg", "")
    _extract_switch_fields(extra, msg_field)


def _build_message(extra: dict[str, str], kv_line: str) -> str:
    msg_field = extra.get("msg", "")
    return _build_message_inner(extra, msg_field, kv_line)


def _severity(extra: dict[str, str], raw_line: str) -> str:
    fg_level = extra.get("level", "").lower()
    if fg_level:
        return severity_from_forti_level(
            level=fg_level, action="", type_="", raw=raw_line
        )
    msg_field = extra.get("msg", "")
    if re.search(r"(?i)fail|reject|denied", extra.get("AuthResult", "")):
        return "High"
    if extra.get("PortStatus") == "down" or re.search(r"port\s+down|link\s+down", msg_field.lower()):
        return "Medium"
    if re.search(r"stp\s+(?:topology\s+change|tcn)", msg_field.lower()):
        return "Medium"
    if extra.get("PortStatus") == "up":
        return "Low"
    return severity_from_text(raw_line)


def parse_fortiswitch(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a FortiSwitch event log file."""
    return parse_forti_kv_lines(
        path,
        source_file,
        source_format="fortiswitch",
        enrich_fn=_enrich,
        build_msg_fn=_build_message,
        severity_fn=_severity,
    )
