#!/usr/bin/env python3
"""Parser registry, format auto-detection, and dispatch."""

from __future__ import annotations

import logging
import re
from datetime import datetime
from pathlib import Path

from logparse.models import LogEvent

log = logging.getLogger(__name__)

# Shared compiled regex for FortiGate/FortiSwitch key=value extraction
KV_REGEX = re.compile(r'(\w+)=("(?:[^"\\]|\\.)*"|[^\s]+)')

# Syslog priority header pattern
SYSLOG_PRI_RE = re.compile(r"^\s*<\d+>\S*\s+\S+\s+\S+\s+\S+\s+\S+\s+")
SYSLOG_PRI_SHORT_RE = re.compile(r"^\s*<\d+>")


def strip_syslog_header(line: str) -> str:
    """Strip optional syslog priority/header prefix from a log line.

    Tries the short ``<pri>`` strip first when the content immediately
    after the priority looks like KV data (``word=``), to avoid the
    greedy BSD pattern consuming actual log fields.
    """
    m = SYSLOG_PRI_SHORT_RE.match(line)
    if m:
        after = line[m.end():]
        # If KV data follows immediately, only strip the priority tag
        if re.match(r"\w+=", after):
            return after
    stripped = SYSLOG_PRI_RE.sub("", line, count=1)
    if stripped == line:
        stripped = SYSLOG_PRI_SHORT_RE.sub("", line, count=1)
    return stripped


def parse_forti_kv_lines(
    path: Path,
    source_file: str,
    *,
    source_format: str,
    enrich_fn: object | None = None,
    build_msg_fn: object,
    severity_fn: object,
) -> list[LogEvent]:
    """Shared loop for FortiGate-family key=value parsers.

    Parameters
    ----------
    enrich_fn : (extra, raw_line) -> None
        Parser-specific field enrichment (e.g. device type, switch fields).
    build_msg_fn : (extra, kv_line) -> str
        Parser-specific display message builder.
    severity_fn : (extra, raw_line) -> str
        Parser-specific severity derivation.
    """
    import sys

    from logparse.enrichment import FORTI_SUBTYPE

    events: list[LogEvent] = []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line_num, raw_line in enumerate(f, 1):
            raw_line = raw_line.rstrip("\n\r")
            if not raw_line.strip():
                continue

            kv_line = strip_syslog_header(raw_line)

            extra: dict[str, str] = {}
            for key, val in KV_REGEX.findall(kv_line):
                extra[sys.intern(key)] = val.strip('"')

            # timestamp
            ts: datetime | None = None
            if extra.get("date") and extra.get("time"):
                try:
                    ts = datetime.strptime(
                        f"{extra['date']} {extra['time']}", "%Y-%m-%d %H:%M:%S"
                    )
                except ValueError:
                    pass
            # Fallback: use eventtime epoch if date/time fields are absent
            if ts is None and extra.get("eventtime"):
                try:
                    epoch = int(extra["eventtime"])
                    ts = datetime.fromtimestamp(epoch)
                except (ValueError, OSError, OverflowError):
                    pass

            # subtype description enrichment
            if extra.get("type") and extra.get("subtype"):
                skey = f"{extra['type']}/{extra['subtype']}"
                if desc := FORTI_SUBTYPE.get(skey):
                    extra["SubtypeDescription"] = desc

            # parser-specific enrichment
            if enrich_fn is not None:
                enrich_fn(extra, raw_line)

            severity = severity_fn(extra, raw_line)
            msg = build_msg_fn(extra, kv_line)

            # prepend subtype description
            if desc := extra.get("SubtypeDescription"):
                if msg:
                    msg = f"[{desc}] {msg}"

            events.append(
                LogEvent(
                    timestamp=ts,
                    severity=severity,
                    source=extra.get("devname") or extra.get("srcip") or "",
                    message=msg,
                    extra=extra,
                    raw=raw_line,
                    source_file=source_file,
                    source_format=source_format,
                    line_number=line_num,
                )
            )
    return events


def detect_format(path: Path) -> str:
    """Auto-detect log format from file extension and content.

    Returns a format name string.  Falls through to ``"raw_text"`` so
    nothing is silently dropped.
    """
    ext = path.suffix.lower()
    if ext == ".evtx":
        return "evtx"
    if ext == ".conf":
        return "fortigate_conf"

    try:
        with open(path, encoding="utf-8", errors="replace") as f:
            first_lines = [f.readline() for _ in range(20)]
    except OSError:
        return "raw_text"

    first_lines = [line for line in first_lines if line]
    if not first_lines:
        return "raw_text"

    # reject binary files
    for line in first_lines:
        if re.search(r"[\x00-\x08\x0e-\x1f]", line):
            return "raw_text"

    # FortiGate config
    for line in first_lines:
        if re.match(r"^#config-version=FG", line):
            return "fortigate_conf"
        if re.match(r"^\s*config system global\s*$", line):
            return "fortigate_conf"

    # FortiSwitch (check before generic KV)
    fsw_match = 0
    for line in first_lines:
        if re.search(r"(\w+)=", line) and (
            re.search(r'devid="?FS\w', line)
            or re.search(r'devid="?S\d', line)
            or re.search(r'devid="?FSW', line)
            or re.search(r'devtype="FortiSwitch"', line)
        ):
            fsw_match += 1
    if fsw_match >= 2:
        return "fortiswitch"

    # JSON Lines / NDJSON (check before FortiGate KV to avoid misdetecting
    # JSONL files that happen to contain logid=/type=/devname= as keys)
    if ext in (".jsonl", ".ndjson"):
        return "jsonl"
    import json as _json
    for line in first_lines:
        stripped = line.strip()
        if stripped.startswith("{"):
            try:
                _json.loads(stripped)
                return "jsonl"
            except _json.JSONDecodeError:
                break

    # FortiGate KV
    for line in first_lines:
        if (
            "logid=" in line
            and "type=" in line
            and ("devname=" in line or "devid=" in line)
        ):
            return "fortigate_kv"

    # FortiClient local
    fc_match = sum(
        1
        for line in first_lines
        if re.match(r"^\[\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", line)
    )
    if fc_match >= 2:
        return "forticlient"

    # Windows Event XML export
    for line in first_lines:
        if re.search(r"<Events[\s>]", line) or re.search(
            r"<Event\s+xmlns=", line
        ):
            return "windows_xml"

    return "raw_text"


# -- parser registry ---------------------------------------------------------

_PARSERS: dict[str, object] = {}  # lazy-populated on first call


def _get_parsers() -> dict:
    if not _PARSERS:
        from logparse.parsers.evtx import parse_evtx
        from logparse.parsers.forticlient import parse_forticlient
        from logparse.parsers.fortigate_conf import parse_fortigate_conf
        from logparse.parsers.fortigate_kv import parse_fortigate_kv
        from logparse.parsers.fortiswitch import parse_fortiswitch
        from logparse.parsers.jsonl import parse_jsonl
        from logparse.parsers.raw_text import parse_raw_text
        from logparse.parsers.windows_xml import parse_windows_xml

        _PARSERS.update(
            {
                "fortigate_conf": parse_fortigate_conf,
                "fortigate_kv": parse_fortigate_kv,
                "forticlient": parse_forticlient,
                "fortiswitch": parse_fortiswitch,
                "evtx": parse_evtx,
                "windows_xml": parse_windows_xml,
                "jsonl": parse_jsonl,
                "raw_text": parse_raw_text,
            }
        )
    return _PARSERS


PARSER_DESCRIPTIONS: dict[str, str] = {
    "fortigate_conf": "FortiGate configuration file (.conf)",
    "fortigate_kv": "FortiGate/Fortinet key=value syslog (.log)",
    "forticlient": "FortiClient EMS local log (.log, .txt)",
    "fortiswitch": "FortiSwitch event log (.log)",
    "evtx": "Windows Event Log binary (.evtx)",
    "windows_xml": "Windows Event Log XML export (.xml)",
    "jsonl": "JSON Lines / NDJSON (.jsonl, .ndjson)",
    "raw_text": "Plain text fallback (line per event)",
}


def parse_file(
    path: Path,
    format_name: str | None = None,
    source_file: str = "",
) -> list[LogEvent]:
    """Parse a file using the named parser (auto-detected if *None*)."""
    if not source_file:
        source_file = path.name

    if format_name is None:
        format_name = detect_format(path)

    parsers = _get_parsers()
    parser_fn = parsers.get(format_name)
    if parser_fn is None:
        log.warning("Unknown format %r for %s", format_name, source_file)
        parser_fn = parsers["raw_text"]

    return parser_fn(path, source_file)
