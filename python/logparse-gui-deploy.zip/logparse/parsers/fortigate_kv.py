#!/usr/bin/env python3
"""FortiGate key=value syslog parser."""

from __future__ import annotations

from pathlib import Path

from logparse.models import LogEvent, severity_from_forti_level
from logparse.parsers import parse_forti_kv_lines

_DEVICE_PREFIX: dict[str, str] = {
    "FG": "FortiGate",
    "FTC": "FortiClient",
    "FAZ": "FortiAnalyzer",
    "FSW": "FortiSwitch",
    "FAP": "FortiAP",
}


def _device_type(devid: str) -> str:
    for prefix, name in _DEVICE_PREFIX.items():
        if devid.startswith(prefix):
            return name
    return "Fortinet"


def _build_message(extra: dict[str, str], kv_line: str) -> str:
    type_ = extra.get("type", "")
    subtype = extra.get("subtype", "")

    if type_ == "traffic":
        parts: list[str] = []
        if extra.get("action"):
            parts.append(extra["action"])
        for field in ("srcip", "dstip", "srcport", "dstport"):
            if extra.get(field):
                parts.append(f"{field}={extra[field]}")
        if extra.get("policyid"):
            parts.append(f"policy={extra['policyid']}")
        return " ".join(parts)

    if type_ == "utm" and subtype == "webfilter":
        parts = []
        if extra.get("action"):
            parts.append(extra["action"])
        if extra.get("url"):
            parts.append(f"url={extra['url']}")
        if extra.get("hostname"):
            parts.append(f"host={extra['hostname']}")
        if extra.get("catdesc"):
            parts.append(f"cat={extra['catdesc']}")
        return " ".join(parts)

    if type_ == "event" and subtype == "vpn":
        parts = []
        if extra.get("action"):
            parts.append(extra["action"])
        if extra.get("tunnelip"):
            parts.append(f"tunnel={extra['tunnelip']}")
        if extra.get("tunneltype"):
            parts.append(f"type={extra['tunneltype']}")
        if extra.get("remip"):
            parts.append(f"remote={extra['remip']}")
        return " ".join(parts)

    if extra.get("msg"):
        return extra["msg"]
    if extra.get("action"):
        return extra["action"]
    return kv_line[:200]


def _enrich(extra: dict[str, str], raw_line: str) -> None:
    if devid := extra.get("devid"):
        extra["DeviceType"] = _device_type(devid)


def _severity(extra: dict[str, str], raw_line: str) -> str:
    return severity_from_forti_level(
        level=extra.get("level", ""),
        action=extra.get("action", ""),
        type_=extra.get("type", ""),
        raw=raw_line,
    )


def parse_fortigate_kv(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a FortiGate key=value log file."""
    return parse_forti_kv_lines(
        path,
        source_file,
        source_format="fortigate_kv",
        enrich_fn=_enrich,
        build_msg_fn=_build_message,
        severity_fn=_severity,
    )
