#!/usr/bin/env python3
"""FortiClient EMS local log parser."""

from __future__ import annotations

import re
from datetime import datetime
from pathlib import Path

from logparse.enrichment import FORTICLIENT_MODULE
from logparse.models import LogEvent, severity_from_text

_PATTERN = re.compile(
    r"^\[(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)\]"
    r"\s+\[(\w+)\]\s+\[([\w.-]+)\]\s+(.*)"
)

_LEVEL_MAP: dict[str, str] = {
    "CRITICAL": "Critical",
    "ERROR": "High",
    "WARNING": "Medium",
    "INFO": "Low",
    "DEBUG": "Info",
}


def parse_forticlient(path: Path, source_file: str = "") -> list[LogEvent]:
    """Parse a FortiClient local diagnostic log."""
    events: list[LogEvent] = []
    prev: LogEvent | None = None

    with open(path, encoding="utf-8", errors="replace") as f:
        for line_num, raw_line in enumerate(f, 1):
            raw_line = raw_line.rstrip("\n\r")
            if not raw_line.strip():
                continue

            m = _PATTERN.match(raw_line)
            if m:
                ts: datetime | None = None
                try:
                    ts_str = m.group(1)
                    # truncate sub-second precision beyond 6 digits
                    if "." in ts_str:
                        base, frac = ts_str.split(".", 1)
                        ts_str = f"{base}.{frac[:6].ljust(6, '0')}"
                    ts = datetime.strptime(ts_str, "%Y-%m-%d %H:%M:%S.%f")
                except ValueError:
                    try:
                        ts = datetime.strptime(m.group(1)[:19], "%Y-%m-%d %H:%M:%S")
                    except ValueError:
                        pass

                raw_level = m.group(2).upper()
                severity = _LEVEL_MAP.get(raw_level) or severity_from_text(raw_level)
                module = m.group(3)
                module_name = FORTICLIENT_MODULE.get(module.lower(), module)

                prev = LogEvent(
                    timestamp=ts,
                    severity=severity,
                    source=module_name,
                    message=m.group(4),
                    extra={"Module": module, "ModuleName": module_name},
                    raw=raw_line,
                    source_file=source_file,
                    source_format="forticlient",
                    line_number=line_num,
                )
                events.append(prev)
            elif prev is not None:
                # continuation line
                prev.raw += f"\n{raw_line}"
                prev.message += f"\n{raw_line}"

    return events
