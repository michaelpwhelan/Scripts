#!/usr/bin/env python3
"""Visualization system — ChartData model and render dispatch."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable


@dataclass
class ChartData:
    """Universal chart data container."""

    chart_type: str
    title: str
    labels: list[str]
    values: list[float]
    series: dict[str, list] = field(default_factory=dict)
    metadata: dict = field(default_factory=dict)
    source_command: str = ""
    timestamp: datetime = field(default_factory=datetime.now)


# Actual chart rendering types (not command aliases)
CHART_TYPES: set[str] = {
    "bar", "heatmap", "line", "scatter", "flow", "stacked", "dist",
    "pie", "geomap",
}

# ---------------------------------------------------------------------------
# Renderer registry
# ---------------------------------------------------------------------------

_RENDERER_REGISTRY: dict[str, Callable[[ChartData, object], None]] = {}


def register_renderer(chart_type: str) -> Callable:
    """Decorator to register a terminal chart renderer."""
    def decorator(fn: Callable[[ChartData, object], None]) -> Callable:
        """Register fn as the renderer for this chart type."""
        _RENDERER_REGISTRY[chart_type] = fn
        CHART_TYPES.add(chart_type)
        return fn
    return decorator


def get_renderer(chart_type: str) -> Callable[[ChartData, object], None] | None:
    """Look up renderer for a chart type."""
    return _RENDERER_REGISTRY.get(chart_type)


def render_agg_visual(agg_data: list, visual_type: str, console) -> None:
    """Render aggregation results as a visual chart.

    Converts AggResult list to ChartData and dispatches to the
    appropriate terminal renderer. Used by pipe-visual callers
    (display, show, where, geo commands).
    """
    chart = ChartData(
        chart_type=visual_type,
        title=visual_type.title(),
        labels=[r.key for r in agg_data],
        values=[float(r.count) for r in agg_data],
    )
    renderer = get_renderer(visual_type) or get_renderer("bar")
    if renderer:
        renderer(chart, console)
