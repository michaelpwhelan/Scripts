#!/usr/bin/env python3
"""Terminal pie chart renderer with proportional donut display."""

from __future__ import annotations

import math

from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    SERIES_COLORS, chart_title, severity_color, terminal_width,
)

_SYMBOLS = ["\u2588", "\u2593", "\u2592", "\u2591", "\u00b7"]

_RADIUS = 7
_INNER_R = 3


@register_renderer("pie")
def render_pie(data: ChartData, console) -> None:
    """Render pie chart — donut on wide terminals, bars on narrow."""
    if not data.labels:
        console.print("[dim]No data to chart.[/dim]")
        return
    if data.title:
        console.print(chart_title(data.title))
    if terminal_width() >= 55 and len(data.labels) >= 2:
        _render_donut(data, console)
    else:
        _render_bars(data, console)


def _render_donut(data: ChartData, console) -> None:
    """Render a proportional donut using Unicode block characters."""
    labels = data.labels
    values = [int(v) for v in data.values]
    total = sum(values)
    if total == 0:
        console.print("[dim]No data to chart.[/dim]")
        return

    rows = _RADIUS * 2 + 1
    # 2x horizontal stretch to compensate for tall terminal chars
    cols = _RADIUS * 4 + 2
    cx, cy = cols // 2, rows // 2

    # Build angle segments
    segments = []
    cumulative = 0.0
    for i, (label, count) in enumerate(zip(labels, values)):
        start = cumulative / total * 2 * math.pi
        cumulative += count
        end = cumulative / total * 2 * math.pi
        color = severity_color(label) or SERIES_COLORS[i % len(SERIES_COLORS)]
        segments.append((start, end, color))

    # Fill grid
    grid = [[" "] * cols for _ in range(rows)]
    color_grid = [[None] * cols for _ in range(rows)]

    for row in range(rows):
        for col in range(cols):
            dx = (col - cx) / 2.0  # aspect ratio compensation
            dy = cy - row
            dist = math.sqrt(dx * dx + dy * dy)
            if _INNER_R <= dist <= _RADIUS:
                angle = math.atan2(dx, dy) % (2 * math.pi)
                for seg_idx, (start, end, color) in enumerate(segments):
                    if start <= angle < end or (seg_idx == len(segments) - 1 and angle >= start):
                        grid[row][col] = "\u2588"
                        color_grid[row][col] = color
                        break

    # Render donut + legend side by side
    max_key_len = max(len(k) for k in labels)
    console.print()

    for row in range(rows):
        # Build donut row
        parts = []
        for col in range(cols):
            ch = grid[row][col]
            c = color_grid[row][col]
            if c:
                parts.append(f"[{c}]{ch}[/{c}]")
            else:
                parts.append(ch)
        donut_line = "".join(parts)

        # Legend entry (one per row, right of donut)
        legend_idx = row - (rows // 2 - len(labels) // 2)
        if 0 <= legend_idx < len(labels):
            label = labels[legend_idx]
            count = values[legend_idx]
            pct = count / total * 100
            color = severity_color(label) or SERIES_COLORS[legend_idx % len(SERIES_COLORS)]
            legend = (f"  [{color}]\u2588\u2588[/{color}] "
                      f"{label.ljust(max_key_len)}  {pct:5.1f}%  "
                      f"({format_number(count)})")
        else:
            legend = ""

        console.print(f"  {donut_line}{legend}")

    console.print(f"  {'':>{cols}}  [dim]Total: {format_number(total)}[/dim]")
    console.print()


def _render_bars(data: ChartData, console) -> None:
    """Fallback: horizontal bars for narrow terminals."""
    labels = data.labels
    values = [int(v) for v in data.values]
    total = sum(values)
    if total == 0:
        console.print("[dim]No data to chart.[/dim]")
        return

    max_key_len = max(len(k) for k in labels)

    console.print()
    for i, (label, count) in enumerate(zip(labels, values)):
        pct = count / total * 100
        sym = _SYMBOLS[i % len(_SYMBOLS)]
        color = severity_color(label) or SERIES_COLORS[i % len(SERIES_COLORS)]
        bar = sym * int(pct / 2)
        key_padded = label.ljust(max_key_len)
        console.print(
            f"  {key_padded}  [{color}]{bar}[/{color}]  {pct:.1f}% ({format_number(count)})"
        )
    console.print(f"  {'Total'.ljust(max_key_len)}  {format_number(total)}")
    console.print()
