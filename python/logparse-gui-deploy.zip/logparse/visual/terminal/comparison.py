#!/usr/bin/env python3
"""Comparison chart — side-by-side comparison of two time periods or filter groups."""

from __future__ import annotations

from collections import Counter
from datetime import datetime

from logparse.models import LogEvent, get_field
from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    SERIES_COLORS, bar_width, chart_title,
)


def build_time_comparison(
    events: list[LogEvent], split_point: datetime, bucket: str = "hour",
) -> ChartData:
    """Split events at a timestamp and compare the two halves by hour-of-day."""
    before = [e for e in events if e.timestamp and e.timestamp < split_point]
    after = [e for e in events if e.timestamp and e.timestamp >= split_point]

    label_a = f"Before {split_point:%Y-%m-%d %H:%M}"
    label_b = f"After {split_point:%Y-%m-%d %H:%M}"

    # Compare by hour-of-day distribution
    hours_a = [0] * 24
    hours_b = [0] * 24
    for e in before:
        hours_a[e.timestamp.hour] += 1
    for e in after:
        hours_b[e.timestamp.hour] += 1

    labels = [f"{h:02d}:00" for h in range(24)]

    return ChartData(
        chart_type="comparison",
        title=f"Comparison: {label_a} vs {label_b}",
        labels=labels,
        values=[],
        series={label_a: hours_a, label_b: hours_b},
        metadata={
            "period_a_label": label_a,
            "period_b_label": label_b,
            "total_a": len(before),
            "total_b": len(after),
        },
    )


def build_filter_comparison(
    events: list[LogEvent], field: str, value_a: str, value_b: str,
) -> ChartData:
    """Compare two groups of events filtered by a field value.

    Compares the top fields (by count) between the two groups.
    """
    group_a = [e for e in events if (get_field(e, field) or "").lower() == value_a.lower()]
    group_b = [e for e in events if (get_field(e, field) or "").lower() == value_b.lower()]

    # Compare by hour-of-day if timestamps exist
    ts_a = [e for e in group_a if e.timestamp]
    ts_b = [e for e in group_b if e.timestamp]

    if ts_a and ts_b:
        hours_a = [0] * 24
        hours_b = [0] * 24
        for e in ts_a:
            hours_a[e.timestamp.hour] += 1
        for e in ts_b:
            hours_b[e.timestamp.hour] += 1
        labels = [f"{h:02d}:00" for h in range(24)]
    else:
        # Fall back to severity distribution
        sev_a: Counter[str] = Counter(e.severity for e in group_a)
        sev_b: Counter[str] = Counter(e.severity for e in group_b)
        all_sevs = sorted(set(sev_a) | set(sev_b))
        labels = all_sevs
        hours_a = [sev_a.get(s, 0) for s in all_sevs]
        hours_b = [sev_b.get(s, 0) for s in all_sevs]

    label_a = f"{field}={value_a}"
    label_b = f"{field}={value_b}"

    return ChartData(
        chart_type="comparison",
        title=f"Comparison: {label_a} vs {label_b}",
        labels=labels,
        values=[],
        series={label_a: hours_a, label_b: hours_b},
        metadata={
            "period_a_label": label_a,
            "period_b_label": label_b,
            "total_a": len(group_a),
            "total_b": len(group_b),
        },
    )


@register_renderer("comparison")
def render_comparison(data: ChartData, console) -> None:
    """Render side-by-side comparison with grouped bars and delta percentages."""
    series_items = [(k, v) for k, v in data.series.items() if isinstance(v, list)]
    if len(series_items) < 2:
        console.print("[dim]Not enough data for comparison.[/dim]")
        return

    if data.title:
        console.print(chart_title(data.title))

    (name_a, vals_a), (name_b, vals_b) = series_items[0], series_items[1]
    total_a = data.metadata.get("total_a", sum(vals_a))
    total_b = data.metadata.get("total_b", sum(vals_b))
    color_a = SERIES_COLORS[0]
    color_b = SERIES_COLORS[1]

    # Summary line
    console.print()
    if total_a > 0:
        delta_pct = (total_b - total_a) / total_a * 100
        delta_str = f"+{delta_pct:.1f}%" if delta_pct >= 0 else f"{delta_pct:.1f}%"
    else:
        delta_str = "n/a"
    console.print(
        f"  [{color_a}]■[/{color_a}] {name_a}: {format_number(total_a)}    "
        f"[{color_b}]■[/{color_b}] {name_b}: {format_number(total_b)}    "
        f"[dim]Δ {delta_str}[/dim]"
    )
    console.print()

    # Grouped bars per label
    max_val = max(max(vals_a, default=0), max(vals_b, default=0)) or 1
    bw = bar_width(label_reserve=35)
    max_label_len = max((len(label) for label in data.labels), default=6)

    for i, label in enumerate(data.labels):
        va = vals_a[i] if i < len(vals_a) else 0
        vb = vals_b[i] if i < len(vals_b) else 0

        wa = int(va / max_val * bw)
        wb = int(vb / max_val * bw)
        bar_a = "█" * wa
        bar_b = "█" * wb

        # Delta
        if va > 0:
            d = (vb - va) / va * 100
            delta = f"+{d:.0f}%" if d >= 0 else f"{d:.0f}%"
        elif vb > 0:
            delta = "+new"
        else:
            delta = ""

        label_pad = label.ljust(max_label_len)
        console.print(
            f"  {label_pad}  [{color_a}]{bar_a}[/{color_a}] {va}"
        )
        console.print(
            f"  {' ' * max_label_len}  [{color_b}]{bar_b}[/{color_b}] {vb}"
            f"  [dim]{delta}[/dim]"
        )

    console.print()
