#!/usr/bin/env python3
"""Hour-of-day x day-of-week heatmap with adaptive density thresholds."""

from __future__ import annotations

import statistics
from collections import defaultdict

from logparse.models import LogEvent
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import DENSITY_CHARS, gradient_color


_DAY_NAMES = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
_DENSITY_COLORS = ["dim", "cyan", "yellow", "bright_yellow", "red"]
_FALLBACK_THRESHOLDS = [0, 5, 20, 50, 100]


def build_heatmap_data(events: list[LogEvent]) -> ChartData:
    """Build a 7x24 heatmap grid from events."""
    grid: dict[int, dict[int, int]] = defaultdict(lambda: defaultdict(int))
    for e in events:
        if e.timestamp:
            grid[e.timestamp.weekday()][e.timestamp.hour] += 1

    labels = []
    values = []
    series: dict[str, list] = {"grid": [], "anomalies": []}

    for day in range(7):
        row = [grid[day][h] for h in range(24)]
        series["grid"].append(row)
        for h in range(24):
            labels.append(f"{_DAY_NAMES[day]} {h:02d}")
            values.append(float(grid[day][h]))

    # Detect anomalies: per-row z-score > 2.5
    anomalies = []
    for day in range(7):
        row = series["grid"][day]
        if len(set(row)) <= 1:
            continue
        try:
            mu = statistics.mean(row)
            sd = statistics.stdev(row)
            if sd == 0:
                continue
            for h, val in enumerate(row):
                if (val - mu) / sd > 2.5:
                    anomalies.append((day, h, val, mu))
        except statistics.StatisticsError:
            continue
    series["anomalies"] = anomalies

    return ChartData(
        chart_type="heatmap",
        title="Activity Heatmap (Day x Hour)",
        labels=labels,
        values=values,
        series=series,
    )


def _compute_thresholds(grid: list[list[int]]) -> list[int]:
    """Compute data-adaptive density thresholds from percentiles."""
    all_vals = sorted(v for row in grid for v in row if v > 0)
    if not all_vals or len(all_vals) < 5:
        return list(_FALLBACK_THRESHOLDS)
    n = len(all_vals)
    return [
        0,
        all_vals[min(n // 5, n - 1)],
        all_vals[min(2 * n // 5, n - 1)],
        all_vals[min(3 * n // 5, n - 1)],
        all_vals[min(4 * n // 5, n - 1)],
    ]


@register_renderer("heatmap")
def render_heatmap(data: ChartData, console) -> None:
    """Render 7x24 hour-of-day x day-of-week grid with adaptive thresholds."""
    from rich.table import Table

    grid = data.series.get("grid", [])
    if not grid:
        console.print("[dim]No timestamp data for heatmap.[/dim]")
        return

    anomalies = data.series.get("anomalies", [])
    anomaly_set = {(a[0], a[1]) for a in anomalies}
    thresholds = _compute_thresholds(grid)

    # Find global max for gradient coloring
    global_max = max(v for row in grid for v in row) or 1

    table = Table(
        title=data.title or "Activity Heatmap",
        show_header=True,
        show_lines=False,
        padding=(0, 0),
    )
    table.add_column("", style="bold", width=4)
    for h in range(24):
        table.add_column(f"{h:02d}", width=2, justify="center")

    for day in range(7):
        row = grid[day]
        cells = [_DAY_NAMES[day]]
        for h, val in enumerate(row):
            char = _density_char(val, thresholds)
            if (day, h) in anomaly_set:
                cells.append(f"[bold red]{char}[/bold red]")
            else:
                # Use gradient color for continuous shading
                ratio = val / global_max if global_max > 0 else 0
                color = gradient_color(ratio) if val > 0 else "dim"
                cells.append(f"[{color}]{char}[/{color}]")
        table.add_row(*cells)

    console.print()
    console.print(table)

    # Dynamic legend showing actual threshold values
    legend_parts = []
    chars = DENSITY_CHARS
    for i, t in enumerate(thresholds):
        if i < len(thresholds) - 1:
            legend_parts.append(f"{chars[i]} <{thresholds[i+1]}")
        else:
            legend_parts.append(f"{chars[min(i, len(chars)-1)]} {t}+")
    console.print(f"  [dim]Legend: {'  '.join(legend_parts)}[/dim]")

    if anomalies:
        console.print()
        for day, h, val, mu in anomalies[:5]:
            console.print(
                f"  [bold yellow][!] Anomaly: {_DAY_NAMES[day]} "
                f"{h:02d}:00 spike ({int(val)} events, "
                f"normally ~{mu:.0f})[/bold yellow]"
            )
    console.print()


def _density_char(count: int, thresholds: list[int]) -> str:
    """Return density character for a count value based on thresholds."""
    for i in range(len(thresholds) - 1, -1, -1):
        if count >= thresholds[i]:
            return DENSITY_CHARS[min(i, len(DENSITY_CHARS) - 1)]
    return DENSITY_CHARS[0]
