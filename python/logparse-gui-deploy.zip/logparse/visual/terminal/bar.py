#!/usr/bin/env python3
"""Enhanced horizontal bar chart renderer with gradient coloring."""

from __future__ import annotations

import statistics

from logparse.network import is_external
from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    HALF_BLOCK, bar_width, chart_title, gradient_color, severity_color,
)


@register_renderer("bar")
def render_bar(data: ChartData, console) -> None:
    """Render horizontal bar chart with gradient colors, half-block precision,
    and mean reference marker."""
    if not data.labels:
        return

    if data.title:
        console.print(chart_title(data.title))

    max_val = max(data.values) if data.values else 1
    total = sum(data.values)
    max_key_len = max(len(k) for k in data.labels)
    bw = bar_width(label_reserve=max_key_len + 25)

    console.print()
    for label, value in zip(data.labels, data.values):
        ratio = value / max(max_val, 1)
        raw_width = ratio * bw
        full_blocks = int(raw_width)
        has_half = (raw_width - full_blocks) >= 0.5
        bar = "\u2588" * full_blocks + (HALF_BLOCK if has_half else "")
        pct = value / max(total, 1) * 100
        key_padded = label.ljust(max_key_len)

        # Severity-aware color, fall back to value gradient
        color = severity_color(label) or gradient_color(ratio)

        # Flag external IPs
        flag = ""
        if _looks_like_ip(label) and is_external(label):
            flag = " [bright_red][!][/bright_red]"

        console.print(
            f"  {key_padded}  [{color}]{bar}[/{color}]  "
            f"{format_number(int(value))} ({pct:.1f}%){flag}"
        )

    # Mean reference marker
    if len(data.values) >= 2:
        try:
            mean_val = statistics.mean(data.values)
            mean_pos = int(mean_val / max(max_val, 1) * bw)
            marker = " " * mean_pos + "▼"
            console.print(
                f"  {' ' * max_key_len}  [dim]{marker} avg ({format_number(int(mean_val))})[/dim]"
            )
        except statistics.StatisticsError:
            pass

    console.print()


def _looks_like_ip(s: str) -> bool:
    """Quick check if string looks like an IP address."""
    parts = s.split(".")
    if len(parts) == 4:
        return all(p.isdigit() for p in parts)
    # IPv6: require at least two colons and hex characters only
    if s.count(":") >= 2:
        return all(c in "0123456789abcdefABCDEF:" for c in s)
    return False
