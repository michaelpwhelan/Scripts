#!/usr/bin/env python3
"""Source-to-destination flow diagram with weighted arrows."""

from __future__ import annotations

from collections import Counter

from logparse.models import LogEvent, get_field
from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import chart_title, gradient_color


def build_flow_data(
    events: list[LogEvent], src_field: str, dst_field: str
) -> ChartData:
    """Count (src, dst) pairs from events."""
    pairs: Counter[tuple[str, str]] = Counter()
    for e in events:
        src = get_field(e, src_field) or ""
        dst = get_field(e, dst_field) or ""
        if src and dst:
            pairs[(src, dst)] += 1

    top = pairs.most_common(15)
    labels = [f"{s} -> {d}" for (s, d), _ in top]
    values = [float(c) for _, c in top]

    return ChartData(
        chart_type="flow",
        title=f"Flow: {src_field} → {dst_field}",
        labels=labels,
        values=values,
        series={"pairs": [(s, d, c) for (s, d), c in top]},
        metadata={"src_field": src_field, "dst_field": dst_field},
    )


_DIRECTIONS = {"internal", "external"}


def build_directional_flow_data(
    events: list[LogEvent], src_dir: str, dst_dir: str,
) -> ChartData:
    """Build flow data filtered by network direction.

    src_dir/dst_dir are 'internal' or 'external'. Scans common IP fields
    (srcip, dstip) and filters pairs by direction classification.

    Examples:
        internal → external  = outbound traffic
        external → internal  = inbound traffic
        internal → internal  = lateral movement
    """
    from logparse.network import is_internal, is_external

    dir_checks = {"internal": is_internal, "external": is_external}
    if src_dir not in _DIRECTIONS or dst_dir not in _DIRECTIONS:
        return ChartData(chart_type="flow", title="Invalid direction", labels=[], values=[])
    src_check = dir_checks[src_dir]
    dst_check = dir_checks[dst_dir]

    pairs: Counter[tuple[str, str]] = Counter()
    for e in events:
        src = get_field(e, "srcip") or ""
        dst = get_field(e, "dstip") or ""
        if src and dst and src_check(src) and dst_check(dst):
            pairs[(src, dst)] += 1

    top = pairs.most_common(15)
    labels = [f"{s} -> {d}" for (s, d), _ in top]
    values = [float(c) for _, c in top]

    title = f"Flow: {src_dir} → {dst_dir}"
    if src_dir == "internal" and dst_dir == "external":
        title = "Outbound Traffic (internal → external)"
    elif src_dir == "external" and dst_dir == "internal":
        title = "Inbound Traffic (external → internal)"
    elif src_dir == "internal" and dst_dir == "internal":
        title = "Lateral Movement (internal → internal)"
    elif src_dir == "external" and dst_dir == "external":
        title = "Transit Traffic (external → external)"

    return ChartData(
        chart_type="flow",
        title=title,
        labels=labels,
        values=values,
        series={"pairs": [(s, d, c) for (s, d), c in top]},
        metadata={"src_dir": src_dir, "dst_dir": dst_dir},
    )


@register_renderer("flow")
def render_flow(data: ChartData, console) -> None:
    """Render top source→destination flows with weighted, colored arrows."""
    pairs = data.series.get("pairs", [])
    if not pairs:
        console.print("[dim]No flow data.[/dim]")
        return

    max_src = max(len(s) for s, _, _ in pairs)
    max_count = max(c for _, _, c in pairs)
    count_width = len(format_number(max_count))

    console.print(chart_title(data.title))
    console.print()
    for src, dst, count in pairs:
        ratio = count / max(max_count, 1)
        color = gradient_color(ratio)
        count_str = format_number(count).rjust(count_width)
        src_pad = src.ljust(max_src)

        # Arrow weight by volume
        if ratio >= 0.6:
            arrow_l, arrow_r = "━━", "━━▶"
        elif ratio >= 0.2:
            arrow_l, arrow_r = "──", "──→"
        else:
            arrow_l, arrow_r = "╌╌", "╌╌→"

        console.print(
            f"  {src_pad}  [{color}]{arrow_l}[{count_str}]{arrow_r}[/{color}]  {dst}"
        )
    console.print()
