#!/usr/bin/env python3
"""Terminal chart renderers — eager imports to populate renderer registry."""

from logparse.visual.terminal import (  # noqa: F401
    bar, pie, heatmap, line, scatter, flow, stacked, dist, treemap,
    sparkline_table, comparison,
)
