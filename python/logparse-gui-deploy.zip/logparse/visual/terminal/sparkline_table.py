#!/usr/bin/env python3
"""Sparkline table — inline sparklines embedded in Rich tables."""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime

from logparse.models import LogEvent, get_field
from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    SERIES_COLORS, chart_title, sparkline,
)


_VALID_BUCKETS = {
    "1m": 60, "5m": 300, "10m": 600, "15m": 900, "30m": 1800,
    "1h": 3600, "hour": 3600, "1d": 86400, "day": 86400,
}


def build_sparkline_table(
    events: list[LogEvent], field: str, bucket: str = "hour",
) -> ChartData:
    """Build sparkline table data — top values with per-bucket time series.

    Groups events by field value, then buckets each group over time.
    """
    bucket_secs = _VALID_BUCKETS.get(bucket, 3600)

    # Count totals and collect timestamps per value
    totals: Counter[str] = Counter()
    ts_by_value: dict[str, list[datetime]] = defaultdict(list)

    for e in events:
        val = get_field(e, field)
        if not val:
            continue
        totals[val] += 1
        if e.timestamp:
            ts_by_value[val].append(e.timestamp)

    if not totals:
        return ChartData(
            chart_type="sparkline_table",
            title=f"Sparkline: {field}",
            labels=[], values=[],
        )

    # Determine time bounds from all events
    all_ts = [e.timestamp for e in events if e.timestamp]
    if not all_ts:
        # No timestamps — return plain totals with no sparklines
        top = totals.most_common(15)
        return ChartData(
            chart_type="sparkline_table",
            title=f"Sparkline: {field}",
            labels=[k for k, _ in top],
            values=[float(c) for _, c in top],
            metadata={"field": field, "bucket": bucket},
        )

    t_min = min(all_ts)
    t_max = max(all_ts)
    total_secs = (t_max - t_min).total_seconds()
    num_buckets = max(1, int(total_secs / bucket_secs) + 1)
    num_buckets = min(num_buckets, 100)  # cap for sanity

    top = totals.most_common(15)
    labels = [k for k, _ in top]
    values = [float(c) for _, c in top]

    series: dict[str, list] = {}
    for label, _ in top:
        bucket_counts = [0] * num_buckets
        for ts in ts_by_value[label]:
            idx = int((ts - t_min).total_seconds() / bucket_secs)
            idx = min(idx, num_buckets - 1)
            bucket_counts[idx] += 1
        series[label] = bucket_counts

    return ChartData(
        chart_type="sparkline_table",
        title=f"Sparkline: {field} ({bucket})",
        labels=labels,
        values=values,
        series=series,
        metadata={"field": field, "bucket": bucket},
    )


@register_renderer("sparkline_table")
def render_sparkline_table(data: ChartData, console) -> None:
    """Render sparkline table with inline sparklines, totals, and trends."""
    from rich.table import Table

    if not data.labels:
        console.print("[dim]No data for sparkline table.[/dim]")
        return

    if data.title:
        console.print(chart_title(data.title))

    console.print()
    table = Table(show_header=True, border_style="dim", padding=(0, 1))
    table.add_column(data.metadata.get("field", "Value"), style="bold")
    table.add_column("Activity", no_wrap=True)
    table.add_column("Total", justify="right", style="cyan")
    table.add_column("Trend", justify="center")

    for i, (label, total) in enumerate(zip(data.labels, data.values)):
        color = SERIES_COLORS[i % len(SERIES_COLORS)]
        series_vals = data.series.get(label, [])

        if series_vals:
            spark = sparkline(series_vals, width=24, color=color)
            # Trend: compare last quarter to first quarter
            n = len(series_vals)
            q = max(1, n // 4)
            first_q = sum(series_vals[:q]) / q if q else 0
            last_q = sum(series_vals[-q:]) / q if q else 0
            if first_q > 0:
                delta_pct = (last_q - first_q) / first_q * 100
                if delta_pct > 10:
                    trend = f"[red]▲ +{delta_pct:.0f}%[/red]"
                elif delta_pct < -10:
                    trend = f"[green]▼ {delta_pct:.0f}%[/green]"
                else:
                    trend = "[dim]─[/dim]"
            else:
                trend = "[dim]─[/dim]" if last_q == 0 else "[red]▲ new[/red]"
        else:
            spark = "[dim]no timestamps[/dim]"
            trend = "[dim]─[/dim]"

        table.add_row(label, spark, format_number(int(total)), trend)

    console.print(table)
    console.print()
