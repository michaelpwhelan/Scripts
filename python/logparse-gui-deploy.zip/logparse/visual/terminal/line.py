#!/usr/bin/env python3
"""Time series sparkline renderer with multi-row display."""

from __future__ import annotations

import statistics

from logparse.pipeline import AggResult
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import BLOCK_CHARS, SERIES_COLORS, chart_title


def build_line_data(agg_data: list[AggResult], title: str = "Timeline") -> ChartData:
    """Build line chart data from aggregation results."""
    return ChartData(
        chart_type="line",
        title=title,
        labels=[r.key for r in agg_data],
        values=[float(r.count) for r in agg_data],
    )


_CHART_HEIGHT = 5


@register_renderer("line")
def render_line(data: ChartData, console) -> None:
    """Render multi-row sparkline with Y-axis labels and mean reference."""
    if data.series and any(isinstance(v, list) for v in data.series.values()):
        _render_multi_series(data, console)
        return

    if not data.values:
        console.print("[dim]No data for sparkline.[/dim]")
        return

    if data.title:
        console.print(chart_title(data.title))

    max_val = max(data.values)
    if max_val == 0:
        console.print("[dim]All values zero.[/dim]")
        return

    height = _CHART_HEIGHT

    # Build multi-row grid
    grid = [[" "] * len(data.values) for _ in range(height)]
    for col, value in enumerate(data.values):
        normalized = value / max_val
        filled_rows = normalized * height
        for row in range(height):
            row_from_bottom = height - 1 - row
            if row_from_bottom < int(filled_rows):
                grid[row][col] = BLOCK_CHARS[7]  # full block
            elif row_from_bottom < filled_rows:
                frac = filled_rows - int(filled_rows)
                level = min(int(frac * 7), 7)
                grid[row][col] = BLOCK_CHARS[level]

    # Mean reference row
    mean_val = statistics.mean(data.values) if len(data.values) >= 2 else 0
    mean_row = height - 1 - int(mean_val / max_val * (height - 1)) if max_val > 0 else height - 1
    mean_row = min(max(mean_row, 0), height - 1)

    # Peak info
    peak_idx = data.values.index(max_val)
    peak_label = data.labels[peak_idx] if peak_idx < len(data.labels) else "?"

    # Time range labels
    first_label = data.labels[0] if data.labels else ""
    last_label = data.labels[-1] if data.labels else ""
    first_short = first_label.split(" ")[-1] if " " in first_label else first_label
    last_short = last_label.split(" ")[-1] if " " in last_label else last_label

    # Y-axis label width
    label_w = 8
    console.print()

    for row in range(height):
        # Y-axis labels at top, middle, bottom
        if row == 0:
            y_label = f"{max_val:.4g}".rjust(label_w)
        elif row == height // 2:
            y_label = f"{max_val / 2:.4g}".rjust(label_w)
        elif row == height - 1:
            y_label = "0".rjust(label_w)
        else:
            y_label = " " * label_w

        row_chars = "".join(grid[row])

        # Insert dim mean reference on the mean row for empty cells
        if row == mean_row:
            parts = []
            for ch in row_chars:
                if ch == " ":
                    parts.append("[dim]╌[/dim]")
                else:
                    parts.append(f"[cyan]{ch}[/cyan]")
            row_str = "".join(parts)
            annotation = f" [dim]avg {mean_val:.0f}[/dim]"
        else:
            row_str = f"[cyan]{row_chars}[/cyan]"
            annotation = ""

        console.print(f"  {y_label} │{row_str}{annotation}")

    # X-axis time range
    sparkline_width = len(data.values)
    pad = max(0, sparkline_width - len(first_short) - len(last_short))
    console.print(f"  {' ' * label_w}  {first_short}{' ' * pad}{last_short}")
    console.print(f"  [dim]Peak: {peak_label} ({int(max_val)})[/dim]")
    console.print()


def _render_multi_series(data: ChartData, console) -> None:
    """Render multiple sparklines stacked vertically, one per series."""
    global_max = 0
    for name, values in data.series.items():
        if isinstance(values, list) and values:
            series_max = max((v for v in values if isinstance(v, (int, float))), default=0)
            global_max = max(global_max, series_max)

    if global_max == 0:
        console.print("[dim]All values zero.[/dim]")
        return

    first_label = data.labels[0] if data.labels else ""
    last_label = data.labels[-1] if data.labels else ""
    first_short = first_label.split(" ")[-1] if " " in first_label else first_label
    last_short = last_label.split(" ")[-1] if " " in last_label else last_label

    console.print()
    max_name_len = max(len(n) for n in data.series) if data.series else 0
    sparkline_width = len(data.labels)

    for i, (name, values) in enumerate(data.series.items()):
        if not isinstance(values, list):
            continue
        color = SERIES_COLORS[i % len(SERIES_COLORS)]

        blocks = []
        peak_val = 0
        for v in values:
            v = v if isinstance(v, (int, float)) else 0
            level = int(v / global_max * 7) if global_max > 0 else 0
            level = min(level, 7)
            blocks.append(BLOCK_CHARS[level])
            peak_val = max(peak_val, v)

        sparkline = "".join(blocks)
        padded_name = name.ljust(max_name_len)
        console.print(
            f"  {padded_name}  [{color}]{sparkline}[/{color}]  peak: {int(peak_val)}"
        )

    # Time range footer — use sparkline_width for consistent alignment
    pad = max(0, sparkline_width - len(first_short) - len(last_short))
    console.print(f"  {' ' * max_name_len}  {first_short}{' ' * pad}{last_short}")
    console.print()
