#!/usr/bin/env python3
"""Hierarchical treemap rendered as an indented tree with proportional bars."""

from __future__ import annotations

from collections import Counter, defaultdict

from logparse.models import LogEvent, get_field
from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    SERIES_COLORS, bar_width, chart_title, terminal_width,
)


def build_treemap_data(events: list[LogEvent], *fields: str) -> ChartData:
    """Build hierarchical treemap data from events grouped by 2-3 fields.

    Produces a flat list with parent references suitable for both
    terminal rendering and Plotly treemap conversion.
    """
    if len(fields) < 2:
        return ChartData(
            chart_type="treemap", title="Treemap", labels=[], values=[],
        )

    # Build nested counts
    tree: dict[str, dict[str, Counter[str]]] = defaultdict(lambda: defaultdict(Counter))
    level1_counts: Counter[str] = Counter()

    for e in events:
        vals = [get_field(e, f) or "(empty)" for f in fields]
        level1_counts[vals[0]] += 1
        if len(fields) == 2:
            tree[vals[0]][""][vals[1]] += 1
        else:
            tree[vals[0]][vals[1]][vals[2]] += 1

    # Flatten into treemap arrays
    root_label = "\x00_root"
    ids = [root_label]
    labels = ["All"]
    parents = [""]
    values = [float(sum(level1_counts.values()))]

    for l1, count1 in level1_counts.most_common():
        l1_id = l1
        ids.append(l1_id)
        labels.append(l1)
        parents.append(root_label)
        values.append(float(count1))

        if len(fields) == 2:
            for l2, count2 in tree[l1][""].most_common():
                l2_id = f"{l1}/{l2}"
                ids.append(l2_id)
                labels.append(l2)
                parents.append(l1_id)
                values.append(float(count2))
        else:
            l2_counts: Counter[str] = Counter()
            for l2 in tree[l1]:
                l2_counts[l2] = sum(tree[l1][l2].values())
            for l2, count2 in l2_counts.most_common():
                l2_id = f"{l1}/{l2}"
                ids.append(l2_id)
                labels.append(l2)
                parents.append(l1_id)
                values.append(float(count2))
                for l3, count3 in tree[l1][l2].most_common():
                    l3_id = f"{l1}/{l2}/{l3}"
                    ids.append(l3_id)
                    labels.append(l3)
                    parents.append(l2_id)
                    values.append(float(count3))

    return ChartData(
        chart_type="treemap",
        title=f"Treemap: {' > '.join(fields)}",
        labels=labels,
        values=values,
        series={"parents": parents, "ids": ids},
        metadata={"fields": list(fields), "root_label": root_label},
    )


@register_renderer("treemap")
def render_treemap(data: ChartData, console) -> None:
    """Render hierarchical treemap as indented tree with proportional bars."""
    if not data.labels or len(data.labels) <= 1:
        console.print("[dim]No data for treemap.[/dim]")
        return

    if data.title:
        console.print(chart_title(data.title))

    parents = data.series.get("parents", [])
    ids = data.series.get("ids", data.labels)
    _root = data.metadata.get("root_label", data.labels[0])

    # Build parent->children mapping
    children: dict[str, list[int]] = defaultdict(list)
    for i, parent in enumerate(parents):
        if parent:
            children[parent].append(i)

    bw = bar_width(label_reserve=40)
    root_val = data.values[0] if data.values else 1
    narrow = terminal_width() < 60

    console.print()
    _render_node(console, data, children, ids, 0, 0, root_val, bw, narrow)
    console.print()


def _render_node(
    console, data: ChartData, children: dict[str, list[int]],
    ids: list[str], idx: int, depth: int, root_val: float,
    bw: int, narrow: bool,
) -> None:
    """Recursively render a tree node with indented bar."""
    label = data.labels[idx]
    value = data.values[idx]
    node_id = ids[idx]

    # Indent and tree connector
    if depth == 0:
        prefix = ""
    elif narrow:
        prefix = "  " * depth
    else:
        prefix = "  " + "│ " * (depth - 1) + "├─"

    # Bar proportional to root
    ratio = value / max(root_val, 1)
    bar_len = max(1, int(ratio * bw))
    color = SERIES_COLORS[depth % len(SERIES_COLORS)]
    bar = "█" * bar_len

    console.print(
        f"  {prefix}{label:<20s}  [{color}]{bar}[/{color}]  "
        f"{format_number(int(value))}"
    )

    # Render children
    child_indices = children.get(node_id, [])
    for ci in child_indices:
        _render_node(console, data, children, ids, ci, depth + 1, root_val, bw, narrow)
