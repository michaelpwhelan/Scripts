#!/usr/bin/env python3
"""Terminal distribution histogram with box-plot summary."""

from __future__ import annotations

import statistics

from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import bar_width, chart_title, gradient_color


@register_renderer("dist")
def render_dist(chart: ChartData, console) -> None:
    """Render distribution histogram with stats summary and IQR box plot."""
    if not chart.labels:
        console.print("[dim]No numeric data for distribution.[/dim]")
        return

    if chart.title:
        console.print(chart_title(chart.title))

    bw = bar_width()
    max_val = max(chart.values) if chart.values else 1
    max_key_len = max(len(k) for k in chart.labels)

    console.print()
    for i, (label, count) in enumerate(zip(chart.labels, chart.values)):
        ratio = count / max(max_val, 1)
        width = int(ratio * bw)
        bar = "\u2588" * width
        key_padded = label.ljust(max_key_len)
        color = gradient_color(ratio)
        console.print(f"  {key_padded}  [{color}]{bar}[/{color}]  {int(count)}")

    # Stats and box plot from raw values
    raw = chart.metadata.get("raw_values", [])
    if raw and len(raw) >= 2:
        sorted_vals = sorted(raw)
        n = len(sorted_vals)
        try:
            median = statistics.median(raw)
            mean = statistics.mean(raw)
            stdev = statistics.stdev(raw)
            p95 = sorted_vals[int(n * 0.95)]
            p99 = sorted_vals[min(int(n * 0.99), n - 1)]
            q1 = sorted_vals[n // 4]
            q3 = sorted_vals[3 * n // 4]
            v_min = sorted_vals[0]
            v_max = sorted_vals[-1]

            console.print(
                f"\n  [dim]Median: {format_number(int(median))}  "
                f"Mean: {format_number(int(mean))}  "
                f"Stdev: {format_number(int(stdev))}  "
                f"P95: {format_number(int(p95))}  "
                f"P99: {format_number(int(p99))}[/dim]"
            )

            # IQR box plot
            _render_box_plot(console, v_min, q1, median, q3, v_max,
                             max_key_len, bw)
        except statistics.StatisticsError:
            pass
    console.print()


def _render_box_plot(console, v_min: float, q1: float, median: float,
                     q3: float, v_max: float,
                     label_w: int, plot_width: int) -> None:
    """Render an ASCII box plot below the histogram."""
    v_range = v_max - v_min
    if v_range <= 0:
        return

    def _pos(v: float) -> int:
        return int((v - v_min) / v_range * (plot_width - 1))

    p_min = _pos(v_min)
    p_q1 = _pos(q1)
    p_med = _pos(median)
    p_q3 = _pos(q3)
    p_max = _pos(v_max)

    # Build the box plot line
    line = [" "] * plot_width
    # Whisker: min to Q1
    for i in range(p_min, p_q1 + 1):
        if 0 <= i < plot_width:
            line[i] = "─"
    # Box: Q1 to Q3
    for i in range(p_q1, p_q3 + 1):
        if 0 <= i < plot_width:
            line[i] = "═"
    # Endpoints
    if 0 <= p_min < plot_width:
        line[p_min] = "├"
    if 0 <= p_q1 < plot_width:
        line[p_q1] = "["
    if 0 <= p_med < plot_width:
        line[p_med] = "│"
    if 0 <= p_q3 < plot_width:
        line[p_q3] = "]"
    if 0 <= p_max < plot_width:
        line[p_max] = "┤"
    # Whisker: Q3 to max
    for i in range(p_q3, p_max + 1):
        if 0 <= i < plot_width:
            if line[i] == " ":
                line[i] = "─"

    box_str = "".join(line)
    padding = " " * label_w
    console.print(f"  {padding}  [cyan]{box_str}[/cyan]")
    console.print(
        f"  {padding}  [dim]"
        f"{format_number(int(v_min))}"
        f"{'':>{max(0, _pos(q1) - len(format_number(int(v_min))))}}"
        f"Q1"
        f"{'':>{max(0, _pos(median) - _pos(q1) - 2)}}"
        f"Med"
        f"{'':>{max(0, _pos(q3) - _pos(median) - 3)}}"
        f"Q3"
        f"[/dim]"
    )
