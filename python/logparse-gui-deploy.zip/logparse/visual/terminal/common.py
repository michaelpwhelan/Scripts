#!/usr/bin/env python3
"""Shared palette, sizing, and legend helpers for terminal charts."""

from __future__ import annotations

import os

PALETTE = {
    "critical": "#ff5555",
    "high": "#ff8c42",
    "medium": "#ffd166",
    "low": "#06d6a0",
    "info": "#118ab2",
    "bar_fill": "#58a6ff",
    "bar_alt": "#3fb950",
    "bar_warn": "#d29922",
    "bar_danger": "#f85149",
}

RICH_COLORS = {
    "critical": "red",
    "high": "bright_red",
    "medium": "yellow",
    "low": "green",
    "info": "cyan",
    "bar_fill": "cyan",
    "bar_alt": "green",
    "bar_warn": "yellow",
    "bar_danger": "red",
}

SERIES_COLORS = ["cyan", "green", "yellow", "magenta", "red", "blue", "bright_cyan", "bright_green"]
PLOTLY_SERIES_COLORS = ["#58a6ff", "#3fb950", "#d29922", "#bc8cff", "#f85149", "#79c0ff", "#ffa657", "#56d364"]

BLOCK_CHARS = "▁▂▃▄▅▆▇█"
HALF_BLOCK = "▌"
DENSITY_CHARS = ("·", "░", "▒", "▓", "█")
BRAILLE_BASE = 0x2800

# Arrow sets by weight: thin, medium, thick
ARROWS = ("─→", "━➤", "━━▶")

# Braille dot-to-bit mapping (row, col) -> bit mask
# Braille cell is 2 columns × 4 rows of dots
BRAILLE_DOTS = [
    [0x01, 0x08],  # row 0: dot1, dot4
    [0x02, 0x10],  # row 1: dot2, dot5
    [0x04, 0x20],  # row 2: dot3, dot6
    [0x40, 0x80],  # row 3: dot7, dot8
]

# Severity keyword → palette key mapping
_SEVERITY_KEYWORDS = {
    "critical": "critical", "emergency": "critical", "alert": "critical",
    "high": "high", "error": "high", "err": "high",
    "medium": "medium", "warning": "medium", "warn": "medium",
    "low": "low", "notice": "low",
    "info": "info", "information": "info", "informational": "info",
    "debug": "info",
}


def terminal_width() -> int:
    """Get usable terminal width."""
    try:
        return os.get_terminal_size().columns
    except (AttributeError, ValueError, OSError):
        return 80


def bar_width(label_reserve: int = 30) -> int:
    """Calculate sensible bar chart width, scaling with terminal."""
    available = terminal_width() - label_reserve
    return max(20, min(available, 100))


def gradient_color(ratio: float) -> str:
    """Map 0.0–1.0 to a green→yellow→red hex color for Rich markup."""
    ratio = max(0.0, min(1.0, ratio))
    if ratio < 0.5:
        t = ratio * 2
        r = int(0x06 + (0xff - 0x06) * t)
        g = int(0xd6 + (0xd1 - 0xd6) * t)
        b = int(0xa0 + (0x66 - 0xa0) * t)
    else:
        t = (ratio - 0.5) * 2
        r = int(0xff + (0xf8 - 0xff) * t)
        g = int(0xd1 + (0x51 - 0xd1) * t)
        b = int(0x66 + (0x49 - 0x66) * t)
    return f"#{r:02x}{g:02x}{b:02x}"


def severity_color(label: str) -> str | None:
    """Return Rich color name if label matches a known severity keyword."""
    key = _SEVERITY_KEYWORDS.get(label.lower())
    if key:
        return RICH_COLORS.get(key)
    return None


def chart_title(title: str) -> str:
    """Format a chart title with dim underline rule."""
    w = min(len(title) + 4, terminal_width() - 4)
    return f"  [bold]{title}[/bold]\n  [dim]{'─' * w}[/dim]"


def sparkline(values: list[float], width: int = 20, color: str = "cyan") -> str:
    """Return a single-line sparkline string using block characters.

    Resamples using max-per-bin to preserve peaks in security data.
    """
    if not values:
        return ""
    min_val = min(values)
    max_val = max(values)
    range_val = (max_val - min_val) or 1
    # Resample to fit width using max-per-bin
    if len(values) > width:
        step = len(values) / width
        sampled = []
        for i in range(width):
            start = int(i * step)
            end = int((i + 1) * step)
            sampled.append(max(values[start:end]) if start < end else values[start])
    elif len(values) < width:
        sampled = values
    else:
        sampled = values
    blocks = []
    for v in sampled:
        level = max(0, min(int((v - min_val) / range_val * 7), 7))
        blocks.append(BLOCK_CHARS[level])
    return f"[{color}]{''.join(blocks)}[/{color}]"
