#!/usr/bin/env python3
"""Two-field scatter plot with braille rendering and density overlay."""

from __future__ import annotations

import statistics

from logparse.models import LogEvent, get_field
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import (
    BRAILLE_BASE, BRAILLE_DOTS, chart_title, gradient_color, terminal_width,
)


def _grid_dims() -> tuple[int, int]:
    """Adaptive grid size based on terminal width."""
    tw = terminal_width()
    w = min(tw - 20, 100)
    h = max(10, min(w // 4, 25))
    return w, h


def build_scatter_data(
    events: list[LogEvent], field_x: str, field_y: str
) -> ChartData:
    """Extract two numeric fields from events for scatter plot."""
    xs, ys = [], []
    for e in events:
        vx = get_field(e, field_x)
        vy = get_field(e, field_y)
        if vx is None or vy is None:
            continue
        try:
            xs.append(float(vx))
            ys.append(float(vy))
        except (ValueError, TypeError):
            continue

    return ChartData(
        chart_type="scatter",
        title=f"{field_x} vs {field_y}",
        labels=[field_x, field_y],
        values=xs,
        series={"y": ys},
        metadata={"field_x": field_x, "field_y": field_y},
    )


@register_renderer("scatter")
def render_scatter(data: ChartData, console) -> None:
    """Render braille-based scatter plot with density coloring."""
    xs = data.values
    ys = data.series.get("y", [])
    if not xs or not ys or len(xs) < 2:
        console.print("[dim]Not enough numeric data for scatter plot.[/dim]")
        return

    if data.title:
        console.print(chart_title(data.title))

    _field_x = data.metadata.get("field_x", "x")
    field_y = data.metadata.get("field_y", "y")
    grid_w, grid_h = _grid_dims()

    min_x, max_x = min(xs), max(xs)
    min_y, max_y = min(ys), max(ys)
    range_x = max_x - min_x or 1
    range_y = max_y - min_y or 1

    # Braille sub-pixel resolution: 2 columns × 4 rows per cell
    braille_w = grid_w * 2
    braille_h = grid_h * 4

    cells = [[0] * grid_w for _ in range(grid_h)]
    density = [[0] * grid_w for _ in range(grid_h)]

    # Outlier detection
    outlier_cells = set()
    if len(xs) >= 3:
        try:
            mu_x, sd_x = statistics.mean(xs), statistics.stdev(xs)
            mu_y, sd_y = statistics.mean(ys), statistics.stdev(ys)
        except statistics.StatisticsError:
            mu_x = mu_y = sd_x = sd_y = 0
    else:
        mu_x = mu_y = sd_x = sd_y = 0

    for x, y in zip(xs, ys):
        # Map to braille sub-pixel coordinates
        bx = int((x - min_x) / range_x * (braille_w - 1))
        by = braille_h - 1 - int((y - min_y) / range_y * (braille_h - 1))
        bx = min(max(bx, 0), braille_w - 1)
        by = min(max(by, 0), braille_h - 1)

        cell_col, sub_col = divmod(bx, 2)
        cell_row, sub_row = divmod(by, 4)
        cell_col = min(cell_col, grid_w - 1)
        cell_row = min(cell_row, grid_h - 1)
        sub_col = min(sub_col, 1)
        sub_row = min(sub_row, 3)

        cells[cell_row][cell_col] |= BRAILLE_DOTS[sub_row][sub_col]
        density[cell_row][cell_col] += 1

        # Track outliers
        if sd_x > 0 and sd_y > 0:
            zx = abs(x - mu_x) / sd_x
            zy = abs(y - mu_y) / sd_y
            if zx > 2.5 or zy > 2.5:
                outlier_cells.add((cell_row, cell_col))

    # Find max density for color scaling
    max_density = 1
    for row in density:
        for d in row:
            if d > max_density:
                max_density = d

    # Render
    label_w = max(len(field_y), 8)
    console.print()

    for r in range(grid_h):
        # Y-axis labels at top, middle, bottom
        if r == 0:
            y_label = f"{max_y:.4g}".rjust(label_w)
        elif r == grid_h // 2:
            y_label = f"{(min_y + max_y) / 2:.4g}".rjust(label_w)
        elif r == grid_h - 1:
            y_label = f"{min_y:.4g}".rjust(label_w)
        else:
            y_label = " " * label_w

        border = "│" if r < grid_h - 1 else "└"
        parts = []
        for c in range(grid_w):
            if cells[r][c] == 0:
                parts.append(" ")
            else:
                ch = chr(BRAILLE_BASE + cells[r][c])
                if (r, c) in outlier_cells:
                    parts.append(f"[bold red]{ch}[/bold red]")
                else:
                    d_ratio = density[r][c] / max_density
                    color = gradient_color(d_ratio)
                    parts.append(f"[{color}]{ch}[/{color}]")

        console.print(f"  {y_label} {border}{''.join(parts)}")

    # X-axis
    console.print(f"  {' ' * label_w}  {'─' * grid_w}")
    x_min_str = f"{min_x:.4g}"
    x_max_str = f"{max_x:.4g}"
    pad = max(0, grid_w - len(x_min_str) - len(x_max_str))
    console.print(f"  {' ' * label_w}  {x_min_str}{' ' * pad}{x_max_str}")

    # Stats line
    n = len(xs)
    info_parts = [f"n = {n}"]

    if outlier_cells:
        info_parts.append(f"{len(outlier_cells)} outlier(s)")

    # Pearson correlation
    if n >= 3 and sd_x > 0 and sd_y > 0:
        cov = sum((x - mu_x) * (y - mu_y) for x, y in zip(xs, ys)) / (n - 1)
        r_val = cov / (sd_x * sd_y)
        info_parts.append(f"r = {r_val:.3f}")
        info_parts.append(f"r² = {r_val * r_val:.3f}")

    console.print(f"  [dim]{' · '.join(info_parts)}[/dim]")
    console.print()
