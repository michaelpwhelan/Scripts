#!/usr/bin/env python3
"""Terminal stacked bar chart renderer."""

from __future__ import annotations

from logparse.util import format_number
from logparse.visual import ChartData, register_renderer
from logparse.visual.terminal.common import SERIES_COLORS, bar_width, chart_title


_BLOCK_STYLES = ["\u2588", "\u2593", "\u2592", "\u2591"]


@register_renderer("stacked")
def render_stacked(chart: ChartData, console) -> None:
    """Render stacked bar chart with different block styles per sub-value."""
    if not chart.labels:
        console.print("[dim]No data for stacked chart.[/dim]")
        return

    if chart.title:
        console.print(chart_title(chart.title))

    sub_keys = chart.metadata.get("sub_keys", [])
    bw = bar_width()
    max_val = max(chart.values) if chart.values else 1
    max_key_len = max(len(k) for k in chart.labels)

    console.print()
    for i, label in enumerate(chart.labels):
        total = chart.values[i]
        key_padded = label.ljust(max_key_len)
        segments = []
        for j, sk in enumerate(sub_keys):
            sk_vals = chart.series.get(sk, [])
            val = sk_vals[i] if i < len(sk_vals) else 0
            width = int(val / max(max_val, 1) * bw)
            block = _BLOCK_STYLES[j % len(_BLOCK_STYLES)]
            color = SERIES_COLORS[j % len(SERIES_COLORS)]
            segments.append(f"[{color}]{block * width}[/{color}]")
        bar = "".join(segments)
        console.print(f"  {key_padded}  {bar}  {format_number(int(total))}")

    # Legend
    console.print()
    legend_parts = []
    for j, sk in enumerate(sub_keys):
        block = _BLOCK_STYLES[j % len(_BLOCK_STYLES)]
        color = SERIES_COLORS[j % len(SERIES_COLORS)]
        legend_parts.append(f"[{color}]{block}[/{color}] {sk}")
    console.print(f"  Legend: {'  '.join(legend_parts)}")
    console.print()
