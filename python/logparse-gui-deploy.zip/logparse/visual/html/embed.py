#!/usr/bin/env python3
"""Embed plotly charts into HTML exports."""

from __future__ import annotations

from logparse.visual.html.plotly_charts import chart_to_plotly

_CDN = "https://cdn.plot.ly/plotly-2.27.0.min.js"


def embed_charts(charts: list, html_content: str) -> str:
    """Inject all session charts as plotly divs into HTML content.

    Args:
        charts: list of ChartData objects
        html_content: existing HTML string

    Returns:
        Modified HTML with charts injected before </body>.
    """
    if not charts:
        return html_content

    divs = []
    has_charts = False

    for i, chart_data in enumerate(charts):
        # Handle geomap chart type separately
        if chart_data.chart_type == "geomap":
            from logparse.visual.html.geo_map import geo_to_plotly
            fig = geo_to_plotly(chart_data)
        else:
            fig = chart_to_plotly(chart_data)
        if fig is None:
            continue
        try:
            div = fig.to_html(
                full_html=False,
                include_plotlyjs=False,
                div_id=f"chart-{i}",
            )
            divs.append(f'<div style="margin: 20px 0;">{div}</div>')
            has_charts = True
        except (AttributeError, ValueError, TypeError):
            continue

    if not has_charts:
        return html_content

    charts_html = (
        f'\n<script src="{_CDN}"></script>\n'
        '<div style="padding: 20px;">\n'
        '<h2 style="color: #4ade80;">Charts</h2>\n'
        + "\n".join(divs)
        + "\n</div>\n"
    )

    if "</body>" in html_content:
        return html_content.replace("</body>", f"{charts_html}</body>")
    return html_content + charts_html
