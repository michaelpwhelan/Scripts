#!/usr/bin/env python3
"""HTML chart renderers (plotly-based)."""
