#!/usr/bin/env python3
"""Geographic map visualization using Plotly scattergeo."""

from __future__ import annotations

from collections import Counter

from logparse.models import LogEvent, get_field
from logparse.visual import ChartData


def build_geo_data(events: list[LogEvent], field: str = "srcip") -> ChartData:
    """Build geographic chart data from IP fields in events.

    Aggregates IPs by country using geoip lookup.
    """
    from logparse.geoip import lookup

    country_counts: Counter[str] = Counter()
    country_codes: dict[str, str] = {}

    for e in events:
        ip = get_field(e, field)
        if not ip:
            continue
        geo = lookup(ip)
        cc = geo.get("country_code", "??")
        country = geo.get("country", "Unknown")
        if cc in ("--", "??"):
            continue
        country_counts[country] += 1
        country_codes[country] = cc

    labels = [c for c, _ in country_counts.most_common()]
    values = [float(country_counts[c]) for c in labels]
    codes = [country_codes.get(c, "??") for c in labels]

    return ChartData(
        chart_type="geomap",
        title=f"Geographic Distribution — {field}",
        labels=labels,
        values=values,
        metadata={"field": field, "country_codes": codes},
    )


def geo_to_plotly(data: ChartData) -> object | None:
    """Convert geo ChartData to a Plotly scattergeo figure.

    Returns None if Plotly is unavailable.
    """
    try:
        import plotly.graph_objects as go
    except ImportError:
        return None

    codes = data.metadata.get("country_codes", [])
    if not codes:
        return None

    # Scale marker sizes (log scale for readability)
    import math
    max_val = max(data.values) if data.values else 1
    sizes = [max(8, min(50, 10 + 30 * math.log1p(v) / math.log1p(max_val))) for v in data.values]

    fig = go.Figure(go.Scattergeo(
        locations=codes,
        locationmode="ISO-3166-1 alpha-2",
        text=[f"{label}: {int(val)}" for label, val in zip(data.labels, data.values)],
        marker=dict(
            size=sizes,
            color=data.values,
            colorscale=[[0, "#16213e"], [0.5, "#58a6ff"], [1, "#f85149"]],
            showscale=True,
            colorbar=dict(title="Events"),
            line=dict(width=0.5, color="#0f3460"),
        ),
    ))

    fig.update_layout(
        title=data.title,
        paper_bgcolor="#1a1a2e",
        plot_bgcolor="#1a1a2e",
        font=dict(color="#e0e0e0", family="Consolas, monospace"),
        title_font_color="#4ade80",
        geo=dict(
            bgcolor="#16213e",
            landcolor="#1a1a2e",
            oceancolor="#0a0e27",
            showocean=True,
            showcountries=True,
            countrycolor="#0f3460",
            coastlinecolor="#0f3460",
            lakecolor="#0a0e27",
            projection_type="natural earth",
        ),
        margin=dict(l=0, r=0, t=50, b=0),
    )

    return fig
