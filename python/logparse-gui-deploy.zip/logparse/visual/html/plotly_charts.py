#!/usr/bin/env python3
"""Convert ChartData to plotly Figure objects."""

from __future__ import annotations

from logparse.visual import ChartData
from logparse.visual.terminal.common import PALETTE, PLOTLY_SERIES_COLORS

_PLOTLY_TEMPLATE = {
    "paper_bgcolor": "#1a1a2e",
    "plot_bgcolor": "#16213e",
    "font": {"color": "#e0e0e0", "family": "Consolas, monospace"},
    "title_font_color": "#4ade80",
    "xaxis": {"gridcolor": "#0f3460", "zerolinecolor": "#0f3460"},
    "yaxis": {"gridcolor": "#0f3460", "zerolinecolor": "#0f3460"},
}


def chart_to_plotly(data: ChartData) -> object | None:
    """Convert ChartData to a plotly Figure. Returns None if plotly unavailable."""
    try:
        import plotly.graph_objects as go
    except ImportError:
        return None

    converters = {
        "bar": _bar_figure,
        "heatmap": _heatmap_figure,
        "line": _line_figure,
        "scatter": _scatter_figure,
        "flow": _flow_figure,
        "dist": _dist_figure,
        "stacked": _stacked_figure,
        "pie": _pie_figure,
        "treemap": _treemap_figure,
        "sparkline_table": _sparkline_table_figure,
        "comparison": _comparison_figure,
    }
    fn = converters.get(data.chart_type, _bar_figure)
    return fn(go, data)


def _apply_layout(fig, data: ChartData) -> None:
    """Apply common dark theme layout."""
    fig.update_layout(
        title=data.title,
        **_PLOTLY_TEMPLATE,
        margin=dict(l=60, r=30, t=50, b=50),
    )


def _bar_figure(go, data: ChartData) -> object:
    fig = go.Figure(go.Bar(
        x=data.values,
        y=data.labels,
        orientation="h",
        marker_color=PALETTE["bar_fill"],
    ))
    _apply_layout(fig, data)
    fig.update_layout(yaxis=dict(autorange="reversed"))
    return fig


def _heatmap_figure(go, data: ChartData) -> object:
    grid = data.series.get("grid", [])
    if not grid:
        return _bar_figure(go, data)
    days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    hours = [f"{h:02d}" for h in range(24)]
    fig = go.Figure(go.Heatmap(
        z=grid,
        x=hours,
        y=days,
        colorscale=[[0, "#16213e"], [0.25, "#118ab2"], [0.5, "#ffd166"], [1, "#ff5555"]],
    ))
    _apply_layout(fig, data)
    return fig


def _line_figure(go, data: ChartData) -> object:
    # Multi-series support
    if data.series and any(isinstance(v, list) for v in data.series.values()):
        fig = go.Figure()
        for i, (name, values) in enumerate(data.series.items()):
            if not isinstance(values, list):
                continue
            fig.add_trace(go.Scatter(
                x=data.labels,
                y=values,
                mode="lines",
                name=name,
                line=dict(color=PLOTLY_SERIES_COLORS[i % len(PLOTLY_SERIES_COLORS)], width=2),
            ))
        _apply_layout(fig, data)
        return fig

    fig = go.Figure(go.Scatter(
        x=data.labels,
        y=data.values,
        mode="lines",
        line=dict(color=PALETTE["bar_fill"], width=2),
        fill="tozeroy",
        fillcolor="rgba(88,166,255,0.2)",
    ))
    _apply_layout(fig, data)
    return fig


def _scatter_figure(go, data: ChartData) -> object:
    ys = data.series.get("y", [])
    fig = go.Figure(go.Scatter(
        x=data.values,
        y=ys,
        mode="markers",
        marker=dict(color=PALETTE["bar_fill"], size=6),
    ))
    _apply_layout(fig, data)
    field_x = data.metadata.get("field_x", "x")
    field_y = data.metadata.get("field_y", "y")
    fig.update_layout(xaxis_title=field_x, yaxis_title=field_y)
    return fig


def _flow_figure(go, data: ChartData) -> object:
    pairs = data.series.get("pairs", [])
    if not pairs:
        return _bar_figure(go, data)
    # Build sankey
    all_nodes = []
    node_map = {}
    sources, targets, values = [], [], []
    for src, dst, count in pairs:
        src_label = f"{src} (src)"
        dst_label = f"{dst} (dst)"
        for label in (src_label, dst_label):
            if label not in node_map:
                node_map[label] = len(all_nodes)
                all_nodes.append(label)
        sources.append(node_map[src_label])
        targets.append(node_map[dst_label])
        values.append(count)

    fig = go.Figure(go.Sankey(
        node=dict(label=all_nodes, color=PALETTE["bar_fill"]),
        link=dict(source=sources, target=targets, value=values),
    ))
    _apply_layout(fig, data)
    return fig


def _dist_figure(go, data: ChartData) -> object:
    raw = data.metadata.get("raw_values", [])
    if raw:
        # Use raw values so Plotly can bin them properly
        fig = go.Figure(go.Histogram(
            x=raw,
            marker_color=PALETTE["bar_fill"],
            nbinsx=20,
        ))
    else:
        # Fallback: pre-binned data as a bar chart
        fig = go.Figure(go.Bar(
            x=data.labels,
            y=data.values,
            marker_color=PALETTE["bar_fill"],
        ))
    _apply_layout(fig, data)
    field = data.metadata.get("field", "value")
    fig.update_layout(xaxis_title=field, yaxis_title="Count")
    return fig


def _stacked_figure(go, data: ChartData) -> object:
    """Proper stacked bar chart with multiple traces per sub-value."""
    sub_keys = data.metadata.get("sub_keys", [])
    if not sub_keys:
        return _bar_figure(go, data)

    fig = go.Figure()
    for i, sk in enumerate(sub_keys):
        sk_vals = data.series.get(sk, [])
        fig.add_trace(go.Bar(
            name=sk,
            y=data.labels,
            x=sk_vals,
            orientation="h",
            marker_color=PLOTLY_SERIES_COLORS[i % len(PLOTLY_SERIES_COLORS)],
        ))
    _apply_layout(fig, data)
    fig.update_layout(barmode="stack", yaxis=dict(autorange="reversed"))
    return fig


def _pie_figure(go, data: ChartData) -> object:
    """Proper pie chart."""
    fig = go.Figure(go.Pie(
        labels=data.labels,
        values=data.values,
        hole=0.3,
        marker=dict(colors=PLOTLY_SERIES_COLORS),
    ))
    _apply_layout(fig, data)
    return fig


def _treemap_figure(go, data: ChartData) -> object:
    """Hierarchical treemap."""
    parents = data.series.get("parents", [])
    ids = data.series.get("ids", data.labels)
    fig = go.Figure(go.Treemap(
        labels=data.labels,
        parents=parents,
        values=data.values,
        ids=ids,
        marker=dict(
            colorscale=[[0, "#16213e"], [0.5, "#58a6ff"], [1, "#f85149"]],
        ),
        branchvalues="total",
    ))
    _apply_layout(fig, data)
    return fig


def _sparkline_table_figure(go, data: ChartData) -> object:
    """Multi-series line chart for sparkline table data."""
    fig = go.Figure()
    for i, label in enumerate(data.labels):
        series_vals = data.series.get(label, [])
        if not isinstance(series_vals, list):
            continue
        fig.add_trace(go.Scatter(
            y=series_vals,
            mode="lines",
            name=label,
            line=dict(color=PLOTLY_SERIES_COLORS[i % len(PLOTLY_SERIES_COLORS)], width=2),
        ))
    _apply_layout(fig, data)
    return fig


def _comparison_figure(go, data: ChartData) -> object:
    """Overlaid comparison chart with two series."""
    fig = go.Figure()
    for i, (name, values) in enumerate(data.series.items()):
        if not isinstance(values, list):
            continue
        fig.add_trace(go.Scatter(
            x=data.labels,
            y=values,
            mode="lines+markers",
            name=name,
            line=dict(color=PLOTLY_SERIES_COLORS[i % len(PLOTLY_SERIES_COLORS)], width=2),
        ))
    _apply_layout(fig, data)
    return fig
