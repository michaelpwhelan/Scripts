#!/usr/bin/env python3
"""User configuration and hints system."""

from __future__ import annotations

import logging
import os
from pathlib import Path

log = logging.getLogger(__name__)


def get_config_dir() -> Path:
    """Return platform-appropriate configuration directory."""
    if os.name == "nt":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "logparse"
    return Path(os.path.expanduser("~/.logparse"))


def get_cache_dir() -> Path:
    """Return platform-appropriate cache directory."""
    if os.name == "nt":
        localappdata = os.environ.get("LOCALAPPDATA")
        if localappdata:
            return Path(localappdata) / "logparse"
    return Path(os.path.expanduser("~/.cache/logparse"))


_CONFIG_DIR = get_config_dir()
_DEFAULT_CONFIG = {
    "default_output": "table",
    "timestamp_format": "datetime",
    "pager": True,
    "tutorial_completed": False,
    "show_hints": True,
}


def ensure_dirs() -> None:
    """Create ~/.logparse/ and subdirectories if needed."""
    for sub in ("routines", "noise", "sessions", "macros", "rules", "baselines"):
        (_CONFIG_DIR / sub).mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Read ~/.logparse/config.yaml, return defaults if missing."""
    path = _CONFIG_DIR / "config.yaml"
    if not path.exists():
        return dict(_DEFAULT_CONFIG)

    text = path.read_text(encoding="utf-8")
    if path.suffix in (".yaml", ".yml"):
        try:
            import yaml
            data = yaml.safe_load(text) or {}
            merged = dict(_DEFAULT_CONFIG)
            merged.update(data)
            return merged
        except ImportError:
            log.info("PyYAML not installed; falling back to JSON parser for config")

    # fall back to JSON
    import json
    try:
        data = json.loads(text)
        merged = dict(_DEFAULT_CONFIG)
        merged.update(data)
        return merged
    except (json.JSONDecodeError, ValueError):
        log.warning("Could not parse config file %s; using defaults", path)
        return dict(_DEFAULT_CONFIG)


def save_config(config: dict) -> None:
    """Write config to ~/.logparse/config.yaml."""
    _CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    path = _CONFIG_DIR / "config.yaml"
    try:
        import yaml
        path.write_text(yaml.dump(config, default_flow_style=False), encoding="utf-8")
    except ImportError:
        import json
        path.write_text(json.dumps(config, indent=2), encoding="utf-8")


# -- Contextual hints shown after commands --

HINTS: dict[str, str] = {
    "where": "Tip: Use 'undo' to step back through filter history.",
    "show": "Tip: Try 'show N' to see full details of a specific event.",
    "count": "Tip: Pipe results with '| sort count' to reorder aggregations.",
    "search": "Tip: Add '| count by source' to see which sources match.",
    "help": "Tip: Try 'cheatsheet' for a compact reference card.",
    "export": "Tip: Use 'export report.html include remember' to add notes.",
    "star": "Tip: Use 'show star' to review all starred events.",
    "vars": "Tip: Use '$name = N.field' to capture values from results.",
    "sort": "Tip: Use 'sort field desc' or 'sort field asc' for direction.",
    "select": "Tip: Use 'show *' to display all available fields.",
}
