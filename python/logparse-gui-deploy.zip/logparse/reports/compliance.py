#!/usr/bin/env python3
"""Compliance report — FFIEC Information Security work program control mapping.

Maps loaded events to FFIEC IS.WP.* domains and generates examination-ready
evidence documentation per FFIEC IT Examination Handbook, NCUA Part 748
Appendix A §III.C.2, and ISE examination expectations.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.compliance_data import (
    CONTROLS, DOMAINS, evidence_status, get_domain_controls, matches_control,
)
from logparse.models import LogEvent
from logparse.util import format_number


def report_compliance(events: list[LogEvent], console: Console) -> None:
    """Generate FFIEC compliance evidence report."""
    console.rule("FFIEC Compliance Evidence Report", style="bold magenta")
    now = datetime.now()

    # -- Attestation header -------------------------------------------------
    ts_events = [e for e in events if e.timestamp]
    console.print(f"  Report generated: {now:%Y-%m-%d %H:%M:%S}")
    console.print(f"  Total events analyzed: {format_number(len(events))}")

    sources = sorted(set(e.source_file or e.source for e in events if e.source_file or e.source))
    formats = sorted(set(e.source_format for e in events if e.source_format))
    console.print(f"  Log sources: {len(sources)}  Formats: {', '.join(formats) or 'N/A'}")

    t_min = min((e.timestamp for e in ts_events), default=None)
    t_max = max((e.timestamp for e in ts_events), default=None)
    if t_min is not None and t_max is not None:
        span = t_max - t_min
        console.print(f"  Review period: {t_min:%Y-%m-%d %H:%M} — {t_max:%Y-%m-%d %H:%M}"
                       f"  ({span.days}d {span.seconds // 3600}h)")
    console.print()

    # -- Score each control -------------------------------------------------
    ctrl_counts: Counter[str] = Counter()
    ctrl_events: defaultdict[str, list[LogEvent]] = defaultdict(list)

    for e in events:
        for ctrl_id, ctrl in CONTROLS.items():
            if matches_control(e.extra, e.message, ctrl):
                ctrl_counts[ctrl_id] += 1
                if len(ctrl_events[ctrl_id]) < 5:  # keep sample
                    ctrl_events[ctrl_id].append(e)

    # -- Multi-source aggregation (IS.WP.AL-3) special handling -------------
    # This control requires evidence from 2+ distinct source formats
    al3_id = "IS.WP.AL-3"
    if al3_id in CONTROLS:
        ctrl_counts[al3_id] = len(formats)

    # -- Domain coverage matrix ---------------------------------------------
    console.rule("Domain Coverage Summary", style="bold")

    summary_table = Table(show_header=True, expand=True, border_style="dim")
    summary_table.add_column("DOMAIN", style="bold", width=12)
    summary_table.add_column("NAME", ratio=1)
    summary_table.add_column("CONTROLS", justify="center", width=9)
    summary_table.add_column("EVIDENCE", justify="right", width=9, style="cyan")
    summary_table.add_column("STATUS", width=14)

    domains_sufficient = 0

    for domain_id, domain_name in DOMAINS.items():
        controls = get_domain_controls(domain_id)
        if not controls:
            continue

        sufficient = 0
        partial = 0
        total_evidence = 0
        for ctrl in controls:
            count = ctrl_counts.get(ctrl.control_id, 0)
            total_evidence += count
            status = evidence_status(count, ctrl)
            if status == "Sufficient":
                sufficient += 1
            elif status == "Partial":
                partial += 1

        if sufficient == len(controls):
            domain_status = "[green]SUFFICIENT[/green]"
            domains_sufficient += 1
        elif sufficient > 0 or partial > 0:
            domain_status = "[yellow]PARTIAL[/yellow]"
        else:
            domain_status = "[red]NO EVIDENCE[/red]"

        summary_table.add_row(
            domain_id, domain_name,
            f"{sufficient}/{len(controls)}",
            format_number(total_evidence),
            domain_status,
        )

    console.print(summary_table)

    coverage_pct = (domains_sufficient / len(DOMAINS) * 100) if DOMAINS else 0
    console.print(f"\n  Overall domain coverage: [bold]{coverage_pct:.0f}%[/bold]"
                  f" ({domains_sufficient}/{len(DOMAINS)} domains with sufficient evidence)")
    console.print()

    # -- Per-control detail -------------------------------------------------
    for domain_id, domain_name in DOMAINS.items():
        controls = get_domain_controls(domain_id)
        if not controls:
            continue

        console.rule(f"{domain_id}: {domain_name}", style="dim")

        for ctrl in controls:
            count = ctrl_counts.get(ctrl.control_id, 0)
            status = evidence_status(count, ctrl)

            if status == "Sufficient":
                status_fmt = "[green]SUFFICIENT[/green]"
            elif status == "Partial":
                status_fmt = "[yellow]PARTIAL[/yellow]"
            else:
                status_fmt = "[red]NO EVIDENCE[/red]"

            console.print(
                f"  [{ctrl.control_id}] {ctrl.name}  —  "
                f"{format_number(count)} events  {status_fmt}"
            )
            console.print(f"    [dim]{ctrl.description}[/dim]")
            console.print(f"    [dim]Ref: {ctrl.handbook_ref}  |  "
                          f"NIST: {', '.join(ctrl.nist_mapping)}[/dim]")

            # Sample evidence
            samples = ctrl_events.get(ctrl.control_id, [])
            if samples:
                for e in samples[:3]:
                    ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else "??:??:??"
                    msg = e.message[:70] + "..." if len(e.message) > 70 else e.message
                    console.print(f"    {ts}  [{e.severity}] {msg}")
                if count > 3:
                    console.print(f"    [dim]... and {count - 3} more[/dim]")
            elif status == "None":
                console.print("    [dim]Gap: No matching events found. "
                              "Verify log sources include data for this control.[/dim]")
            console.print()

    # -- Log retention assessment -------------------------------------------
    console.rule("Log Retention Assessment", style="bold")
    if t_min is not None and t_max is not None:
        span = t_max - t_min
        days = span.days
        if days >= 90:
            console.print(f"  Log span: [green]{days} days[/green]"
                          f" (meets FFIEC 90-day minimum recommendation)")
        elif days >= 30:
            console.print(f"  Log span: [yellow]{days} days[/yellow]"
                          f" (below 90-day FFIEC recommendation)")
        else:
            console.print(f"  Log span: [red]{days} days[/red]"
                          f" (significantly below 90-day FFIEC recommendation)")
    else:
        console.print("  [dim]No timestamped events — cannot assess retention.[/dim]")
    console.print()

    # -- Audit trail integrity ----------------------------------------------
    console.rule("Audit Trail Integrity", style="bold")
    log_clears = sum(1 for e in events
                     if e.extra.get("EventID") == "1102")
    policy_changes = sum(1 for e in events
                         if e.extra.get("EventID") == "4719")

    if log_clears > 0:
        console.print(f"  [red]ALERT: {log_clears} audit log clear event(s) detected (EID 1102)[/red]")
    else:
        console.print("  [green]No audit log clear events detected[/green]")

    if policy_changes > 0:
        console.print(f"  [yellow]Note: {policy_changes} audit policy change(s) detected (EID 4719)[/yellow]")
    else:
        console.print("  [green]No audit policy changes detected[/green]")

    console.print(f"\n  [dim]Evidence of {format_number(len(events))} events across "
                  f"{len(sources)} source(s) demonstrates ongoing log review "
                  f"per FFIEC Information Security Booklet §II.C.22[/dim]")
