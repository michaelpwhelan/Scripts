#!/usr/bin/env python3
"""Morning briefing — overnight summary."""

from __future__ import annotations

from collections import Counter

from rich.console import Console
from logparse.models import LogEvent, get_field
from logparse.util import compact_table, format_number


def report_morning(events: list[LogEvent], console: Console) -> None:
    """Generate morning briefing with overnight highlights."""
    ts_events = [e for e in events if e.timestamp]

    console.rule(
        f"Overnight: {format_number(len(events))} events",
        style="bold green",
    )
    if ts_events:
        t_min = min(e.timestamp for e in ts_events)
        t_max = max(e.timestamp for e in ts_events)
        console.print(f"  {t_min:%H:%M} — {t_max:%H:%M}, {t_max:%Y-%m-%d}")
    console.print()

    # -- critical/high alerts (only shown when present) -----------------------
    critical = [e for e in events if e.severity in ("Critical", "High")]
    if critical:
        sev_counts = Counter(e.severity for e in critical)
        console.rule(f"{len(critical)} critical/high", style="bold red")
        console.print(
            f"  Critical: {sev_counts.get('Critical', 0)} | "
            f"High: {sev_counts.get('High', 0)}"
        )
        for e in critical[:5]:
            ts = e.timestamp.strftime("%H:%M:%S") if e.timestamp else "??:??:??"
            console.print(f"  [red]{ts}[/red] [{e.severity}] {e.source}: {e.message[:80]}")
        if len(critical) > 5:
            console.print(f"  [dim]... and {len(critical) - 5} more[/dim]")
        console.print()

    # -- failed auth (only shown when present) --------------------------------
    fail_events = [
        e for e in events
        if any(k in e.message.lower() for k in ("fail", "denied", "reject"))
        or e.extra.get("EventID") in ("4625", "4771", "6273")
    ]
    if fail_events:
        console.rule(f"{format_number(len(fail_events))} failed auth", style="bold yellow")
        user_counts = Counter(
            get_field(e, "TargetUserName") or get_field(e, "user") or "(unknown)"
            for e in fail_events
        )
        table = compact_table()
        table.add_column("USER", style="bold")
        table.add_column("ATTEMPTS", justify="right", style="red")
        for user, count in user_counts.most_common(5):
            table.add_row(user, format_number(count))
        console.print(table)
        console.print()

    # -- IPsec (only shown when present) --------------------------------------
    ipsec_events = [
        e for e in events
        if "ipsec" in e.message.lower() or e.extra.get("subtype", "").lower() == "ipsec"
    ]
    if ipsec_events:
        import re as _re
        down_events = [e for e in ipsec_events if _re.search(r"\bdown\b", e.message, _re.IGNORECASE)]
        title = f"{format_number(len(ipsec_events))} IPsec events"
        if down_events:
            title += f", {len(down_events)} down"
        console.rule(title, style="bold cyan")
        if down_events:
            for e in down_events[:3]:
                ts = e.timestamp.strftime("%H:%M:%S") if e.timestamp else "??:??:??"
                console.print(f"  [red]{ts}[/red] {e.message[:80]}")
        console.print()

    # -- source activity ------------------------------------------------------
    console.rule("Sources", style="bold")
    source_counts = Counter(e.source for e in events if e.source)
    table = compact_table()
    table.add_column("SOURCE", style="bold")
    table.add_column("EVENTS", justify="right", style="cyan")
    for src, count in source_counts.most_common(10):
        table.add_row(src, format_number(count))
    console.print(table)
