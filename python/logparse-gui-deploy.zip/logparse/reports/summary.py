#!/usr/bin/env python3
"""Summary report — overview, severity distribution, top sources."""

from __future__ import annotations

from collections import Counter

from rich.console import Console
from logparse.models import SEVERITY_LEVELS, LogEvent, get_field
from logparse.util import compact_table, format_number


def report_summary(events: list[LogEvent], console: Console) -> None:
    """Generate overview summary report."""
    ts_events = [e for e in events if e.timestamp]

    console.rule(f"{format_number(len(events))} events", style="bold")
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        span = last - first
        console.print(f"  {first:%Y-%m-%d %H:%M:%S} — {last:%Y-%m-%d %H:%M:%S} ({span})")
    console.print()

    # severity distribution
    console.rule("Severity", style="bold")
    sev_counts = Counter(e.severity for e in events)
    sev_colors = {
        "Critical": "bold red", "High": "red", "Medium": "yellow",
        "Low": "cyan", "Info": "dim",
    }
    total = max(len(events), 1)
    max_count = max(sev_counts.values()) if sev_counts else 1

    for sev in SEVERITY_LEVELS:
        count = sev_counts.get(sev, 0)
        pct = count / total * 100
        bar_width = int(count / max_count * 40) if max_count else 0
        bar = "\u2588" * bar_width
        style = sev_colors.get(sev, "")
        console.print(
            f"  [{style}]{sev.upper():<10}[/{style}]"
            f" [cyan]{bar}[/cyan]  {format_number(count)}  ({pct:.1f}%)"
        )
    console.print()

    # top sources
    console.rule("Sources", style="bold")
    source_counts = Counter(e.source for e in events if e.source)
    table = compact_table()
    table.add_column("SOURCE", style="bold")
    table.add_column("COUNT", justify="right", style="cyan")
    table.add_column("%", justify="right")
    for src, count in source_counts.most_common(10):
        table.add_row(src, format_number(count), f"{count/total*100:.1f}%")
    console.print(table)
    console.print()

    # top source IPs
    ip_counts = Counter(
        get_field(e, "srcip") for e in events if get_field(e, "srcip")
    )
    if ip_counts:
        console.rule("Source IPs", style="bold")
        table = compact_table()
        table.add_column("IP", style="bold")
        table.add_column("COUNT", justify="right", style="cyan")
        for ip, count in ip_counts.most_common(10):
            table.add_row(ip, format_number(count))
        console.print(table)
        console.print()

    # top event IDs
    eid_counts = Counter(
        get_field(e, "EventID") for e in events if get_field(e, "EventID")
    )
    if eid_counts:
        console.rule("Event IDs", style="bold")
        table = compact_table()
        table.add_column("EVENT ID", style="bold")
        table.add_column("COUNT", justify="right", style="cyan")
        for eid, count in eid_counts.most_common(10):
            table.add_row(eid, format_number(count))
        console.print(table)
