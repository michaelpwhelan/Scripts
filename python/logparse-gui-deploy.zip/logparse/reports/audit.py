#!/usr/bin/env python3
"""Audit report — privileged activity, account changes, failed auth."""

from __future__ import annotations

from collections import Counter

from rich.console import Console
from logparse.models import LogEvent, get_field
from logparse.util import compact_table, format_number

# Privileged activity Event IDs
_PRIV_EIDS = {"4672", "4648", "4697", "7045"}
# Account management Event IDs
_ACCT_EIDS = {"4720", "4722", "4723", "4724", "4725", "4726", "4728", "4732", "4756"}
# Failed auth Event IDs
_FAIL_EIDS = {"4625", "4771", "6273"}


def report_audit(events: list[LogEvent], console: Console) -> None:
    """Generate audit report for security review."""
    console.rule("Audit Report", style="bold red")

    ts_events = [e for e in events if e.timestamp]
    console.print(f"  Events: {format_number(len(events))}")
    if ts_events:
        t_min = min(e.timestamp for e in ts_events)
        t_max = max(e.timestamp for e in ts_events)
        console.print(
            f"  Period: {t_min:%Y-%m-%d %H:%M} — "
            f"{t_max:%Y-%m-%d %H:%M}"
        )
    console.print()

    # privileged activity
    console.rule("Privileged Activity", style="bold")
    priv_events = [e for e in events if e.extra.get("EventID") in _PRIV_EIDS]
    if priv_events:
        eid_counts = Counter(e.extra.get("EventID") for e in priv_events)
        table = compact_table()
        table.add_column("EVENT ID", style="bold")
        table.add_column("DESCRIPTION")
        table.add_column("COUNT", justify="right", style="cyan")
        eid_desc = {
            "4672": "Special privileges assigned",
            "4648": "Logon with explicit credentials",
            "4697": "Service installed",
            "7045": "New service registered",
        }
        for eid, count in eid_counts.most_common():
            table.add_row(eid, eid_desc.get(eid, ""), format_number(count))
        console.print(table)
        console.print(f"  Total: {format_number(len(priv_events))}")
    else:
        console.print("  [dim]No privileged activity events.[/dim]")
    console.print()

    # account changes
    console.rule("Account Changes", style="bold")
    acct_events = [e for e in events if e.extra.get("EventID") in _ACCT_EIDS]
    if acct_events:
        eid_desc = {
            "4720": "Account created",
            "4722": "Account enabled",
            "4723": "Password change attempted",
            "4724": "Password reset",
            "4725": "Account disabled",
            "4726": "Account deleted",
            "4728": "Member added to global group",
            "4732": "Member added to local group",
            "4756": "Member added to universal group",
        }
        for e in acct_events[:15]:
            eid = e.extra.get("EventID", "")
            target = get_field(e, "TargetUserName") or ""
            actor = get_field(e, "SubjectUserName") or ""
            ts = e.timestamp.strftime("%Y-%m-%d %H:%M") if e.timestamp else ""
            desc = eid_desc.get(eid, eid)
            console.print(f"  {ts}  {desc}: {target} (by {actor})")
        if len(acct_events) > 15:
            console.print(f"  ... and {len(acct_events) - 15} more")
    else:
        console.print("  [dim]No account change events.[/dim]")
    console.print()

    # failed authentication
    console.rule("Failed Authentication", style="bold")
    fail_events = [
        e for e in events
        if e.extra.get("EventID") in _FAIL_EIDS
        or any(k in e.message.lower() for k in ("fail", "denied", "reject", "auth-fail"))
    ]
    if fail_events:
        user_counts = Counter(
            get_field(e, "TargetUserName") or get_field(e, "user") or "(unknown)"
            for e in fail_events
        )
        ip_counts = Counter(
            get_field(e, "IpAddress") or get_field(e, "srcip") or "(unknown)"
            for e in fail_events
        )
        console.print(f"  Total failures: {format_number(len(fail_events))}")
        console.print(f"  Unique users: {len(user_counts)}")
        console.print(f"  Unique source IPs: {len(ip_counts)}")
        console.print()
        console.print("  Top targeted users:")
        for user, count in user_counts.most_common(5):
            console.print(f"    {user}: {format_number(count)}")
        console.print("  Top source IPs:")
        for ip, count in ip_counts.most_common(5):
            console.print(f"    {ip}: {format_number(count)}")
    else:
        console.print("  [dim]No failed authentication events.[/dim]")
