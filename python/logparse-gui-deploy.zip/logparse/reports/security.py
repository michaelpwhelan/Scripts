#!/usr/bin/env python3
"""Security report — severity breakdown, MITRE, anomalies, auth failures."""

from __future__ import annotations

from collections import Counter

from rich.console import Console
from rich.table import Table

from logparse.models import SEVERITY_LEVELS, LogEvent, get_field
from logparse.util import format_number


def report_security(events: list[LogEvent], console: Console) -> None:
    """Generate a security report."""

    # -- header ---------------------------------------------------------------
    sev_counts: Counter[str] = Counter(e.severity for e in events)
    ts_events = [e for e in events if e.timestamp]

    console.rule(
        f"Security: {format_number(len(events))} events",
        style="bold red",
    )
    if ts_events:
        first = min(e.timestamp for e in ts_events)
        last = max(e.timestamp for e in ts_events)
        console.print(f"  {first:%Y-%m-%d %H:%M} — {last:%Y-%m-%d %H:%M}")

    sev_parts = [f"{sev} {format_number(sev_counts[sev])}"
                 for sev in SEVERITY_LEVELS if sev_counts[sev]]
    if sev_parts:
        console.print(f"  {' | '.join(sev_parts)}")
    console.print()

    # -- MITRE ATT&CK --------------------------------------------------------
    try:
        from logparse.mitre import scan_events, detect_kill_chains
        matches = scan_events(events)
        if matches:
            table = Table(title="MITRE ATT&CK", show_header=True)
            table.add_column("ID", style="bold cyan")
            table.add_column("NAME")
            table.add_column("TACTIC")
            table.add_column("EVENTS", justify="right")
            table.add_column("SCORE", justify="right")

            for m in matches[:10]:
                table.add_row(
                    m.technique.technique_id,
                    m.technique.name,
                    m.technique.tactic,
                    str(m.count),
                    f"{m.score:.1f}",
                )
            console.print(table)

            chains = detect_kill_chains(matches)
            for chain, chain_matches in chains:
                stages = " -> ".join(m.technique.technique_id for m in chain_matches)
                console.print(f"  [bold red]{chain.name}:[/bold red] {stages}")
                console.print(f"    {chain.description}")
            console.print()
    except ImportError:
        pass

    # -- anomalies ------------------------------------------------------------
    try:
        from logparse.analyzers.anomaly import run_all_detectors
        findings = run_all_detectors(events)
        if findings:
            table = Table(title="Anomalies", show_header=True)
            table.add_column("DETECTOR")
            table.add_column("FINDING")
            table.add_column("SEVERITY")
            table.add_column("SCORE", justify="right")

            for f in findings[:8]:
                sev_style = {"High": "bright_red", "Medium": "yellow"}.get(f.severity, "")
                table.add_row(
                    f.detector,
                    f.title,
                    f"[{sev_style}]{f.severity}[/{sev_style}]",
                    f"{f.score:.1f}",
                )
            console.print(table)
            console.print()
    except ImportError:
        pass

    # -- failed auth sources --------------------------------------------------
    fail_events = [
        e for e in events
        if "fail" in (get_field(e, "action") or "").lower()
        or "deny" in (get_field(e, "action") or "").lower()
        or e.severity in ("High", "Critical")
    ]
    if fail_events:
        src_counter: Counter[str] = Counter()
        for e in fail_events:
            src = get_field(e, "srcip") or get_field(e, "source") or ""
            if src:
                src_counter[src] += 1

        if src_counter:
            table = Table(
                title=f"{format_number(len(fail_events))} failed/denied",
                show_header=True,
            )
            table.add_column("SOURCE", style="bold")
            table.add_column("COUNT", justify="right")

            for src, cnt in src_counter.most_common(10):
                table.add_row(src, format_number(cnt))
            console.print(table)
            console.print()

    console.rule(style="dim")
