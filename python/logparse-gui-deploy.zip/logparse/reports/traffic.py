#!/usr/bin/env python3
"""Traffic report — top talkers, deny analysis, port breakdown, bandwidth."""

from __future__ import annotations

import statistics
from collections import Counter

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number


def report_traffic(events: list[LogEvent], console: Console) -> None:
    """Generate a traffic analysis report."""
    console.rule(f"Traffic: {format_number(len(events))} events", style="bold cyan")
    console.print()

    # 1. Top talkers by srcip
    src_counter: Counter[str] = Counter()
    for e in events:
        src = get_field(e, "srcip") or ""
        if src:
            src_counter[src] += 1

    if src_counter:
        table = Table(title="Top Talkers (by srcip)", show_header=True)
        table.add_column("SOURCE IP", style="bold")
        table.add_column("EVENTS", justify="right")
        table.add_column("%", justify="right")

        total = sum(src_counter.values())
        for ip, cnt in src_counter.most_common(10):
            pct = cnt / total * 100
            table.add_row(ip, format_number(cnt), f"{pct:.1f}%")
        console.print(table)
    console.print()

    # 2. Deny analysis
    deny_events = [
        e for e in events
        if (get_field(e, "action") or "").lower() in ("deny", "drop", "block", "dropped", "blocked")
    ]
    if deny_events:
        dst_counter: Counter[str] = Counter()
        port_counter: Counter[str] = Counter()
        for e in deny_events:
            dst = get_field(e, "dstip") or ""
            port = get_field(e, "dstport") or ""
            if dst:
                target = f"{dst}:{port}" if port else dst
                dst_counter[target] += 1
            if port:
                port_counter[port] += 1

        if dst_counter:
            table = Table(title=f"Deny Analysis ({len(deny_events)} denied)", show_header=True)
            table.add_column("TARGET", style="bold")
            table.add_column("DENIES", justify="right")

            for target, cnt in dst_counter.most_common(10):
                table.add_row(target, format_number(cnt))
            console.print(table)
    console.print()

    # 3. Port breakdown
    all_ports: Counter[str] = Counter()
    for e in events:
        port = get_field(e, "dstport") or ""
        if port:
            all_ports[port] += 1

    if all_ports:
        table = Table(title="Port Breakdown", show_header=True)
        table.add_column("PORT", style="bold")
        table.add_column("EVENTS", justify="right")
        table.add_column("%", justify="right")

        total = sum(all_ports.values())
        for port, cnt in all_ports.most_common(10):
            pct = cnt / total * 100
            table.add_row(port, format_number(cnt), f"{pct:.1f}%")
        console.print(table)
    console.print()

    # 4. Bandwidth outliers
    byte_vals: list[float] = []
    byte_events: list[tuple[float, LogEvent]] = []
    for e in events:
        sent = get_field(e, "sentbyte")
        if sent:
            try:
                val = float(sent)
                byte_vals.append(val)
                byte_events.append((val, e))
            except (ValueError, TypeError):
                continue

    if len(byte_vals) >= 3:
        try:
            mu = statistics.mean(byte_vals)
            sd = statistics.stdev(byte_vals)
            n_bv = len(byte_vals)
            sorted_bv = sorted(byte_vals)
            p95 = sorted_bv[min(int(n_bv * 0.95), n_bv - 1)]
            p99 = sorted_bv[min(int(n_bv * 0.99), n_bv - 1)]

            console.print("[bold]Bandwidth Stats (sentbyte):[/bold]")
            console.print(f"  Mean: {_human_bytes(mu)}  Median: {_human_bytes(statistics.median(byte_vals))}")
            console.print(f"  P95: {_human_bytes(p95)}  P99: {_human_bytes(p99)}")

            if sd > 0:
                outliers = [
                    (val, e) for val, e in byte_events
                    if (val - mu) / sd > 2
                ]
                if outliers:
                    console.print(f"\n  [yellow]⚠ {len(outliers)} bandwidth outlier(s) (>2σ):[/yellow]")
                    for val, e in sorted(outliers, key=lambda x: -x[0])[:5]:
                        src = get_field(e, "srcip") or ""
                        dst = get_field(e, "dstip") or ""
                        console.print(f"    {src} → {dst}: {_human_bytes(val)}")
        except statistics.StatisticsError:
            pass

    console.print()
    console.rule(style="dim")


def _human_bytes(n: float) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if abs(n) < 1024:
            return f"{n:.0f}{unit}"
        n /= 1024
    return f"{n:.0f}TB"
