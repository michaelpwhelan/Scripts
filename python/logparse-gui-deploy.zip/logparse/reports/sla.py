#!/usr/bin/env python3
"""SLA report — availability, MTTR, and performance metrics."""

from __future__ import annotations

import statistics
from collections import Counter
from datetime import timedelta

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_FAIL_ACTIONS = {"deny", "denied", "blocked", "drop", "fail", "failed", "error", "timeout"}
_RECOVER_ACTIONS = {"accept", "allow", "pass", "success", "up"}


def report_sla(events: list[LogEvent], console: Console) -> None:
    """Generate SLA compliance report with availability and performance metrics."""
    if not events:
        console.print("[dim]No events for SLA report.[/dim]")
        return

    console.rule("SLA Compliance Report", style="bold cyan")

    timestamps = sorted(e.timestamp for e in events if e.timestamp)
    if len(timestamps) < 2:
        console.print("[dim]Need timestamped events for SLA report.[/dim]")
        return

    total_span = timestamps[-1] - timestamps[0]
    total_secs = total_span.total_seconds()

    # Count failures
    total_events = len(events)
    fail_count = 0
    for e in events:
        action = (get_field(e, "action") or "").lower()
        if action in _FAIL_ACTIONS:
            fail_count += 1

    failure_rate = fail_count / max(total_events, 1) * 100

    # Gap analysis for availability
    gap_threshold = timedelta(minutes=max(total_secs / 6000, 5))
    gaps: list[tuple[int, int, timedelta]] = []
    for i in range(len(timestamps) - 1):
        gap = timestamps[i + 1] - timestamps[i]
        if gap > gap_threshold:
            gaps.append((i, i + 1, gap))

    total_gap_secs = sum(g[2].total_seconds() for g in gaps)
    availability = max(0, (1 - total_gap_secs / max(total_secs, 1)) * 100)

    # MTTR / MTTF estimation
    # Track state transitions: fail->recover (sorted by time for correct pairing)
    fail_times: list[float] = []
    recover_times: list[float] = []
    for e in events:
        if not e.timestamp:
            continue
        action = (get_field(e, "action") or "").lower()
        if action in _FAIL_ACTIONS:
            fail_times.append(e.timestamp.timestamp())
        elif action in _RECOVER_ACTIONS:
            recover_times.append(e.timestamp.timestamp())

    fail_times.sort()
    recover_times.sort()

    # Estimate MTTR: average gap between failure and next recovery
    # Each recovery is consumed once to avoid pairing with multiple failures
    mttr_values: list[float] = []
    ri = 0
    for ft in fail_times:
        while ri < len(recover_times) and recover_times[ri] <= ft:
            ri += 1
        if ri < len(recover_times):
            mttr_values.append(recover_times[ri] - ft)
            ri += 1  # consume this recovery

    # Estimate MTTF: average gap between recovery and next failure
    mttf_values: list[float] = []
    fi = 0
    for rt in recover_times:
        while fi < len(fail_times) and fail_times[fi] <= rt:
            fi += 1
        if fi < len(fail_times):
            mttf_values.append(fail_times[fi] - rt)
            fi += 1  # consume this failure

    # Trend: compare first half vs second half failure rates
    midpoint = timestamps[len(timestamps) // 2]
    first_half_fails = sum(1 for e in events if e.timestamp and e.timestamp < midpoint and
                          (get_field(e, "action") or "").lower() in _FAIL_ACTIONS)
    second_half_fails = fail_count - first_half_fails
    first_half_total = sum(1 for e in events if e.timestamp and e.timestamp < midpoint)
    second_half_total = total_events - first_half_total
    first_rate = first_half_fails / max(first_half_total, 1) * 100
    second_rate = second_half_fails / max(second_half_total, 1) * 100
    if second_rate < first_rate * 0.8:
        trend = "[green]Improving[/green]"
    elif second_rate > first_rate * 1.2:
        trend = "[red]Degrading[/red]"
    else:
        trend = "[yellow]Stable[/yellow]"

    # Summary panel
    avail_color = "green" if availability >= 99 else "yellow" if availability >= 95 else "red"
    lines = [
        f"  [bold]Time Range:[/bold]     {timestamps[0].strftime('%Y-%m-%d %H:%M')} — {timestamps[-1].strftime('%Y-%m-%d %H:%M')}",
        f"  [bold]Duration:[/bold]       {_fmt_td(total_span)}",
        "",
        f"  [bold]Availability:[/bold]   [{avail_color}]{availability:.3f}%[/{avail_color}]",
        f"  [bold]Failure Rate:[/bold]   {failure_rate:.2f}% ({format_number(fail_count)} / {format_number(total_events)})",
        f"  [bold]Event Gaps:[/bold]     {len(gaps)}",
        f"  [bold]Trend:[/bold]          {trend}",
    ]

    if mttr_values:
        avg_mttr = statistics.mean(mttr_values)
        lines.append(f"  [bold]MTTR:[/bold]           {_fmt_secs(avg_mttr)}")
    if mttf_values:
        avg_mttf = statistics.mean(mttf_values)
        lines.append(f"  [bold]MTTF:[/bold]           {_fmt_secs(avg_mttf)}")

    console.print(Panel("\n".join(lines), title="SLA Metrics", border_style="cyan"))

    # Per-source breakdown
    source_total: Counter[str] = Counter()
    source_fail: Counter[str] = Counter()
    for e in events:
        source = e.source or "(unknown)"
        source_total[source] += 1
        action = (get_field(e, "action") or "").lower()
        if action in _FAIL_ACTIONS:
            source_fail[source] += 1

    if len(source_total) > 1:
        table = Table(title="Per-Source Availability", border_style="dim")
        table.add_column("Source", style="bold")
        table.add_column("Events", justify="right")
        table.add_column("Failures", justify="right")
        table.add_column("Fail %", justify="right")

        for source, total in source_total.most_common(10):
            fails = source_fail[source]
            fail_pct = fails / max(total, 1) * 100
            color = "red" if fail_pct > 10 else "yellow" if fail_pct > 5 else "green"
            table.add_row(
                source[:20], format_number(total),
                format_number(fails), f"[{color}]{fail_pct:.1f}%[/{color}]"
            )
        console.print(table)

    # Latency stats
    latency_values: list[float] = []
    for e in events:
        for field in ("duration", "latency", "rtt"):
            val = get_field(e, field)
            if val:
                try:
                    latency_values.append(float(val))
                    break
                except (ValueError, TypeError):
                    continue

    if latency_values and len(latency_values) >= 2:
        sorted_lat = sorted(latency_values)
        n = len(sorted_lat)
        table = Table(title="Latency Distribution", border_style="dim")
        table.add_column("Metric", style="bold")
        table.add_column("Value", justify="right", style="cyan")
        table.add_row("Samples", format_number(n))
        table.add_row("Min", f"{sorted_lat[0]:,.1f}")
        table.add_row("Mean", f"{statistics.mean(latency_values):,.1f}")
        table.add_row("Median", f"{statistics.median(latency_values):,.1f}")
        table.add_row("P95", f"{sorted_lat[min(int(n * 0.95), n - 1)]:,.1f}")
        table.add_row("P99", f"{sorted_lat[min(int(n * 0.99), n - 1)]:,.1f}")
        table.add_row("Max", f"{sorted_lat[-1]:,.1f}")
        console.print(table)


def _fmt_td(td: timedelta) -> str:
    total = int(td.total_seconds())
    if total < 3600:
        return f"{total // 60}m"
    if total < 86400:
        return f"{total // 3600}h {(total % 3600) // 60}m"
    return f"{total // 86400}d {(total % 86400) // 3600}h"


def _fmt_secs(secs: float) -> str:
    if secs < 60:
        return f"{secs:.0f}s"
    if secs < 3600:
        return f"{secs / 60:.1f}m"
    return f"{secs / 3600:.1f}h"
