#!/usr/bin/env python3
"""Evidence generation report — examiner-ready documentation of log review.

Produces a structured evidence document demonstrating ongoing log review,
multi-source aggregation, and security monitoring per FFIEC Information
Security Booklet §II.C.22 and NCUA Part 748 Appendix A §III.C.2.

This is the single highest-value report for ISE examination readiness.
"""

from __future__ import annotations

from collections import Counter
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.compliance_data import (
    CONTROLS, DOMAINS, evidence_status, get_domain_controls, matches_control,
)
from logparse.models import LogEvent
from logparse.util import format_number


def report_evidence(events: list[LogEvent], console: Console) -> None:
    """Generate examiner-ready evidence report."""
    now = datetime.now()

    console.rule("Log Review Evidence Report", style="bold green")
    console.print()

    # ── 1. Attestation header ─────────────────────────────────────────────
    console.print("[bold]1. Review Attestation[/bold]")
    console.print(f"   Date generated:   {now:%Y-%m-%d %H:%M:%S}")
    console.print("   Tool:             logparse")

    ts_events = [e for e in events if e.timestamp]
    t_min = min((e.timestamp for e in ts_events), default=None)
    t_max = max((e.timestamp for e in ts_events), default=None)
    if t_min is not None and t_max is not None:
        console.print(f"   Review period:    {t_min:%Y-%m-%d %H:%M} — {t_max:%Y-%m-%d %H:%M}")
    console.print(f"   Events analyzed:  {format_number(len(events))}")
    console.print()

    # ── 2. Log sources inventory ──────────────────────────────────────────
    console.print("[bold]2. Log Sources Inventory[/bold]")
    console.print("   [dim](Demonstrates multi-source aggregation per FFIEC §II.C.22)[/dim]")
    console.print()

    # Group by source file
    source_info: dict[str, dict] = {}
    for e in events:
        sf = e.source_file or e.source or "(unknown)"
        if sf not in source_info:
            source_info[sf] = {
                "format": e.source_format or "unknown",
                "count": 0,
                "min_ts": None,
                "max_ts": None,
                "severities": Counter(),
            }
        info = source_info[sf]
        info["count"] += 1
        info["severities"][e.severity] += 1
        if e.timestamp:
            if info["min_ts"] is None or e.timestamp < info["min_ts"]:
                info["min_ts"] = e.timestamp
            if info["max_ts"] is None or e.timestamp > info["max_ts"]:
                info["max_ts"] = e.timestamp

    src_table = Table(show_header=True, expand=True, border_style="dim")
    src_table.add_column("SOURCE", ratio=1)
    src_table.add_column("FORMAT", width=16)
    src_table.add_column("EVENTS", justify="right", width=10, style="cyan")
    src_table.add_column("TIME RANGE", width=38)
    src_table.add_column("CRIT/HIGH", justify="right", width=10)

    for sf, info in sorted(source_info.items(), key=lambda x: -x[1]["count"]):
        time_range = ""
        if info["min_ts"] is not None and info["max_ts"] is not None:
            time_range = (f"{info['min_ts']:%Y-%m-%d %H:%M} — "
                          f"{info['max_ts']:%Y-%m-%d %H:%M}")
        crit_high = info["severities"]["Critical"] + info["severities"]["High"]
        crit_high_str = format_number(crit_high) if crit_high else "-"

        name = sf
        if len(name) > 40:
            name = "..." + name[-37:]
        src_table.add_row(
            name, info["format"], format_number(info["count"]),
            time_range, crit_high_str,
        )

    console.print(src_table)
    console.print(f"   Total: {len(source_info)} source(s), "
                  f"{len(set(i['format'] for i in source_info.values()))} format(s)")
    console.print()

    # ── 3. FFIEC control evidence matrix ──────────────────────────────────
    console.print("[bold]3. FFIEC Control Evidence Matrix[/bold]")
    console.print()

    ctrl_counts: Counter[str] = Counter()
    for e in events:
        for ctrl_id, ctrl in CONTROLS.items():
            if matches_control(e.extra, e.message, ctrl):
                ctrl_counts[ctrl_id] += 1

    # Multi-source aggregation special handling
    formats = set(i["format"] for i in source_info.values())
    al3_id = "IS.WP.AL-3"
    if al3_id in CONTROLS:
        ctrl_counts[al3_id] = len(formats)

    matrix_table = Table(show_header=True, expand=True, border_style="dim")
    matrix_table.add_column("DOMAIN", width=12, style="bold")
    matrix_table.add_column("NAME", ratio=1)
    matrix_table.add_column("COVERAGE", width=10)
    matrix_table.add_column("STATUS", width=14)

    domains_sufficient = 0
    for domain_id, domain_name in DOMAINS.items():
        controls = get_domain_controls(domain_id)
        if not controls:
            continue
        sufficient = sum(
            1 for c in controls
            if evidence_status(ctrl_counts.get(c.control_id, 0), c) == "Sufficient"
        )
        if sufficient == len(controls):
            status = "[green]SUFFICIENT[/green]"
            domains_sufficient += 1
        elif sufficient > 0 or any(
            evidence_status(ctrl_counts.get(c.control_id, 0), c) == "Partial"
            for c in controls
        ):
            status = "[yellow]PARTIAL[/yellow]"
        else:
            status = "[red]GAP[/red]"
        matrix_table.add_row(
            domain_id, domain_name,
            f"{sufficient}/{len(controls)}", status,
        )

    console.print(matrix_table)
    coverage = (domains_sufficient / len(DOMAINS) * 100) if DOMAINS else 0
    console.print(f"   Overall: [bold]{coverage:.0f}%[/bold] domain coverage"
                  f" ({domains_sufficient}/{len(DOMAINS)})")
    console.print()

    # ── 4. Notable findings ───────────────────────────────────────────────
    console.print("[bold]4. Notable Findings[/bold]")
    console.print()

    # Anomaly findings (reuse analyzer)
    try:
        from logparse.analyzers.anomaly import run_all_detectors
        findings = run_all_detectors(events)
        if findings:
            for f in findings[:5]:
                sev_colors = {"Critical": "red", "High": "bright_red",
                              "Medium": "yellow", "Low": "green"}
                color = sev_colors.get(f.severity, "dim")
                console.print(f"   [{color}][{f.severity}][/{color}] "
                              f"{f.title} (score: {f.score:.1f})")
                console.print(f"      [dim]{f.description}[/dim]")
            if len(findings) > 5:
                console.print(f"   [dim]... and {len(findings) - 5} more findings[/dim]")
        else:
            console.print("   [dim]No anomalies detected.[/dim]")
    except ImportError:
        console.print("   [dim]Anomaly analyzer unavailable.[/dim]")
    console.print()

    # MITRE technique matches
    try:
        from logparse.mitre import scan_events
        matches = scan_events(events)
        if matches:
            console.print("   [bold]MITRE ATT&CK Detections:[/bold]")
            for m in matches[:5]:
                console.print(
                    f"   [{m.technique.technique_id}] {m.technique.name} "
                    f"({m.technique.tactic}) — {m.count} event(s), "
                    f"score {m.score:.1f}"
                )
            if len(matches) > 5:
                console.print(f"   [dim]... and {len(matches) - 5} more techniques[/dim]")
        else:
            console.print("   [dim]No MITRE ATT&CK technique matches.[/dim]")
    except ImportError:
        console.print("   [dim]MITRE scanner unavailable.[/dim]")
    console.print()

    # ── 5. Log retention assessment ───────────────────────────────────────
    console.print("[bold]5. Log Retention Assessment[/bold]")

    if t_min is not None and t_max is not None:
        span = t_max - t_min
        days = span.days
        if days >= 90:
            console.print(f"   Retention span: [green]{days} days[/green]"
                          f" — meets FFIEC 90-day minimum")
        elif days >= 30:
            console.print(f"   Retention span: [yellow]{days} days[/yellow]"
                          f" — below 90-day recommendation")
        else:
            console.print(f"   Retention span: [red]{days} days[/red]"
                          f" — significantly below recommendation")
    else:
        console.print("   [dim]No timestamped events available.[/dim]")
    console.print()

    # ── 6. Audit trail integrity ──────────────────────────────────────────
    console.print("[bold]6. Audit Trail Integrity[/bold]")

    log_clears = sum(1 for e in events if e.extra.get("EventID") == "1102")
    policy_changes = sum(1 for e in events if e.extra.get("EventID") == "4719")

    if log_clears > 0:
        console.print(f"   [red]ALERT: {log_clears} audit log clear(s) (EID 1102)[/red]")
    else:
        console.print("   [green]No log clearing events detected (EID 1102)[/green]")

    if policy_changes > 0:
        console.print(f"   [yellow]{policy_changes} audit policy change(s) (EID 4719)[/yellow]")
    else:
        console.print("   [green]No audit policy changes (EID 4719)[/green]")
    console.print()

    # ── Signature block ───────────────────────────────────────────────────
    console.rule("Review Certification", style="dim")
    console.print("   This report documents automated log review of the above sources.")
    console.print("   Evidence demonstrates ongoing monitoring per FFIEC Information Security")
    console.print("   Booklet §II.C.22 and NCUA Part 748 Appendix A §III.C.2.")
    console.print()
    console.print("   Reviewed by: ___________________________  Date: ______________")
    console.print()
