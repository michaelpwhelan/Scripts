#!/usr/bin/env python3
"""Incident report — timeline, assets, MITRE mapping, IOCs."""

from __future__ import annotations

from collections import Counter
from datetime import datetime

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_IP_FIELDS = {"srcip", "dstip", "src", "dst", "ipaddr", "clientip", "remip"}
_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser", "account"}


def report_incident(events: list[LogEvent], console: Console) -> None:
    """Generate an incident analysis report."""
    if not events:
        console.print("[dim]No events.[/dim]")
        return

    # -- gather data upfront --------------------------------------------------
    severity_counts: Counter[str] = Counter(e.severity for e in events)
    critical_high = severity_counts.get("Critical", 0) + severity_counts.get("High", 0)
    sources = set(e.source for e in events if e.source)

    timestamps = sorted(e.timestamp for e in events if e.timestamp)
    time_range = ""
    if len(timestamps) >= 2:
        time_range = (f"{timestamps[0].strftime('%Y-%m-%d %H:%M')} — "
                      f"{timestamps[-1].strftime('%Y-%m-%d %H:%M')}")
    elif timestamps:
        time_range = timestamps[0].strftime("%Y-%m-%d %H:%M")

    all_ips: set[str] = set()
    all_users: set[str] = set()
    all_hosts: set[str] = set()
    for e in events:
        for field in _IP_FIELDS:
            val = get_field(e, field)
            if val:
                all_ips.add(val)
        for field in _USER_FIELDS:
            val = get_field(e, field)
            if val and len(val) > 1:
                all_users.add(val)
        hostname = get_field(e, "hostname") or get_field(e, "devname") or ""
        if hostname:
            all_hosts.add(hostname)

    # -- header ---------------------------------------------------------------
    console.rule(
        f"Incident: {format_number(len(events))} events, "
        f"{format_number(critical_high)} critical/high",
        style="bold red",
    )
    if time_range:
        console.print(f"  {time_range}  |  {format_number(len(sources))} sources")
    asset_parts = []
    if all_ips:
        asset_parts.append(f"{format_number(len(all_ips))} IPs")
    if all_users:
        asset_parts.append(f"{format_number(len(all_users))} users")
    if all_hosts:
        asset_parts.append(f"{format_number(len(all_hosts))} hosts")
    if asset_parts:
        console.print(f"  {', '.join(asset_parts)} involved")
    console.print()

    # -- critical/high timeline -----------------------------------------------
    high_sev = [e for e in events if e.severity in ("Critical", "High")]
    high_sev.sort(key=lambda e: e.timestamp if e.timestamp else datetime.max)

    if high_sev:
        table = Table(
            title=f"{len(high_sev)} critical/high events",
            border_style="dim", show_lines=True,
        )
        table.add_column("Time", style="dim", width=19)
        table.add_column("Sev", width=8)
        table.add_column("Source", width=15)
        table.add_column("Event", ratio=1)

        sev_colors = {"Critical": "red", "High": "bright_red"}
        for e in high_sev[:30]:
            ts = e.timestamp.strftime("%Y-%m-%d %H:%M:%S") if e.timestamp else ""
            color = sev_colors.get(e.severity, "dim")
            msg = e.message[:80] + "..." if len(e.message) > 80 else e.message
            table.add_row(ts, f"[{color}]{e.severity}[/{color}]", (e.source or "")[:15], msg)
        console.print(table)
        if len(high_sev) > 30:
            console.print(f"  [dim]... and {len(high_sev) - 30} more[/dim]")
        console.print()

    # -- MITRE ATT&CK --------------------------------------------------------
    try:
        from logparse.mitre import scan_events, detect_kill_chains
        mitre_matches = scan_events(events)
        if mitre_matches:
            table = Table(title="MITRE ATT&CK", border_style="dim")
            table.add_column("Technique", style="bold")
            table.add_column("Tactic")
            table.add_column("Matches", justify="right", style="cyan")

            for m in sorted(mitre_matches, key=lambda x: x.count, reverse=True)[:15]:
                table.add_row(
                    f"{m.technique.technique_id} {m.technique.name}",
                    m.technique.tactic,
                    format_number(m.count),
                )
            console.print(table)

            chains = detect_kill_chains(mitre_matches)
            for chain, chain_matches in chains:
                stages = " -> ".join(m.technique.technique_id for m in chain_matches)
                console.print(f"  [bold red]{chain.name}:[/bold red] {stages}")
            console.print()
    except ImportError:
        pass

    # -- IOCs (external IPs with threat classification) -----------------------
    try:
        from logparse.threat_intel import classify_ip
        external_ips = [ip for ip in all_ips if not _is_private(ip)]
        if external_ips:
            iocs: list[tuple[str, str, str]] = []
            for ip in external_ips:
                info = classify_ip(ip)
                if info["category"] in ("tor", "scanner"):
                    iocs.append((ip, info["category"], info["provider"]))

            if iocs:
                table = Table(title=f"{len(iocs)} IOCs", border_style="red")
                table.add_column("IP", style="bold red")
                table.add_column("Category")
                table.add_column("Provider")
                for ip, cat, provider in iocs[:20]:
                    table.add_row(ip, cat, provider)
                console.print(table)
                console.print()
    except ImportError:
        pass

    console.rule(style="dim")


def _is_private(ip: str) -> bool:
    import ipaddress
    try:
        return ipaddress.ip_address(ip).is_private
    except ValueError:
        return False
