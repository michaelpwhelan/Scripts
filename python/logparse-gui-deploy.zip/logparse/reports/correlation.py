#!/usr/bin/env python3
"""Correlation report — entity relationships across log sources."""

from __future__ import annotations

from collections import Counter, defaultdict

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent, get_field
from logparse.util import format_number

_IP_FIELDS = {"srcip", "dstip", "src", "dst", "ipaddr", "clientip"}
_USER_FIELDS = {"user", "username", "targetusername", "subjectusername",
                "srcuser", "dstuser"}


def report_correlation(events: list[LogEvent], console: Console) -> None:
    """Generate cross-source entity correlation report."""
    if not events:
        console.print("[dim]No events for correlation report.[/dim]")
        return

    console.rule("Entity Correlation Report", style="bold cyan")

    # Map entities to sources
    ip_sources: defaultdict[str, set[str]] = defaultdict(set)
    ip_events: defaultdict[str, int] = defaultdict(int)
    user_sources: defaultdict[str, set[str]] = defaultdict(set)
    user_events: defaultdict[str, int] = defaultdict(int)

    source_event_counts: Counter[str] = Counter()

    for e in events:
        source = e.source_file or e.source or "unknown"
        source_event_counts[source] += 1

        for field in _IP_FIELDS:
            val = get_field(e, field)
            if val:
                ip_sources[val].add(source)
                ip_events[val] += 1

        for field in _USER_FIELDS:
            val = get_field(e, field)
            if val and len(val) > 1:
                key = val.lower()
                user_sources[key].add(source)
                user_events[key] += 1

    # Source overview
    console.print(f"\n  Sources: {len(source_event_counts)}")
    for src, count in source_event_counts.most_common():
        from pathlib import Path
        console.print(f"    {Path(src).name}: {format_number(count)} events")

    # Cross-source IPs
    multi_ips = {ip: srcs for ip, srcs in ip_sources.items() if len(srcs) >= 2}
    if multi_ips:
        sorted_ips = sorted(multi_ips.items(), key=lambda x: len(x[1]), reverse=True)
        table = Table(title=f"Cross-Source IPs ({len(sorted_ips)})", border_style="dim")
        table.add_column("IP", style="bold")
        table.add_column("Sources", justify="right", style="cyan")
        table.add_column("Events", justify="right")
        table.add_column("Seen In")

        for ip, sources in sorted_ips[:25]:
            from pathlib import Path
            names = ", ".join(Path(s).name for s in sorted(sources))
            if len(names) > 50:
                names = names[:47] + "..."
            table.add_row(ip, str(len(sources)), format_number(ip_events[ip]), names)
        console.print(table)
    else:
        console.print("\n[dim]No IPs found across multiple sources.[/dim]")

    # Cross-source users
    multi_users = {u: srcs for u, srcs in user_sources.items() if len(srcs) >= 2}
    if multi_users:
        sorted_users = sorted(multi_users.items(), key=lambda x: len(x[1]), reverse=True)
        table = Table(title=f"Cross-Source Users ({len(sorted_users)})", border_style="dim")
        table.add_column("User", style="bold")
        table.add_column("Sources", justify="right", style="cyan")
        table.add_column("Events", justify="right")
        table.add_column("Seen In")

        for user, sources in sorted_users[:25]:
            from pathlib import Path
            names = ", ".join(Path(s).name for s in sorted(sources))
            if len(names) > 50:
                names = names[:47] + "..."
            table.add_row(user, str(len(sources)), format_number(user_events[user]), names)
        console.print(table)
    else:
        console.print("\n[dim]No users found across multiple sources.[/dim]")

    # Summary
    console.print(f"\n  [dim]Cross-source IPs: {len(multi_ips)} | "
                  f"Cross-source users: {len(multi_users)} | "
                  f"Total entities: {format_number(len(ip_sources) + len(user_sources))}[/dim]")
