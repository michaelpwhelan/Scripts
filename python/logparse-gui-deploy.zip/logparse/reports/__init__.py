#!/usr/bin/env python3
"""Report generators."""

from __future__ import annotations

from logparse.reports.summary import report_summary
from logparse.reports.morning import report_morning
from logparse.reports.audit import report_audit
from logparse.reports.compliance import report_compliance
from logparse.reports.timeline_report import report_timeline
from logparse.reports.security import report_security
from logparse.reports.traffic import report_traffic
from logparse.reports.incident import report_incident
from logparse.reports.correlation import report_correlation
from logparse.reports.sla import report_sla
from logparse.reports.evidence import report_evidence

REPORTS = {
    "summary": report_summary,
    "morning": report_morning,
    "audit": report_audit,
    "compliance": report_compliance,
    "evidence": report_evidence,
    "timeline": report_timeline,
    "security": report_security,
    "traffic": report_traffic,
    "incident": report_incident,
    "correlation": report_correlation,
    "sla": report_sla,
}
