#!/usr/bin/env python3
"""Timeline report — chronological event listing."""

from __future__ import annotations

from rich.console import Console
from rich.table import Table

from logparse.models import LogEvent
from logparse.util import format_number


def report_timeline(events: list[LogEvent], console: Console) -> None:
    """Generate chronological timeline report."""
    console.rule("Timeline Report", style="bold cyan")

    ts_events = [e for e in events if e.timestamp]
    ts_events.sort(key=lambda e: e.timestamp)

    console.print(f"  Events with timestamps: {format_number(len(ts_events))}")
    if ts_events:
        console.print(
            f"  Range: {ts_events[0].timestamp:%Y-%m-%d %H:%M:%S} — "
            f"{ts_events[-1].timestamp:%Y-%m-%d %H:%M:%S}"
        )
    console.print()

    if not ts_events:
        console.print("[dim]No timestamped events to display.[/dim]")
        return

    sev_style = {
        "Critical": "bold red",
        "High": "red",
        "Medium": "yellow",
        "Low": "cyan",
        "Info": "dim",
    }

    table = Table(show_header=True, expand=True, highlight=False)
    table.add_column("TIME", width=19, no_wrap=True)
    table.add_column("SEV", width=8, no_wrap=True)
    table.add_column("SOURCE", max_width=20, no_wrap=True, overflow="ellipsis")
    table.add_column("MESSAGE", ratio=3, no_wrap=True, overflow="ellipsis")

    # show up to 100 events, prioritizing severity
    display = ts_events
    if len(display) > 100:
        # show first 30, last 30, and 40 highest severity in between
        head = display[:30]
        tail = display[-30:]
        middle_pool = display[30:len(display) - 30]
        if middle_pool:
            middle = sorted(
                middle_pool,
                key=lambda e: {"Critical": 0, "High": 1, "Medium": 2, "Low": 3, "Info": 4}.get(e.severity, 5),
            )[:40]
            middle.sort(key=lambda e: e.timestamp)
        else:
            middle = []
        display = head + middle + tail
        console.print(f"  [dim]Showing {len(display)} of {format_number(len(ts_events))} events[/dim]")
        console.print()

    for e in display:
        style = sev_style.get(e.severity, "")
        table.add_row(
            e.timestamp.strftime("%Y-%m-%d %H:%M:%S"),
            f"[{style}]{e.severity}[/{style}]",
            e.source,
            e.message.replace("\n", " ")[:200],
        )

    console.print(table)
