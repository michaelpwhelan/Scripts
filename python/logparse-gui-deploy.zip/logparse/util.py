#!/usr/bin/env python3
"""Shared utilities."""

from __future__ import annotations

import re
from datetime import date, timedelta

_DURATION_RE = re.compile(r"^(\d+)\s*(s|sec|m|min|h|hr|d|day)s?$", re.IGNORECASE)
_LAST_RE = re.compile(
    r"^last\s+(\d+)\s*(s|sec|m|min|h|hr|d|day)s?$", re.IGNORECASE
)

_UNITS: dict[str, str] = {
    "s": "s", "sec": "s",
    "m": "m", "min": "m",
    "h": "h", "hr": "h",
    "d": "d", "day": "d",
}


def parse_duration(text: str) -> timedelta | None:
    """Parse ``30s``, ``5m``, ``2h``, ``1d``, ``last 24hr`` into a timedelta."""
    text = text.strip()
    m = _LAST_RE.match(text) or _DURATION_RE.match(text)
    if not m:
        return None
    value = int(m.group(1))
    unit = _UNITS.get(m.group(2).lower())
    if not unit:
        return None
    match unit:
        case "s":
            return timedelta(seconds=value)
        case "m":
            return timedelta(minutes=value)
        case "h":
            return timedelta(hours=value)
        case "d":
            return timedelta(days=value)
    return None


_DAY_NAMES = {
    "monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3,
    "friday": 4, "saturday": 5, "sunday": 6,
    "mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6,
}


def parse_date_expr(text: str) -> date | None:
    """Parse natural date expressions into a date.

    Supports: ``today``, ``yesterday``, ``last tuesday``,
    ``MM-DD``, ``YYYY-MM-DD``, ``03-19``.
    """
    text = text.strip().lower()
    today = date.today()

    if text == "today":
        return today
    if text == "yesterday":
        return today - timedelta(days=1)

    # "last <weekday>"
    m = re.match(r"^last\s+(\w+)$", text)
    if m:
        day_name = m.group(1)
        target = _DAY_NAMES.get(day_name)
        if target is not None:
            days_back = (today.weekday() - target) % 7
            if days_back == 0:
                days_back = 7
            return today - timedelta(days=days_back)

    # YYYY-MM-DD
    m = re.match(r"^(\d{4})-(\d{1,2})-(\d{1,2})$", text)
    if m:
        try:
            return date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except ValueError:
            return None

    # MM-DD (assume current year)
    m = re.match(r"^(\d{1,2})-(\d{1,2})$", text)
    if m:
        try:
            return date(today.year, int(m.group(1)), int(m.group(2)))
        except ValueError:
            return None

    return None


def format_number(n: int) -> str:
    """Comma-separated number formatting."""
    return f"{n:,}"


def truncate(text: str, width: int) -> str:
    """Truncate with ellipsis if text exceeds width."""
    if not text:
        return ""
    if len(text) <= width:
        return text
    return text[: width - 1] + "\u2026"


def compact_table(**overrides):
    """Create a compact Rich Table — the standard REPL style.

    Defaults: ``show_header=True, box=None, pad_edge=False``.
    Pass keyword args to override any parameter.
    """
    from rich.table import Table

    defaults: dict = {"show_header": True, "box": None, "pad_edge": False}
    defaults.update(overrides)
    return Table(**defaults)


class InternPool:
    """Bounded string interning pool for low-cardinality field values.

    Interns strings via ``sys.intern()`` up to *max_cardinality* unique values.
    After that, returns strings un-interned to avoid unbounded memory use.
    """

    __slots__ = ("_seen", "_max")

    def __init__(self, max_cardinality: int = 10_000) -> None:
        self._seen: set[str] = set()
        self._max = max_cardinality

    def maybe_intern(self, s: str) -> str:
        """Intern string if pool has not reached max cardinality."""
        import sys

        if len(self._seen) < self._max:
            s = sys.intern(s)
            self._seen.add(s)
        return s
