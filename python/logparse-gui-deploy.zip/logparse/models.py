#!/usr/bin/env python3
"""Core event model and field helpers."""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass, field
from datetime import datetime

from logparse.severity import (  # re-exported for backward compatibility
    SEVERITY_LEVELS as SEVERITY_LEVELS,
    SEV_ORDER as SEV_ORDER,
    severity_from_forti_level as severity_from_forti_level,
    severity_from_text as severity_from_text,
)


@dataclass
class LogEvent:
    """Single parsed log event."""

    timestamp: datetime | None = None
    severity: str = "Low"
    source: str = ""
    message: str = ""
    extra: dict[str, str] = field(default_factory=dict)
    raw: str = ""
    source_file: str = ""
    source_format: str = ""
    line_number: int = -1


# -- timestamp helpers -------------------------------------------------------


def timestamp_range(
    events: Iterable[LogEvent],
) -> tuple[datetime | None, datetime | None]:
    """Return (first_seen, last_seen) from events with timestamps."""
    first: datetime | None = None
    last: datetime | None = None
    for e in events:
        ts = e.timestamp
        if ts is None:
            continue
        if first is None or ts < first:
            first = ts
        if last is None or ts > last:
            last = ts
    return first, last


# -- field access ------------------------------------------------------------

_FIELD_ALIASES = {
    "sev": "severity", "msg": "message", "src": "source",
    "ts": "timestamp", "dst": "dstip", "pol": "policyid",
    "protocol": "proto", "act": "action", "dev": "devname",
    "cat": "catdesc", "svc": "service",
}


def resolve_field_alias(field_name: str) -> str:
    """Resolve short field aliases to canonical names."""
    return _FIELD_ALIASES.get(field_name.lower(), field_name)


_CORE_FIELDS = {
    "severity": "severity",
    "source": "source",
    "message": "message",
    "sourcefile": "source_file",
    "sourceformat": "source_format",
}


def get_field(event: LogEvent, field_name: str) -> str | None:
    """Case-insensitive field lookup across core attrs and extra dict."""
    original = field_name
    field_name = resolve_field_alias(field_name)
    fl = field_name.lower()

    if fl == "timestamp":
        if event.timestamp is not None:
            return event.timestamp.strftime("%Y-%m-%d %H:%M:%S")
        return None

    attr = _CORE_FIELDS.get(fl)
    if attr is not None:
        val = getattr(event, attr)
        return val if val else None

    # exact key match in extra (try resolved name first, then original)
    val = event.extra.get(field_name)
    if val is not None:
        return val
    if original != field_name:
        val = event.extra.get(original)
        if val is not None:
            return val

    # case-insensitive fallback (match against both resolved and original)
    ol = original.lower()
    for k, v in event.extra.items():
        kl = k.lower()
        if kl == fl or kl == ol:
            return v

    return None
