# logparse GUI - Windows Server 2022 Deployment

## Quick Install

1. Install Python 3.10+ from python.org (check Add to PATH)
2. Extract this zip to C:\logparse\
3. Open PowerShell as Administrator:

   cd C:\logparse
   pip install -e ".[gui,evtx,windows]"

4. Launch: logparse --gui
5. With HTTPS: logparse --gui --tls
6. As service: logparse --install-service
