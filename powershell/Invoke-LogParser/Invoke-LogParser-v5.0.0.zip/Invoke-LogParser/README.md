# Invoke-LogParser v5.0

Operational intelligence platform for sysadmins. Parses, correlates, and investigates log files across 32 formats from Fortinet, Microsoft, Veeam, Zabbix, and more. Dual-mode architecture: full WinForms GUI on Windows with GDI+ dashboard visualizations, plus color-coded console mode for Linux/macOS/pwsh.

## Quick Start

```powershell
# GUI mode (Windows) — just launch it
.\Invoke-LogParser.ps1

# Open a file directly
.\Invoke-LogParser.ps1 -FilePath "C:\Logs\firewall.log"

# Console mode (any platform)
pwsh -File ./Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log -Level ERROR

# SQL query language
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log -Query 'action:deny srcip:10.* | count by dstport | top 20'

# Multi-source correlation
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log,./security.evtx,./nps.xml -Aggregate correlation

# Morning briefing report
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log,./backup.log -MorningBriefing ./briefing.html

# Anomaly detection against baseline
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log -BaselineBuild "weekday-normal"
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log -BaselineCompare "weekday-normal"

# Automated triage
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./fw.log,./security.evtx -TriageReport ./triage.html
```

## Prerequisites

- **PowerShell 5.1+** (Windows PowerShell or pwsh 7+)
- **GUI mode** requires Windows with .NET WinForms
- **Console mode** works on any platform
- **No external modules required** — pure PowerShell + .NET

## Supported Formats (32)

### Fortinet
| ID | Format | Extensions |
|---|---|---|
| `fortigate-kv` | Fortinet Key=Value (FortiGate/FortiClient EMS/FortiAP syslog) | `.log` |
| `fortigate-conf` | FortiGate Configuration File | `.conf` |
| `fortigate-ipsec` | FortiGate IPsec VPN Log (phase negotiation, DPD, tunnel state) | `.log` |
| `fortigate-bgp` | FortiGate BGP Routing Log (neighbor state, route changes) | `.log` |
| `fortigate-ha` | FortiGate HA Cluster Log (failover, heartbeat, sync) | `.log` |
| `forticlient-local` | FortiClient Local Log | `.log`, `.txt` |
| `fortimanager-audit` | FortiManager Audit Log (admin actions, policy pushes) | `.log` |
| `fortianalyzer-event` | FortiAnalyzer Event Log | `.log` |
| `fortiswitch-event` | FortiSwitch Event Log (port, STP, PoE, 802.1X, MAC) | `.log` |

### Microsoft
| ID | Format | Extensions |
|---|---|---|
| `windows-evtx` | Windows Event Log | `.evtx` |
| `defender-alerts` | Microsoft Defender for Endpoint Alerts | `.json`, `.csv` |
| `defender-vulnerability` | Defender Vulnerability Assessment | `.json`, `.csv` |
| `entra-signin` | Entra ID Sign-In Logs | `.json` |
| `entra-audit` | Entra ID Audit Logs | `.json` |
| `intune-compliance` | Intune Device Compliance | `.json`, `.csv` |
| `hyperv-event` | Hyper-V Event Log | `.evtx` |
| `certificate-event` | Certificate Lifecycle Events | `.evtx`, `.csv`, `.json` |
| `nps-radius` | NPS/RADIUS DTS XML | `.xml`, `.log` |
| `dhcp-server` | Windows DHCP Server Log | `.log` |
| `dns-debug` | Windows DNS Debug Log | `.log`, `.txt` |

### Infrastructure
| ID | Format | Extensions |
|---|---|---|
| `veeam-job` | Veeam Backup Job Log | `.log` |
| `veeam-session` | Veeam Session Detail | `.csv`, `.json` |
| `zabbix-export` | Zabbix Event/Problem Export | `.csv`, `.json` |

### Web & Syslog
| ID | Format | Extensions |
|---|---|---|
| `iis-w3c` | IIS / W3C Extended Log | `.log` |
| `apache-combined` | Apache / Nginx Combined Log Format | `.log`, `.access` |
| `syslog-rfc3164` | Syslog RFC 3164 | `.log`, `.syslog` |
| `syslog-rfc5424` | Syslog RFC 5424 | `.log`, `.syslog` |

### Generic
| ID | Format | Extensions |
|---|---|---|
| `csv-auto` | CSV with Headers (auto-mapped columns) | `.csv` |
| `json-ndjson` | JSON / NDJSON (JSON Lines) | `.json`, `.jsonl`, `.ndjson` |
| `powershell-transcript` | PowerShell Transcript | `.txt`, `.log` |
| `generic-regex` | User-Defined Regex (named capture groups) | any |
| `plaintext` | Plain Text (fallback) | any |

Compressed files (`.gz`, `.zip`) are automatically decompressed.

## SQL Query Language

The built-in Simple Query Language (SQL) provides fast, expressive searching:

```
# Field matching
action:deny                          # exact match
srcip:10.12.*                        # wildcard
user:"john smith"                    # quoted phrase
dstport:>1024                        # numeric comparison

# Logical operators
action:deny AND srcip:10.12.*       # both (default)
severity:high OR severity:critical  # either
NOT source:fortigate                # negation
(user:admin OR user:root) AND action:deny

# Virtual fields (work across all parser types)
user:jsmith       # maps to user/User-Name/TargetUserName/UserPrincipalName
srcip:10.0.1.*    # maps to srcip/IpAddress/SourceAddress
severity:high     # maps CRITICAL+ERROR
time:last24h      # relative time filter
device:FG-009     # maps to devname/DeviceName/MachineName

# Aggregation pipeline
source:fortigate action:deny | count by dstport | sort count desc | head 20
severity:critical | timeline 1h
user:* | count by user | top 10
srcip:10.* | stats count EventID
```

### Pipeline Stages
| Stage | Description |
|---|---|
| `count` | Count matching events |
| `count by <field>` | Group and count by field |
| `top N <field>` | Top N values of field |
| `stats <func> <field>` | Aggregate: sum, avg, min, max, count |
| `timeline <interval>` | Bucket by time: 1m, 5m, 1h, 1d |
| `table <f1>,<f2>,...` | Tabular output with selected fields |
| `sort <field> asc/desc` | Sort results |
| `head N` / `tail N` | First/last N results |

## Analysis Engines (14)

| Engine | Description |
|---|---|
| Failed Login Aggregator | Cross-source failed auth aggregation (AD, NPS, FortiGate) |
| VPN Session Analyzer | Session tracking with impossible travel detection |
| Correlation Engine | Cross-source event correlation with configurable rules |
| BGP Route Analyzer | Neighbor stability, flap detection, route change tracking |
| IPsec Tunnel Analyzer | Per-tunnel health, negotiation failures, DPD patterns |
| NPS Session Analyzer | Per-NAS summaries, auth latency, failure categorization |
| Certificate Expiry Tracker | Cert inventory by urgency (expired, 30d, 90d) |
| Change Audit Analyzer | Cross-platform change timeline (AD, FortiManager, Entra) |
| Threat Correlator | Cross-source threat indicators with weighted scoring |
| Compliance Analyzer | FFIEC/NCUA control mapping with evidence assessment |
| IOC Matcher | Indicator of Compromise matching (IP, hash, domain) |
| Investigation Templates | Pre-built analysis templates (22 templates) |
| Anomaly Detector | Behavioral baseline comparison with z-score deviation |
| Automated Triage | Rule-based triage with 10 pre-built workflows |

## Live Data Connectors (7)

Pull data directly from operational systems — no manual log export required:

| Connector | System | Auth Method |
|---|---|---|
| `WindowsEventLog` | Remote Windows Event Logs via WinRM | Kerberos/NTLM |
| `FortiAnalyzerApi` | FortiAnalyzer JSON-RPC API | Token-based |
| `ZabbixApi` | Zabbix JSON-RPC API | Token-based |
| `DefenderApi` | Microsoft 365 Defender API (Graph) | OAuth2 client credentials |
| `SnipeItApi` | Snipe-IT Asset Management REST API | API token |
| `OsTicketApi` | osTicket REST API (read + create tickets) | API key |

Credentials stored securely via Windows Credential Manager. All connectors include retry logic and graceful failure handling.

## Behavioral Baselines & Anomaly Detection

Learn "normal" from historical data and surface deviations:

```powershell
# Build a baseline from known-good data
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./week-of-logs/ -Recurse -BaselineBuild "normal-weekday"

# Compare new data against baseline
.\Invoke-LogParser.ps1 -ConsoleMode -FilePath ./today.log -BaselineCompare "normal-weekday"
```

Detection methods:
- **Volume** — z-score deviation in event rates per hour/day/minute
- **Distribution** — shifts in severity, source, or field value distributions
- **Temporal** — activity in normally-quiet hours
- **Relational** — new user+IP associations
- **New patterns** — field values never seen in baseline

Severity thresholds: >4 sigma = Critical, >3 sigma = High, >2 sigma = Medium, >1 sigma = Low

## Network Topology Awareness

Define your network in `data/topology.json` to enable:

- **Traffic path resolution** — "site 012 to site 001 routes via hub 009"
- **Impact propagation** — hub failure automatically flags all downstream spokes
- **Site-scoped analysis** — "show me everything at site 012 across all sources"
- **Topology-aware correlation** — tunnel flap at 009 checks all connected spokes
- **Site health dashboard** — per-site health scoring organized by role

## Automated Triage

10 pre-built triage rules that automatically detect, gather, and assess:

| Rule | Trigger | Severity |
|---|---|---|
| Multiple Failed Admin Logins | >5 admin auth failures in 15 min | HIGH |
| Lateral Movement | Logon + remote access to new target | CRITICAL |
| Tunnel Instability | >10 tunnel flaps in 1 hour | HIGH |
| Backup Failure Chain | Veeam failure + infrastructure events | HIGH |
| Certificate Expiring | Cert <30 days on critical asset | MEDIUM-HIGH |
| BGP Route Anomaly | Unexpected neighbor/route change | HIGH |
| NPS Degradation | >50 NPS rejections in 30 min | HIGH |
| Defender Critical Alert | Critical Defender alert | CRITICAL |
| Config Change Outside Window | Policy push outside maintenance | MEDIUM |
| Multiple AV Detections | >3 AV events across endpoints in 1h | HIGH |

Triage results include contributing events, affected entities, asset context, and recommended investigation steps.

## Reports (7)

| Report | Description |
|---|---|
| Audit Report | FFIEC/NCUA compliance audit evidence |
| Morning Briefing | Daily ops summary: tunnels, backups, logins, certs, alerts, site health |
| Site Health | Per-device severity breakdown, tunnel health, auth health |
| Incident Timeline | Chronological cross-source timeline with MITRE annotations |
| FFIEC Compliance | Per-control FFIEC evidence assessment with coverage scoring |
| Vulnerability | CVE severity distribution, affected systems, remediation priorities |
| Statistical Summary | Severity breakdown, hourly/daily heatmaps, burst detection |

## GUI Dashboard

GDI+ rendered widgets in a scrollable dashboard panel:

- **Timeline chart** — horizontal event timeline with severity coloring and density shading
- **Severity donut** — proportional ring chart of event distribution
- **Top-N bar chart** — horizontal bars for sources, destinations, users
- **Activity heatmap** — 24x7 hour-of-day by day-of-week heat grid
- **Sparkline** — compact event volume trend line
- **Site map** — topology diagram with health-colored nodes and tunnel lines
- **Anomaly indicator** — traffic light showing baseline deviation status

## Enrichment Data

- **Windows Event IDs** — 140+ annotated IDs (security, AD, NPS, Hyper-V, DHCP, Defender, Entra, certificate services)
- **MITRE ATT&CK** — 58+ event-to-technique mappings (Windows + FortiGate)
- **NPS/RADIUS reason codes** — 50+ translations
- **FortiGate mappings** — type/subtype descriptions, logid ranges, action mapping
- **FortiManager actions** — 24 admin action descriptions
- **IPsec error codes** — IKEv2 notification types (RFC 7296) + FortiGate errors
- **BGP state codes** — FSM states + RFC 4271 notification codes/subcodes
- **Veeam error codes** — 25 error/warning codes with KB references
- **FortiSwitch events** — port, STP, PoE, MAC, LLDP event descriptions
- **Certificate events** — AD CS event IDs + CAPI2 events
- **Hyper-V events** — VMMS, replication, storage, integration services
- **FFIEC control map** — 10 control domains mapped to detectable event patterns
- **Asset criticality** — type/role/site-based scoring rules

## Performance

- **Virtual-mode DataGridView** — 500K+ entries without memory issues
- **Background runspace parsing** — large files parsed in separate thread
- **Compiled regex caching** — filter regex compiled once, reused
- **On-parse indexing** — field indexes for O(log n) time range queries
- **Parse caching** — SHA256-keyed cache with LRU eviction for instant re-opens
- **Streaming parsers** — line-by-line processing for memory efficiency

## Console Parameters

| Parameter | Description |
|---|---|
| `-FilePath <path>` | Log file(s) or directory path |
| `-ConsoleMode` | Force console output |
| `-Theme <name>` | Dark, Light, HighContrast, SolarizedDark, Nord, Monokai |
| `-Filter <text>` | Case-insensitive text filter |
| `-FilterRegex <regex>` | Regex filter |
| `-Level <level>` | ALL, CRITICAL, ERROR, WARNING, INFO, DEBUG, TRACE |
| `-Source <text>` | Source filter |
| `-Format <id>` | Force parser format |
| `-Head N` / `-Tail N` | Limit output |
| `-OutputObject` | Emit PSCustomObject to pipeline |
| `-ExportCsv <path>` | Export to CSV |
| `-ExportHtml <path>` | Export to HTML |
| `-ExportJson <path>` | Export to JSON |
| `-Template <name>` | Apply investigation template |
| `-IocFile <path>` | IOC list for matching |
| `-Stats` | Show statistical summary |
| `-Aggregate <type>` | FailedLogins, VpnSessions, BgpRoutes, IpsecTunnels, NpsSessions, CertExpiry, ChangeAudit, Threats, Correlation, Compliance, Anomaly, Triage |
| `-AuditReport <path>` | FFIEC/NCUA audit report |
| `-MorningBriefing <path>` | Daily ops briefing |
| `-SiteHealthReport <path>` | Site health report |
| `-IncidentTimeline <path>` | Incident timeline |
| `-FfiecReport <path>` | FFIEC compliance report |
| `-VulnerabilityReport <path>` | Vulnerability report |
| `-TriageReport <path>` | Automated triage report |
| `-Query <sql>` | Execute SQL query |
| `-BaselineBuild <name>` | Build behavioral baseline |
| `-BaselineCompare <name>` | Compare against baseline |
| `-DateFrom` / `-DateTo` | Date range filter |
| `-Recurse` | Recurse into directories |

## Keyboard Shortcuts (GUI)

| Shortcut | Action |
|---|---|
| `Ctrl+O` | Open file |
| `Ctrl+R` / `F5` | Reload |
| `Ctrl+F` / `/` | Focus search |
| `Ctrl+B` | Toggle bookmark |
| `Ctrl+D` | Cycle theme |
| `Ctrl+E` | Export CSV |
| `Ctrl+Shift+E` | Export HTML |
| `Ctrl+G` | Go to line |
| `Ctrl+T` | Toggle tail mode |
| `Ctrl+Up/Down` | Navigate bookmarks |
| `Ctrl+C` | Copy selected rows |
| `Ctrl+Shift+S` | Save filter profile |
| `Ctrl+Plus/Minus` | Adjust font size |
| `Home/End` | Jump to first/last entry |
| `Escape` | Clear search |

## Testing

```powershell
# Run all tests
pwsh -File tests/TestRunner.ps1 -Category all

# Run parser tests only
pwsh -File tests/TestRunner.ps1 -Category parsers

# Run specific test
pwsh -File tests/TestRunner.ps1 -Category queries -Filter "Lexer"

# Categories: parsers, analysis, queries, engines, integration
```

48 test files with 15 synthetic log samples covering all parsers, analysis engines, query language, and integration scenarios.

## Architecture

```
Invoke-LogParser/
├── Invoke-LogParser.ps1        # Entry point (params, module loading, main flow)
├── lib/                        # Core engine modules (22)
│   ├── ParserEngine.ps1        #   Parser registration, auto-detect, background parse
│   ├── FilterEngine.ps1        #   GUI filtering with regex caching
│   ├── QueryLanguage.ps1       #   SQL lexer/parser/evaluator/aggregation
│   ├── BaselineEngine.ps1      #   Behavioral baseline learning and comparison
│   ├── TopologyEngine.ps1      #   Network topology awareness
│   ├── AssetEngine.ps1         #   Asset enrichment and criticality scoring
│   ├── DiffEngine.ps1          #   Dataset and config comparison
│   ├── TriageEngine.ps1        #   Automated triage workflows
│   ├── IndexEngine.ps1         #   On-parse field indexing
│   ├── CacheManager.ps1        #   Parsed data caching with LRU eviction
│   └── ...                     #   Export, State, Config, Helpers, etc.
├── parsers/                    # Log format parsers (32)
├── enrichment/                 # Enrichment data modules (12)
├── analysis/                   # Analysis engines (14)
├── reports/                    # Report generators (7)
├── connectors/                 # Live data connectors (7)
├── gui/                        # WinForms GUI + GDI+ widgets (5)
├── console/                    # Console mode (1)
├── data/                       # JSON config/rules/mappings (7)
└── tests/                      # Test framework + samples (48)
```

## License

Internal tool. Not licensed for external distribution.
